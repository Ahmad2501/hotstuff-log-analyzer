"""
lc_helpers.py - helpers shared by q4 (timeouts / leader change), q5 (event ordering) and q6 (regency analysis).

Everything here works on the parsed event table (common.load_events) and on the raw log text.  "Line" = physical line
number in the original log file.  Senders of "Sending STOP / STOPDATA / SYNC ..." lines are NOT tagged in the logs; they are
inferred from the "Received leader change message of type X for regency R from replica S" lines (causality: a message cannot
be received before it was sent) and the inference is always labelled as such.
"""
import re
from itertools import permutations
from common import *

LC_DESC = {
    'lc_timeout': 'request timed out ("The following requests timed out")',
    'lc_forward': 'timed-out request forwarded to the leader ("Forwarding requests ... to leader")',
    'lc_attempt': 'replica attempts to start a leader change ("Attempting to start leader change")',
    'lc_send_stop': 'STOP sent ("Sending STOP message to install regency R"; sender not tagged)',
    'lc_retransmit': 'STOP re-transmitted ("Re-transmitting STOP message to install regency R"; sender not tagged)',
    'lc_recv': 'leader-change message received ("Received leader change message of type T for regency R from replica S"; receiver not tagged)',
    'lc_state': '"Last regency: a, next regency: b" printed by the receiving replica (receiver not tagged)',
    'lc_send_stopdata': 'STOPDATA sent to the new leader ("Sending STOPDATA of regency R"; sender not tagged)',
    'lc_no_ooc_sync': '"No out of context SYNC for regency R" (no early SYNC was stored)',
    'lc_send_sync': 'SYNC sent by the new leader ("Sending SYNC message for regency R"; sender not tagged)',
    'lc_no_proof': '"I did not install any proof of last decided consensus -1"',
    'sync_write': 'WRITE of the re-proposed value at the higher timestamp ("Sending WRITE message for CID C, timestamp T"; sender not tagged)',
}

_raw_cache = {}


def raw_lines(i):
    """List of raw text lines of log i (index = line number - 1)."""
    if i not in _raw_cache:
        with open(LOGS[i]['path'], errors='replace') as f:
            _raw_cache[i] = f.read().split('\n')
    return _raw_cache[i]


def raw(i, line, width=170):
    t = raw_lines(i)[line - 1]
    return t[:width]


def lc_events(ev):
    return ev[ev.kind.str.startswith('lc_') | (ev.kind == 'sync_write')].copy()


def install_lines(ev):
    """{regency: first line of 'Sending SYNC message for regency R'} (the new leader has finished the synchronisation)."""
    sy = ev[ev.kind == 'lc_send_sync'].dropna(subset=['regency'])
    return {int(r): int(g.line.min()) for r, g in sy.groupby('regency')}


def first_receipts(ev, mtype, regency):
    """Distinct senders of 'Received ... type <mtype> for regency <R> from replica S' in order of FIRST receipt.
    Returns DataFrame: sender, first_line, last_line, n_receipts, rank."""
    d = ev[(ev.kind == 'lc_recv') & (ev.mtype == mtype) & (ev.regency == regency)].dropna(subset=['sender'])
    if not len(d):
        return pd.DataFrame(columns=['sender', 'first_line', 'last_line', 'n_receipts', 'rank'])
    g = d.groupby(d.sender.astype(int)).line.agg(first_line='min', last_line='max', n_receipts='size').reset_index()
    g = g.sort_values('first_line').reset_index(drop=True)
    g['rank'] = np.arange(1, len(g) + 1)
    return g


def send_inference(ev, send_kind, mtype, regency):
    """Infer which replica sent each untagged 'Sending <mtype> ... regency R' line (send_kind = 'lc_send_stop' or
    'lc_send_stopdata').  Causality rule: a replica X can only have sent its message on a line BEFORE the first line that
    shows X's message being received ('Received ... type <mtype> for regency R from replica X').  All assignments of the
    send lines to the observed senders that respect this rule are enumerated (<= 4! = 24).
    Returns a DataFrame with one row per send line: candidate senders (union over all feasible assignments), number of
    feasible assignments, assigned_sender (only when unique), the number of distinct senders whose message had already been
    received (anywhere) before the send line, and - for STOP - role = starter / joiner (starter = the send is preceded
    within 8 lines by a not yet matched 'Attempting to start leader change' line)."""
    sends = ev[(ev.kind == send_kind) & (ev.regency == regency)].sort_values('line')
    attempts = ev[ev.kind == 'lc_attempt'].sort_values('line')
    rec = ev[(ev.kind == 'lc_recv') & (ev.mtype == mtype) & (ev.regency == regency)].dropna(subset=['sender'])
    fr = rec.groupby(rec.sender.astype(int)).line.min().to_dict()
    lines = [int(x) for x in sends.line]
    senders = sorted(fr)
    feas = []
    if len(lines) == len(senders):
        feas = [p for p in permutations(senders) if all(lines[j] < fr[p[j]] for j in range(len(lines)))]
    cand = []
    for j, ln in enumerate(lines):
        if feas:
            cand.append(sorted(set(p[j] for p in feas)))
        else:
            cand.append(sorted(s for s in senders if ln < fr[s]))
    used = set()
    rows = []
    for j, ln in enumerate(lines):
        role = ''
        att_line = None
        if send_kind == 'lc_send_stop':
            prev = attempts[(attempts.line < ln) & (attempts.line >= ln - 8)]
            prev = [int(x) for x in prev.line if int(x) not in used]
            role = 'joiner (no unmatched "Attempting to start leader change" line right before it)'
            if prev:
                att_line = max(prev)
                used.add(att_line)
                role = 'starter (own timeout: "Attempting to start leader change" at line %d)' % att_line
        before = rec[rec.line < ln]
        is_stop = send_kind == 'lc_send_stop'      # the "senders already seen" count is the join-threshold evidence of STOP only
        rows.append(dict(regency=regency, message=mtype, send_line=ln, candidate_senders='|'.join(str(c) for c in cand[j]),
                         n_feasible_assignments=len(feas) if feas else None,
                         assigned_sender=cand[j][0] if len(cand[j]) == 1 else None,
                         role=role, attempt_line=att_line,
                         distinct_senders_received_before=int(before.sender.nunique()) if is_stop else None,
                         senders_received_before=('|'.join(str(int(x)) for x in sorted(before.sender.unique())) if is_stop else None)))
    return pd.DataFrame(rows)


def stop_send_inference(ev, regency):
    return send_inference(ev, 'lc_send_stop', 'STOP', regency)


def pair_recv_with_state(ev):
    """Pair every 'Received leader change message ...' line with the 'Last regency: a, next regency: b' line that the same
    handler prints right after it.  Receivers are not tagged, and the lines of several replicas interleave, so the pairing is
    FIFO: the k-th state line belongs to the k-th receipt line.  This is checked, not assumed: a state line never precedes
    its receipt (the running difference receipts - states stays between 0 and 2) and the distance is at most 4 lines.
    Returns one row per receipt with the paired state (last, next) and the lines involved."""
    seq = ev[ev.kind.isin(['lc_recv', 'lc_state'])].sort_values(['line', 'pos']).reset_index(drop=True)
    recs = seq[seq.kind == 'lc_recv'].reset_index(drop=True)
    sts = seq[seq.kind == 'lc_state'].reset_index(drop=True)
    n = min(len(recs), len(sts))
    out = pd.DataFrame(dict(
        line=recs.line.astype(int), mtype=recs.mtype, regency=recs.regency.astype('Int64'), sender=recs.sender.astype('Int64')))
    out['state_line'] = pd.Series(sts.line.iloc[:n].astype(int).values, index=range(n)).reindex(out.index)
    out['last'] = pd.Series(sts['last'].iloc[:n].astype(int).values, index=range(n)).reindex(out.index)
    out['next'] = pd.Series(sts['next'].iloc[:n].astype(int).values, index=range(n)).reindex(out.index)
    return out


def pairing_check(ev):
    """Verification numbers for the FIFO pairing: (#receipts, #state lines, max running lead of receipts, min lead, max line distance)."""
    seq = ev[ev.kind.isin(['lc_recv', 'lc_state'])].sort_values(['line', 'pos'])
    lead = 0
    mx = mn = 0
    for k in seq.kind:
        lead += 1 if k == 'lc_recv' else -1
        mx, mn = max(mx, lead), min(mn, lead)
    pr = pair_recv_with_state(ev)
    dist = (pr.state_line - pr.line).max()
    return dict(n_receipts=int((seq.kind == 'lc_recv').sum()), n_state_lines=int((seq.kind == 'lc_state').sum()),
                max_receipts_ahead_of_states=mx, min_receipts_ahead_of_states=mn, max_line_distance=int(dist))


def cid_at_line(q1_log, line):
    """CID in progress at a line = CID with the latest first_propose_line <= line."""
    fp = q1_log.set_index('cid').first_propose_line.dropna().sort_values()
    m = fp[fp <= line]
    return int(m.index[-1]) if len(m) else -1
