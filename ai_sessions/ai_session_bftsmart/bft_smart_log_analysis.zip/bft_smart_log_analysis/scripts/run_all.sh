#!/usr/bin/env bash
# run_all.sh - rebuild every CSV and every plot from the four raw logs, re-check the numbers quoted in the report, write README.md.
#
# Setup: put the four logs into ../logs/ under these names (the paths are set in scripts/common.py):
#   log1_main.log     = main.log     (the only log with [replicaN] prefixes)
#   log2_main_2.log   = main_2.log
#   log3_main_3.log   = main_3.log
#   log4_main_4.log   = main_4.log
# Needs Python 3 with pandas, numpy, scipy and matplotlib.
#
# Run:  bash scripts/run_all.sh        (about 2 minutes)
# Result: csv/parsed/*.csv (event tables), csv/q0..q6_*.csv, csv/check_claims.csv, plots/q1..q6_*.png, README.md
set -euo pipefail
cd "$(dirname "$0")/.."
for f in log1_main.log log2_main_2.log log3_main_3.log log4_main_4.log; do
  if [ ! -e "logs/$f" ]; then
    echo "missing logs/$f - copy the four logs into logs/ under the names listed at the top of scripts/run_all.sh (see README.md)" >&2
    exit 1
  fi
done
for s in 00_parse_logs q1_consensus_progress q2_first_last_senders q3_views_vote_order q4_leader_change_timeouts q5_event_ordering q6_regency_analysis check_claims make_readme; do
  echo "== scripts/$s.py"
  python3 -I "scripts/$s.py"
done
echo "done: csv/ and plots/ rebuilt; csv/check_claims.csv lists every claim that was re-checked against the raw logs; README.md lists every file"
