#!/usr/bin/env python3
"""
make_readme.py - writes README.md (manifest of every script, CSV table and plot) and checks that the manifest is complete.

The manifest below is the single place where every file is described.  The script
  * reads every CSV that is listed and prints/writes its number of rows and columns (so the numbers cannot go stale),
  * fails (exit code 1) if a listed file does not exist or if a file in scripts/, csv/, csv/parsed/ or plots/ is not listed,
  * writes README.md,
  * with  --doc-md PATH  also writes the same manifest as Markdown tables (used for the "Files" section of the report).

Outputs
  README.md
  (optional) the Markdown tables given with --doc-md
Run:  python3 -I scripts/make_readme.py [--doc-md PATH]      (needs the other scripts to have run first)
"""
import os
import sys
import glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pandas as pd
from common import ROOT

# ------------------------------------------------------------------------------------------------------------------
# manifest.  Descriptions must not contain the pipe character (they go into Markdown tables).
# ------------------------------------------------------------------------------------------------------------------
SCRIPTS = [
    ('scripts/run_all.sh', 'Runs every step below in order (parse, q1 to q6, check_claims, make_readme); about 2 minutes. Stops with a message if a log is missing.'),
    ('scripts/common.py', 'Shared constants (N=4, F=1, quorum = 3rd vote, join threshold 2 STOPs, install threshold 3 STOPs), log paths, table loader and writer, plot style.'),
    ('scripts/bft_parse.py', 'Tolerant parser. Matches the tail of every message because client output overwrote or was glued to replica lines; classifies every damaged line.'),
    ('scripts/00_parse_logs.py', 'Runs the parser on the four logs. Writes csv/parsed/*.csv and csv/q0_parse_quality.csv.'),
    ('scripts/q1_consensus_progress.py', 'Q1: progress per CID, event counts, notable lines; plot q1.'),
    ('scripts/q2_first_last_senders.py', 'Q2: first and last WRITE and ACCEPT sender per CID, shares, tests, mean rank; plots q2.'),
    ('scripts/q3_views_vote_order.py', 'Q3: views (regency, leader, epoch timestamp), match of log entries with views, shared patterns, vote order; plot q3.'),
    ('scripts/lc_helpers.py', 'Helpers shared by q4 to q6: leader-change vocabulary, raw-line access, causality-based inference of untagged senders.'),
    ('scripts/q4_leader_change_timeouts.py', 'Q4: timeouts and leader change (timeline, milestones, sender inference, STOP re-transmissions, start-up race); plot q4.'),
    ('scripts/q5_event_ordering.py', 'Q5: ordering of the normal chain and of the recovery chain, causality checks, relationships from the task text; plot q5.'),
    ('scripts/q6_regency_analysis.py', 'Q6: regency inventory, STOP senders, last/next regency pairs, leader roles, recovery order, effect of the never-installed regency; plot q6.'),
    ('scripts/check_claims.py', 'Independent check: re-derives {n_claims} numbers and line numbers quoted in the report from the raw logs with plain regular expressions (no parser) and writes csv/check_claims.csv.'),
    ('scripts/make_readme.py', 'This manifest: writes README.md and checks that every file is listed and exists.'),
]

# (path, group, is_main, description)
CSVS = [
    # ---- Q0: parsing -------------------------------------------------------------------------------------------
    ('csv/q0_parse_quality.csv', 'Parsing (all questions)', False, 'One row per log: lines per damage class (blank, client-only, spliced, damaged head, torn head, lost bracket, unparsed), recovered client tokens, events with a lost head, prefix-versus-"I am" conflicts, decision lines.'),
    ('csv/parsed/events_log1.csv', 'Parsing (all questions)', False, 'Log 1: one row per recognised message: line, position in line, kind, replica and where it was read from, sender, CID, timestamp, vote count, regency, message type, last/next regency, client number, tail_only flag, line class.'),
    ('csv/parsed/events_log2.csv', 'Parsing (all questions)', False, 'Log 2: same columns as events_log1.csv (replica only where "I am:N" is printed).'),
    ('csv/parsed/events_log3.csv', 'Parsing (all questions)', False, 'Log 3: same columns as events_log1.csv (replica only where "I am:N" is printed).'),
    ('csv/parsed/events_log4.csv', 'Parsing (all questions)', False, 'Log 4: same columns as events_log1.csv (replica only where "I am:N" is printed).'),
    ('csv/parsed/issues_log1.csv', 'Parsing (all questions)', False, 'Log 1: one row per physical line that is not one clean message: line, class, raw text, note, events recovered from it. Class "unparsed" is empty.'),
    ('csv/parsed/issues_log2.csv', 'Parsing (all questions)', False, 'Log 2: same columns as issues_log1.csv.'),
    ('csv/parsed/issues_log3.csv', 'Parsing (all questions)', False, 'Log 3: same columns as issues_log1.csv.'),
    ('csv/parsed/issues_log4.csv', 'Parsing (all questions)', False, 'Log 4: same columns as issues_log1.csv.'),
    # ---- Q1 -----------------------------------------------------------------------------------------------------
    ('csv/q1_cid_progress.csv', 'Q1 progress, events, unusual lines', True, 'One row per (log, CID): first/last line, PROPOSE line, first/last decision line and count, execution lines, client-reply line, attempts, highest epoch timestamp, WRITE/ACCEPT counts, out-of-context lines, PROPOSE sender, decision latency in lines.'),
    ('csv/q1_event_counts.csv', 'Q1 progress, events, unusual lines', False, 'Count of every event type per log with the count expected for 1,000 CIDs and the difference.'),
    ('csv/q1_notable_lines.csv', 'Q1 progress, events, unusual lines', False, 'Every non-routine line (start-up banners, timeouts, forwarding, STOP, STOPDATA, SYNC, regency state lines) with line, type, regency, sender, CID, timestamp.'),
    # ---- Q2 -----------------------------------------------------------------------------------------------------
    ('csv/q2_first_last_per_cid.csv', 'Q2 first and last senders', True, 'One row per (log, CID, attempt): first/last WRITE sender and line, first/last ACCEPT sender and line, full send order, candidates where the sender is inferred, receive-order cross-check, log 1 speculative-ACCEPT order.'),
    ('csv/q2_summary_by_replica.csv', 'Q2 first and last senders', False, 'Per log, message, first/last and replica: count, share, Wilson 95 % interval, chi-square against uniform and among the followers, Holm-adjusted p.'),
    ('csv/q2_mean_rank.csv', 'Q2 first and last senders', False, 'Mean sending rank per replica (1 = first, 4 = last) with 95 % interval, Friedman test, Kendall W.'),
    ('csv/q2_pairwise_precedence.csv', 'Q2 first and last senders', False, 'Probability that replica i sends before replica j, per log and message.'),
    ('csv/q2_role_pooled.csv', 'Q2 first and last senders', False, 'Leader versus follower shares per log and pooled over the four logs, binomial test against 25 %, shares by ring offset (leader + k).'),
    ('csv/q2_cross_log_tests.csv', 'Q2 first and last senders', False, 'Chi-square homogeneity tests between logs, by replica id and by role relative to the leader.'),
    ('csv/q2_stability_blocks.csv', 'Q2 first and last senders', False, 'Shares in three blocks of 333 CIDs with a homogeneity test: is the pattern stable over the run?'),
    ('csv/q2_independence_check.csv', 'Q2 first and last senders', False, 'Lag-1 repeat rate of the first/last sender against the rate expected if CIDs were independent.'),
    ('csv/q2_method_crosscheck.csv', 'Q2 first and last senders', False, 'Agreement of the send-line definition with the receive-line definition and (log 1) the broadcast-line definition.'),
    ('csv/q2_evidence_examples.csv', 'Q2 first and last senders', False, 'Three example CIDs with the line number of every send, per log, message, position and replica.'),
    # ---- Q3 -----------------------------------------------------------------------------------------------------
    ('csv/q3_views.csv', 'Q3 views and vote order', True, 'One row per (log, view): regency, leader, epoch timestamp, leader = regency mod 4 check, membership view, status (installed or only attempted), CIDs and decided CIDs, first/last line.'),
    ('csv/q3_view_log_entry_matches.csv', 'Q3 views and vote order', False, 'Per (log, view, check): how many log-line fields agree with the view, with the mismatching lines.'),
    ('csv/q3_view_pattern_signature.csv', 'Q3 views and vote order', False, 'Per (log, view): events and lines per CID (means, medians, IQR), leader first/last shares.'),
    ('csv/q3_view_pattern_similarity.csv', 'Q3 views and vote order', False, 'Pairwise view comparison per metric: test, effect size, Holm-adjusted p, verdict.'),
    ('csv/q3_view_pattern_pairs.csv', 'Q3 views and vote order', False, 'One verdict per pair of views (how many of the 10 metrics differ).'),
    ('csv/q3_vote_order_global.csv', 'Q3 views and vote order', False, 'Per (log, view, CID, message): order in which the senders first appear in the received-vote lines (merged stream).'),
    ('csv/q3_vote_order_per_receiver_log1.csv', 'Q3 views and vote order', False, 'Log 1 only, per (CID, receiver): exact order of remote WRITEs and ACCEPTs, closing vote, position of the own ACCEPT.'),
    ('csv/q3_vote_order_summary.csv', 'Q3 views and vote order', False, 'Shares (Wilson interval) of first / last / closing vote by sender and by role, per view and vantage point.'),
    ('csv/q3_vote_order_tests.csv', 'Q3 views and vote order', False, 'Tests of the vote-order shares: uniform, followers equal, homogeneity between views.'),
    ('csv/q3_vote_position_by_role_log1.csv', 'Q3 views and vote order', False, 'Log 1: share of every position per vote group (follower at leader, leader at follower, ...) and message.'),
    ('csv/q3_vote_precedence_log1.csv', 'Q3 views and vote order', False, 'Log 1: probability that the vote of sender x arrives before the vote of sender y at the same receiver.'),
    ('csv/q3_closing_vote_inference.csv', 'Q3 views and vote order', False, 'Precision and coverage of the adjacency inference of the closing vote (log 1) and closing-vote shares by role in all logs.'),
    ('csv/q3_per_receiver_completeness_log1.csv', 'Q3 views and vote order', False, 'Log 1: how many (CID, receiver) pairs have a complete vote order, how many were completed by elimination.'),
    # ---- Q4 -----------------------------------------------------------------------------------------------------
    ('csv/q4_timeline_events.csv', 'Q4 timeouts and leader change', True, 'One row per leader-change or timeout line of logs 2 and 4 (plus an explicit no-events row for logs 1 and 3): line, phase, kind, regency, type, sender and its basis (tagged or inferred), last/next regency, CID in progress, text.'),
    ('csv/q4_keyword_counts.csv', 'Q4 timeouts and leader change', False, 'Per log and keyword (timeout, regency, STOP, SYNC, error, ...): number of lines, first and last line; backs "no events" for logs 1 and 3.'),
    ('csv/q4_summary_per_log.csv', 'Q4 timeouts and leader change', False, 'One row per log: count of every leader-change message, first/last line, regencies installed or attempted.'),
    ('csv/q4_milestones.csv', 'Q4 timeouts and leader change', False, 'Ordered milestones of the recovery in logs 2 and 4 with line numbers and distance from the first timeout.'),
    ('csv/q4_send_inference.csv', 'Q4 timeouts and leader change', False, 'Causality-based inference of the sender of each untagged STOP / STOPDATA / SYNC line: feasible assignments, assigned sender, role.'),
    ('csv/q4_retransmissions_log4.csv', 'Q4 timeouts and leader change', False, 'The 188 re-transmissions of the STOP for regency 2 in log 4: line, phase, CID in progress, gaps, receipts.'),
    ('csv/q4_startup_race.csv', 'Q4 timeouts and leader change', False, 'Start-up banners against first PROPOSE against the outcome of CID 0 at timestamp 0, one row per log.'),
    # ---- Q5 -----------------------------------------------------------------------------------------------------
    ('csv/q5_chain_per_cid.csv', 'Q5 ordering of events', True, 'One row per (log, CID, attempt): first/last line and count of every chain stage (invocation, PROPOSE, executing propose, WRITE sent, WRITE quorum, ACCEPT sent, ACCEPT quorum, decision, execution, reply), regency, leader, pooled-order verdict.'),
    ('csv/q5_chain_link_checks.csv', 'Q5 ordering of events', False, 'Per log and link L0 to L8: CIDs checked, incomplete, violations, largest inversion, example lines.'),
    ('csv/q5_chain_per_replica.csv', 'Q5 ordering of events', False, 'Exact within-replica order test per log, link and replica.'),
    ('csv/q5_causality_checks.csv', 'Q5 ordering of events', False, 'Per log: "received before sent" counts for WRITE and ACCEPT, and the position of the client reply among the execution lines.'),
    ('csv/q5_cross_cid_order.csv', 'Q5 ordering of events', False, 'Order of decisions, executions and replies across consecutive CIDs.'),
    ('csv/q5_relationship_checks.csv', 'Q5 ordering of events', False, 'The relationships listed in the task (leader PROPOSE, WRITE for every PROPOSE, same value, ...) with counts of cases that hold and exceptions.'),
    ('csv/q5_stage_offsets.csv', 'Q5 ordering of events', False, 'Per log and stage: median and quartiles of the line offset from the first PROPOSE of the CID.'),
    ('csv/q5_recovery_chain.csv', 'Q5 ordering of events', False, 'Logs 2 and 4: the recovery stages from timeout to client reply with first/last line, counts, order rule and verdict; the regency-2 side branch of log 4.'),
    ('csv/q5_cid0_attempts.csv', 'Q5 ordering of events', False, 'CID 0 at ts 0 and at ts 1 (one attempt in logs 1 and 3): stage counts, regency, leader, value digest.'),
    # ---- Q6 -----------------------------------------------------------------------------------------------------
    ('csv/q6_regency_inventory.csv', 'Q6 regency analysis', True, 'One row per (log, regency): status (installed, attempted, none), STOP/STOPDATA/SYNC counts, distinct STOP senders, thresholds reached, expected and observed leader, CIDs decided.'),
    ('csv/q6_stop_senders.csv', 'Q6 regency analysis', False, 'Per (log, message type, regency, sender): receipts, first/last line, rank, role, basis (tagged or inferred).'),
    ('csv/q6_state_pairs.csv', 'Q6 regency analysis', False, 'Counts of the "Last regency / next regency" pairs per received message type and regency, with their meaning.'),
    ('csv/q6_pairing_check.csv', 'Q6 regency analysis', False, 'Validation of the pairing between receipt lines and state lines.'),
    ('csv/q6_leader_roles.csv', 'Q6 regency analysis', False, 'PROPOSE senders per regency in effect (leader check, replaced leader) and follower activity.'),
    ('csv/q6_recovery_response_order.csv', 'Q6 regency analysis', False, 'Order of the replicas in STOP, STOPDATA, WRITE ts 1 and ACCEPT ts 1 (logs 2 and 4), tagged or inferred.'),
    ('csv/q6_regency2_effect_per_cid.csv', 'Q6 regency analysis', False, 'Per (log, CID): decision latency in lines with and without leader-change lines inside the window.'),
    ('csv/q6_regency2_effect_summary.csv', 'Q6 regency analysis', False, 'Group medians and Mann-Whitney tests (Holm-corrected) with effect sizes: did the never-installed regency change later CIDs?'),
    ('csv/q6_integrity_checks.csv', 'Q6 regency analysis', False, 'Per log: decisions, executions, replies in order, leader and timestamp of CIDs 1 and above.'),
    # ---- check --------------------------------------------------------------------------------------------------
    ('csv/check_claims.csv', 'Independent check of the report', False, 'One row per claim quoted in the report ({n_claims} claims), re-derived from the raw logs: section, claim, expected, found, status (all PASS).'),
]

PLOTS = [
    ('plots/q1_progress_and_counts.png', 'Q1', '(a) decision latency of every CID in the four logs, CID 0 highlighted; (b) normal-chain events per CID; (c) recovery events, log 2 against log 4.'),
    ('plots/q2_first_last_shares.png', 'Q2', 'Share of CIDs in which each replica is the first or last WRITE and ACCEPT sender, per log; the leader is marked, 25 % is the chance level.'),
    ('plots/q2_mean_rank.png', 'Q2', 'Mean sending rank of each replica (1 = first, 4 = last) with 95 % interval, WRITE and ACCEPT, per log.'),
    ('plots/q3_views_vote_order.png', 'Q3', '(a) first and last vote by role in every view; (b) position of the WRITE votes per receiver in log 1; (c) the same for ACCEPT.'),
    ('plots/q4_leader_change_timeline.png', 'Q4', '(a) and (b) lines 55 to 345 of logs 2 and 4: start-up, timeout, STOP, STOPDATA, SYNC, WRITE/ACCEPT at ts 1, decision; (c) cumulative STOP re-transmissions for regency 2 in log 4.'),
    ('plots/q5_event_ordering.png', 'Q5', '(a) line offset of every stage of the normal chain; (b) order violations per link and log; (c) CID 0 per attempt; (d) recovery chain of logs 2 and 4.'),
    ('plots/q6_regency_analysis.png', 'Q6', '(a) distinct STOP senders per regency against the thresholds; (b) "Last regency / next regency" pairs; (c) decision latency by group; (d) order of the replicas in the recovery.'),
]

QUESTION_ORDER = ['Parsing (all questions)', 'Q1 progress, events, unusual lines', 'Q2 first and last senders', 'Q3 views and vote order',
                  'Q4 timeouts and leader change', 'Q5 ordering of events', 'Q6 regency analysis', 'Independent check of the report']


def fill_claim_count(n):
    """Replace the {n_claims} placeholder in the manifest texts by the number of rows of csv/check_claims.csv; double quotes in the
    descriptions become single quotes (the texts go into Markdown tables and JSON)."""
    def fix(d):
        return d.replace('{n_claims}', str(n)).replace('"', "'")
    for k, (rel, d) in enumerate(SCRIPTS):
        SCRIPTS[k] = (rel, fix(d))
    for k, (rel, g, m, d) in enumerate(CSVS):
        CSVS[k] = (rel, g, m, fix(d))
    for k, (rel, q, d) in enumerate(PLOTS):
        PLOTS[k] = (rel, q, fix(d))


def shape(rel):
    d = pd.read_csv(os.path.join(ROOT, rel), low_memory=False)
    return d.shape[0], d.shape[1]


def verify():
    problems = []
    listed = [p for p, _ in SCRIPTS] + [p for p, _, _, _ in CSVS] + [p for p, _, _ in PLOTS]
    for rel in listed:
        if not os.path.isfile(os.path.join(ROOT, rel)):
            problems.append('listed but missing: ' + rel)
    on_disk = set()
    for pat in ('scripts/*', 'csv/*.csv', 'csv/parsed/*.csv', 'plots/*'):
        for f in glob.glob(os.path.join(ROOT, pat)):
            if os.path.isfile(f):
                on_disk.add(os.path.relpath(f, ROOT))
    for rel in sorted(on_disk - set(listed)):
        problems.append('on disk but not listed: ' + rel)
    for rel, _, _, desc in CSVS:
        if '|' in desc:
            problems.append('pipe character in description of ' + rel)
    return problems


def build():
    shapes = {rel: shape(rel) for rel, _, _, _ in CSVS if os.path.isfile(os.path.join(ROOT, rel))}
    fill_claim_count(shapes['csv/check_claims.csv'][0])
    n_claims = shapes['csv/check_claims.csv'][0]
    n_csv = len(CSVS)
    mains = [(g, rel) for rel, g, m, _ in CSVS if m]

    # ---------------- README.md -------------------------------------------------------------------------------
    L = []
    L.append('# BFT-SMaRt logs: consensus, views and leader change - analysis files')
    L.append('')
    L.append('Scripts, tables (CSV) and plots behind the written report. The report answers six questions about four console logs of a '
             'BFT-SMaRt run (4 replicas, 1 client, 1,000 requests): consensus progress (Q1), first and last WRITE/ACCEPT senders (Q2), views and '
             'vote order (Q3), timeouts and leader change (Q4), ordering of events (Q5) and regencies (Q6). Every claim in the report carries '
             'line numbers; the numbers are in the CSV files, and csv/check_claims.csv lists %d of them that were re-derived from the raw logs by an '
             'independent script.' % n_claims)
    L.append('')
    L.append('## Run it again')
    L.append('')
    L.append('1. Python 3 with pandas, numpy, scipy and matplotlib.')
    L.append('2. Copy the four logs into `logs/` under these names (the paths are set in `scripts/common.py`):')
    L.append('')
    L.append('   | File in `logs/` | Original name | Notes |')
    L.append('   |---|---|---|')
    L.append('   | `log1_main.log` | `main.log` | log 1, the only log with `[replicaN]` prefixes |')
    L.append('   | `log2_main_2.log` | `main_2.log` | log 2 |')
    L.append('   | `log3_main_3.log` | `main_3.log` | log 3 |')
    L.append('   | `log4_main_4.log` | `main_4.log` | log 4 |')
    L.append('')
    L.append('3. `bash scripts/run_all.sh` (about 2 minutes). It rebuilds every CSV and every plot and then re-checks the quoted numbers. '
             'In the environment where the report was produced, a clean re-run reproduced all CSV tables value for value and all plots byte for byte (other library versions may change the bytes of a plot).')
    L.append('')
    L.append('## Conventions')
    L.append('')
    L.append('- **Line** is the 1-based physical line number in the original log file. The logs have no wall-clock time, so "earlier" and "later" always '
             'mean an earlier or later line in the same file. Distances are in lines, never in seconds.')
    L.append('- **Log 1 to log 4** are `main.log`, `main_2.log`, `main_3.log` and `main_4.log`.')
    L.append('- **ts / timestamp** is the epoch timestamp of the consensus protocol for a CID (0 for a first attempt, 1 for the retry of CID 0 in logs 2 and 4), not a clock time.')
    L.append('- **View** is (regency, leader, epoch timestamp); the membership view `ID:0` is the same in all logs.')
    L.append('- **Tagged or inferred.** Only log 1 has `[replicaN]` prefixes. In the other logs a line is attributed to a replica only where `I am:N` or `from replica N` is printed; '
             'every other attribution is inferred from line order and is labelled so (columns `*_inferred`, `basis`, `sender_basis`).')
    L.append('- **Quorum** is the 3rd WRITE and the 3rd ACCEPT (N = 4, F = 1). A leader change is joined after STOPs from F + 1 = 2 distinct replicas and installed after 3.')
    L.append('')
    L.append('## Main table per question')
    L.append('')
    L.append('| Question | Main CSV | Plot |')
    L.append('|---|---|---|')
    plot_by_q = {}
    for rel, q, _ in PLOTS:
        plot_by_q.setdefault(q, []).append('`' + rel + '`')
    for g, rel in mains:
        q = g.split(' ')[0]
        L.append('| %s | `%s` | %s |' % (q, rel, ', '.join(plot_by_q.get(q, []))))
    L.append('')
    L.append('## Scripts')
    L.append('')
    L.append('| File | What it does |')
    L.append('|---|---|')
    for rel, d in SCRIPTS:
        L.append('| `%s` | %s |' % (rel, d))
    L.append('')
    L.append('## CSV tables (%d files; every column is named in the header row)' % n_csv)
    for g in QUESTION_ORDER:
        L.append('')
        L.append('### ' + g)
        L.append('')
        L.append('| File | Rows x columns | What it contains |')
        L.append('|---|---|---|')
        for rel, gg, m, d in CSVS:
            if gg == g:
                r, c = shapes[rel]
                L.append('| `%s`%s | %s x %d | %s |' % (rel, ' (main)' if m else '', format(r, ','), c, d))
    L.append('')
    L.append('## Plots (%d files, one or more per question)' % len(PLOTS))
    L.append('')
    L.append('| File | Question | What it shows |')
    L.append('|---|---|---|')
    for rel, q, d in PLOTS:
        L.append('| `%s` | %s | %s |' % (rel, q, d))
    L.append('')
    L.append('## What could still be wrong')
    L.append('')
    L.append('The report ends with a section of that name. In short: the logs have no clock, so only line order is evidence; log 1 lost characters where client text '
             'overwrote replica text; in logs 2 to 4 the receiving replica is not printed and several senders are inferred; a regency was seen installed only twice (regencies 0 and 1), '
             'so "leader = regency mod 4" is verified for those two only; each log is a single run.')
    L.append('')
    with open(os.path.join(ROOT, 'README.md'), 'w') as f:
        f.write('\n'.join(L))
    return shapes


def doc_markdown(shapes):
    L = []
    L.append('### Scripts')
    L.append('')
    L.append('| File | What it does |')
    L.append('|---|---|')
    for rel, d in SCRIPTS:
        L.append('| `%s` | %s |' % (rel, d))
    L.append('')
    L.append('### CSV tables')
    for g in QUESTION_ORDER:
        L.append('')
        L.append('**' + g + '**')
        L.append('')
        L.append('| File | Rows x columns | What it contains |')
        L.append('|---|---|---|')
        for rel, gg, m, d in CSVS:
            if gg == g:
                r, c = shapes[rel]
                L.append('| `%s`%s | %s x %d | %s |' % (rel.replace('csv/', ''), ' (main)' if m else '', format(r, ','), c, d))
    L.append('')
    L.append('### Plots')
    L.append('')
    L.append('| File | Question | What it shows |')
    L.append('|---|---|---|')
    for rel, q, d in PLOTS:
        L.append('| `%s` | %s | %s |' % (rel.replace('plots/', ''), q, d))
    return '\n'.join(L) + '\n'


def main():
    problems = verify()
    if problems:
        for p in problems:
            print('PROBLEM:', p)
        sys.exit(1)
    shapes = build()
    if '--doc-md' in sys.argv:
        out = sys.argv[sys.argv.index('--doc-md') + 1]
        with open(out, 'w') as f:
            f.write(doc_markdown(shapes))
        print('wrote', out)
    print('README.md written: %d scripts, %d CSV files, %d plots, all listed files exist, nothing unlisted' % (len(SCRIPTS), len(CSVS), len(PLOTS)))


if __name__ == '__main__':
    main()
