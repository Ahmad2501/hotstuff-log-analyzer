#!/usr/bin/env python3
"""
q3_views_vote_order.py - Question 3: analysis by VIEW (regency, leader, epoch timestamp), matches between log entries and
views, which views share the same pattern, and the order in which votes (WRITE / ACCEPT) are received.

View = (regency, leader, epoch timestamp).  The membership view "ID:0" (4 replicas, F=1) is the same in all logs
(printed once per replica at start-up: lines 21/33/45/56 in logs 1, 2, 4 and 21/33/45/57 in log 3).
Regency in effect of a CID attempt = highest regency whose "Sending SYNC message for regency R" line precedes the first
line of the attempt (0 if none).  Leader = sender of the PROPOSE lines (attempt 0) or the sender of the SYNC message
(CID 0, ts 1).  "leader = regency mod N" is CHECKED here, not assumed.

Three vantage points for vote order (the logs have no clock - line order only):
  G  global stream, all logs.  Per CID: the order in which the senders' votes FIRST appear in the received-vote lines
     ("WRITE received from:X", "ACCEPT from X").  The receiving replica is not printed in logs 2-4, so these lines are a merged stream.
  P  per receiver, log 1 only.  The [replicaN] prefix gives the receiver, so the order of the votes at each replica is exact
     (within-replica order is not disturbed by the prefix wrapper).  Votes that arrive after the decision are only logged as
     "Out of context msg" without sender: they are the LAST vote at that receiver and their sender is inferred by elimination.
  C  closing vote, inferred.  For "Sending ACCEPT message ... I am:Y" the two lines before it are
     [WRITE received from:X][I have 3, WRITE's ...] -> X closed Y's WRITE quorum (adjacency inference; its precision is
     measured in log 1, where the prefix tells the truth).

Outputs (csv/ and plots/)
  q3_views.csv                      one row per (log, view): regency, leader, ts, lines, CIDs, installed or only attempted
  q3_view_log_entry_matches.csv     per (log, view, check): how many log-line fields agree with the view (+ mismatching lines)
  q3_view_pattern_signature.csv     per (log, view): mean/median events and lines per CID
  q3_view_pattern_similarity.csv    pairwise view comparison (signature tests + vote-order tests), Holm-adjusted
  q3_view_pattern_pairs.csv         one verdict per pair of views (how many of the metrics differ)
  q3_vote_order_global.csv          per (log, view, CID): first-appearance order of the senders in the received-vote lines
  q3_vote_order_per_receiver_log1.csv  per (CID, receiver) in log 1: remote WRITE order, ACCEPT order, closing votes
  q3_vote_order_summary.csv         shares (+ Wilson CI) of first / last / closing by sender replica and by role, per vantage point
  q3_vote_order_tests.csv           tests: uniform, followers-equal, by-role homogeneity between views
  q3_closing_vote_inference.csv     precision of the adjacency inference (log 1) and closing-vote shares in logs 2-4
  plots/q3_views_vote_order.png
"""
import os
import sys
from itertools import combinations
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

CHAIN_KINDS = ['propose_recv', 'propose_exec', 'write_send', 'write_comp', 'write_count', 'write_recv', 'accept_send', 'quorum_set',
               'accept_recv', 'accept_count', 'decide', 'exec', 'spec_proof', 'spec_accept']


def holm(pvals):
    p = np.asarray(pvals, float)
    n = len(p)
    adj = np.empty(n)
    running = 0.0
    for rank, idx in enumerate(np.argsort(p)):
        running = max(running, (n - rank) * p[idx])
        adj[idx] = min(1.0, running)
    return adj


# ------------------------------------------------------------------------------------------------------------
# 1. views
# ------------------------------------------------------------------------------------------------------------
def build_views(i, ev):
    """Returns (views_df, attempt_view_df, install_lines).  attempt_view_df: (cid, attempt) -> regency, leader, ts, view_id."""
    sy = ev[ev.kind == 'lc_send_sync'].dropna(subset=['regency'])
    install_line = {0: 0}
    for r, g in sy.groupby('regency'):
        install_line[int(r)] = int(g.line.min())
    chain = ev[ev.kind.isin(['propose_recv', 'write_send', 'accept_send', 'decide', 'sync_write'])].dropna(subset=['cid'])
    pr = ev[ev.kind == 'propose_recv'].groupby('cid').sender.agg(lambda s: int(s.mode().iloc[0]))
    sync_sender = {}
    for r, g in ev[(ev.kind == 'lc_recv') & (ev.mtype == 'SYNC')].dropna(subset=['regency']).groupby('regency'):
        sync_sender[int(r)] = int(g.sender.mode().iloc[0])
    rows = []
    for (cid, att), g in chain.groupby(['cid', 'attempt']):
        cid, att = int(cid), int(att)
        first = int(g.line.min())
        reg = max([r for r, l in install_line.items() if l < first] or [0])
        if cid == 0 and att == 1:
            leader = sync_sender.get(reg, -1)
        else:
            leader = int(pr.get(cid, -1))
        rows.append(dict(cid=cid, attempt=att, regency=reg, leader=leader, epoch_ts=att, first_line=first, last_line=int(g.line.max()),
                         n_decide=int((g.kind == 'decide').sum())))
    av = pd.DataFrame(rows)
    av['view_id'] = av.apply(lambda r: 'R%d/L%d/T%d' % (r.regency, r.leader, r.epoch_ts), axis=1)
    vr = []
    for vid, g in av.groupby('view_id'):
        r0 = g.iloc[0]
        n_cids = g.cid.nunique()
        n_dec = int((g.n_decide > 0).sum())            # (CID, attempt) pairs of this view with at least one decision line
        if n_dec == len(g):
            status = 'in effect (consensus decided in it)'
        elif n_dec == 0:
            status = 'in effect (CID proposed, never decided in it)'
        else:
            status = 'in effect (%d of %d CID attempts decided in it)' % (n_dec, len(g))
        vr.append(dict(log=LOGS[i]['label'], view_id=vid, regency=int(r0.regency), leader=int(r0.leader), epoch_ts=int(r0.epoch_ts),
                       leader_equals_regency_mod_N=int(r0.leader == r0.regency % N), membership_view_id=0,
                       status=status, n_cids=n_cids, n_cids_decided=n_dec, cid_from=int(g.cid.min()), cid_to=int(g.cid.max()),
                       first_line=int(g.first_line.min()), last_line=int(g.last_line.max()),
                       note=''))
    # attempted but never installed regencies: regency numbers that appear in leader-change lines but never in "Sending SYNC"
    lc = ev[ev.kind.str.startswith('lc_') & ev.regency.notna()]
    for r, g in lc.groupby('regency'):
        r = int(r)
        if r not in install_line:
            vr.append(dict(log=LOGS[i]['label'], view_id='R%d/L%d/T?' % (r, r % N), regency=r, leader=r % N, epoch_ts=-1,
                           leader_equals_regency_mod_N=1, membership_view_id=0, status='ATTEMPTED, never installed (no SYNC)',
                           n_cids=0, n_cids_decided=0, cid_from=None, cid_to=None, first_line=int(g.line.min()), last_line=int(g.line.max()),
                           note='%d leader-change lines mention regency %d (leader would be replica %d by regency mod N)' % (len(g), r, r % N)))
    return pd.DataFrame(vr).sort_values(['regency', 'epoch_ts']).reset_index(drop=True), av, install_line


def view_matches(i, ev, av, install_line):
    """Fields printed in log lines vs the view the line belongs to."""
    out = []
    lab = LOGS[i]['label']
    amap = {(int(r.cid), int(r.attempt)): r for r in av.itertuples()}

    def add(view, check, n, nm, bad_lines):
        out.append(dict(log=lab, view_id=view, check=check, n_checked=n, n_match=n - nm, n_mismatch=nm,
                        match_pct=round(100 * (n - nm) / n, 2) if n else None,
                        mismatch_lines=';'.join(str(x) for x in bad_lines[:12])))
    d = ev[ev.cid.notna() & ev.kind.isin(['propose_recv', 'propose_exec', 'write_count', 'accept_count', 'quorum_set', 'sync_write'])].copy()
    d['view'] = [amap[(int(c), int(a))].view_id if (int(c), int(a)) in amap else None for c, a in zip(d.cid, d.attempt)]
    d['v_leader'] = [amap[(int(c), int(a))].leader if (int(c), int(a)) in amap else None for c, a in zip(d.cid, d.attempt)]
    d['v_ts'] = [amap[(int(c), int(a))].epoch_ts if (int(c), int(a)) in amap else None for c, a in zip(d.cid, d.attempt)]
    d = d[d.view.notna()]
    checks = [('propose_recv', 'PROPOSE received from:<L>  ==  leader of the view', 'sender', 'v_leader'),
              ('propose_exec', 'Executing propose ... Epoch Timestamp:<T>  ==  ts of the view', 'ts', 'v_ts'),
              ('write_count', "I have k, WRITE's ... Epoch timestamp:<T>  ==  ts of the view", 'ts', 'v_ts'),
              ('accept_count', 'I have k ACCEPTs ... Timestamp:<T>  ==  ts of the view', 'ts', 'v_ts'),
              ('quorum_set', 'Setting consensus C QuorumWrite tiemstamp to <T>  ==  ts of the view', 'ts', 'v_ts'),
              ('sync_write', 'Sending WRITE message for CID 0, timestamp <T>  ==  ts of the view', 'ts', 'v_ts')]
    for kind, label, col, vcol in checks:
        s = d[d.kind == kind]
        for view, g in s.groupby('view'):
            bad = g[g[col].astype(float) != g[vcol].astype(float)]
            add(view, label, len(g), len(bad), [int(x) for x in bad.line])
    # leader == regency mod N for every view in effect
    vv = av.drop_duplicates('view_id')
    for r in vv.itertuples():
        ok = int(r.leader == r.regency % N)
        add(r.view_id, 'leader of the view == regency mod N (N=4)', 1, 1 - ok, [])
    # leader-change lines: regency printed vs regency in effect at that line
    lc = ev[ev.kind.str.startswith('lc_') & ev.regency.notna()].copy()
    lc['in_effect'] = [max([r for r, l in install_line.items() if l < ln] or [0]) for ln in lc.line]
    lc['rt'] = lc.kind.where(lc.kind != 'lc_recv', 'lc_recv_' + lc.mtype.fillna('?').astype(str))
    spec = {'lc_send_stop': ('"Sending STOP message to install regency R": R == last synchronized regency + 1', 1),
            'lc_retransmit': ('"Re-transmitting STOP message to install regency R": R == last synchronized regency + 1', 1),
            'lc_recv_STOP': ('"Received ... STOP for regency R": R == last synchronized regency + 1', 1),
            'lc_send_stopdata': ('"Sending STOPDATA of regency R": R == last synchronized regency + 1', 1),
            'lc_recv_STOPDATA': ('"Received ... STOPDATA for regency R": R == last synchronized regency + 1', 1),
            'lc_no_ooc_sync': ('"No out of context SYNC for regency R": R == last synchronized regency + 1', 1),
            'lc_send_sync': ('"Sending SYNC message for regency R": R == regency installed by this line', 0),
            'lc_recv_SYNC': ('"Received ... SYNC for regency R": R == regency installed by the SYNC', 0)}
    for rt, (label, delta) in spec.items():
        s = lc[lc.rt == rt]
        if not len(s):
            continue
        for R, g in s.groupby('regency'):
            if rt in ('lc_send_sync', 'lc_recv_SYNC'):
                expected = g.regency.astype(int)                           # SYNC lines for R: in effect after the first install line
                bad = g[g.line < install_line.get(int(R), 1e18)] if rt == 'lc_recv_SYNC' else g.iloc[0:0]
            else:
                expected = g.in_effect + delta
                bad = g[g.regency.astype(int) != expected]
            add('leader change to regency %d' % int(R), label, len(g), len(bad), [int(x) for x in bad.line])
    return pd.DataFrame(out)


# ------------------------------------------------------------------------------------------------------------
# 2. vote order
# ------------------------------------------------------------------------------------------------------------
def first_appearance(ev, kind, av):
    """per (cid, attempt): sender -> line of the first received-vote line of that sender."""
    d = ev[(ev.kind == kind) & ev.cid.notna() & ev.sender.notna()]
    g = d.groupby([d.cid.astype(int), d.attempt.astype(int), d.sender.astype(int)]).line.min().unstack()
    g = g.reindex(columns=range(N))
    g.index.names = ['cid', 'attempt']
    return g


def describe_order(r):
    """Text of a first-appearance row: observed order, then senders that never appear (= late vote at every receiver)."""
    seen = list(r.dropna().sort_values().index)
    missing = [x for x in range(N) if x not in seen]
    txt = '>'.join(str(x) for x in seen)
    lines = '>'.join(str(int(r[x])) for x in seen)
    if missing:
        txt += ' (never counted: %s)' % ','.join(str(x) for x in missing)
        lines += ' (never counted: %s)' % ','.join(str(x) for x in missing)
    return txt, lines, seen, missing


def rank_rows(first_lines, leaders, tag, view_of, lab):
    """One row per CID attempt.  A sender whose vote never appears in a received-vote line was the late vote at every
    receiver (it only shows up as 'Out of context'); with exactly ONE such sender it is the LAST one (inferred by elimination)."""
    rows = []
    for (cid, att), r in first_lines.iterrows():
        txt, lines, seen, missing = describe_order(r)
        if len(missing) > 1:
            continue
        order = seen + missing
        L = leaders.get((cid, att), -1)
        rows.append(dict(log=lab, view_id=view_of.get((cid, att)), cid=cid, attempt=att, leader=L, message=tag,
                         order='>'.join(str(x) for x in order), lines=lines,
                         first_sender=order[0], last_sender=order[-1], last_inferred=int(bool(missing)),
                         first_role=(order[0] - L) % N, last_role=(order[-1] - L) % N))
    return rows


def per_receiver_log1(ev, av):
    """Exact per-receiver vote order in log 1 (receiver = [replicaN] prefix)."""
    ev = ev[(ev.cid >= 1) & (ev.cid <= 999) & (ev.attempt == 0)].copy()
    leaders = {int(r.cid): int(r.leader) for r in av[(av.attempt == 0)].itertuples()}
    # --- fill missing receiver of WRITE-received lines by elimination (each receiver gets one vote per other sender)
    w = ev[ev.kind == 'write_recv'].copy()
    filled = 0
    for cid, g in w.groupby('cid'):
        unk = g[g.rep.isna() & g.sender.notna()]
        if not len(unk):
            continue
        known = g[g.rep.notna()]
        for idx, row in unk.iterrows():
            X = int(row.sender)
            taken = set(int(r) for r in known[known.sender == X].rep)
            cand = [r for r in range(N) if r != X and r not in taken]
            if len(cand) == 1:
                w.loc[idx, 'rep'] = cand[0]
                known = pd.concat([known, w.loc[[idx]]])
                filled += 1
    a = ev[ev.kind == 'accept_recv'].copy()
    stream = ev[ev.rep.notna()].sort_values(['line', 'pos'])
    rows = []
    stats_ = dict(write_pairs=0, write_pairs_complete=0, accept_pairs=0, accept_pairs_complete=0, write_rep_filled_by_elimination=filled)
    for cid in range(1, 1000):
        L = leaders.get(cid, -1)
        for R in range(N):
            wr = w[(w.cid == cid) & (w.rep == R)].sort_values(['line', 'pos'])
            ar = a[(a.cid == cid) & (a.rep == R)].sort_values(['line', 'pos'])
            row = dict(cid=cid, receiver=R, leader=L, receiver_role='leader' if R == L else 'follower')
            # WRITE: three remote votes
            ws = [int(x) for x in wr.sender]
            miss = [r for r in range(N) if r != R and r not in ws]
            stats_['write_pairs'] += 1
            if len(ws) == 3 and len(set(ws)) == 3:
                row['write_order'] = '>'.join(map(str, ws)); row['write_last_inferred'] = 0
                row['write_lines'] = '>'.join(str(int(x)) for x in wr.line)
                stats_['write_pairs_complete'] += 1
            elif len(ws) == 2 and len(set(ws)) == 2 and len(miss) == 1:
                row['write_order'] = '>'.join(map(str, ws + miss)); row['write_last_inferred'] = 1      # late vote = out-of-context line
                row['write_lines'] = '>'.join(str(int(x)) for x in wr.line) + '>(ooc)'
                stats_['write_pairs_complete'] += 1
            # ACCEPT: first three counted votes (own vote included when it was counted), 4th by elimination
            asd = [int(x) for x in ar.sender]
            stats_['accept_pairs'] += 1
            if len(asd) == 3 and len(set(asd)) == 3:
                last = [r for r in range(N) if r not in asd][0]
                row['accept_order'] = '>'.join(map(str, asd + [last])); row['accept_last_inferred'] = 1
                row['accept_lines'] = '>'.join(str(int(x)) for x in ar.line) + '>(ooc)'
                row['own_accept_position'] = (asd + [last]).index(R) + 1
                stats_['accept_pairs_complete'] += 1
            # closing votes from the receiver's own stream: the event directly before the first count==3 line
            s = stream[(stream.cid == cid) & (stream.rep == R)]
            for tag, kcount, krecv in (('write', 'write_count', 'write_recv'), ('accept', 'accept_count', 'accept_recv')):
                c3 = s[(s.kind == kcount) & (s.k == 3)]
                if len(c3):
                    ln = int(c3.iloc[0].line)
                    prev = s[(s.line < ln) & (~s.kind.isin(['paxos_msg']))]
                    if len(prev):
                        p = prev.iloc[-1]
                        row['%s_closing_sender' % tag] = int(p.sender) if p.kind == krecv and pd.notna(p.sender) else (R if p.kind != krecv else None)
                        row['%s_closing_line' % tag] = int(p.line)
                        row['%s_closing_is_own_vote' % tag] = int(p.kind != krecv)
            rows.append(row)
    return pd.DataFrame(rows), stats_


def closing_by_adjacency(ev):
    """Blind adjacency inference: [WRITE received from:X][I have 3, WRITE's][Sending ACCEPT message ... I am:Y] -> (cid, Y, X, lines)."""
    seq = ev[~ev.kind.isin(['paxos_msg']) & ev.cid.notna()].reset_index(drop=True)
    out = []
    kinds = seq.kind.to_numpy()
    for j in np.where(kinds == 'accept_send')[0]:
        if j >= 2 and kinds[j - 1] == 'write_count' and kinds[j - 2] == 'write_recv':
            a, b, c = seq.iloc[j - 2], seq.iloc[j - 1], seq.iloc[j]
            if b.k == 3 and a.cid == b.cid == c.cid and pd.notna(a.sender) and pd.notna(c.rep):
                out.append(dict(cid=int(c.cid), attempt=int(c.attempt), receiver=int(c.rep), closing_sender=int(a.sender),
                                line_recv=int(a.line), line_accept=int(c.line), rep_prefix_recv=a.rep, rep_prefix_count=b.rep, rep_prefix_accept=c.rep))
    return pd.DataFrame(out)


def share_rows(lab, view, vantage, message, position, keytype, series, n_total, extra=None):
    rows = []
    for key, cnt in series.items():
        lo, hi = wilson(int(cnt), n_total)
        r = dict(log=lab, view_id=view, vantage=vantage, message=message, position=position, key_type=keytype, key=key,
                 n=int(n_total), count=int(cnt), share_pct=round(100 * cnt / n_total, 2),
                 wilson95_lo_pct=round(100 * lo, 2), wilson95_hi_pct=round(100 * hi, 2))
        if extra:
            r.update(extra)
        rows.append(r)
    return rows


def main():
    style()
    all_views, all_matches, sig_rows, glob_rows, summ, tests, closing_rows = [], [], [], [], [], [], []
    q1 = pd.read_csv(os.path.join(CSV_DIR, 'q1_cid_progress.csv'))
    cache = {}
    fa_cache = {}
    recv_counts = {}          # (log, tag, pos, view) -> role counts
    for i in LOGS:
        lab = LOGS[i]['label']
        ev = load_events(i)
        views, av, install_line = build_views(i, ev)
        all_views.append(views)
        all_matches.append(view_matches(i, ev, av, install_line))
        view_of = {(int(r.cid), int(r.attempt)): r.view_id for r in av.itertuples()}
        leaders = {(int(r.cid), int(r.attempt)): int(r.leader) for r in av.itertuples()}
        cache[i] = (ev, av)
        # ---------------- (G) global stream first-appearance order, WRITE and ACCEPT
        for tag, kind in (('WRITE', 'write_recv'), ('ACCEPT', 'accept_recv')):
            fa = first_appearance(ev, kind, av)
            fa_cache[(i, tag)] = fa
            glob_rows += rank_rows(fa, leaders, tag, view_of, lab)
    gl = pd.DataFrame(glob_rows)
    gl['view_id'] = gl['view_id'].fillna('')
    write_csv(gl, 'q3_vote_order_global.csv')           # all CIDs, including CID 0 and its two attempts in logs 2 and 4
    gl = gl[gl.cid >= 1].copy()                          # statistics below: CIDs 1..999 only (same population as Q2)

    # ---------------- shares per view (big views: >= 900 CIDs) by sender and by role
    big = gl.groupby(['log', 'view_id']).cid.nunique()
    big = big[big >= 900]
    for (lab, vid), n in big.items():
        for tag in ('WRITE', 'ACCEPT'):
            d = gl[(gl.log == lab) & (gl.view_id == vid) & (gl.message == tag)]
            n_t = len(d)
            for pos in ('first', 'last'):
                by_rep = d['%s_sender' % pos].value_counts().reindex(range(N), fill_value=0)
                by_role = d['%s_role' % pos].value_counts().reindex(range(N), fill_value=0)
                summ += share_rows(lab, vid, 'G global stream', tag, pos, 'sender_replica', by_rep, n_t)
                summ += share_rows(lab, vid, 'G global stream', tag, pos, 'role_rel_leader (0 = leader)', by_role, n_t)
                recv_counts[(lab, tag, pos, vid)] = by_role.to_numpy()
                lead = int(d.leader.iloc[0])
                fol = by_rep.drop(lead)
                chi, p = stats.chisquare(fol.values)
                chi_u, p_u = stats.chisquare(by_rep.values)
                tests.append(dict(scope='%s %s' % (lab, vid), vantage='G global stream', message=tag, position=pos,
                                  test='followers equal (chi-square, 2 dof)', n=int(fol.sum()), statistic=round(chi, 3), p_value=p))
                tests.append(dict(scope='%s %s' % (lab, vid), vantage='G global stream', message=tag, position=pos,
                                  test='all four replicas equal (chi-square, 3 dof)', n=n_t, statistic=round(chi_u, 3), p_value=p_u))
                lo, hi = wilson(int(by_role.iloc[0]), n_t)
                bt = stats.binomtest(int(by_role.iloc[0]), n_t, 0.25)
                tests.append(dict(scope='%s %s' % (lab, vid), vantage='G global stream', message=tag, position=pos,
                                  test='leader share vs 25 % (binomial)', n=n_t, statistic=round(100 * by_role.iloc[0] / n_t, 2), p_value=bt.pvalue))

    # ---------------- (P) per-receiver order in log 1 (exact within each replica's stream)
    ev1, av1 = cache[1]
    pr, pstats = per_receiver_log1(ev1, av1)
    write_csv(pr, 'q3_vote_order_per_receiver_log1.csv')
    vid1 = av1[av1.cid >= 1].view_id.iloc[0]
    # position of the leader's / followers' vote at leader and follower receivers
    pos_rows = []
    for tag, col, npos in (('WRITE', 'write_order', 3), ('ACCEPT', 'accept_order', 4)):
        d = pr.dropna(subset=[col])
        cnt = {}
        for r in d.itertuples():
            order = [int(x) for x in getattr(r, col).split('>')]
            for pos, snd in enumerate(order, 1):
                if snd == r.receiver:
                    grp = 'own vote at the %s' % r.receiver_role
                elif snd == r.leader:
                    grp = "leader's vote at a follower"
                elif r.receiver_role == 'leader':
                    grp = "follower's vote at the leader"
                else:
                    grp = "follower's vote at another follower"
                cnt.setdefault(grp, np.zeros(npos, int))[pos - 1] += 1
        for grp, arr in cnt.items():
            for pos in range(npos):
                lo, hi = wilson(int(arr[pos]), int(arr.sum()))
                pos_rows.append(dict(log='log 1', view_id=vid1, vantage='P per receiver (exact)', message=tag, vote_group=grp,
                                     position=pos + 1, n_votes=int(arr.sum()), count=int(arr[pos]),
                                     share_pct=round(100 * arr[pos] / arr.sum(), 2), wilson95_lo_pct=round(100 * lo, 2),
                                     wilson95_hi_pct=round(100 * hi, 2),
                                     position_is_inferred=int((tag == 'ACCEPT' and pos == 3) or (tag == 'WRITE' and pos == 2 and False))))
    pos_df = pd.DataFrame(pos_rows)
    write_csv(pos_df, 'q3_vote_position_by_role_log1.csv')
    # first / last / closing remote sender per receiver, by sender replica and by role, split by receiver role
    for tag, col, ncol in (('WRITE', 'write_order', 'write_closing_sender'), ('ACCEPT', 'accept_order', 'accept_closing_sender')):
        d = pr.dropna(subset=[col])
        for rrole in ('follower', 'leader', 'all receivers'):
            dd = d if rrole == 'all receivers' else d[d.receiver_role == rrole]
            orders = [[int(x) for x in s.split('>')] for s in dd[col]]
            for posname, getter in (('first', lambda o, r: [x for x in o if x != r][0] if tag == 'WRITE' else o[0]),
                                    ('last', lambda o, r: o[-1])):
                snd = pd.Series([getter(o, rc) for o, rc in zip(orders, dd.receiver)])
                if len(snd) == 0:
                    continue
                lead_series = pd.Series(dd.leader.to_numpy())
                role = ((snd - lead_series) % N)
                by_rep = snd.value_counts().reindex(range(N), fill_value=0)
                by_role = role.value_counts().reindex(range(N), fill_value=0)
                summ += share_rows('log 1', vid1, 'P per receiver (exact), receivers: %s' % rrole, tag, posname, 'sender_replica', by_rep, len(snd))
                summ += share_rows('log 1', vid1, 'P per receiver (exact), receivers: %s' % rrole, tag, posname, 'role_rel_leader (0 = leader)', by_role, len(snd))
            cs = dd[ncol].dropna().astype(int)
            if len(cs):
                crole = ((cs.to_numpy() - dd.loc[cs.index, 'leader'].to_numpy()) % N)
                by_role = pd.Series(crole).value_counts().reindex(range(N), fill_value=0)
                summ += share_rows('log 1', vid1, 'P per receiver (exact), receivers: %s' % rrole, tag, 'closing (vote that makes count 3)', 'role_rel_leader (0 = leader)', by_role, len(cs))
    # test: do the two followers differ in position at a follower receiver (exact test via pairwise precedence)?
    prec = []
    for tag, col in (('WRITE', 'write_order'), ('ACCEPT', 'accept_order')):
        d = pr.dropna(subset=[col])
        wins = np.zeros((N, N), int)
        tot = np.zeros((N, N), int)
        for r in d.itertuples():
            order = [int(x) for x in getattr(r, col).split('>')]
            pos = {s: k for k, s in enumerate(order)}
            for x, y in combinations(order, 2):
                if x in pos and y in pos:
                    a, b = (x, y) if pos[x] < pos[y] else (y, x)
                    wins[a, b] += 1
                    tot[a, b] += 1
                    tot[b, a] += 1
        for x in range(N):
            for y in range(N):
                if x != y and tot[x, y]:
                    prec.append(dict(log='log 1', vantage='P per receiver (exact)', message=tag, sender_x=x, sender_y=y,
                                     p_x_before_y=round(wins[x, y] / tot[x, y], 4), n_receiver_cids=int(tot[x, y])))
    write_csv(pd.DataFrame(prec), 'q3_vote_precedence_log1.csv')
    # followers equal among remote WRITE votes at the leader and among positions (Friedman) at followers
    d = pr.dropna(subset=['write_order'])
    for rrole in ('leader',):
        dd = d[d.receiver_role == rrole]
        # follower senders at the leader: position of each in 1..3
        mat = []
        for r in dd.itertuples():
            order = [int(x) for x in r.write_order.split('>')]
            mat.append([order.index(f) + 1 for f in range(N) if f != r.leader])
        mat = np.array(mat)
        fr = stats.friedmanchisquare(*[mat[:, k] for k in range(3)])
        tests.append(dict(scope='log 1 ' + vid1, vantage='P per receiver (exact), receiver = leader', message='WRITE', position='order of the 3 follower votes',
                          test='Friedman: the three followers arrive at the same mean position', n=len(mat), statistic=round(fr.statistic, 3), p_value=fr.pvalue))
    for tag, col in (('WRITE', 'write_order'), ('ACCEPT', 'accept_order')):
        dd = pr.dropna(subset=[col])
        dd = dd[dd.receiver_role == 'follower']
        # the two OTHER followers at a follower receiver: who is earlier? (sign test)
        a_first = 0; n = 0
        for r in dd.itertuples():
            order = [int(x) for x in getattr(r, col).split('>')]
            others = sorted(f for f in range(N) if f != r.leader and f != r.receiver)
            n += 1
            a_first += order.index(others[0]) < order.index(others[1])
        bt = stats.binomtest(int(a_first), n, 0.5)
        tests.append(dict(scope='log 1 ' + vid1, vantage='P per receiver (exact), receiver = follower', message=tag, position='order of the 2 other followers',
                          test='sign test: lower-numbered other follower first (expect 50 %)', n=n, statistic=round(100 * a_first / n, 2), p_value=bt.pvalue))
    # leader-receiver vs follower-receiver: the last-in-order sender of ACCEPT (inferred late vote) by role - kept in summary above

    # ---------------- (C) closing-vote inference by adjacency: precision in log 1, shares in logs 2-4
    adj_rows = []
    for i in LOGS:
        ev, av = cache[i]
        evm = ev[(ev.cid >= 1) & (ev.cid <= 999) & (ev.attempt == 0)]
        ad = closing_by_adjacency(evm)
        leaders = {int(r.cid): int(r.leader) for r in av[av.attempt == 0].itertuples()}
        n_accept_lines = int((evm.kind == 'accept_send').sum())
        rec = dict(log=LOGS[i]['label'], n_accept_send_lines=n_accept_lines, n_adjacent_triples=len(ad),
                   coverage_pct=round(100 * len(ad) / n_accept_lines, 1))
        if LOGS[i]['prefixed'] and len(ad):
            same = ((ad.rep_prefix_recv == ad.receiver) & (ad.rep_prefix_count == ad.receiver)).sum()
            rec['precision_same_replica_pct'] = round(100 * same / len(ad), 1)
            # compare with the exact closing sender from the receiver's own stream
            ex = pr.dropna(subset=['write_closing_sender']).set_index(['cid', 'receiver']).write_closing_sender
            m = ad.join(ex, on=['cid', 'receiver'])
            m = m.dropna(subset=['write_closing_sender'])
            rec['agree_with_exact_closing_sender_pct'] = round(100 * (m.closing_sender == m.write_closing_sender).mean(), 1)
        if len(ad):
            ad['leader'] = ad.cid.map(leaders)
            ad['role'] = (ad.closing_sender - ad.leader) % N
            ad['receiver_role'] = np.where(ad.receiver == ad.leader, 'leader', 'follower')
            for rr in ('follower', 'leader'):
                s = ad[ad.receiver_role == rr]
                by_role = s.role.value_counts().reindex(range(N), fill_value=0)
                for k in range(N):
                    rec['closer_role%d_at_%s_receivers_pct' % (k, rr)] = round(100 * by_role[k] / len(s), 1) if len(s) else None
                rec['n_at_%s_receivers' % rr] = len(s)
        adj_rows.append(rec)
    # exact shares from log 1 receiver streams, same layout
    d = pr.dropna(subset=['write_closing_sender']).copy()
    d['role'] = (d.write_closing_sender.astype(int) - d.leader) % N
    rec = dict(log='log 1 (exact, from [replicaN] streams)', n_accept_send_lines=len(d), n_adjacent_triples=len(d), coverage_pct=100.0)
    for rr in ('follower', 'leader'):
        s = d[d.receiver_role == rr]
        by_role = s.role.value_counts().reindex(range(N), fill_value=0)
        for k in range(N):
            rec['closer_role%d_at_%s_receivers_pct' % (k, rr)] = round(100 * by_role[k] / len(s), 1)
        rec['n_at_%s_receivers' % rr] = len(s)
    adj_rows.append(rec)
    write_csv(pd.DataFrame(adj_rows), 'q3_closing_vote_inference.csv')

    # ---------------- view pattern signature (per CID) and pairwise similarity of the big views
    sig_views = {}
    nonrep = {}
    for i in LOGS:
        iss = pd.read_csv(os.path.join(PARSED_DIR, 'issues_log%d.csv' % i), low_memory=False)
        nonrep[i] = np.sort(iss[iss.klass.isin(['client_only', 'blank'])].line.to_numpy())
    for i in LOGS:
        ev, av = cache[i]
        lab = LOGS[i]['label']
        qq = q1[(q1.log == lab)].set_index('cid')
        for vid, g in av[(av.cid >= 1) | (av.attempt == 0)].groupby('view_id'):
            cids = sorted(int(c) for c in g.cid)
            cids_main = [c for c in cids if c >= 1]
            if len(cids_main) < 100:
                continue
            q = qq.loc[cids_main]
            span = (q.last_line - q.first_line)
            nr = nonrep[i]
            skip_span = np.searchsorted(nr, q.last_line.to_numpy(), side='right') - np.searchsorted(nr, q.first_line.to_numpy(), side='left')
            skip_lat = np.searchsorted(nr, q.first_decide_line.to_numpy(), side='right') - np.searchsorted(nr, q.first_propose_line.to_numpy(), side='left')
            rspan = span.to_numpy() - skip_span                       # replica lines only (client-only and blank lines removed)
            rlat = q.decide_latency_lines.to_numpy() - skip_lat
            sig_views[(lab, vid)] = dict(span=span.to_numpy(), lat=q.decide_latency_lines.to_numpy(), wrecv=q.n_write_recv.to_numpy(), ooc=q.n_ooc.to_numpy(),
                                         rspan=rspan, rlat=rlat)
            sig_rows.append(dict(log=lab, view_id=vid, n_cids=len(cids_main), cid_from=min(cids_main), cid_to=max(cids_main),
                                 propose_lines_per_cid=4, write_send_per_cid=4, accept_send_per_cid=4, decide_lines_per_cid=4, exec_lines_per_cid=4,
                                 mean_write_recv_per_cid=round(q.n_write_recv.mean(), 3), mean_accept_recv_per_cid=round(q.n_accept_recv.mean(), 3),
                                 mean_out_of_context_per_cid=round(q.n_ooc.mean(), 3),
                                 median_lines_per_cid=float(span.median()), iqr_lines_per_cid='%d-%d' % (span.quantile(.25), span.quantile(.75)),
                                 median_replica_lines_per_cid=float(np.median(rspan)), mean_client_or_blank_lines_per_cid=round(float(skip_span.mean()), 3),
                                 median_propose_to_decide_lines=float(q.decide_latency_lines.median()),
                                 median_replica_lines_propose_to_decide=float(np.median(rlat)),
                                 leader_write_first_pct=round(100 * (gl[(gl.log == lab) & (gl.view_id == vid) & (gl.message == 'WRITE')].first_role == 0).mean(), 1),
                                 leader_write_last_pct=round(100 * (gl[(gl.log == lab) & (gl.view_id == vid) & (gl.message == 'WRITE')].last_role == 0).mean(), 1),
                                 leader_accept_first_pct=round(100 * (gl[(gl.log == lab) & (gl.view_id == vid) & (gl.message == 'ACCEPT')].first_role == 0).mean(), 1),
                                 leader_accept_last_pct=round(100 * (gl[(gl.log == lab) & (gl.view_id == vid) & (gl.message == 'ACCEPT')].last_role == 0).mean(), 1)))
    # single-CID views (CID 0 in logs 2 and 4)
    for i in (2, 4):
        ev, av = cache[i]
        lab = LOGS[i]['label']
        for r in av[av.cid == 0].itertuples():
            wtxt, wl, _, _ = describe_order(fa_cache[(i, 'WRITE')].loc[(0, r.attempt)])
            atxt, al, _, _ = describe_order(fa_cache[(i, 'ACCEPT')].loc[(0, r.attempt)])
            sig_rows.append(dict(log=lab, view_id=r.view_id, n_cids=1, cid_from=0, cid_to=0,
                                 note='single CID (CID 0, attempt %d, lines %d-%d): senders in order of first appearance in the received-vote lines - '
                                      'WRITE %s (lines %s); ACCEPT %s (lines %s)' % (r.attempt, r.first_line, r.last_line, wtxt, wl, atxt, al)))
    write_csv(pd.DataFrame(sig_rows), 'q3_view_pattern_signature.csv')

    sim = []
    keys = list(sig_views)
    for (ka, kb) in combinations(keys, 2):
        A, B = sig_views[ka], sig_views[kb]
        for metric, label in (('span', 'lines spanned by a CID (first to last line)'), ('lat', 'lines from PROPOSE to first decision'),
                              ('rspan', 'REPLICA lines spanned by a CID (client-only and blank lines removed)'),
                              ('rlat', 'REPLICA lines from PROPOSE to first decision (client-only and blank lines removed)'),
                              ('wrecv', 'WRITE-received lines per CID'), ('ooc', 'out-of-context lines per CID')):
            u = stats.mannwhitneyu(A[metric], B[metric])
            rrb = abs(2 * u.statistic / (len(A[metric]) * len(B[metric])) - 1)          # rank-biserial correlation
            sim.append(dict(view_a='%s %s' % ka, view_b='%s %s' % kb, metric=label, test='Mann-Whitney U', median_a=float(np.median(A[metric])),
                            median_b=float(np.median(B[metric])), mean_a=round(float(np.mean(A[metric])), 3), mean_b=round(float(np.mean(B[metric])), 3),
                            statistic=round(u.statistic, 1), p_value=u.pvalue, effect_size=round(rrb, 3), effect_measure='rank-biserial |r|'))
        for tag in ('WRITE', 'ACCEPT'):
            for pos in ('first', 'last'):
                ca, cb = recv_counts[(ka[0], tag, pos, ka[1])], recv_counts[(kb[0], tag, pos, kb[1])]
                tab = np.vstack([ca, cb])
                tab = tab[:, tab.sum(axis=0) > 0]
                chi, p, dof, _ = stats.chi2_contingency(tab)
                sim.append(dict(view_a='%s %s' % ka, view_b='%s %s' % kb,
                                metric='%s received-vote order: %s sender by ROLE (leader, L+1, L+2, L+3)' % (tag, pos),
                                test='chi-square homogeneity (3 dof)', median_a=None, median_b=None, statistic=round(chi, 2), p_value=p,
                                effect_size=round(float(np.sqrt(chi / tab.sum())), 3), effect_measure="Cramer's V"))
    sdf = pd.DataFrame(sim)
    sdf['p_holm'] = holm(sdf.p_value.values)
    sig = sdf.p_holm < 0.01
    sdf['effect_label'] = np.where(sdf.effect_size < 0.1, 'negligible (<0.1)', np.where(sdf.effect_size < 0.3, 'small (0.1-0.3)', 'medium or larger (>=0.3)'))
    sdf['differs'] = np.where(~sig, 'no significant difference',
                              np.where(sdf.effect_size < 0.1, 'significant (Holm p<0.01) but negligible effect', 'DIFFERS: significant (Holm p<0.01) and effect >= 0.1'))
    write_csv(sdf, 'q3_view_pattern_similarity.csv')
    prs = []
    for (a, b), g in sdf.groupby(['view_a', 'view_b'], sort=False):
        d = g[g.differs.str.startswith('DIFFERS')]
        wk = g[g.differs.str.startswith('significant')]
        prs.append(dict(view_a=a, view_b=b, n_metrics=len(g), n_differ=len(d), n_significant_but_negligible=len(wk),
                        differing_metrics=' | '.join(d.metric + ' (' + d.effect_size.astype(str) + ')'),
                        verdict='same pattern on every metric' if len(d) == 0 else 'different pattern: %d of %d metrics differ (effect >= 0.1)' % (len(d), len(g))))
    write_csv(pd.DataFrame(prs), 'q3_view_pattern_pairs.csv')

    # ---------------- write remaining tables
    write_csv(pd.concat(all_views, ignore_index=True), 'q3_views.csv')
    write_csv(pd.concat(all_matches, ignore_index=True), 'q3_view_log_entry_matches.csv')
    write_csv(pd.DataFrame(summ), 'q3_vote_order_summary.csv')
    write_csv(pd.DataFrame(tests), 'q3_vote_order_tests.csv')
    pd.Series(pstats).to_csv(os.path.join(CSV_DIR, 'q3_per_receiver_completeness_log1.csv'), header=['value'], index_label='metric')
    print('per-receiver completeness (log 1):', pstats)
    plot_q3(recv_counts, pos_df)
    return gl, pr, pos_df, recv_counts


def plot_q3(recv_counts, pos_df):
    """Figure: (a) role-relative first/last shares of the received-vote order by view; (b) log 1 per-receiver vote positions."""
    import matplotlib.gridspec as gridspec
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list('seq', ['#f1f6fd', SEQ[1], SEQ[3], SEQ[5], SEQ[6]])
    views = [('log 1', 'R0/L0/T0'), ('log 3', 'R0/L0/T0'), ('log 2', 'R1/L1/T0'), ('log 4', 'R1/L1/T0')]
    groups = [('WRITE', 'first', 'WRITE: first sender'), ('WRITE', 'last', 'WRITE: last sender'),
              ('ACCEPT', 'first', 'ACCEPT: first sender'), ('ACCEPT', 'last', 'ACCEPT: last sender')]
    fig = plt.figure(figsize=(13.2, 9.8))
    gs = gridspec.GridSpec(2, 2, height_ratios=[1.0, 1.2], hspace=0.42, wspace=0.34, figure=fig, left=0.13, right=0.985, top=0.95, bottom=0.17)
    ax = fig.add_subplot(gs[0, :])
    nrow, ncol = len(views), 4 * len(groups)
    xs = []
    for gi in range(len(groups)):
        for k in range(4):
            xs.append(gi * 4.5 + k)
    for ri, (lab, vid) in enumerate(views):
        for gi, (tag, pos, _) in enumerate(groups):
            cnt = recv_counts[(lab, tag, pos, vid)]
            sh = 100 * cnt / cnt.sum()
            for k in range(4):
                x = gi * 4.5 + k
                col = cmap(min(sh[k] / 65.0, 1.0))
                ax.add_patch(plt.Rectangle((x - 0.47, ri - 0.45), 0.94, 0.9, facecolor=col, edgecolor=SURFACE, linewidth=1.5))
                ax.text(x, ri, '%.0f' % sh[k], ha='center', va='center', fontsize=8.5, color='white' if sh[k] / 65.0 > 0.45 else TEXT)
    ax.set_xlim(-0.7, 3 * 4.5 + 3.7)
    ax.set_ylim(nrow - 0.4, -0.75)
    ax.set_yticks(range(nrow))
    ax.set_yticklabels(['%s  (%s)\n%s' % (lab, LOGS[int(lab.split()[1])]['file'], vid) for lab, vid in views], fontsize=8.5)
    ax.set_xticks(xs)
    ax.set_xticklabels(['leader', 'L+1', 'L+2', 'L+3'] * 4, fontsize=7.8)
    ax.xaxis.set_ticks_position('bottom')
    for gi, (_, _, title) in enumerate(groups):
        ax.text(gi * 4.5 + 1.5, -0.62, title, ha='center', va='bottom', fontsize=9, color=TEXT, fontweight='bold')
    ax.grid(False)
    ax.set_title('(a) Order in which the senders\' votes first appear in the received-vote lines - share of CIDs 1-999 (%), by ROLE of the sender (L = leader of the view)',
                 fontsize=10, pad=24)
    for sp in ax.spines.values():
        sp.set_visible(False)
    # (b)/(c) per-receiver positions, log 1
    colors = {1: SEQ[6], 2: SEQ[4], 3: SEQ[2], 4: SEQ[0]}
    short = {"leader's vote at a follower": 'leader \u2192 follower', "follower's vote at another follower": 'follower \u2192 follower',
             "follower's vote at the leader": 'follower \u2192 leader', 'own vote at the leader': 'own vote, at leader',
             'own vote at the follower': 'own vote, at follower'}
    for col, (tag, npos, groups_b, ttl) in enumerate([
            ('WRITE', 3, ["leader's vote at a follower", "follower's vote at another follower", "follower's vote at the leader"],
             '(b) WRITE - position of each vote among the 3 remote votes\nat one receiver (log 1; receiver = [replicaN] prefix)'),
            ('ACCEPT', 4, ['own vote at the leader', 'own vote at the follower', "leader's vote at a follower", "follower's vote at another follower", "follower's vote at the leader"],
             '(c) ACCEPT - position among the 4 votes at one receiver\n(own vote included; 4th = late vote, inferred by elimination)')]):
        axb = fig.add_subplot(gs[1, col])
        d = pos_df[pos_df.message == tag]
        nvotes = {}
        for gi, g in enumerate(groups_b):
            dd = d[d.vote_group == g].sort_values('position')
            left = 0.0
            for r in dd.itertuples():
                axb.barh(gi, r.share_pct, left=left, height=0.62, color=colors[r.position], edgecolor=SURFACE, linewidth=2.0)
                if r.share_pct >= 7:
                    axb.text(left + r.share_pct / 2, gi, '%.0f' % r.share_pct, ha='center', va='center', fontsize=8.5,
                             color='white' if r.position <= 2 else TEXT)
                left += r.share_pct
            nvotes[g] = int(dd.n_votes.iloc[0])
        axb.set_yticks(range(len(groups_b)))
        axb.set_yticklabels(['%s\n(n = %s)' % (short[g], format(nvotes[g], ',')) for g in groups_b], fontsize=8.6)
        axb.set_ylim(len(groups_b) - 0.4, -0.6)
        axb.set_xlim(0, 100)
        axb.set_xlabel('% of the votes in the group')
        axb.set_title(ttl, fontsize=9.6, loc='left', pad=8)
        axb.grid(axis='y', visible=False)
        handles = [plt.Rectangle((0, 0), 1, 1, color=colors[k]) for k in range(1, npos + 1)]
        names = ['1st vote', '2nd vote', '3rd vote', '4th vote (late)'][:npos]
        axb.legend(handles, names, ncol=npos, loc='upper center', bbox_to_anchor=(0.5, -0.17), fontsize=8)
    fig.text(0.5, 0.012, 'A \u2192 B: the vote sent by A, as received at replica B (in (b) and (c) B is identified by the [replicaN] prefix of log 1).   '
             'Darker = larger share in (a).  Rows 2-4 of (a) are the same pattern on every metric; row 1 (log 1) shows a stronger leader-first share.',
             ha='center', fontsize=8, color=TEXT2)
    save(fig, 'q3_views_vote_order.png')


if __name__ == '__main__':
    main()
