#!/usr/bin/env python3
"""
check_claims.py - independent re-check of the numbers and line numbers that the report quotes.

It reads ONLY the four raw log files (no parsed tables, no bft_parse.py) and re-derives each claim with plain regular
expressions, so a mistake in the parser cannot hide a wrong number in the report.  Every claim is printed as PASS or FAIL
with the value quoted in the report ("expected") and the value found in the raw text ("found").

Output   csv/check_claims.csv   columns: section, claim, expected, found, status
Run      python3 -I scripts/check_claims.py       (exit code 1 if any claim fails)

Conventions (same as everywhere): line = 1-based physical line number of the original log file; log 1 = main.log (has
[replicaN] prefixes), log 2 = main_2.log, log 3 = main_3.log, log 4 = main_4.log.  Tail-based regular expressions are used
for the message types of the normal chain, because in log 1 the head of some lines was overwritten by client text.
"""
import os
import re
import sys
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import LOGS, CSV_DIR          # only the file locations are taken from common.py

import pandas as pd

# ------------------------------------------------------------------------------------------------------------------
# 1. read the raw logs and collect every occurrence of every message type once: (line, offset in line, groups)
# ------------------------------------------------------------------------------------------------------------------
TEXT = {}
for _i, _info in LOGS.items():
    with open(_info['path'], 'rb') as _f:
        _data = _f.read()
    assert b'\r' not in _data, 'carriage returns would change the line numbering'
    _lines = _data.decode('utf-8', errors='replace').split('\n')
    if _lines and _lines[-1] == '':
        _lines.pop()
    TEXT[_i] = _lines

# name: (cheap literal pre-filter, regex)
PATS = {
    'propose':  ('consensus cId:', re.compile(r'from:(\d+), for consensus cId:(\d+), I am:(\d+)')),
    'pexec':    ('Epoch Timestamp:', re.compile(r'cId:(\d+), Epoch Timestamp:(\d+)')),
    'wsend':    ('WRITE for cId:', re.compile(r'WRITE for cId:(\d+), I am:(\d+)')),
    'syncwrite': ('Sending WRITE message for CID', re.compile(r'Sending WRITE message for CID (\d+), timestamp (\d+)')),
    'wq':       ("WRITE's for cId:", re.compile(r"3, WRITE's for cId:(\d+), Epoch timestamp:(\d+)")),
    'asend':    ('ACCEPT message, cId:', re.compile(r'ACCEPT message, cId:(\d+), I am:(\d+)')),
    'aq':       ('ACCEPTs for cId:', re.compile(r'3 ACCEPTs for cId:(\d+), Timestamp:(\d+)')),
    'aq2':      ('ACCEPTs for cId:', re.compile(r'2 ACCEPTs for cId:(\d+), Timestamp:(\d+)')),
    'arecv':    (' for consensus ', re.compile(r'(?:from|rom|om|m) (\d+) for consensus (\d+)')),
    'wrecv':    ('for consensus cId:', re.compile(r'from:(\d+), for consensus cId:(\d+)(?!\d|, I am)')),
    'decide':   ('Deciding consensus', re.compile(r'Deciding consensus (\d+)')),
    'value':    ('Current value = ', re.compile(r'Current value = (\d+)')),
    'inv':      ('Invocation ', re.compile(r'Invocation (\d+)')),
    'reply':    ('returned value: ', re.compile(r'returned value: (\d+)')),
    'ooc':      ('Out of context msg with id', re.compile(r'Out of context msg with id (\d+)')),
    'paxos':    ('Processing paxos msg with id', re.compile(r'Processing paxos msg with id (\d+)')),
    'timeout':  ('The following requests timed out', re.compile(r'The following requests timed out')),
    'forward':  ('Forwarding requests', re.compile(r'Forwarding requests')),
    'attempt':  ('Attempting to start leader change', re.compile(r'Attempting to start leader change')),
    'sendstop': ('Sending STOP message', re.compile(r'Sending STOP message to install regency (\d+)')),
    'retx':     ('Re-transmitting STOP', re.compile(r'Re-transmitting STOP message to install regency (\d+)')),
    'recv':     ('Received leader change message',
                 re.compile(r'Received leader change message of type (\w+) for regency (\d+) from replica (\d+)')),
    'state':    ('Last regency', re.compile(r'Last regency: (\d+), next regency: (\d+)')),
    'sendstopdata': ('Sending STOPDATA', re.compile(r'Sending STOPDATA of regency (\d+)')),
    'nooocsync': ('No out of context SYNC', re.compile(r'No out of context SYNC for regency (\d+)')),
    'sendsync': ('Sending SYNC message', re.compile(r'Sending SYNC message for regency (\d+)')),
    'noproof':  ('I did not install any proof', re.compile(r'I did not install any proof')),
    'banner':   ('Ready to process operations', re.compile(r'Ready to process operations')),
    'uptodate': ('Replica state is up to date', re.compile(r'Replica state is up to date')),
    'membership': ('In current view', re.compile(r'In current view: ID:(\d+); F:(\d+); Processes:0')),
    'reqtimeout': ('requestTimeout', re.compile(r'requestTimeout = (\d+)')),
    'bad':      ('', re.compile(r'Exception|ERROR|WARN|SEVERE')),
}

EV = {i: {k: [] for k in PATS} for i in LOGS}
REGEX_LINES = {i: {} for i in LOGS}
for i in LOGS:
    for n, t in enumerate(TEXT[i], 1):
        for name, (lit, rx) in PATS.items():
            if lit and lit not in t:
                continue
            for m in rx.finditer(t):
                EV[i][name].append((n, m.start(), tuple(int(g) if g is not None and g.isdigit() else g for g in m.groups())))


# Log 1 only: client text overwrote characters of replica lines.  Two repairs are needed, both of them plain text rules.
# (a) reply tokens: the digits of a replica line whose head was lost can stand right behind the reply number
#     (", returned value: 1042 ACCEPTs for cId:103" is reply 104 followed by the count 2).  The reply number is taken as the
#     shortest prefix of the digit string that is larger than the previous reply.
for _i in LOGS:
    _prev = 0
    _fixed = []
    for _n, _o, _g in EV[_i]['reply']:
        _s = str(_g[0])
        _v = next((int(_s[:k]) for k in range(1, len(_s) + 1) if int(_s[:k]) > _prev), int(_s))
        _fixed.append((_n, _o, (_v,)))
        _prev = _v
    EV[_i]['reply'] = _fixed
# (b) decision lines: "Deciding consensus C" can lose (part of) the word "Deciding"; the tail "consensus C" at the end of the line
#     stays.  The only other lines that end in "consensus C" read "... for consensus C" or "... from consensus C".
DEC = {}
for _i in LOGS:
    if _i == 1:
        DEC[_i] = []
        for _n, _t in enumerate(TEXT[_i], 1):
            _m = re.search(r'(?<!for )(?<!from )consensus (\d+)\s*$', _t)
            if _m:
                DEC[_i].append((_n, _m.start(), (int(_m.group(1)),)))
    else:
        DEC[_i] = EV[_i]['decide']


def lines(i, name, where=None):
    """Line numbers of an event type (one entry per occurrence, in file order); where(groups) filters."""
    return [n for n, _, g in EV[i][name] if where is None or where(g)]


# ------------------------------------------------------------------------------------------------------------------
# 2. the claims
# ------------------------------------------------------------------------------------------------------------------
ROWS = []


def claim(section, text, expected, found):
    if isinstance(expected, float) or isinstance(found, float):
        ok = abs(float(expected) - float(found)) < 0.051          # percentages are quoted with one decimal
    else:
        ok = expected == found
    ROWS.append(dict(section=section, claim=text, expected=str(expected), found=str(found), status='PASS' if ok else 'FAIL'))


def per_log(section, text, expected_by_log, getter):
    for i in LOGS:
        if i in expected_by_log:
            claim(section, '%s [log %d]' % (text, i), expected_by_log[i], getter(i))


# ---- format and start-up ---------------------------------------------------------------------------------------
per_log('format', 'number of physical lines', {1: 127966, 2: 128229, 3: 128128, 4: 129668}, lambda i: len(TEXT[i]))
per_log('format', 'lines containing Exception, ERROR, WARN or SEVERE', {1: 0, 2: 0, 3: 0, 4: 0}, lambda i: len(lines(i, 'bad')))
per_log('format', 'lines "In current view: ID:0; F:1; Processes:0..."', {1: [21, 33, 45, 56], 2: [21, 33, 45, 56], 3: [21, 33, 45, 57], 4: [21, 33, 45, 56]},
        lambda i: lines(i, 'membership', lambda g: g[0] == 0 and g[1] == 1))
per_log('format', 'view IDs printed other than ID:0', {1: 0, 2: 0, 3: 0, 4: 0}, lambda i: len(lines(i, 'membership', lambda g: g[0] != 0)))
per_log('format', 'lines "requestTimeout = 2000"', {1: [16, 28, 40, 51], 2: [16, 28, 40, 51], 3: [16, 28, 40, 52], 4: [16, 28, 40, 51]},
        lambda i: lines(i, 'reqtimeout', lambda g: g[0] == 2000))
per_log('startup', '"Ready to process operations" banner lines', {1: [62, 67, 72, 77], 2: [62, 71, 153, 161], 3: [62, 67, 72, 77], 4: [62, 67, 153, 161]},
        lambda i: lines(i, 'banner'))
per_log('startup', '"Replica state is up to date" lines', {1: [59, 64, 69, 74], 2: [59, 68, 150, 158], 3: [59, 64, 69, 74], 4: [59, 64, 150, 158]},
        lambda i: lines(i, 'uptodate'))
per_log('startup', 'first "PROPOSE received" line', {1: 84, 2: 76, 3: 84, 4: 75}, lambda i: min(lines(i, 'propose')))

# ---- Q1 counts --------------------------------------------------------------------------------------------------
per_log('Q1', '"PROPOSE received" lines', {1: 4000, 2: 4000, 3: 4000, 4: 4000}, lambda i: len(EV[i]['propose']))
per_log('Q1', '"Sending WRITE for cId" lines', {1: 4000, 2: 4000, 3: 4000, 4: 4000}, lambda i: len(EV[i]['wsend']))
per_log('Q1', 'WRITE-quorum lines ("I have 3, WRITE\'s")', {1: 3999, 2: 4002, 3: 4000, 4: 4002}, lambda i: len(EV[i]['wq']))
per_log('Q1', '"Sending ACCEPT message" lines', {1: 4000, 2: 4002, 3: 4000, 4: 4002}, lambda i: len(EV[i]['asend']))
per_log('Q1', '"ACCEPT from X for consensus C" lines', {1: 12000, 2: 12004, 3: 12000, 4: 12004}, lambda i: len(EV[i]['arecv']))
per_log('Q1', 'ACCEPT-quorum lines ("I have 3 ACCEPTs")', {1: 3999, 2: 4000, 3: 4000, 4: 4000}, lambda i: len(EV[i]['aq']))
per_log('Q1', '"Deciding consensus" lines (log 1: lines that end in "consensus C" when the head is damaged)', {1: 4000, 2: 4000, 3: 4000, 4: 4000}, lambda i: len(DEC[i]))
per_log('Q1', 'every CID has exactly 4 decision lines', {1: True, 2: True, 3: True, 4: True},
        lambda i: sorted(collections.Counter(g[0] for _, _, g in DEC[i]).items()) == [(c, 4) for c in range(1000)])
per_log('Q1', '"Current value = V" (executed request) lines', {1: 4000, 2: 4000, 3: 4000, 4: 4000}, lambda i: len(EV[i]['value']))
per_log('Q1', 'executed values 1..1000, each 4 times',
        {1: True, 2: True, 3: True, 4: True},
        lambda i: sorted(collections.Counter(g[0] for _, _, g in EV[i]['value']).items()) == [(v, 4) for v in range(1, 1001)])
per_log('Q1', '"Invocation N" tokens', {1: 220, 2: 1000, 3: 1000, 4: 1000}, lambda i: len(EV[i]['inv']))
per_log('Q1', '"returned value: V" tokens', {1: 857, 2: 1000, 3: 1000, 4: 1000}, lambda i: len(EV[i]['reply']))
per_log('Q1', 'client replies are 1..1000 in order (logs with all tokens)', {2: True, 3: True, 4: True},
        lambda i: [g[0] for _, _, g in EV[i]['reply']] == list(range(1, 1001)))
per_log('Q1', 'client replies are strictly increasing (log 1: surviving tokens)', {1: True},
        lambda i: all(a < b for a, b in zip([g[0] for _, _, g in EV[i]['reply']], [g[0] for _, _, g in EV[i]['reply']][1:])))
per_log('Q1', '"Out of context msg with id" occurrences', {2: 4881, 3: 4818, 4: 4773}, lambda i: len(EV[i]['ooc']))
per_log('Q1', '"Processing paxos msg with id" occurrences', {2: 27139, 3: 27182, 4: 27247}, lambda i: len(EV[i]['paxos']))
claim('Q1', 'log 1: decision lines whose head "Deciding" is (partly) overwritten, line numbers', [6348, 14178, 45829, 55964, 127167],
      [n for n, o, g in DEC[1] if not re.search(r'Deciding consensus \d+', TEXT[1][n - 1])])
per_log('Q1', 'CID 0: first and last decision line', {1: (168, 208), 2: (301, 322), 3: (180, 204), 4: (308, 333)},
        lambda i: (min(n for n, _, g in DEC[i] if g[0] == 0), max(n for n, _, g in DEC[i] if g[0] == 0)))
for i, (a, b) in {2: (324, 329), 4: (313, 338)}.items():
    cl = [n for n, _, g in EV[i]['value'] if g[0] == 1]
    claim('Q1', 'executions of request 1 (first, last line) [log %d]' % i, (a, b), (cl[0], cl[-1]))
per_log('Q1', 'CID 999: first and last decision line',
        {1: (127928, 127963), 2: (128189, 128225), 3: (128100, 128118), 4: (128385, 128410)},
        lambda i: (min(n for n, _, g in DEC[i] if g[0] == 999), max(n for n, _, g in DEC[i] if g[0] == 999)))
claim('Q1', 'reply "returned value: 1" line (log 2, log 3, log 4)', (330, 211, 339),
      tuple(min(n for n, _, g in EV[i]['reply'] if g[0] == 1) for i in (2, 3, 4)))
claim('Q1', 'last client reply "returned value: 1000" (log 2, log 3, log 4)', (128202, 128126, 128414),
      tuple(max(n for n, _, g in EV[i]['reply'] if g[0] == 1000) for i in (2, 3, 4)))
claim('Q1', 'log 1: last surviving reply is value 999 on line 127748', (999, 127748),
      (EV[1]['reply'][-1][2][0], EV[1]['reply'][-1][0]))

# ---- CID 0, first attempt (logs 2 and 4) --------------------------------------------------------------------------
for i, exp in {2: dict(propose=[76, 78, 81, 97], wsend=[84, 87, 100, 124], wq=[104, 114], asend=[105, 115], aq2=[147, 148]),
               4: dict(propose=[75, 78, 81, 88], wsend=[84, 91, 94, 105], wq=[101, 115], asend=[102, 116], aq2=[147, 149])}.items():
    cut = min(lines(i, 'syncwrite'))
    for name, val in exp.items():
        claim('Q4/Q5', 'CID 0 at ts 0, lines of %s [log %d]' % (name, i), val,
              [n for n, _, g in EV[i][name] if g[0] == 0 and n < cut])

# ---- leader change (logs 2 and 4) ----------------------------------------------------------------------------------
for i in (1, 3):
    for name in ('timeout', 'forward', 'attempt', 'sendstop', 'retx', 'recv', 'state', 'sendstopdata', 'nooocsync', 'sendsync', 'noproof', 'syncwrite'):
        claim('Q4', 'leader-change line type "%s" occurs [log %d]' % (name, i), 0, len(EV[i][name]))
    claim('Q4', 'lines containing the word "regency" [log %d]' % i, 0, sum(1 for t in TEXT[i] if 'regency' in t.lower()))
LC = {
    2: dict(timeout=[163, 165, 167, 169, 171, 174], forward=[164, 166, 168, 170], attempt=[172, 175],
            sendstop=[173, 176, 185, 190], sendstopdata=[197, 203, 204], nooocsync=[198, 205, 206], sendsync=[213],
            noproof=[214, 224, 225, 233], syncwrite=[221, 226, 236, 258]),
    4: dict(timeout=[163, 165, 167, 169, 171, 174, 195], forward=[164, 166, 168, 170], attempt=[172, 175, 196],
            sendstop=[173, 176, 187, 188, 201], sendstopdata=[197, 206, 216], nooocsync=[198, 207, 217], sendsync=[222],
            noproof=[223, 233, 234, 244], syncwrite=[230, 235, 245, 265]),
}
for i, d in LC.items():
    for name, val in d.items():
        claim('Q4', 'lines of "%s" [log %d]' % (name, i), val, lines(i, name))
claim('Q4', 'regencies named in the STOP sends [log 2]', [1, 1, 1, 1], [g[0] for _, _, g in EV[2]['sendstop']])
claim('Q4', 'regencies named in the STOP sends [log 4]', [1, 1, 1, 1, 2], [g[0] for _, _, g in EV[4]['sendstop']])
for i, tot in {2: 18, 4: 585}.items():
    c = collections.Counter((g[0], g[1]) for _, _, g in EV[i]['recv'])
    claim('Q4', 'received leader-change messages by (type, regency) [log %d]' % i,
          {(('STOP', 1)): 12, ('STOPDATA', 1): 3, ('SYNC', 1): 3} if i == 2 else {('STOP', 1): 12, ('STOPDATA', 1): 3, ('SYNC', 1): 3, ('STOP', 2): 567}, dict(c))
    claim('Q4', '"Last regency" lines [log %d]' % i, tot, len(EV[i]['state']))
# first receipt of each sender, STOP for regency 1
for i, exp in {2: [(0, 177), (3, 183), (1, 188), (2, 195)], 4: [(0, 177), (3, 183), (1, 191), (2, 202)]}.items():
    seen = {}
    for n, _, g in EV[i]['recv']:
        if g[0] == 'STOP' and g[1] == 1 and g[2] not in seen:
            seen[g[2]] = n
    claim('Q6', 'STOP for regency 1: first receipt per sender (replica, line) [log %d]' % i, exp, sorted(seen.items(), key=lambda kv: kv[1]))
for i, exp in {2: [(3, 201), (0, 211), (2, 222)], 4: [(2, 204), (0, 212), (3, 231)]}.items():
    claim('Q6', 'STOPDATA receipts (sender, line) [log %d]' % i, exp, [(g[2], n) for n, _, g in EV[i]['recv'] if g[0] == 'STOPDATA'])
for i, exp in {2: [215, 217, 219], 4: [224, 226, 228]}.items():
    claim('Q6', 'SYNC receipts from replica 1 [log %d]' % i, exp, [n for n, _, g in EV[i]['recv'] if g[0] == 'SYNC' and g[2] == 1])
# regency 2 (log 4)
r2 = [(n, g) for n, _, g in EV[4]['recv'] if g[1] == 2]
claim('Q6', 'STOP for regency 2 received: count, senders, first and last line [log 4]', (567, {1}, 210, 129667),
      (len(r2), {g[2] for _, g in r2}, r2[0][0], r2[-1][0]))
claim('Q6', 'regency-2 STOP re-transmissions: count, first, last line [log 4]', (188, 7306, 129662),
      (len(EV[4]['retx']), EV[4]['retx'][0][0], EV[4]['retx'][-1][0]))
rt = lines(4, 'retx')
claim('Q6', 'in-run re-transmission lines (before the last reply, line 128414) [log 4]',
      [7306, 16265, 28632, 43194, 59864, 75654, 90290, 108038, 124950], [n for n in rt if n < 128414])
claim('Q6', 'tail re-transmissions: count, first line, spacing [log 4]', (179, 128416, {7}),
      (len([n for n in rt if n > 128414]), min(n for n in rt if n > 128414), {b - a for a, b in zip([n for n in rt if n > 128414], [n for n in rt if n > 128414][1:])}))
claim('Q6', 'no STOPDATA, SYNC or STOP(2)-related WRITE for regency 2 [log 4]', (0, 0, 0),
      (sum(1 for _, _, g in EV[4]['sendstopdata'] if g[0] == 2), sum(1 for _, _, g in EV[4]['sendsync'] if g[0] == 2),
       sum(1 for _, _, g in EV[4]['recv'] if g[1] == 2 and g[0] != 'STOP')))
claim('Q6', 'lines containing the word "regency" (log 2, log 4)', (47, 1370), tuple(sum(1 for t in TEXT[i] if 'regency' in t.lower()) for i in (2, 4)))
claim('Q6', 'lines containing "regency 2" [log 4]', 756, sum(1 for t in TEXT[4] if 'regency 2' in t))
# FIFO pairing of receipts and state lines
for i, exp in {2: {(0, 0): 4, (0, 1): 4, (1, 1): 10}, 4: {(0, 0): 4, (0, 1): 4, (1, 1): 6, (1, 2): 4}}.items():
    seq = sorted([(n, o, 'r', g) for n, o, g in EV[i]['recv']] + [(n, o, 's', g) for n, o, g in EV[i]['state']])
    recs = [x for x in seq if x[2] == 'r']
    sts = [x for x in seq if x[2] == 's']
    lead = mx = mn = 0
    for x in seq:
        lead += 1 if x[2] == 'r' else -1
        mx, mn = max(mx, lead), min(mn, lead)
    claim('Q6', 'FIFO pairing is valid: receipts == state lines, never a state line before its receipt [log %d]' % i,
          (True, True), (len(recs) == len(sts), mn >= 0))
    c = collections.Counter(s[3] for r, s in zip(recs, sts) if r[3][1] == 1)
    claim('Q6', '(last, next) pairs of the regency-1 messages [log %d]' % i, exp, dict(c))
    claim('Q6', 'max receipts waiting / max line distance [log %d]' % i, (2, 2 if i == 2 else 4),
          (mx, max(s[0] - r[0] for r, s in zip(recs, sts))))
seq4 = sorted([(n, o, 'r', g) for n, o, g in EV[4]['recv']] + [(n, o, 's', g) for n, o, g in EV[4]['state']])
recs4 = [x for x in seq4 if x[2] == 'r']
sts4 = [x for x in seq4 if x[2] == 's']
claim('Q6', 'all 567 STOP(2) receipts pair with (1, 1) [log 4]', {(1, 1): 567},
      dict(collections.Counter(s[3] for r, s in zip(recs4, sts4) if r[3][1] == 2)))
claim('Q6', 'STOP(1) and STOPDATA(1) receipts of log 4 that pair with next regency 2: (message, line) of the receipts',
      [('STOP', 202), ('STOPDATA', 204), ('STOPDATA', 212), ('STOPDATA', 231)],
      [(r[3][0], r[0]) for r, s in zip(recs4, sts4) if s[3] == (1, 2)])
claim('Q6', 'state lines "Last regency: 1, next regency: 2" [log 4]', [203, 205, 213, 232], [s[0] for r, s in zip(recs4, sts4) if s[3] == (1, 2)])

# who could have sent the untagged STOP and STOPDATA lines: a replica cannot send after the first line that shows its message being received
from itertools import permutations


def feasible(i, send_name, mtype, regency):
    sends = [n for n, _, g in EV[i][send_name] if g[0] == regency]
    first = {}
    for n, _, g in EV[i]['recv']:
        if g[0] == mtype and g[1] == regency and g[2] not in first:
            first[g[2]] = n
    perms = [p for p in permutations(sorted(first)) if all(sends[j] < first[p[j]] for j in range(len(sends)))] if len(sends) == len(first) else []
    return sends, [sorted({p[j] for p in perms}) for j in range(len(sends))], len(perms)


for i, exp in {2: ([173, 176, 185, 190], [[0, 3], [0, 3], [1], [2]], 2), 4: ([173, 176, 187, 188], [[0, 3], [0, 3], [1, 2], [1, 2]], 4)}.items():
    claim('Q4', 'STOP sends: lines, candidate senders per line, number of feasible assignments [log %d]' % i, exp, feasible(i, 'sendstop', 'STOP', 1))
for i, exp in {2: ([197, 203, 204], [[3], [0, 2], [0, 2]], 2), 4: ([197, 206, 216], [[2], [0], [3]], 1)}.items():
    claim('Q4', 'STOPDATA sends: lines, candidate senders per line, number of feasible assignments [log %d]' % i, exp, feasible(i, 'sendstopdata', 'STOPDATA', 1))
for i, exp in {2: {185: {0, 3}, 190: {0, 1, 3}}, 4: {187: {0, 3}, 188: {0, 3}}}.items():
    claim('Q4', 'distinct STOP senders already received before each joiner STOP [log %d]' % i, exp,
          {n: {g[2] for m, _, g in EV[i]['recv'] if g[0] == 'STOP' and g[1] == 1 and m < n} for n in exp})

# CID 0 changes its 32-number value between the two attempts (Q5)
for i, (l0, v0, l1, v1) in {2: (106, [117, -29, 118], 221, [-109, -92, 110]), 4: (103, [18, 8, 10], 230, [66, 125, 119])}.items():
    a = [int(x) for x in re.search(r'value \[([-\d, ]+)', TEXT[i][l0 - 1]).group(1).split(',')]
    b = [int(x) for x in re.search(r'value \[([-\d, ]+)', TEXT[i][l1 - 1]).group(1).split(',')]
    claim('Q5', 'CID 0 value at ts 0 (line %d) and ts 1 (line %d): first three numbers, 32 numbers each, different [log %d]' % (l0, l1, i),
          (v0, v1, 32, 32, True), (a[:3], b[:3], len(a), len(b), a != b))

# ---- lines that are not clean (the "Lines that could not be parsed" section) ------------------------------------------------
per_log('parse', 'empty physical lines', {1: 567, 2: 356, 3: 385, 4: 397}, lambda i: sum(1 for t in TEXT[i] if t == ''))
per_log('parse', 'lines that hold only client text (", returned value: N" or "Invocation N")', {1: 19, 2: 966, 3: 957, 4: 954},
        lambda i: sum(1 for t in TEXT[i] if re.fullmatch(r'(, returned value: \d+|Invocation \d+)\s*', t)))
claim('parse', 'log 1: the two torn quorum lines (CID 140 lines 18104-18105, CID 665 lines 85273-85274)',
      ['[replica2] -- I have', ", WRITE's for cId:140, Epoch timestamp:0,", '[replica2] -- I have', 'ACCEPTs for cId:665, Timestamp:0'],
      [TEXT[1][18103].strip(), TEXT[1][18104].strip(), TEXT[1][85272].strip(), TEXT[1][85273].strip()])
claim('parse', 'log 1: WRITE-count lines that start without the count digit (line, CID)',
      [(18105, 140), (36230, 282), (63715, 497), (95831, 748), (113296, 885)],
      [(n, int(re.search(r"cId:(\d+)", t).group(1))) for n, t in enumerate(TEXT[1], 1) if t.startswith(", WRITE's for cId:")])
claim('parse', 'log 1: ACCEPT-count lines that start without the count digit (line, CID)', [(85274, 665)],
      [(n, int(re.search(r"cId:(\d+)", t).group(1))) for n, t in enumerate(TEXT[1], 1) if t.startswith(' ACCEPTs for cId:')])
claim('parse', 'log 1: line 127748 holds a reply token in front of the tail of a WRITE-received line',
      ', returned value: 999eceived from:2, for consensus cId:998', TEXT[1][127747].strip())
claim('parse', 'log 1: lines that start with "replica0]" .. "replica3]" (lost bracket)', 560,
      sum(1 for t in TEXT[1] if re.match(r' ?replica\d\]', t)))

# ---- PROPOSE senders and leaders (Q3 and Q6) -------------------------------------------------------------------------
per_log('Q6', 'PROPOSE lines from replica 0 (first, last, count)', {1: (84, 127873, 4000), 2: (76, 97, 4), 3: (84, 128015, 4000), 4: (75, 88, 4)},
        lambda i: (min(n for n, _, g in EV[i]['propose'] if g[0] == 0), max(n for n, _, g in EV[i]['propose'] if g[0] == 0),
                   sum(1 for _, _, g in EV[i]['propose'] if g[0] == 0)))


def propose_from(i, rep):
    ls = [n for n, _, g in EV[i]['propose'] if g[0] == rep]
    return (min(ls), max(ls), len(ls)) if ls else None


per_log('Q6', 'PROPOSE lines from replica 1 (first, last, count)', {1: None, 2: (332, 128119, 3996), 3: None, 4: (341, 128313, 3996)},
        lambda i: propose_from(i, 1))
per_log('Q6', 'PROPOSE lines from replicas 2 and 3', {1: None, 2: None, 3: None, 4: None},
        lambda i: (propose_from(i, 2), propose_from(i, 3)) if (propose_from(i, 2) or propose_from(i, 3)) else None)
per_log('Q6', 'tagged WRITE / ACCEPT sends of replica 0 after the SYNC (regency 1)', {2: (999, 1000), 4: (999, 1000)},
        lambda i: (sum(1 for n, _, g in EV[i]['wsend'] if g[1] == 0 and n > min(lines(i, 'sendsync'))),
                   sum(1 for n, _, g in EV[i]['asend'] if g[1] == 0 and n > min(lines(i, 'sendsync')))))
per_log('Q6', 'PROPOSE lines after the SYNC that name a leader other than replica 1', {2: 0, 4: 0},
        lambda i: sum(1 for n, _, g in EV[i]['propose'] if n > min(lines(i, 'sendsync')) and g[0] != 1))
per_log('Q3', 'CIDs 1..999: all four PROPOSE lines name the same leader', {1: True, 2: True, 3: True, 4: True},
        lambda i: all(len({g[0] for _, _, g in EV[i]['propose'] if g[1] == c}) == 1 for c in range(1000)))
per_log('Q3', 'Executing propose lines: printed timestamp 0 everywhere, except none at ts 1',
        {1: (4000, 0), 2: (4000, 0), 3: (4000, 0), 4: (4000, 0)},
        lambda i: (sum(1 for _, _, g in EV[i]['pexec'] if g[1] == 0), sum(1 for _, _, g in EV[i]['pexec'] if g[1] != 0)))
per_log('Q3', 'timestamp printed by the ts-1 SYNC WRITE lines (CID 0)', {2: [(0, 1)] * 4, 4: [(0, 1)] * 4},
        lambda i: [g for _, _, g in EV[i]['syncwrite']])
per_log('Q3', 'ACCEPT-quorum lines print timestamp 1 only for CID 0 after the SYNC', {2: 4, 4: 4},
        lambda i: sum(1 for _, _, g in EV[i]['aq'] if g[1] == 1))

# ---- Q2: first and last sender -------------------------------------------------------------------------------------
LEADER = {1: 0, 2: 1, 3: 0, 4: 1}
EXPECT_Q2 = {  # leader's share (%) of CIDs 1..999: WRITE first, WRITE last, ACCEPT first, ACCEPT last
    1: (71.2, 6.2, 21.8, 23.4), 2: (62.5, 5.0, 20.4, 21.6), 3: (61.8, 7.3, 20.2, 24.7), 4: (62.5, 5.9, 21.9, 25.0)}


def order(i, name, cid):
    ev = sorted((n, o, g[1]) for n, o, g in EV[i][name] if g[0] == cid)
    return [(r, n) for n, o, r in ev]


for i in LOGS:
    f = collections.Counter()
    for cid in range(1, 1000):
        w, a = order(i, 'wsend', cid), order(i, 'asend', cid)
        if len(w) != 4 or len(a) != 4:
            f['incomplete'] += 1
            continue
        f['wf'] += w[0][0] == LEADER[i]
        f['wl'] += w[-1][0] == LEADER[i]
        f['af'] += a[0][0] == LEADER[i]
        f['al'] += a[-1][0] == LEADER[i]
    claim('Q2', 'CIDs 1..999 with 4 WRITE and 4 ACCEPT sends [log %d]' % i, 0, f['incomplete'])
    got = tuple(round(100.0 * f[k] / 999, 1) for k in ('wf', 'wl', 'af', 'al'))
    for lab, e, g in zip(('WRITE first', 'WRITE last', 'ACCEPT first', 'ACCEPT last'), EXPECT_Q2[i], got):
        claim('Q2', 'leader share of CIDs 1..999, %s, in %% [log %d]' % (lab, i), e, g)
for i, (we, ae) in {1: ([(0, 215), (2, 229), (3, 237), (1, 253)], [(3, 250), (0, 260), (1, 268), (2, 290)]),
                    2: ([(1, 336), (2, 349), (3, 351), (0, 359)], [(3, 371), (1, 381), (2, 388), (0, 397)]),
                    3: ([(0, 217), (1, 229), (2, 237), (3, 240)], [(0, 255), (3, 266), (2, 272), (1, 273)]),
                    4: ([(1, 344), (2, 354), (0, 362), (3, 365)], [(3, 386), (2, 393), (1, 396), (0, 402)])}.items():
    claim('Q2', 'CID 1 WRITE send order (replica, line) [log %d]' % i, we, order(i, 'wsend', 1))
    claim('Q2', 'CID 1 ACCEPT send order (replica, line) [log %d]' % i, ae, order(i, 'asend', 1))
claim('Q2', 'CID 0, ts 0, WRITE send order (replica, line) [log 2]', [(0, 84), (3, 87), (1, 100), (2, 124)], order(2, 'wsend', 0))
claim('Q2', 'CID 0, ts 0, WRITE send order (replica, line) [log 4]', [(0, 84), (1, 91), (3, 94), (2, 105)], order(4, 'wsend', 0))
claim('Q2', 'CID 0 ACCEPT sends, ts 0 then ts 1 (replica, line) [log 2]', [(0, 105), (1, 115), (0, 246), (1, 253), (3, 265), (2, 280)], order(2, 'asend', 0))
claim('Q2', 'CID 0 ACCEPT sends, ts 0 then ts 1 (replica, line) [log 4]', [(0, 102), (1, 116), (1, 253), (2, 257), (3, 263), (0, 278)], order(4, 'asend', 0))

# ---- Q5: pooled order tests of the chain ------------------------------------------------------------------------------
STEPS = ('propose', 'pexec', 'wsend', 'wq', 'asend', 'aq', 'decide', 'exec', 'reply')


def chain_groups(i):
    """{(cid, attempt): {step: sorted [(line, offset)]}}.  CID 0 of logs 2 and 4 has attempt 1 from the first ts-1 WRITE line on."""
    cut = min(lines(i, 'syncwrite')) if EV[i]['syncwrite'] else None
    g = collections.defaultdict(lambda: collections.defaultdict(list))

    def att(cid, n):
        return 1 if (cut is not None and cid == 0 and n >= cut) else 0
    for step in ('propose', 'pexec', 'wsend', 'wq', 'asend', 'aq'):
        for n, o, gr in EV[i][step]:
            g[(gr[0], att(gr[0], n))][step].append((n, o))
    for n, o, gr in DEC[i]:
        g[(gr[0], att(gr[0], n))]['decide'].append((n, o))
    for n, o, gr in EV[i]['syncwrite']:
        g[(0, 1)]['wsend'].append((n, o))
    # execution lines carry the request number V = CID + 1: "(k) Counter was incremented. Current value = V"
    for n, o, gr in EV[i]['value']:
        g[(gr[0] - 1, att(gr[0] - 1, n))]['exec'].append((n, o))
    for n, o, gr in EV[i]['reply']:
        g[(gr[0] - 1, att(gr[0] - 1, n))]['reply'].append((n, o))
    return g


def kth(a, b):      # k-th later line must come after the k-th earlier line; a group with different counts is incomplete, not a violation
    return len(a) == len(b) and any(y < x for x, y in zip(a, b))


def after3(a, b, m=3):   # every later line must come after the m-th earlier line
    return len(a) >= m and any(y < a[m - 1] for y in b)


LINKS = [('L1 PROPOSE before Executing propose', 'propose', 'pexec', 'k'),
         ('L2 Executing propose before Sending WRITE', 'pexec', 'wsend', 'k'),
         ('L3 three WRITE sends before the WRITE quorum', 'wsend', 'wq', 3),
         ('L4 WRITE quorum before Sending ACCEPT', 'wq', 'asend', 'k'),
         ('L5 three ACCEPT sends before the ACCEPT quorum', 'asend', 'aq', 3),
         ('L6 ACCEPT quorum before Deciding', 'aq', 'decide', 'k'),
         ('L7 Deciding before Counter was incremented', 'decide', 'exec', 'k')]
for i in LOGS:
    G = chain_groups(i)
    for name, a, b, mode in LINKS:
        viol = 0
        for key, d in G.items():
            if not d[a] or not d[b]:
                continue
            A, B = sorted(d[a]), sorted(d[b])
            if mode == 'k':
                viol += kth(A, B)
            else:
                viol += after3(A, B)
        exp = 0
        if i == 1 and name.startswith('L3'):
            exp = 50
        if i == 1 and name.startswith('L5'):
            exp = 20
        claim('Q5', '%s: CID attempts with a violation [log %d]' % (name, i), exp, viol)
    viol = n_rep = 0
    for key, d in G.items():
        if d['reply'] and len(d['exec']) >= 2:
            n_rep += 1
            viol += sorted(d['reply'])[0] < sorted(d['exec'])[1]
    exp = 788 if i == 1 else 0
    claim('Q5', 'L8 two executions before the client reply: CIDs with a violation [log %d]' % i, exp, viol)
    if i == 1:
        claim('Q5', 'L8 number of CIDs whose reply token survives [log 1]', 857, n_rep)


# ---- Q5 "Why log 1 differs": a vote received on a line before the sender's own send line ----------------------------------
# Pair = (CID, sender) with a receipt line and a send line; the receipt that counts is the first one.  For CID 0 in logs 2 and 4 only the
# first attempt is used (lines before the first "Sending SYNC message" line), because the second attempt re-sends the same votes.
def first_lines(i, name, key):
    first_sync = min(lines(i, 'sendsync'), default=None)
    d = {}
    for n, _, g in EV[i][name]:
        k = key(g)
        if k[0] == 0 and first_sync is not None and n > first_sync:
            continue
        d.setdefault(k, n)
    return d


def received_before_sent(i, recv_name, recv_key, send_name):
    recv = first_lines(i, recv_name, recv_key)                       # (cid, sender) -> first receipt line
    send = first_lines(i, send_name, lambda g: (g[0], g[1]))         # (cid, replica) -> first send line
    pairs = [k for k in recv if k in send]
    bad = [k for k in pairs if recv[k] <= send[k]]
    return len(pairs), len(bad), max([send[k] - recv[k] for k in bad], default=0), recv, send


for i in LOGS:
    wp, wb, wm, wr, ws = received_before_sent(i, 'wrecv', lambda g: (g[1], g[0]), 'wsend')
    ap, ab, am, ar, as_ = received_before_sent(i, 'arecv', lambda g: (g[1], g[0]), 'asend')
    exp_w = {1: (3954, 185, 75), 2: (3931, 0, 0), 3: (3918, 0, 0), 4: (3942, 0, 0)}[i]
    exp_a = {1: (3568, 145, 83), 2: (3506, 0, 0), 3: (3513, 0, 0), 4: (3545, 0, 0)}[i]
    claim('Q5', 'WRITE received before the sender\'s own send line: pairs, violations, largest inversion [log %d]' % i, exp_w, (wp, wb, wm))
    claim('Q5', 'ACCEPT received before the sender\'s own send line: pairs, violations, largest inversion [log %d]' % i, exp_a, (ap, ab, am))
    if i == 1:
        claim('Q5', 'log 1 example: CID 10, WRITE from replica 1 received on line, sent on line', (1397, 1406), (wr[(10, 1)], ws[(10, 1)]))
        claim('Q5', 'log 1 example: CID 18, ACCEPT from replica 1 received on line, sent on line', (2459, 2469), (ar[(18, 1)], as_[(18, 1)]))


# ---- Q3: CIDs 1..999 whose last WRITE / ACCEPT sender is inferred (only 3 distinct senders appear in the receipt lines) --------
for i in LOGS:
    exp_w = {1: 46, 2: 69, 3: 82, 4: 58}[i]
    exp_a = {1: 431, 2: 492, 3: 486, 4: 453}[i]
    senders_w, senders_a = {}, {}
    for n, _, g in EV[i]['wrecv']:
        senders_w.setdefault(g[1], set()).add(g[0])
    for n, _, g in EV[i]['arecv']:
        senders_a.setdefault(g[1], set()).add(g[0])
    claim('Q3', 'CIDs 1..999 with only 3 distinct senders in the "WRITE received" lines (last WRITE sender inferred) [log %d]' % i, exp_w,
          sum(1 for c in range(1, 1000) if len(senders_w.get(c, ())) == 3))
    claim('Q3', 'CIDs 1..999 with only 3 distinct senders in the "ACCEPT from" lines (last ACCEPT sender inferred) [log %d]' % i, exp_a,
          sum(1 for c in range(1, 1000) if len(senders_a.get(c, ())) == 3))

# ------------------------------------------------------------------------------------------------------------------
df = pd.DataFrame(ROWS)
out = os.path.join(CSV_DIR, 'check_claims.csv')
df.to_csv(out, index=False)
n_fail = int((df.status == 'FAIL').sum())
for r in ROWS:
    if r['status'] == 'FAIL':
        print('FAIL  [%s] %s\n      expected %s\n      found    %s' % (r['section'], r['claim'], r['expected'][:300], r['found'][:300]))
print('%d claims checked, %d PASS, %d FAIL  (%s)' % (len(df), len(df) - n_fail, n_fail, out))
sys.exit(1 if n_fail else 0)
