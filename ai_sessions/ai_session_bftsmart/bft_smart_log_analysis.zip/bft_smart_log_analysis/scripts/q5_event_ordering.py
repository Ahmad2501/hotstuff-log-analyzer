#!/usr/bin/env python3
"""
q5_event_ordering.py - Question 5: ordering of events.

Normal chain checked in every log (line numbers only - the logs have no clock):
    PROPOSE -> WRITE quorum -> ACCEPT -> ACCEPT quorum -> local decision -> ordered execution -> client reply
Recovery chain checked in the logs that have one (2 and 4):
    timeout -> STOP -> STOPDATA -> SYNC -> same CID at a higher timestamp -> WRITE -> ACCEPT -> DECIDE (-> execution -> reply)

How "ordered" is tested when most lines carry no replica id (logs 2-4)
  * pooled dominance test: for every CID the k-th occurrence of a later stage must be on a later line than the k-th occurrence of the
    earlier stage (a necessary condition of "every replica goes through the stages in this order"); quorum stages are compared with the
    3rd (WRITE / ACCEPT) occurrence of the stage they depend on, the client reply with the 2nd execution line (a client needs at least F+1 = 2 replies);
  * exact per-replica test where a replica id is available: log 1 ([replicaN] prefix, plus elimination when exactly one prefix of a CID is lost)
    for every stage, logs 2-4 for the stages whose text contains "I am:N" (PROPOSE received, Sending WRITE, Sending ACCEPT);
  * causality test across replicas: a message cannot be received on an earlier line than the line on which its sender logged it.

Outputs (csv/ unless stated)
  q5_chain_per_cid.csv          one row per (log, CID, attempt): first / last line and count of every stage, regency, leader, pooled-order verdict
  q5_chain_link_checks.csv      per log and link L0-L8: CIDs checked / incomplete / stage absent, violations, largest inversion, example lines
  q5_chain_per_replica.csv      per log, link and replica: exact within-replica order test (+ all stages together)
  q5_causality_checks.csv       per log: "received before sent" counts for WRITE and ACCEPT; client reply position among the execution lines
  q5_cross_cid_order.csv        per log: order of decisions / executions / replies across consecutive CIDs (pooled and exact per replica)
  q5_relationship_checks.csv    per log: the relationships listed in the task text (leader PROPOSE, WRITE for every PROPOSE, same value, ...) with counts
  q5_stage_offsets.csv          per log and stage: median / IQR of the line offset from the first PROPOSE of the CID
  q5_recovery_chain.csv         logs 2 and 4: the 16 recovery stages (+ the regency-2 side branch of log 4): first / last line, counts, order rule and verdict
  q5_cid0_attempts.csv          CID 0 at ts 0 and at ts 1 (and the single attempt of logs 1 and 3): stage counts, regency, leader, value digest
plots/q5_event_ordering.png
Run:  python3 -I scripts/q5_event_ordering.py      (needs 00_parse_logs.py first)
"""
import os
import re
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lc_helpers import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

STAGES = [  # key, event kind, k filter, label
    ('inv', 'client_inv', None, 'client "Invocation N"'),
    ('propose', 'propose_recv', None, 'PROPOSE received'),
    ('pexec', 'propose_exec', None, 'Executing propose'),
    ('wsend', 'write_send', None, 'Sending WRITE'),
    ('wq', 'write_count', 3, 'WRITE quorum ("I have 3, WRITE\'s")'),
    ('asend', 'accept_send', None, 'Sending ACCEPT'),
    ('aq', 'accept_count', 3, 'ACCEPT quorum ("I have 3 ACCEPTs")'),
    ('decide', 'decide', None, 'Deciding consensus'),
    ('exec', 'exec', None, 'Counter was incremented (execution)'),
    ('reply', 'client_ret', None, 'client ", returned value" (reply)'),
]
LINKS = [  # id, description, from, to, rule
    ('L0', 'client "Invocation N" -> first PROPOSE of CID N', 'inv', 'propose', 'first'),
    ('L1', 'PROPOSE received -> Executing propose (same replica)', 'propose', 'pexec', 'k'),
    ('L2', 'Executing propose -> Sending WRITE (same replica)', 'pexec', 'wsend', 'k'),
    ('L3', 'Sending WRITE (3 replicas) -> WRITE quorum', 'wsend', 'wq', 'n3'),
    ('L4', 'WRITE quorum -> Sending ACCEPT (same replica)', 'wq', 'asend', 'k'),
    ('L5', 'Sending ACCEPT (3 replicas) -> ACCEPT quorum', 'asend', 'aq', 'n3'),
    ('L6', 'ACCEPT quorum -> Deciding (same replica)', 'aq', 'decide', 'k'),
    ('L7', 'Deciding -> Counter incremented (same replica)', 'decide', 'exec', 'k'),
    ('L8', 'Counter incremented (2 replicas = F+1) -> client reply', 'exec', 'reply', 'n2'),
]
RULE_TEXT = {'first': 'first line of A < first line of B', 'k': 'k-th line of B > k-th line of A for k = 1..4',
             'n3': 'every line of B > 3rd line of A (3 distinct replicas must have sent)',
             'n2': 'every line of B > 2nd line of A (a client needs at least F+1 = 2 replies)'}
REPLICA_STAGES = [('propose_recv', None), ('propose_exec', None), ('write_send', None), ('write_count', 3), ('accept_send', None),
                  ('accept_count', 3), ('decide', None), ('exec', None)]
LOG1_ARTIFACT_LINKS = ('L3', 'L5', 'L8')


def arrays(ev, log_no):
    e = ev.dropna(subset=['cid']).copy()
    e['cid'] = e.cid.astype(int)
    out = {}
    for key, kind, k, _ in STAGES:
        d = e[e.kind == kind]
        if k is not None:
            d = d[d.k == k]
        if log_no == 1 and key == 'inv':
            d = d.iloc[0:0]                  # log 1: "Invocation N" tokens are garbled (phantom CIDs) -> not used
        out[key] = {kk: np.sort(g.line.values) for kk, g in d.groupby(['cid', 'attempt'])}
    return out


def eval_link(A, B, rule):
    """-> (status, violation?, inversion in lines).  status: ok / incomplete (counts differ or fewer than needed) / absent (a stage is missing)."""
    if A is None or B is None or len(A) == 0 or len(B) == 0:
        return 'absent', False, 0
    if rule == 'first':
        return 'ok', bool(B[0] <= A[0]), int(A[0] - B[0]) if B[0] <= A[0] else 0
    if rule == 'k':
        if len(A) != len(B):
            return 'incomplete', False, 0
        bad = B <= A
        return 'ok', bool(bad.any()), int((A - B)[bad].max()) if bad.any() else 0
    n = 3 if rule == 'n3' else 2
    if len(A) < n:
        return 'incomplete', False, 0
    bad = B <= A[n - 1]
    return 'ok', bool(bad.any()), int((A[n - 1] - B)[bad].max()) if bad.any() else 0


def link_checks(i, ev, arr):
    lab = LOGS[i]['label']
    keys = sorted(arr['propose'])            # (cid, attempt) with a PROPOSE: CID 0 ts 1 has none (it starts from the SYNC)
    rows, viol_by_key = [], {k: [] for k in keys}
    for lid, desc, a, b, rule in LINKS:
        chk = inc = bad = absent = 0
        mx = 0
        ex = None
        for key in keys:
            st, v, inv = eval_link(arr[a].get(key), arr[b].get(key), rule)
            if st == 'ok':
                chk += 1
                if v:
                    bad += 1
                    viol_by_key[key].append(lid)
                    mx = max(mx, inv)
                    if ex is None:
                        ex = (key, arr[a].get(key).tolist(), arr[b].get(key).tolist())
            elif st == 'incomplete':
                inc += 1
            else:
                absent += 1
        note = ''
        if i == 1 and lid == 'L0':
            note = 'not evaluated: the "Invocation N" tokens of log 1 are garbled (phantom CIDs)'
        if i == 1 and lid == 'L8':
            note = ('ARTIFACT of log 1: unprefixed client text is not in causal order with the prefixed replica lines (the reply line precedes ALL execution lines of the CID in '
                    '659 of 857 cases) or overwrites the head of an execution line; client-vs-replica line order is not comparable in log 1')
        if i == 1 and lid in ('L3', 'L5'):
            note = ('ARTIFACT of log 1: cross-replica line order is not causal there (prefixing wrapper, see q5_causality_checks.csv: 4-5 percent of '
                    'messages are "received" before they are "sent"); the exact within-replica test (q5_chain_per_replica.csv) has 0 violations')
        if i == 1 and lid in ('L4', 'L6') and inc:
            note = 'a CID with a damaged / lost line is counted as incomplete, not as a violation'
        if lid == 'L0' and i != 1:
            note = 'client text is written in causal order with the replica lines in logs 2-4'
        if lid in ('L3', 'L4', 'L5', 'L6', 'L7', 'L8') and i in (2, 4) and absent:
            note = 'CID 0 at ts 0 stops after the ACCEPT step (no ACCEPT quorum, no decision), so the later stages are absent for that (CID, ts) - see q5_cid0_attempts.csv'
        rows.append(dict(log=lab, link=lid, description=desc, rule=RULE_TEXT[rule], n_keys=len(keys), n_cids_checked=chk, n_incomplete=inc, n_stage_absent=absent,
                         n_violations=bad, pct_violations=round(100 * bad / chk, 2) if chk else None, max_inversion_lines=mx,
                         example=('CID %d ts %d: A lines %s, B lines %s' % (ex[0][0], ex[0][1], ex[1], ex[2])) if ex else '', note=note))
    return pd.DataFrame(rows), viol_by_key


def replica_table(i, ev):
    """(CID, attempt, replica) x stage -> first line.  Exact: replica from [replicaN] prefix / "I am:N" (+ elimination in log 1)."""
    e = ev.dropna(subset=['cid']).copy()
    e['cid'] = e.cid.astype(int)
    if i == 1:
        for kind in ['propose_exec', 'decide', 'exec', 'write_count', 'accept_count']:
            e = fill_by_elimination(e, kind)
    cols = {}
    for kind, k in REPLICA_STAGES:
        d = e[e.kind == kind]
        if k is not None:
            d = d[d.k == k]
        if len(d) == 0 or d.rep.notna().mean() < 0.9:
            continue
        d = d.dropna(subset=['rep'])
        cols[kind + ('3' if k else '')] = d.groupby(['cid', 'attempt', 'rep']).line.min()
    return pd.concat(cols, axis=1)


def per_replica(i, ev):
    lab = LOGS[i]['label']
    t = replica_table(i, ev)
    names = list(t.columns)
    scope = ('exact: [replicaN] prefix / "I am:N" (+ elimination when exactly one prefix of a CID is lost)' if i == 1 else 'exact for the stages that carry "I am:N"')
    rows = []
    for a, b in zip(names, names[1:]):
        d = t[[a, b]].dropna()
        for rep, g in d.groupby(level='rep'):
            rows.append(dict(log=lab, link='%s -> %s' % (a, b), replica=int(rep), n_checked=len(g), n_violations=int((g[b] <= g[a]).sum()), scope=scope))
    full = t.dropna()
    bad_any = np.any(np.column_stack([(full[b] <= full[a]).values for a, b in zip(names, names[1:])]), axis=1)
    n_rows = len(set(k[:2] for k in t.index)) * N
    rows.append(dict(log=lab, link='ALL STAGES TOGETHER (%s)' % ' -> '.join(names), replica=-1, n_checked=len(full), n_violations=int(bad_any.sum()),
                     scope='(CID, ts, replica) rows in which every listed stage is present: %d of %d' % (len(full), n_rows)))
    return pd.DataFrame(rows)


def causality(i, ev):
    lab = LOGS[i]['label']
    e = ev.dropna(subset=['cid']).copy()
    e['cid'] = e.cid.astype(int)
    rows = []

    def pair_test(send_kind, recv_kind, text):
        s = e[(e.kind == send_kind) & (e.attempt == 0)].dropna(subset=['rep']).copy()
        s['rep'] = s.rep.astype(int)
        s = s.groupby(['cid', 'rep']).line.min()
        r = e[(e.kind == recv_kind) & (e.attempt == 0)].dropna(subset=['sender']).copy()
        r['rep'] = r.sender.astype(int)
        r = r.groupby(['cid', 'rep']).line.min()
        m = pd.concat([s.rename('sent'), r.rename('first_received')], axis=1).dropna()
        bad = m[m.first_received <= m.sent]
        ok = m[m.first_received > m.sent]
        rows.append(dict(log=lab, test=text, n_pairs=len(m), n_violations=len(bad), pct=round(100 * len(bad) / len(m), 2),
                         max_inversion_lines=int((bad.sent - bad.first_received).max()) if len(bad) else 0,
                         example=('CID %d sender %d: received on line %d, sent on line %d' % (bad.index[0][0], bad.index[0][1], bad.first_received.iloc[0], bad.sent.iloc[0])) if len(bad) else '',
                         min_gap_lines_when_ok=int((ok.first_received - ok.sent).min())))
    pair_test('write_send', 'write_recv', 'WRITE received (from:X) on a line BEFORE X\'s own "Sending WRITE ... I am:X" line (same CID)')
    pair_test('accept_send', 'accept_recv', 'ACCEPT received (from X) on a line BEFORE X\'s own "Sending ACCEPT ... I am:X" line (same CID)')
    ex = e[e.kind == 'exec'].groupby('cid').line.apply(lambda s: np.sort(s.values))
    rp = e[e.kind == 'client_ret'].groupby('cid').line.min()
    pos = pd.Series([int((ex[c] < l).sum()) for c, l in rp.items() if c in ex.index])
    vc = pos.value_counts().sort_index().to_dict()
    rows.append(dict(log=lab, test='client reply line: number of execution lines of the same request that precede it (at least F+1 = 2 are needed)', n_pairs=len(pos),
                     n_violations=int((pos < 2).sum()), pct=round(100 * (pos < 2).sum() / max(len(pos), 1), 2), max_inversion_lines=None,
                     example='#execution lines before the reply -> #CIDs: %s' % vc, min_gap_lines_when_ok=None))
    return pd.DataFrame(rows)


def per_replica_cross_cid(i, ev):
    """exact: for one replica, the line of stage S for CID c+1 is later than for CID c (attempts of CID 0 in order)."""
    t = replica_table(i, ev)
    out = []
    for stage in t.columns:
        n = bad = 0
        det = []
        for rep, g in t[stage].dropna().groupby(level='rep'):
            s = g.droplevel('rep').sort_index()          # sorted by (cid, attempt)
            dif = s.diff().dropna()
            n += len(dif)
            b = int((dif <= 0).sum())
            bad += b
            det.append('replica %d: %d of %d' % (int(rep), b, len(dif)))
        out.append((stage, n, bad, '; '.join(det)))
    return out


def cross_cid(i, ev, arr):
    lab = LOGS[i]['label']
    rows = []

    def add(test, n, bad, note=''):
        rows.append(dict(log=lab, test=test, n_checked=n, n_violations=bad, note=note))
    last = {}
    for key in ('decide', 'exec'):
        d = {}
        for (cid, att), v in sorted(arr[key].items()):
            d[cid] = v                                  # the last attempt of a CID wins (CID 0: ts 1)
        last[key] = d
        name = 'decision' if key == 'decide' else 'execution'
        cids = sorted(d)
        chk = bad = bad2 = 0
        for c1, c2 in zip(cids, cids[1:]):
            A, B = d[c1], d[c2]
            if len(A) != len(B):
                continue
            chk += 1
            bad += int(np.any(B <= A))
            bad2 += int(B[0] <= A[0])
        add('pooled: k-th %s line of CID c+1 is after the k-th %s line of CID c (k = 1..4)' % (name, name), chk, bad,
            'necessary condition for "every replica makes its %s of CID c before that of CID c+1"' % name)
        add('pooled: first %s line increases with the CID' % name, chk, bad2, '')
    fd = last['decide']
    cids = sorted(fd)
    ov = sum(1 for c1, c2 in zip(cids, cids[1:]) if fd[c1][-1] > fd[c2][0])
    add('INFO (not a violation): the slowest replica decides CID c on a later line than the fastest replica decides CID c+1', len(cids) - 1, ov,
        'replicas progress independently, only the order inside one replica matters (tested exactly below where the replica is known)')
    for stage, n, bad, det in per_replica_cross_cid(i, ev):
        add('exact per replica: %s of CID c+1 is after %s of CID c' % (stage, stage), n, bad, det)
    if i != 1:
        rp = {c: v[0] for (c, att), v in arr['reply'].items()}
        iv = {c: v[0] for (c, att), v in arr['inv'].items()}
        pr = {c: v[0] for (c, att), v in arr['propose'].items() if att == 0}
        cids = sorted(rp)
        add('client reply lines increase with the CID', len(cids) - 1, sum(1 for a, b in zip(cids, cids[1:]) if rp[b] <= rp[a]))
        add('client reply of CID c is before the "Invocation" of c+1', len(cids) - 1, sum(1 for c in cids[:-1] if c + 1 in iv and iv[c + 1] <= rp[c]),
            'the client is sequential: one outstanding request at a time')
        add('client reply of CID c is before the first PROPOSE of c+1', len(cids) - 1, sum(1 for c in cids[:-1] if c + 1 in pr and pr[c + 1] <= rp[c]), '')
    else:
        rows.append(dict(log=lab, test='client reply / Invocation order across CIDs', n_checked=0, n_violations=None,
                         note='not evaluated for log 1: client text overwrites replica characters / is garbled (857 of 1000 replies, 220 "Invocation" tokens survive)'))
    return pd.DataFrame(rows)


_ARR = re.compile(r'value \[([^\]]*)\]')


def value_arrays(i, ev):
    """{(cid, ts attempt): set of 32-number value arrays printed by 'QuorumWrite ... value [...]' and 'Sending WRITE message for CID 0, timestamp 1' lines}."""
    d = ev[ev.kind.isin(['quorum_set', 'sync_write']) & ev.cid.notna()]
    out, n_bad = {}, 0
    for _, r in d.iterrows():
        m = _ARR.search(raw(i, int(r.line), 3000))
        try:
            nums = tuple(int(x) for x in m.group(1).split(','))
        except Exception:
            n_bad += 1
            continue
        if len(nums) != 32:
            n_bad += 1
            continue
        out.setdefault((int(r.cid), int(r.attempt)), set()).add(nums)
    return out, len(d), n_bad


def relationship_checks(i, ev, arr):
    lab = LOGS[i]['label']
    rows = []
    sync = install_lines(ev)

    def add(rel, text, n, ok, detail='', example=''):
        rows.append(dict(log=lab, relationship=rel, test=text, n_checked=n, n_holding=ok, n_exceptions=n - ok, detail=detail, example=example))
    # R1: PROPOSE comes from the expected leader
    p = ev[(ev.kind == 'propose_recv') & ev.sender.notna() & ev.cid.notna()].copy()
    reg = np.where((1 in sync) & (p.line > sync.get(1, 10 ** 12)), 1, 0)
    exp = reg % N
    snd = p.sender.astype(int).values
    ok = int((snd == exp).sum())
    seen = {int(r): sorted(set(int(x) for x in snd[reg == r])) for r in sorted(set(reg))}
    add('R1 valid PROPOSE from the expected leader', 'sender of "PROPOSE received from:L" == regency in effect mod N (regency 1 from the "Sending SYNC" line on)', len(p), ok,
        'senders seen per regency: %s' % seen, '' if ok == len(p) else 'first exception at line %d' % int(p.line.values[snd != exp][0]))
    g = p.groupby(['cid', 'attempt']).sender.nunique()
    add('R1 valid PROPOSE from the expected leader', 'all PROPOSE lines of one (CID, ts) name the same sender', len(g), int((g == 1).sum()))
    # R2: each replica that got the PROPOSE sends a WRITE (exact where the replica is known)
    t = replica_table(i, ev)
    if {'propose_recv', 'write_send'} <= set(t.columns):
        has_p = t.propose_recv.notna()
        both = has_p & t.write_send.notna() & (t.write_send > t.propose_recv)
        add('R2 PROPOSE -> WRITE phase', '(CID, ts, replica) with a PROPOSE that also has a later "Sending WRITE ... I am:N" line', int(has_p.sum()), int(both.sum()))
    # R3: WRITE quorum -> ACCEPT: counts per (CID, ts)
    keys = sorted(set(arr['wq']) | set(arr['asend']))
    eq = sum(1 for k in keys if len(arr['wq'].get(k, [])) == len(arr['asend'].get(k, [])))
    add('R3 WRITE quorum -> ACCEPT', '(CID, ts) in which the number of WRITE-quorum lines equals the number of "Sending ACCEPT" lines', len(keys), eq,
        'the exceptions are (CID, ts) where a damaged line lost one of the two' if eq != len(keys) else '')
    # R4: ACCEPT quorum -> decision
    keys = sorted(set(arr['aq']) | set(arr['decide']))
    eq = sum(1 for k in keys if len(arr['aq'].get(k, [])) == len(arr['decide'].get(k, [])))
    add('R4 ACCEPT quorum -> local decision', '(CID, ts) in which the number of ACCEPT-quorum lines equals the number of "Deciding consensus" lines', len(keys), eq)
    # R5: decision -> execution -> reply
    keys = sorted(set(arr['decide']) | set(arr['exec']))
    eq = sum(1 for k in keys if len(arr['decide'].get(k, [])) == len(arr['exec'].get(k, [])))
    add('R5 decision -> execution', '(CID, ts) in which the number of "Deciding consensus" lines equals the number of "Counter was incremented" lines', len(keys), eq)
    cids = sorted(set(c for c, _ in arr['exec']))
    one = sum(1 for c in cids if sum(len(arr['reply'].get((c, a), [])) for a in (0, 1)) == 1)
    add('R5 execution -> client reply', 'CIDs with exactly one client reply line', len(cids), one,
        'log 1: the missing reply tokens are lost to the capture artifacts (overwritten / garbled), not missing replies' if i == 1 else '')
    # R6: same value in the WRITE quorum; new value at ts 1
    va, nl, nbad = value_arrays(i, ev)
    multi = sum(1 for k, s in va.items() if len(s) > 1)
    add('R6 same value', '(CID, ts) whose "QuorumWrite ... value [32 numbers]" / "Sending WRITE message ... value" lines all carry the same value', len(va), len(va) - multi,
        '%d value lines read, %d unreadable (damaged by capture)' % (nl, nbad))
    allv = {}
    for k, s in va.items():
        for v in s:
            allv.setdefault(v, set()).add(k)
    dup = sum(1 for v, ks in allv.items() if len(ks) > 1)
    add('R6 same value', 'distinct value arrays that occur in only one (CID, ts) (every consensus instance has its own value)', len(allv), len(allv) - dup)
    if (0, 1) in va and (0, 0) in va:
        same = int(va[(0, 0)] == va[(0, 1)])
        add('R6 same value', 'CID 0: the value at ts 1 equals the value at ts 0', 1, same,
            'the ts-1 value is a DIFFERENT 32-number array (same client request, relayed in the STOP messages): the recovery re-proposes the request under a new value, not a copy of the ts-0 one')
    # R7: epoch timestamp
    e = ev[ev.ts.notna() & ev.cid.notna()]
    bad = e[e.ts != e.attempt]
    add('R7 epoch timestamp', 'lines with an "Epoch Timestamp / timestamp T" field whose T equals the ts attempt derived from the line position (0 everywhere, 1 for CID 0 after the SYNC)', len(e), len(e) - len(bad),
        'CIDs >= 1 are decided at ts 0 (a new consensus instance restarts at ts 0); ts values seen for CID 0: %s' % sorted(set(int(x) for x in e[e.cid == 0].ts)))
    return pd.DataFrame(rows)


def chain_table(i, ev, arr, viol_by_key):
    lab = LOGS[i]['label']
    sync = install_lines(ev)
    keys = sorted(set(k for s in arr.values() for k in s))
    prop = ev[ev.kind == 'propose_recv'].dropna(subset=['sender', 'cid'])
    rows = []
    for key in keys:
        cid, att = key
        r = dict(log=lab, cid=cid, attempt=att)
        for sk, _, _, _ in STAGES:
            a = arr[sk].get(key)
            r['%s_first' % sk] = int(a[0]) if a is not None and len(a) else None
            r['%s_last' % sk] = int(a[-1]) if a is not None and len(a) else None
            r['%s_n' % sk] = int(len(a)) if a is not None else 0
        p = prop[(prop.cid == cid) & (prop.attempt == att)]
        first_line = int(p.line.min()) if len(p) else None
        if att == 1:
            reg = 1
        else:
            reg = 1 if (1 in sync and first_line is not None and first_line > sync[1]) else 0
        r['regency'] = reg
        r['leader_from_PROPOSE_sender'] = int(p.sender.iloc[0]) if len(p) else None
        r['leader_expected_regency_mod_N'] = leader_of_regency(reg)
        r['pooled_order_violations'] = ','.join(viol_by_key.get(key, [])) if key in viol_by_key else ''
        ex = np.array(arr['exec'].get(key, []))
        r['reply_after_n_exec_lines'] = int((ex < r['reply_first']).sum()) if r['reply_first'] is not None else None
        rows.append(r)
    return pd.DataFrame(rows)


def stage_offsets(chain):
    rows = []
    c = chain[(chain.cid >= 1) & (chain.attempt == 0)]
    for lab, g in c.groupby('log'):
        for sk, _, _, label in STAGES:
            if sk == 'inv':
                continue
            f = (g['%s_first' % sk] - g.propose_first).dropna()
            l = (g['%s_last' % sk] - g.propose_first).dropna()
            if not len(f):
                continue
            rows.append(dict(log=lab, stage=sk, label=label, n_cids=len(f), median_first_offset=float(f.median()), q1_first=float(f.quantile(.25)), q3_first=float(f.quantile(.75)),
                             median_last_offset=float(l.median()), q1_last=float(l.quantile(.25)), q3_last=float(l.quantile(.75)),
                             median_occurrences_per_cid=float(g['%s_n' % sk].median()),
                             comparable='NO (log 1: unprefixed client text is not in causal order with replica lines)' if (lab == 'log 1' and sk == 'reply') else 'yes'))
    return pd.DataFrame(rows)


def short_text(i, line, width=120):
    t = raw(i, line, 400).replace('\t', ' ')
    if 'value [' in t:
        t = t[:t.index('value [') + 7] + '...]'
    return t[:width].strip()


def recovery_chain(i, ev):
    """The 16 stages of  timeout -> STOP -> STOPDATA -> SYNC -> WRITE/ACCEPT/DECIDE at ts 1 -> execution -> reply  for regency 1,
    each with the order rule that links it to its predecessor and the verdict.  Log 4 additionally has a regency-2 side branch."""
    lab = LOGS[i]['label']
    d = lc_events(ev)
    stop1 = d[(d.kind == 'lc_send_stop') & (d.regency == 1)].line.values
    last_stop1 = int(stop1.max())
    c0 = ev[(ev.cid == 0) & (ev.attempt == 1)]

    def L(df):
        return np.sort(df.line.values)

    def ep(df):                                          # lines of the regency-1 episode (up to the last STOP(1) send line)
        a = L(df)
        return a[a <= last_stop1]
    S = {
        'timeout': ep(d[d.kind == 'lc_timeout']), 'forward': ep(d[d.kind == 'lc_forward']), 'attempt': ep(d[d.kind == 'lc_attempt']),
        'stop_sent': L(d[(d.kind == 'lc_send_stop') & (d.regency == 1)]), 'stop_recv': L(d[(d.kind == 'lc_recv') & (d.mtype == 'STOP') & (d.regency == 1)]),
        'stopdata_sent': L(d[(d.kind == 'lc_send_stopdata') & (d.regency == 1)]), 'stopdata_recv': L(d[(d.kind == 'lc_recv') & (d.mtype == 'STOPDATA') & (d.regency == 1)]),
        'sync_sent': L(d[(d.kind == 'lc_send_sync') & (d.regency == 1)]), 'sync_recv': L(d[(d.kind == 'lc_recv') & (d.mtype == 'SYNC') & (d.regency == 1)]),
        'write1': L(d[d.kind == 'sync_write']), 'wq1': L(c0[(c0.kind == 'write_count') & (c0.k == 3)]), 'asend1': L(c0[c0.kind == 'accept_send']),
        'aq1': L(c0[(c0.kind == 'accept_count') & (c0.k == 3)]), 'decide1': L(c0[c0.kind == 'decide']), 'exec1': L(c0[c0.kind == 'exec']),
        'reply1': L(c0[c0.kind == 'client_ret'])}
    stop_inf = stop_send_inference(ev, 1)
    fr = first_receipts(ev, 'STOP', 1)
    third_sender_line = int(fr.sort_values('first_line').first_line.iloc[2]) if len(fr) >= 3 else None
    sd_recv = S['stopdata_recv']
    sd_senders = sorted(set(int(x) for x in d[(d.kind == 'lc_recv') & (d.mtype == 'STOPDATA') & (d.regency == 1)].sender))

    def after_all(a, ref):                              # every line of a is after `ref`
        return bool(len(a) and ref is not None and (a > ref).all())

    def kth(a, b):                                       # k-th line of b after the k-th line of a
        return bool(len(a) == len(b) and (b > a).all())
    joiners = stop_inf[stop_inf.role.str.startswith('joiner')]
    starters = stop_inf[stop_inf.role.str.startswith('starter')]
    att_ok = all(any(0 < a - t <= 2 for t in S['timeout']) for a in S['attempt'])
    R = [  # key, label, expected count, rule text, verdict, note
        ('timeout', 'request timed out (4 first timeouts + 2 second timeouts)', 6, 'first event of the episode', None,
         'the first 4 are each followed by "Forwarding requests ... to leader", the 2 later ones by "Attempting to start leader change"'),
        ('forward', 'timed-out request forwarded to the leader', 4, 'first "Forwarding" line is after the first timeout line', after_all(S['forward'][:1], S['timeout'][0]),
         'one per replica; the forward is the FIRST reaction to a timeout - no leader change yet'),
        ('attempt', 'replica attempts to start a leader change', 2, 'every "Attempting" line directly follows a (second) timeout line', att_ok,
         'the replicas whose second timeout fired first (starters, inferred 0 and 3 - see q4_send_inference.csv)'),
        ('stop_sent', 'STOP sent for regency 1', 4, 'each starter STOP follows its "Attempting" line; each joiner STOP follows >= F+1 = 2 distinct STOP senders already received',
         bool(len(starters) == 2 and (joiners.distinct_senders_received_before >= JOIN_STOPS).all()),
         '2 starters + 2 joiners = 4 distinct senders (inferred by causality; the "Sending STOP" lines carry no id)'),
        ('stop_recv', 'STOP received for regency 1', 12, 'first receipt is after the first STOP send line', after_all(S['stop_recv'][:1], S['stop_sent'][0]),
         '4 STOPs x 3 receivers; every STOP receipt names a sender (from replica S)'),
        ('stopdata_sent', 'STOPDATA sent to the new leader', 3, '3rd distinct STOP sender received (pooled) before the first STOPDATA send (2F+1 = 3 needed to install)',
         after_all(S['stopdata_sent'][:1], third_sender_line), 'sent by the 3 followers; the new leader (replica 1) uses its own STOPDATA locally (no "Sending STOPDATA" line for it)'),
        ('stopdata_recv', 'STOPDATA received by the new leader', 3, 'first receipt is after the first STOPDATA send line', after_all(S['stopdata_recv'][:1], S['stopdata_sent'][0]),
         'from replicas %s; the 3rd receipt arrives AFTER the SYNC was sent (2 receipts + the leader\'s own STOPDATA = 3 = enough)' % sd_senders),
        ('sync_sent', 'SYNC sent by the new leader', 1, 'after the 2nd STOPDATA receipt (+ own STOPDATA = 3)', bool(len(sd_recv) >= 2 and S['sync_sent'][0] > sd_recv[1]),
         '"Sending SYNC message for regency 1" = the new leader has finished synchronising'),
        ('sync_recv', 'SYNC received by the followers', 3, 'first receipt is after the SYNC send line', after_all(S['sync_recv'][:1], S['sync_sent'][0]), 'all from replica 1 (3 followers)'),
        ('write1', 'WRITE at ts 1 ("Sending WRITE message for CID 0, timestamp 1")', 4, 'first line is after the first SYNC receipt', after_all(S['write1'][:1], S['sync_recv'][0]),
         'no PROPOSE line: the SYNC carries the value; the CID restarts at the HIGHER timestamp 1'),
        ('wq1', 'WRITE quorum at ts 1 ("I have 3, WRITE\'s ... timestamp:1")', 4, 'every line is after the 3rd WRITE-at-ts-1 line', after_all(S['wq1'], int(S['write1'][2])), ''),
        ('asend1', 'ACCEPT at ts 1 ("Sending ACCEPT message, cId:0, I am:N")', 4, 'k-th ACCEPT line is after the k-th WRITE-quorum line', kth(S['wq1'], S['asend1']), ''),
        ('aq1', 'ACCEPT quorum at ts 1 ("I have 3 ACCEPTs ... Timestamp:1")', 4, 'every line is after the 3rd ACCEPT-at-ts-1 line', after_all(S['aq1'], int(S['asend1'][2])), ''),
        ('decide1', 'DECIDE ("Deciding consensus 0")', 4, 'k-th decision line is after the k-th ACCEPT-quorum line', kth(S['aq1'], S['decide1']), 'the same CID 0 is now decided - at ts 1'),
        ('exec1', 'execution ("Counter was incremented. Current value = 1")', 4, 'k-th execution line is after the k-th decision line', kth(S['decide1'], S['exec1']), ''),
        ('reply1', 'client reply (", returned value: 1")', 1, 'after the 2nd execution line', after_all(S['reply1'], int(S['exec1'][1])),
         'the request that timed out is finally answered'),
    ]
    rows = []
    for n, (key, label, exp, rule, ok, note) in enumerate(R, 1):
        a = S[key]
        rows.append(dict(log=lab, branch='regency 1 recovery (installed)', step=n, stage=label, first_line=int(a[0]) if len(a) else None, last_line=int(a[-1]) if len(a) else None,
                         n_lines=len(a), expected_n=exp, count_as_expected='yes' if len(a) == exp else 'NO (%d)' % len(a), order_rule=rule,
                         order_rule_holds=('n/a' if ok is None else ('yes' if ok else 'NO')), note=note, example_text=short_text(i, int(a[0])) if len(a) else ''))
    st2 = d[d.regency == 2]
    if len(st2):                                         # side branch: regency 2 (log 4)
        t2 = d[(d.kind == 'lc_timeout') & (d.line > last_stop1)]
        a2 = d[(d.kind == 'lc_attempt') & (d.line > last_stop1)]
        s2 = d[(d.kind == 'lc_send_stop') & (d.regency == 2)]
        rt2 = d[(d.kind == 'lc_retransmit') & (d.regency == 2)]
        rc2 = d[(d.kind == 'lc_recv') & (d.mtype == 'STOP') & (d.regency == 2)]
        senders2 = sorted(set(int(x) for x in rc2.sender.dropna()))
        for m, (label, df, exp, note) in enumerate([
                ('request timed out again (3rd timeout; regency 1 is still being synchronised)', t2, '1', ''),
                ('attempt to start a leader change', a2, '1', 'one more starter (inferred replica 1)'),
                ('STOP sent for regency 2', s2, '1', 'sender inferred = replica 1 (the only sender seen in the STOP(2) receipts)'),
                ('STOP for regency 2 re-transmitted', rt2, 'many', 'periodic re-transmission; no second sender ever joins (F+1 = 2 never reached)'),
                ('STOP for regency 2 received', rc2, 'many', 'all receipts come from replica(s) %s: 1 distinct sender < F+1 = 2 -> no join, never installed' % senders2)], 17):
            a = L(df)
            rows.append(dict(log=lab, branch='regency 2 side branch (never installed)', step=m, stage=label, first_line=int(a[0]) if len(a) else None, last_line=int(a[-1]) if len(a) else None,
                             n_lines=len(a), expected_n=exp, count_as_expected='n/a', order_rule='', order_rule_holds='n/a', note=note,
                             example_text=short_text(i, int(a[0])) if len(a) else ''))
    return pd.DataFrame(rows)


def digest(i, line):
    m = _ARR.search(raw(i, line, 2000))
    return m.group(1) if m else None


def cid0_attempts(i, ev):
    lab = LOGS[i]['label']
    rows = []
    c0 = ev[ev.cid == 0]
    atts = sorted(c0.attempt.unique())
    dig = {}
    for att in atts:
        d = c0[c0.attempt == att]
        q = d[d.kind.isin(['quorum_set', 'sync_write'])]
        ds = set(digest(i, int(l)) for l in q.line)
        ds.discard(None)
        dig[att] = ds
    for att in atts:
        d = c0[c0.attempt == att]
        ac = d[d.kind == 'accept_count']
        pr = d[d.kind == 'propose_recv']
        dg = sorted(dig[att])
        reg = 1 if att == 1 else 0
        rows.append(dict(
            log=lab, attempt=int(att), epoch_ts=int(att), regency=reg, leader_from_PROPOSE_sender=int(pr.sender.iloc[0]) if len(pr) else None, leader_expected_regency_mod_N=leader_of_regency(reg),
            how_started='PROPOSE from the leader of regency 0' if len(pr) else 'SYNC of regency 1 (no PROPOSE line): "Sending WRITE message for CID 0, timestamp 1"',
            n_PROPOSE_received=len(pr), n_Executing_propose=int((d.kind == 'propose_exec').sum()),
            n_WRITE_sent=int(d.kind.isin(['write_send', 'sync_write']).sum()), n_replicas_reached_WRITE_quorum=int(((d.kind == 'write_count') & (d.k == 3)).sum()),
            n_ACCEPT_sent=int((d.kind == 'accept_send').sum()), n_replicas_reached_ACCEPT_quorum=int(((d.kind == 'accept_count') & (d.k == 3)).sum()),
            max_ACCEPTs_counted=int(ac.k.max()) if len(ac) else 0, n_decide=int((d.kind == 'decide').sum()), n_exec=int((d.kind == 'exec').sum()),
            n_client_reply=int((d.kind == 'client_ret').sum()), first_line=int(d.line.min()), last_line=int(d.line.max()),
            n_distinct_value_digests=len(dg), digest_first8=(','.join(dg[0].split(',')[:8]).replace(' ', '') if dg else ''),
            chain_completed=(('yes: decided and executed' + ('' if (d.kind == 'client_ret').sum() else ' (log 1: the reply token of CID 0 is lost)'))
                             if (d.kind == 'decide').sum() else 'NO: stopped before the ACCEPT quorum (no decision)')))
    out = pd.DataFrame(rows)
    out['digest_equals_previous_attempt'] = ''
    for k in range(1, len(out)):
        out.loc[k, 'digest_equals_previous_attempt'] = 'yes' if out.digest_first8.iloc[k] == out.digest_first8.iloc[k - 1] else 'NO (different 32-number value)'
    return out


def plot_q5(offsets, links_all, perrep_all, rec, attempts):
    import matplotlib.gridspec as gridspec
    from matplotlib.colors import LinearSegmentedColormap
    fig = plt.figure(figsize=(14.0, 12.8))
    gs = gridspec.GridSpec(2, 2, hspace=0.40, wspace=0.40, left=0.12, right=0.985, top=0.935, bottom=0.125, figure=fig)
    def title(x, y, text):
        fig.text(x, y, text, ha='left', va='bottom', fontsize=9.8, fontweight='bold', color=TEXT)

    # (a) ladder of the normal chain
    ax = fig.add_subplot(gs[0, 0])
    order = ['propose', 'wsend', 'wq', 'asend', 'aq', 'decide', 'exec', 'reply']
    names = ['PROPOSE received', 'Sending WRITE', 'WRITE quorum', 'Sending ACCEPT\n(logged at WRITE quorum)', 'ACCEPT quorum', 'Deciding consensus', 'Counter incremented\n(execution)', 'client reply']
    for si, sk in enumerate(order):
        for k, lab in enumerate(['log 1', 'log 2', 'log 3', 'log 4']):
            if lab == 'log 1' and sk == 'reply':
                continue                                   # not comparable (see footnote)
            r = offsets[(offsets.log == lab) & (offsets.stage == sk)]
            if not len(r):
                continue
            r = r.iloc[0]
            y = si + (k - 1.5) * 0.17
            c = LOG_COLOR[k + 1]
            ax.plot([r.median_first_offset, r.median_last_offset], [y, y], color=c, lw=2.2, solid_capstyle='round', zorder=2)
            ax.scatter([r.median_first_offset], [y], s=22, color=c, edgecolor=SURFACE, linewidth=0.7, zorder=3)
    ax.text(119, 7.0, 'log 1 omitted: not comparable (see note)', ha='right', va='center', fontsize=7.6, color=MUTED)
    ax.set_yticks(range(len(order)))
    ax.set_yticklabels(names, fontsize=8.3)
    ax.set_ylim(len(order) - 0.45, -0.6)
    ax.set_xlim(-4, 132)
    ax.set_xlabel('lines after the first "PROPOSE received" line of the CID (median over CIDs 1-999)')
    ax.grid(axis='y', visible=False)
    title(0.09, 0.966, '(a) Normal chain: first (dot) to last (end of bar) line of each stage')
    hs = [plt.Line2D([0], [0], color=LOG_COLOR[k], lw=2.4, label='log %d' % k) for k in range(1, 5)]
    ax.legend(handles=hs, ncol=4, loc='lower left', bbox_to_anchor=(0.0, 1.0), fontsize=8, columnspacing=1.2, handlelength=1.4, frameon=False, borderaxespad=0.15)

    # (b) violation grid
    ax = fig.add_subplot(gs[0, 1])
    cmap = LinearSegmentedColormap.from_list('seq', ['#e9eff8', SEQ[2], SEQ[4], SEQ[6]])
    link_ids = [l[0] for l in LINKS]
    short = {'L0': 'Invocation -> PROPOSE', 'L1': 'PROPOSE -> Executing propose', 'L2': 'Executing propose -> WRITE sent', 'L3': 'WRITE sent (3) -> WRITE quorum',
             'L4': 'WRITE quorum -> ACCEPT sent', 'L5': 'ACCEPT sent (3) -> ACCEPT quorum', 'L6': 'ACCEPT quorum -> decision', 'L7': 'decision -> execution',
             'L8': 'execution (2) -> client reply'}
    rows_b = []
    for lid in link_ids:
        cells = []
        for lab in ['log 1', 'log 2', 'log 3', 'log 4']:
            r = links_all[(links_all.log == lab) & (links_all.link == lid)].iloc[0]
            cells.append((int(r.n_violations), int(r.n_cids_checked), lab == 'log 1' and lid in LOG1_ARTIFACT_LINKS))
        rows_b.append(('%s  %s' % (lid, short[lid]), cells))
    cells = []
    for lab in ['log 1', 'log 2', 'log 3', 'log 4']:
        r = perrep_all[(perrep_all.log == lab) & (perrep_all.replica == -1)].iloc[0]
        cells.append((int(r.n_violations), int(r.n_checked), False))
    rows_b.append(None)                                       # spacer
    rows_b.append(('E  exact, per replica\n((CID, ts, replica) rows, all stages\nwith a replica id)', cells))
    ri = -1
    ticks, tl = [], []
    for row in rows_b:
        ri += 1
        if row is None:
            continue
        ticks.append(ri)
        tl.append(row[0])
        for ci, (v, n, dag) in enumerate(row[1]):
            if n == 0:
                ax.add_patch(plt.Rectangle((ci - 0.46, ri - 0.44), 0.92, 0.88, facecolor=SURFACE, edgecolor=GRID, linewidth=1.0))
                ax.text(ci, ri, 'n/a', ha='center', va='center', fontsize=8, color=MUTED)
                continue
            share = v / n
            level = 0.0 if v == 0 else 0.25 + 0.75 * min(share / 0.6, 1.0)
            ax.add_patch(plt.Rectangle((ci - 0.46, ri - 0.44), 0.92, 0.88, facecolor=cmap(level), edgecolor=SURFACE, linewidth=1.2))
            ax.text(ci, ri, '%d / %d%s' % (v, n, ' †' if dag else ''), ha='center', va='center', fontsize=8.2, color='white' if level > 0.6 else TEXT)
    ax.set_xlim(-0.6, 3.6)
    ax.set_ylim(ri + 0.6, -0.6)
    ax.set_xticks(range(4))
    ax.set_xticklabels(['log 1', 'log 2', 'log 3', 'log 4'], fontsize=9)
    ax.xaxis.set_ticks_position('top')
    ax.set_yticks(ticks)
    ax.set_yticklabels(tl, fontsize=8.1)
    ax.grid(False)
    for sp in ax.spines.values():
        sp.set_visible(False)
    title(0.47, 0.966, '(b) Order test per link: CIDs violating the order / CIDs checked')

    # (c) CID 0 attempts
    ax = fig.add_subplot(gs[1, 0])
    cols = [('log 3', 0, 'log 3\nts 0'), ('log 2', 0, 'log 2\nts 0'), ('log 2', 1, 'log 2\nts 1'), ('log 4', 0, 'log 4\nts 0'), ('log 4', 1, 'log 4\nts 1')]
    rowsd = [('n_PROPOSE_received', 'PROPOSE received'), ('n_WRITE_sent', 'WRITE sent'), ('n_replicas_reached_WRITE_quorum', 'WRITE quorum reached'),
             ('n_ACCEPT_sent', 'ACCEPT sent'), ('n_replicas_reached_ACCEPT_quorum', 'ACCEPT quorum reached'), ('n_decide', 'decision'), ('n_exec', 'execution'), ('n_client_reply', 'client reply')]
    cm = LinearSegmentedColormap.from_list('c', ['#e9eff8', SEQ[2], SEQ[4], SEQ[6]])
    for ci, (lab, att, _) in enumerate(cols):
        r = attempts[(attempts.log == lab) & (attempts.attempt == att)].iloc[0]
        for ri, (key, _) in enumerate(rowsd):
            n = int(r[key])
            if key == 'n_PROPOSE_received' and n == 0:
                ax.add_patch(plt.Rectangle((ci - 0.46, ri - 0.44), 0.92, 0.88, facecolor=SURFACE, edgecolor=GRID, linewidth=1.0))
                ax.text(ci, ri, 'SYNC\n(no PROPOSE)', ha='center', va='center', fontsize=7.2, color=TEXT2)
                continue
            full = 1 if key == 'n_client_reply' else 4
            if n == 0:
                ax.add_patch(plt.Rectangle((ci - 0.46, ri - 0.44), 0.92, 0.88, facecolor=SURFACE, edgecolor=REPLICA_COLOR[1], linewidth=1.6))
                ax.text(ci, ri, '0', ha='center', va='center', fontsize=9, color=REPLICA_COLOR[1], fontweight='bold')
                continue
            ax.add_patch(plt.Rectangle((ci - 0.46, ri - 0.44), 0.92, 0.88, facecolor=cm(n / full), edgecolor=SURFACE, linewidth=1.2))
            ax.text(ci, ri, '%d of %d' % (n, full), ha='center', va='center', fontsize=8.4, color='white' if n / full > 0.5 else TEXT)
    ax.set_xlim(-0.6, len(cols) - 0.4)
    ax.set_ylim(len(rowsd) - 0.4, -0.6)
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels([c[2] for c in cols], fontsize=8.6)
    ax.xaxis.set_ticks_position('top')
    ax.set_yticks(range(len(rowsd)))
    ax.set_yticklabels([r[1] for r in rowsd], fontsize=8.6)
    ax.grid(False)
    for sp in ax.spines.values():
        sp.set_visible(False)
    title(0.09, 0.505, '(c) CID 0 at each attempt: replicas that reached each stage')

    # (d) recovery staircase
    ax = fig.add_subplot(gs[1, 1])
    labels = ['timeout', 'forwarded to leader', 'attempt leader change', 'STOP sent', 'STOP received', 'STOPDATA sent', 'STOPDATA received', 'SYNC sent', 'SYNC received',
              'WRITE ts 1 sent', 'WRITE quorum ts 1', 'ACCEPT ts 1 sent', 'ACCEPT quorum ts 1', 'DECIDE', 'execution', 'client reply']
    main_rows = rec[rec.branch.str.startswith('regency 1')]
    for lab, c, dy in [('log 2', LOG_COLOR[2], -0.13), ('log 4', LOG_COLOR[4], 0.13)]:
        r = main_rows[main_rows.log == lab].sort_values('step')
        for _, x in r.iterrows():
            y = x.step - 1 + dy
            ax.plot([x.first_line, x.last_line], [y, y], color=c, lw=2.2, solid_capstyle='round', zorder=2)
            ax.scatter([x.first_line], [y], s=22, color=c, edgecolor=SURFACE, linewidth=0.7, zorder=3)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=8.2)
    ax.set_ylim(len(labels) - 0.4, -0.6)
    ax.set_xlim(150, 345)
    ax.set_xlabel('line number (dot = first line of the stage, bar = up to its last line)')
    ax.grid(axis='y', visible=False)
    hs = [plt.Line2D([0], [0], color=LOG_COLOR[k], lw=2.4, label='log %d' % k) for k in (2, 4)]
    ax.legend(handles=hs, ncol=2, loc='lower left', bbox_to_anchor=(0.0, 1.0), fontsize=8, columnspacing=1.2, handlelength=1.4, frameon=False, borderaxespad=0.15)
    title(0.47, 0.505, '(d) Recovery chain of regency 1 in logs 2 and 4: the stages follow each other')
    fig.text(0.5, 0.012,
             'Lines, not seconds: the logs have no clock.   (a) medians over CIDs 1-999; the log-1 client reply is left out (its unprefixed client text is not in causal order with the prefixed replica lines).\n'
             '(b) \u2020 = artifact of log 1\'s capture (cross-replica and client lines are not in causal order); row E (exact, per replica) has 0 violations in all four logs; L0 is not evaluable in log 1; logs 2-4: 0 violations in every link.\n'
             '(c) outlined 0 = stage not reached. In logs 2 and 4 only 2 of 4 replicas reached the WRITE quorum / sent an ACCEPT at ts 0 and nobody reached the ACCEPT quorum; at ts 1 all four complete the chain. Log 1 behaves like log 3 (its CID-0 reply token is lost).\n'
             '(d) bars overlap because 4 replicas / 4 messages are interleaved; every order rule of q5_recovery_chain.csv holds. Log 4 also has a regency-2 side branch (lines 195-201 and later), not drawn here.',
             ha='center', fontsize=7.7, color=TEXT2, linespacing=1.45)
    save(fig, 'q5_event_ordering.png')


def main():
    style()
    evs = {i: load_events(i) for i in LOGS}
    links, perrep, caus, xcid, rel, chains, recs, atts = [], [], [], [], [], [], [], []
    for i in LOGS:
        ev = evs[i]
        arr = arrays(ev, i)
        lk, vk = link_checks(i, ev, arr)
        links.append(lk)
        perrep.append(per_replica(i, ev))
        caus.append(causality(i, ev))
        xcid.append(cross_cid(i, ev, arr))
        rel.append(relationship_checks(i, ev, arr))
        chains.append(chain_table(i, ev, arr, vk))
        atts.append(cid0_attempts(i, ev))
        if len(lc_events(ev)):
            recs.append(recovery_chain(i, ev))
    links = pd.concat(links, ignore_index=True)
    perrep = pd.concat(perrep, ignore_index=True)
    caus = pd.concat(caus, ignore_index=True)
    xcid = pd.concat(xcid, ignore_index=True)
    rel = pd.concat(rel, ignore_index=True)
    chain = pd.concat(chains, ignore_index=True)
    rec = pd.concat(recs, ignore_index=True)
    att = pd.concat(atts, ignore_index=True)
    off = stage_offsets(chain)
    write_csv(chain, 'q5_chain_per_cid.csv')
    write_csv(links, 'q5_chain_link_checks.csv')
    write_csv(perrep, 'q5_chain_per_replica.csv')
    write_csv(caus, 'q5_causality_checks.csv')
    write_csv(xcid, 'q5_cross_cid_order.csv')
    write_csv(rel, 'q5_relationship_checks.csv')
    write_csv(off, 'q5_stage_offsets.csv')
    write_csv(rec, 'q5_recovery_chain.csv')
    write_csv(att, 'q5_cid0_attempts.csv')
    plot_q5(off, links, perrep, rec, att)
    pd.set_option('display.width', 280); pd.set_option('display.max_columns', 60); pd.set_option('display.max_colwidth', 150); pd.set_option('display.max_rows', 400)
    print(links.drop(columns=['rule', 'note', 'example']).to_string())
    print(perrep[perrep.replica == -1].to_string())
    print(caus.to_string())
    print(xcid.to_string())
    print(rel.to_string())
    print(rec.drop(columns=['expected_n', 'example_text']).to_string())
    print(att.T.to_string())


if __name__ == '__main__':
    main()
