"""
common.py - shared constants, loaders and plotting style for the BFT-SMaRt log analysis.

Conventions used everywhere
  * "line" = 1-based physical line number in the ORIGINAL log file (main.log, main_2.log, ...).
  * Logs are numbered as in the task text: log 1 = main.log (has [replicaN] prefixes), log 2 = main_2.log,
    log 3 = main_3.log, log 4 = main_4.log.
  * The logs carry no wall-clock time.  "Earlier/later" always means "earlier/later line in the same file".
  * "ts" is the epoch timestamp of the consensus protocol (not a clock time).
"""
import os
import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_DIR = os.path.join(ROOT, 'csv')
PARSED_DIR = os.path.join(CSV_DIR, 'parsed')
PLOT_DIR = os.path.join(ROOT, 'plots')
for _d in (CSV_DIR, PARSED_DIR, PLOT_DIR):
    os.makedirs(_d, exist_ok=True)

LOGS = {
    1: dict(label='log 1', file='main.log',   path=os.path.join(ROOT, 'logs', 'log1_main.log'),   prefixed=True),
    2: dict(label='log 2', file='main_2.log', path=os.path.join(ROOT, 'logs', 'log2_main_2.log'), prefixed=False),
    3: dict(label='log 3', file='main_3.log', path=os.path.join(ROOT, 'logs', 'log3_main_3.log'), prefixed=False),
    4: dict(label='log 4', file='main_4.log', path=os.path.join(ROOT, 'logs', 'log4_main_4.log'), prefixed=False),
}
N, F = 4, 1
QUORUM_COUNT = 3          # BFT-SMaRt proceeds when the count is > (N+F)//2 = 2, i.e. at the 3rd WRITE / 3rd ACCEPT
JOIN_STOPS = F + 1        # a replica joins a leader change after STOPs from F+1 = 2 distinct replicas
INSTALL_STOPS = 2 * F + 1  # a regency is installed after STOPs from 2F+1 = 3 distinct replicas


def leader_of_regency(regency: int) -> int:
    """BFT-SMaRt: leader = regency mod N (to be checked against PROPOSE senders - done in q3/q6)."""
    return regency % N


def load_events(i: int) -> pd.DataFrame:
    """Parsed events of log `i` (csv/parsed/events_log{i}.csv, produced by 00_parse_logs.py)."""
    ev = pd.read_csv(os.path.join(PARSED_DIR, 'events_log%d.csv' % i), low_memory=False,
                     dtype={'mtype': 'string', 'rep_src': 'string', 'line_class': 'string', 'kind': 'string'})
    ev['kind'] = ev['kind'].replace({'decide_amb': 'decide'})            # 4 'Deciding' heads lost in log 1
    ev = ev.sort_values(['line', 'pos'], kind='stable').reset_index(drop=True)
    # executed request / client reply carry the request number V; request V is decided in CID V-1 (1 request per CID)
    m = ev.kind.isin(['exec', 'client_ret'])
    ev.loc[m, 'cid'] = ev.loc[m, 'value'] - 1
    m = ev.kind.eq('client_inv')
    ev.loc[m, 'cid'] = ev.loc[m, 'value']
    # attempt: CID 0 is run twice in logs 2/4 (ts 0, then ts 1 after the leader change); ts-1 events start at the
    # first "Sending WRITE message for CID 0, timestamp 1" line (checked: all ts=0 events of CID 0 are before it)
    ev['attempt'] = 0
    cut = ev.loc[ev.kind.eq('sync_write'), 'line'].min()
    if pd.notna(cut):
        ev.loc[(ev.cid == 0) & (ev.line >= cut) & ~ev.kind.isin(['client_inv']), 'attempt'] = 1
    return ev


def fill_by_elimination(ev: pd.DataFrame, kind: str) -> pd.DataFrame:
    """Log 1 only: when exactly one of the 4 events `kind` of a CID has lost its [replicaN] prefix, the replica is
    the one missing from the other three.  Marks rep_src='elimination'.  Returns a modified copy."""
    ev = ev.copy()
    d = ev[ev.kind == kind]
    for cid, g in d.groupby('cid'):
        if len(g) == 4 and g.rep.isna().sum() == 1 and g.rep.notna().sum() == 3 and g.rep.dropna().nunique() == 3:
            missing = set(range(N)) - set(int(r) for r in g.rep.dropna())
            if len(missing) == 1:
                idx = g.index[g.rep.isna()][0]
                ev.loc[idx, 'rep'] = missing.pop()
                ev.loc[idx, 'rep_src'] = 'elimination'
    return ev


def wilson(k, n, z=1.96):
    """Wilson score interval for a proportion k/n -> (low, high)."""
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (centre - half, centre + half)


# ----------------------------------------------------------------------------------------------------------
# plotting style (dataviz skill: validated categorical slots 1-4, recessive solid grid, thin marks)
# ----------------------------------------------------------------------------------------------------------
SURFACE = '#fcfcfb'
TEXT = '#0b0b0b'
TEXT2 = '#52514e'
MUTED = '#8a8984'
GRID = '#e4e3df'
REPLICA_COLOR = {0: '#2a78d6', 1: '#eb6834', 2: '#1baf7a', 3: '#eda100'}   # blue, orange, aqua, yellow (slots 1-4)
# log colours (different job than replica colours): categorical slots 5-8 in order
LOG_COLOR = {1: '#e87ba4', 2: '#008300', 3: '#6250d6', 4: '#e34948'}
SEQ = ['#cde2fb', '#9ec5f4', '#6da7ec', '#3987e5', '#256abf', '#184f95', '#0d366b']  # sequential blue 100..700


def style():
    import matplotlib as mpl
    mpl.rcParams.update({
        'figure.facecolor': SURFACE, 'axes.facecolor': SURFACE, 'savefig.facecolor': SURFACE,
        'axes.edgecolor': GRID, 'axes.linewidth': 1.0, 'axes.labelcolor': TEXT2,
        'xtick.color': TEXT2, 'ytick.color': TEXT2, 'text.color': TEXT, 'axes.titlecolor': TEXT,
        'axes.titlesize': 10.5, 'axes.titleweight': 'bold', 'axes.titlelocation': 'left',
        'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.9, 'grid.linestyle': '-',
        'axes.axisbelow': True, 'axes.spines.top': False, 'axes.spines.right': False,
        'axes.spines.left': False, 'xtick.major.size': 0, 'ytick.major.size': 0,
        'font.size': 9, 'axes.labelsize': 9, 'legend.frameon': False, 'legend.fontsize': 8.5,
        'lines.linewidth': 2.0, 'lines.solid_capstyle': 'round', 'figure.dpi': 110,
    })


def save(fig, name):
    path = os.path.join(PLOT_DIR, name)
    fig.savefig(path, dpi=170, bbox_inches='tight')
    return path


def write_csv(df, name):
    path = os.path.join(CSV_DIR, name)
    df.to_csv(path, index=False)
    return path
