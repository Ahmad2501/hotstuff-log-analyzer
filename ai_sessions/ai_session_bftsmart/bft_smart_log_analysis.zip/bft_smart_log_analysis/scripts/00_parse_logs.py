#!/usr/bin/env python3
"""
00_parse_logs.py - parse the four BFT-SMaRt logs into event tables and report parse quality.

Outputs
  csv/parsed/events_log{1..4}.csv   one row per recognised message (line, pos, kind, rep, sender, cid, ts, ...)
  csv/parsed/issues_log{1..4}.csv   one row per physical line that is NOT a clean single message (class + raw text)
  csv/q0_parse_quality.csv          per log: number of lines per class + client-token recovery + damaged events
Run:  python3 -I scripts/00_parse_logs.py
"""
import os
import sys
import csv
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bft_parse
from common import LOGS, PARSED_DIR, write_csv
import pandas as pd


def main():
    rows = []
    for i, info in LOGS.items():
        events, issues = bft_parse.parse_log(info['path'], info['prefixed'])
        with open(os.path.join(PARSED_DIR, 'events_log%d.csv' % i), 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=bft_parse.EVENT_COLS, extrasaction='ignore')
            w.writeheader()
            w.writerows(events)
        with open(os.path.join(PARSED_DIR, 'issues_log%d.csv' % i), 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=bft_parse.ISSUE_COLS, extrasaction='ignore')
            w.writeheader()
            w.writerows(issues)
        with open(info['path'], errors='replace') as f:
            n_lines = sum(1 for _ in f)
        cls = collections.Counter(r['klass'] for r in issues)
        kinds = collections.Counter(e['kind'] for e in events)
        tail_only = sum(1 for e in events if e['tail_only'])
        no_rep = sum(1 for e in events if info['prefixed'] and e['rep'] is None
                     and e['kind'] not in ('client_inv', 'client_ret') and not e['kind'].startswith('st_'))
        conflicts = sum(1 for e in events if 'CONFLICT' in str(e['rep_src']))
        row = dict(log=info['label'], file=info['file'], prefixed=int(info['prefixed']), n_lines=n_lines,
                   n_events=len(events), lines_not_clean=len(issues),
                   unparsed_lines=cls.get('unparsed', 0) + cls.get('unparsed_residue', 0),
                   blank_lines=cls.get('blank', 0),
                   client_only_lines=cls.get('client_only', 0),
                   spliced_client_lines=cls.get('spliced_client', 0),
                   spliced_concat_lines=cls.get('spliced_concat', 0) + cls.get('spliced_mixed', 0),
                   damaged_head_lost_lines=cls.get('damaged_recovered', 0),
                   torn_head_lines=cls.get('torn_head', 0),
                   prefix_bracket_lost_lines=cls.get('prefix_bracket_lost', 0),
                   events_with_head_lost=tail_only,
                   events_without_replica_prefix=no_rep,
                   prefix_vs_iam_conflicts=conflicts,
                   client_invocation_tokens=kinds.get('client_inv', 0),
                   client_returned_value_tokens=kinds.get('client_ret', 0),
                   decide_events=kinds.get('decide', 0) + kinds.get('decide_amb', 0))
        rows.append(row)
        print(info['label'], row)
    write_csv(pd.DataFrame(rows), 'q0_parse_quality.csv')


if __name__ == '__main__':
    main()
