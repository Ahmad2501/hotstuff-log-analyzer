#!/usr/bin/env python3
"""
q6_regency_analysis.py - Question 6: regency analysis.

Answers (with line numbers in the CSVs)
  * how many regencies each log has: installed vs attempted-never-installed (logs 1 and 3: none - regency 0 only),
  * which replicas sent STOP / STOPDATA / SYNC, who started and who joined, were F+1 (join) and 2F+1 (install) reached,
  * "Last regency / next regency" pairs (1,1 on a STOP for regency 2 = the regency did not advance),
  * leader per regency, leader = regency mod N, did the replaced leader keep proposing,
  * order of the replicas in the recovery (first / last / late), marked as tagged or inferred,
  * did the never-installed regency 2 of log 4 change anything for the later CIDs.

Outputs
  csv/q6_regency_inventory.csv         one row per (log, regency): status, STOP/STOPDATA/SYNC counts, distinct senders, thresholds, leader, pairs
  csv/q6_stop_senders.csv              one row per (log, message type, regency, sender): receipts, first/last line, rank, role (tagged/inferred)
  csv/q6_state_pairs.csv               "Last regency / next regency" pair counts per received message type and regency
  csv/q6_pairing_check.csv             verification of the receipt <-> state-line pairing
  csv/q6_leader_roles.csv              PROPOSE senders per regency in effect (leader check, replaced leader) + follower activity
  csv/q6_recovery_response_order.csv   order of replicas in STOP / STOPDATA / WRITE ts 1 / ACCEPT ts 1 (logs 2, 4), tagged vs inferred
  csv/q6_regency2_effect_per_cid.csv   per CID: decision latency in lines, leader-change lines inside the CID, ...
  csv/q6_regency2_effect_summary.csv   group medians and Mann-Whitney tests (Holm-corrected) with effect sizes
  csv/q6_integrity_checks.csv          per log: decisions, replies in order, leader of CIDs >= 1, ts of CIDs >= 1
  plots/q6_regency_analysis.png
Run:  python3 -I scripts/q6_regency_analysis.py      (needs 00_parse_logs.py, q1, q2 and q4 first)
"""
import os
import re
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lc_helpers import *
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    run = 0.0
    for k, idx in enumerate(order):
        run = max(run, (m - k) * p[idx])
        adj[idx] = min(1.0, run)
    return adj


def regency_in_effect(sync_line):
    def f(line):
        r = 0
        for R, ln in sorted(sync_line.items()):
            if line > ln:
                r = R
        return r
    return f


def pair_string(pairs, mtype=None, R=None):
    d = pairs
    if mtype is not None:
        d = d[d.mtype == mtype]
    if R is not None:
        d = d[d.regency == R]
    if not len(d):
        return ''
    c = d.groupby(['last', 'next']).size()
    return '; '.join('(%d,%d): %d' % (a, b, n) for (a, b), n in c.items())


# ----------------------------------------------------------------------------------------------------------------
def inventory(i, ev, q1, send_inf):
    lab = LOGS[i]['label']
    d = lc_events(ev)
    sync_line = install_lines(ev)
    f_reg = regency_in_effect(sync_line)
    regs = sorted(set([0]) | set(int(x) for x in d.regency.dropna().unique()))
    prop = ev[ev.kind == 'propose_recv'].dropna(subset=['sender', 'cid']).copy()
    prop['reg_eff'] = prop.line.map(f_reg)
    dec = ev[ev.kind == 'decide'].dropna(subset=['cid']).copy()
    first_dec = dec.groupby('cid').line.min()
    dec_reg = first_dec.map(f_reg)
    pairs = pair_recv_with_state(ev) if len(d) else pd.DataFrame(columns=['mtype', 'regency', 'last', 'next'])
    rows = []
    for R in regs:
        sends = d[(d.kind == 'lc_send_stop') & (d.regency == R)]
        retr = d[(d.kind == 'lc_retransmit') & (d.regency == R)]
        rec_stop = d[(d.kind == 'lc_recv') & (d.mtype == 'STOP') & (d.regency == R)]
        senders = sorted(set(int(x) for x in rec_stop.sender.dropna()))
        sd_s = d[(d.kind == 'lc_send_stopdata') & (d.regency == R)]
        sd_r = d[(d.kind == 'lc_recv') & (d.mtype == 'STOPDATA') & (d.regency == R)]
        sy_s = d[(d.kind == 'lc_send_sync') & (d.regency == R)]
        sy_r = d[(d.kind == 'lc_recv') & (d.mtype == 'SYNC') & (d.regency == R)]
        mine = d[d.regency == R]
        installed = R in sync_line
        p = prop[prop.reg_eff == R] if (R == 0 or installed) else prop.iloc[0:0]
        leaders = sorted(set(int(x) for x in p.sender))
        expected = leader_of_regency(R)
        n_dec = int((dec_reg == R).sum()) if (R == 0 or installed) else 0
        n_att = int(p.cid.nunique())
        if R == 0:
            if len(d) == 0:
                status = 'initial regency; the only regency of this log - NO leader-change event at all (normal chain)'
            else:
                status = 'initial regency; replaced by regency 1 after the CID-0 timeout (no CID decided in it)'
        elif installed:
            status = 'INSTALLED (STOP quorum, STOPDATA to the new leader, SYNC sent and received, CIDs decided in it)'
        else:
            status = 'ATTEMPTED, NEVER INSTALLED (STOP only; no STOPDATA, no SYNC)'
        if R == 0:
            ev_txt = ('no regency event' if len(d) == 0 else 'regency 0 until the SYNC of regency 1 at line %d' % sync_line.get(1, -1))
        elif installed:
            ev_txt = ('first "Sending STOPDATA of regency %d" line %d; "Sending SYNC message for regency %d" line %d; '
                      'first PROPOSE of the regency from replica %s at line %d'
                      % (R, sd_s.line.min(), R, sy_s.line.min(), ','.join(map(str, leaders)), p.line.min()))
        else:
            ev_txt = ('%d STOP broadcasts (1 "Sending STOP" at line %d + %d "Re-transmitting"), %d receipts, all from replica(s) %s; no STOPDATA / SYNC / PROPOSE for it'
                      % (len(sends) + len(retr), sends.line.min() if len(sends) else -1, len(retr), len(rec_stop), ','.join(map(str, senders))))
        rows.append(dict(
            log=lab, file=LOGS[i]['file'], regency=R, status=status,
            first_line=int(mine.line.min()) if len(mine) else None, last_line=int(mine.line.max()) if len(mine) else None,
            n_stop_sent=len(sends), n_stop_retransmitted=len(retr), n_stop_received=len(rec_stop),
            distinct_stop_senders=len(senders), stop_senders=','.join(map(str, senders)) if senders else 'none',
            join_threshold_F1_reached=('yes' if len(senders) >= JOIN_STOPS else 'no') if R > 0 else 'n/a',
            install_threshold_2F1_reached=('yes' if len(senders) >= INSTALL_STOPS else 'no') if R > 0 else 'n/a',
            n_stopdata_sent=len(sd_s), n_stopdata_received=len(sd_r), n_sync_sent=len(sy_s), n_sync_received=len(sy_r),
            leader_expected_regency_mod_N=expected,
            leader_observed_from_PROPOSE='none (never installed)' if not (R == 0 or installed) else ','.join(map(str, leaders)),
            observed_equals_expected=('yes' if leaders == [expected] else 'no') if (R == 0 or installed) else 'not testable (never installed)',
            n_cids_with_PROPOSE=n_att, n_cids_decided_in_regency=n_dec,
            last_next_pairs_of_received_messages=pair_string(pairs, None, R) if R > 0 else '', evidence=ev_txt))
    return pd.DataFrame(rows)


def sender_table(i, ev, send_inf):
    lab = LOGS[i]['label']
    d = lc_events(ev)
    if not len(d):
        return pd.DataFrame()
    sync_line = install_lines(ev)
    rows = []
    for (mtype, R), _ in d[d.kind == 'lc_recv'].groupby(['mtype', 'regency']):
        R = int(R)
        fr = first_receipts(ev, mtype, R)
        si = send_inf[(send_inf.regency == R) & (send_inf.message == mtype)] if len(send_inf) else send_inf
        st_c, jo_c = set(), set()
        if mtype == 'STOP' and len(si):
            for r in si.itertuples():
                cs = set(int(x) for x in str(r.candidate_senders).split('|') if x != '')
                (st_c if str(r.role).startswith('starter') else jo_c).update(cs)
        for r in fr.itertuples():
            role, late = '', ''
            if mtype == 'STOP':
                s = int(r.sender)
                if s in st_c and s not in jo_c:
                    role = 'starter (INFERRED: its STOP can only be a send line preceded by "Attempting to start leader change")'
                elif s in jo_c and s not in st_c:
                    role = 'joiner (INFERRED: its STOP can only be a send line without an own "Attempting ..." line)'
                else:
                    role = 'undetermined'
            if mtype == 'STOPDATA':
                late = 'yes - first receipt after the new leader had already sent SYNC' if r.first_line > sync_line.get(R, 10 ** 12) else 'no'
            rows.append(dict(log=lab, message=mtype, regency=R, sender=int(r.sender), rank_by_first_receipt=int(r.rank), n_receipts=int(r.n_receipts),
                             first_line=int(r.first_line), last_line=int(r.last_line), role=role, late_after_SYNC_sent=late,
                             basis='sender tagged ("from replica N"); role/lateness inferred from line order'))
    return pd.DataFrame(rows)


def state_pair_table(i, ev):
    d = lc_events(ev)
    if not len(d):
        return pd.DataFrame(), pd.DataFrame()
    pr = pair_recv_with_state(ev)
    meaning = {
        (0, 0): 'receiver still in regency 0 and not in a leader change (next = last)',
        (0, 1): 'receiver in regency 0 with next regency 1: it has started / joined the leader change',
        (1, 1): 'regency 1 installed, no further change pending at the receiver',
        (1, 2): 'receiver has next regency 2 > last regency 1: it started the regency-2 change itself (only replica 1)',
    }
    rows = []
    for (mt, R, a, b), g in pr.groupby(['mtype', 'regency', 'last', 'next']):
        mean = meaning.get((int(a), int(b)), '')
        if (int(R), int(a), int(b)) == (2, 1, 1):
            mean = 'DID NOT ADVANCE: STOP for regency 2 received, last regency stays 1 and next regency stays 1 (no join, no install)'
        rows.append(dict(log=LOGS[i]['label'], message=mt, regency_in_message=int(R), last_regency=int(a), next_regency=int(b), n=len(g),
                         first_receipt_line=int(g.line.min()), last_receipt_line=int(g.line.max()), meaning=mean))
    chk = pairing_check(ev)
    chk = dict(log=LOGS[i]['label'], **chk, pairing='FIFO: k-th "Last regency" line <-> k-th "Received leader change message" line',
               verdict='valid: a state line never precedes its receipt; at most %d receipts are waiting at any time; max %d lines apart'
               % (chk['max_receipts_ahead_of_states'], chk['max_line_distance']))
    return pd.DataFrame(rows), pd.DataFrame([chk])


def leader_roles(i, ev):
    lab = LOGS[i]['label']
    sync_line = install_lines(ev)
    f_reg = regency_in_effect(sync_line)
    prop = ev[ev.kind == 'propose_recv'].dropna(subset=['sender', 'cid']).copy()
    prop['reg_eff'] = prop.line.map(f_reg)
    regs = sorted(set([0]) | set(sync_line))
    rows = []
    for R in regs:
        for rep in range(N):
            p = prop[(prop.reg_eff == R) & (prop.sender == rep)]
            ws = ev[(ev.kind == 'write_send') & (ev.rep == rep)]
            acs = ev[(ev.kind == 'accept_send') & (ev.rep == rep)]
            if R in sync_line:
                lo, hi = (sync_line[R], sync_line.get(R + 1, 10 ** 12))
            else:
                lo, hi = (0, sync_line.get(1, 10 ** 12))
            ws = ws[(ws.line > lo) & (ws.line < hi)] if R else ws[(ws.line < hi)]
            acs = acs[(acs.line > lo) & (acs.line < hi)] if R else acs[(acs.line < hi)]
            expected = leader_of_regency(R)
            rows.append(dict(
                log=lab, regency_in_effect=R, replica=rep, expected_leader_regency_mod_N=expected,
                role_observed=('LEADER (sent the PROPOSEs)' if len(p) else 'follower (no PROPOSE sent)'),
                role_expected=('leader' if rep == expected else 'follower'),
                n_PROPOSE_lines_from_this_replica=len(p), n_cids_proposed=int(p.cid.nunique()),
                first_propose_line=int(p.line.min()) if len(p) else None, last_propose_line=int(p.line.max()) if len(p) else None,
                n_write_send_lines_tagged=len(ws), n_accept_send_lines_tagged=len(acs),
                note=('replaced leader: no PROPOSE after the SYNC line %d' % sync_line.get(1, -1)) if (R == 1 and rep == 0 and not len(p)) else ''))
    return pd.DataFrame(rows)


def parse_orders(note):
    m = re.search(r'receive lines: ([0-9>]+(?: ; [0-9>]+)*)', str(note))
    if not m:
        return []
    return [[int(x) for x in o.strip().split('>')] for o in m.group(1).split(' ; ')]


def recovery_order(i, ev, q2, send_inf):
    lab = LOGS[i]['label']
    sync_line = install_lines(ev)
    rows = []

    def add(stage, rep, rank_lo, rank_hi, line, basis, note=''):
        rows.append(dict(log=lab, stage=stage, replica=rep, rank_first=rank_lo, rank_last=rank_hi, line=line, basis=basis, note=note))

    fr = first_receipts(ev, 'STOP', 1)
    for r in fr.itertuples():
        add('STOP(1): first receipt', int(r.sender), int(r.rank), int(r.rank), int(r.first_line), 'tagged (from replica N); order of first receipt ~ order of sending')
    fr = first_receipts(ev, 'STOPDATA', 1)
    for r in fr.itertuples():
        late = r.first_line > sync_line.get(1, 10 ** 12)
        add('STOPDATA(1): first receipt at the new leader', int(r.sender), int(r.rank), int(r.rank), int(r.first_line), 'tagged (from replica N)',
            'late: arrives after the leader sent SYNC' if late else '')
    c0 = q2[(q2.log == lab) & (q2.cid == 0) & (q2.attempt == 1)]
    if len(c0):
        c0 = c0.iloc[0]
        orders = parse_orders(c0.note)
        lines = [int(x) for x in str(c0.write_send_lines).split('>')]
        if orders:
            for rep in range(N):
                ranks = sorted(set(o.index(rep) + 1 for o in orders))
                add('WRITE at ts 1 ("Sending WRITE message for CID 0, timestamp 1")', rep, min(ranks), max(ranks),
                    lines[min(ranks) - 1] if len(ranks) == 1 else None, 'INFERRED (sender not tagged; line-order + causality, %d feasible order(s): %s)'
                    % (len(orders), ' | '.join('>'.join(map(str, o)) for o in orders)))
        order = [int(x) for x in str(c0.accept_send_order).split('>')]
        alines = [int(x) for x in str(c0.accept_send_lines).split('>')]
        for k, rep in enumerate(order):
            add('ACCEPT at ts 1 ("Sending ACCEPT message, cId:0, I am:N")', rep, k + 1, k + 1, alines[k], 'tagged (I am:N)')
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------------------------------
def effect_tables(evs, q1):
    parts = []
    for i in LOGS:
        lab = LOGS[i]['label']
        p = q1[q1.log == lab].copy().reset_index(drop=True)
        ev = evs[i]
        lcl = np.sort(ev[ev.kind.str.startswith('lc_')].line.values)

        def n_between(a, b):
            if pd.isna(a) or pd.isna(b):
                return np.nan
            return int(np.searchsorted(lcl, b, 'left') - np.searchsorted(lcl, a, 'right'))
        p['lc_lines_in_decide_window'] = [n_between(a, b) for a, b in zip(p.first_propose_line, p.first_decide_line)]
        p['lc_lines_in_cid_span'] = [n_between(a, b) for a, b in zip(p.first_line, p.last_line)]
        p['decide_latency_lines'] = p.decide_latency_lines.astype(float)
        p['decide_latency_excl_lc_lines'] = p.decide_latency_lines - p.lc_lines_in_decide_window
        parts.append(p[['log', 'cid', 'first_line', 'last_line', 'first_propose_line', 'first_decide_line', 'decide_latency_lines',
                        'lc_lines_in_decide_window', 'decide_latency_excl_lc_lines', 'lc_lines_in_cid_span', 'max_epoch_ts', 'propose_leader', 'n_decide_lines', 'n_ooc']])
    return pd.concat(parts, ignore_index=True)


def mwu(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    u, p = stats.mannwhitneyu(a, b, alternative='two-sided', method='asymptotic')
    r = 2 * u / (len(a) * len(b)) - 1                              # rank-biserial correlation: > 0 -> a larger than b
    diff = np.subtract.outer(a, b).ravel()
    return dict(U=u, p=p, rank_biserial=r, hodges_lehmann_shift_lines=float(np.median(diff)))


def effect_summary(per):
    q = per[per.cid >= 1].copy()
    q['hit'] = q.lc_lines_in_cid_span.fillna(0) > 0
    groups = {
        'log 1 (CIDs 1-999)': q[q.log == 'log 1'],
        'log 2 (CIDs 1-999)': q[q.log == 'log 2'],
        'log 3 (CIDs 1-999)': q[q.log == 'log 3'],
        'log 4, CIDs without a leader-change line inside': q[(q.log == 'log 4') & ~q.hit],
        'log 4, CIDs with STOP(2) lines inside': q[(q.log == 'log 4') & q.hit],
    }
    rows = []
    for name, g in groups.items():
        x = g.decide_latency_excl_lc_lines.astype(float)
        rows.append(dict(group=name, n_cids=len(g), median_latency_lines_raw=float(g.decide_latency_lines.median()),
                         median_latency_excl_lc_lines=float(x.median()), q1=float(x.quantile(.25)), q3=float(x.quantile(.75)),
                         min=float(x.min()), max=float(x.max()), median_lc_lines_inside=float(g.lc_lines_in_decide_window.median()),
                         median_ooc_lines=float(g.n_ooc.astype(float).median())))
    summ = pd.DataFrame(rows)
    comps = [('log 4 hit vs log 4 clear', 'log 4, CIDs with STOP(2) lines inside', 'log 4, CIDs without a leader-change line inside',
              'does a CID that contains a STOP(2) re-transmission take longer once those lines are excluded?'),
             ('log 4 clear vs log 2', 'log 4, CIDs without a leader-change line inside', 'log 2 (CIDs 1-999)',
              'same regency 1 / leader 1 in both; only log 4 carries the stalled regency 2'),
             ('log 4 clear vs log 3', 'log 4, CIDs without a leader-change line inside', 'log 3 (CIDs 1-999)', 'regency 1 (log 4) vs regency 0 (log 3)'),
             ('log 4 clear vs log 1', 'log 4, CIDs without a leader-change line inside', 'log 1 (CIDs 1-999)', 'regency 1 (log 4) vs regency 0 (log 1)'),
             ('log 2 vs log 3', 'log 2 (CIDs 1-999)', 'log 3 (CIDs 1-999)', 'reference: two logs without any stalled regency, regency 1 vs 0'),
             ('log 1 vs log 3', 'log 1 (CIDs 1-999)', 'log 3 (CIDs 1-999)', 'reference: both regency 0, no leader change - shows the log-1 offset is not a regency effect')]
    tr = []
    for name, a, b, why in comps:
        x = groups[a].decide_latency_excl_lc_lines.astype(float).values
        y = groups[b].decide_latency_excl_lc_lines.astype(float).values
        r = mwu(x, y)
        tr.append(dict(comparison=name, group_a=a, group_b=b, n_a=len(x), n_b=len(y), median_a=float(np.median(x)), median_b=float(np.median(y)), question=why, **r))
    tr = pd.DataFrame(tr)
    tr['p_holm'] = holm(tr.p.values)
    tr['effect_label'] = pd.cut(tr.rank_biserial.abs(), [-1, 0.1, 0.3, 0.5, 1.01], labels=['negligible (<0.1)', 'small (0.1-0.3)', 'medium (0.3-0.5)', 'large (>0.5)']).astype(str)
    return summ, tr


def integrity(i, ev, q1):
    lab = LOGS[i]['label']
    p = q1[q1.log == lab]
    ex = ev[ev.kind == 'exec']
    cr = ev[ev.kind == 'client_ret'].sort_values('line')
    vals = cr.value.dropna().astype(int).tolist()
    exec_per_req = ex.groupby(ex.value.astype(int)).size()
    rest = p[p.cid >= 1]
    return dict(log=lab, n_cids=len(p), n_cids_with_4_decide_lines=int((p.n_decide_lines == 4).sum()),
                n_exec_lines=len(ex), requests_with_4_exec_lines='%d of %d' % (int((exec_per_req == 4).sum()), len(exec_per_req)),
                exec_values_1_to_1000=bool(sorted(exec_per_req.index.tolist()) == list(range(1, 1001))),
                n_client_replies_parsed=len(vals),
                client_replies_strictly_increasing=bool(all(b > a for a, b in zip(vals, vals[1:]))),
                client_replies_are_1_to_1000_in_order=bool(vals == list(range(1, 1001))),
                cids_ge1_leader=','.join(str(int(x)) for x in sorted(rest.propose_leader.dropna().unique())),
                cids_ge1_max_epoch_ts=int(rest.max_epoch_ts.max()), cids_ge1_with_more_than_one_attempt=int((rest.n_attempts > 1).sum()),
                note=('log 1: client text overwrote replica characters, only part of the "returned value" tokens survive (the order check uses the survivors)'
                      if i == 1 else ''))


# ----------------------------------------------------------------------------------------------------------------
def plot_q6(inv, senders, pairs, per, order):
    import matplotlib.gridspec as gridspec
    from matplotlib.colors import LinearSegmentedColormap
    fig = plt.figure(figsize=(13.6, 11.6))
    gs = gridspec.GridSpec(2, 2, hspace=0.52, wspace=0.36, left=0.075, right=0.985, top=0.935, bottom=0.165, figure=fig)

    # (a) distinct STOP senders vs thresholds
    ax = fig.add_subplot(gs[0, 0])
    bars = [('log 1', 0), ('log 2', 1), ('log 3', 0), ('log 4', 1), ('log 4', 2)]
    for xi, (lab, R) in enumerate(bars):
        s = senders[(senders.log == lab) & (senders.message == 'STOP') & (senders.regency == R)].sort_values('rank_by_first_receipt') if len(senders) else senders
        if R == 0:
            ax.text(xi, 0.12, 'no STOP at all\n(regency 0 only)', ha='center', va='bottom', fontsize=8.2, color=TEXT2)
            continue
        for k, r in enumerate(s.itertuples()):
            c = REPLICA_COLOR[int(r.sender)]
            ax.bar(xi, 1, bottom=k, width=0.62, color=c, edgecolor=SURFACE, linewidth=2.0)
            ax.text(xi, k + 0.5, '%d' % r.sender, ha='center', va='center', fontsize=9, color=TEXT if int(r.sender) == 3 else 'white', fontweight='bold')
        status = inv[(inv.log == lab) & (inv.regency == R)].status.iloc[0]
        ax.text(xi, len(s) + 0.12, 'installed' if status.startswith('INSTALLED') else 'never installed', ha='center', va='bottom', fontsize=8.4, color=TEXT)
    for y, txt in [(JOIN_STOPS, 'F+1 = 2: join threshold'), (INSTALL_STOPS, '2F+1 = 3: install threshold')]:
        ax.axhline(y, color=MUTED, lw=1.1, ls=(0, (4, 3)), zorder=1)
        ax.text(2.0, y + 0.06, txt, ha='center', va='bottom', fontsize=8.2, color=TEXT2)
    ax.set_xticks(range(len(bars)))
    ax.set_xticklabels(['log 1\nregency 0', 'log 2\nregency 1', 'log 3\nregency 0', 'log 4\nregency 1', 'log 4\nregency 2'], fontsize=8.6)
    ax.set_ylim(0, 4.9)
    ax.set_xlim(-0.55, 4.6)
    ax.set_ylabel('distinct replicas whose STOP was received')
    ax.grid(axis='x', visible=False)
    ax.set_title('(a) Distinct STOP senders per regency vs the thresholds\n(segment = one replica, bottom = first received)', fontsize=9.8, pad=8)

    # (b) (last, next) pair grid
    ax = fig.add_subplot(gs[0, 1])
    cols = [(0, 0), (0, 1), (1, 1), (1, 2)]
    rows = [('STOP', 1, 'STOP for regency 1'), ('STOP', 2, 'STOP for regency 2'), ('STOPDATA', 1, 'STOPDATA (regency 1)'), ('SYNC', 1, 'SYNC (regency 1)')]
    cmap = LinearSegmentedColormap.from_list('seq', ['#f1f6fd', SEQ[1], SEQ[3], SEQ[5], SEQ[6]])
    xs = {}
    for gi, lab in enumerate(['log 2', 'log 4']):
        for ci, c in enumerate(cols):
            xs[(lab, c)] = gi * 4.7 + ci
    for lab in ['log 2', 'log 4']:
        for ri, (mt, R, _) in enumerate(rows):
            for c in cols:
                g = pairs[(pairs.log == lab) & (pairs.message == mt) & (pairs.regency_in_message == R) & (pairs.last_regency == c[0]) & (pairs.next_regency == c[1])]
                n = int(g.n.sum()) if len(g) else 0
                x = xs[(lab, c)]
                col = cmap(np.log10(1 + n) / np.log10(1 + 567)) if n else SURFACE
                ax.add_patch(plt.Rectangle((x - 0.46, ri - 0.44), 0.92, 0.88, facecolor=col, edgecolor=GRID if not n else SURFACE, linewidth=1.2))
                if n:
                    ax.text(x, ri, format(n, ','), ha='center', va='center', fontsize=8.6, color='white' if np.log10(1 + n) / np.log10(568) > 0.55 else TEXT)
                if lab == 'log 4' and (mt, R, c) == ('STOP', 2, (1, 1)):
                    ax.add_patch(plt.Rectangle((x - 0.46, ri - 0.44), 0.92, 0.88, facecolor='none', edgecolor=REPLICA_COLOR[1], linewidth=2.2))
    ax.set_xlim(-0.7, 4.7 + 3.7)
    ax.set_ylim(len(rows) + 0.55, -1.15)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([r[2] for r in rows], fontsize=8.4)
    ax.set_xticks([xs[('log 2', c)] for c in cols] + [xs[('log 4', c)] for c in cols])
    ax.set_xticklabels(['%d,%d' % c for c in cols] * 2, fontsize=8.4)
    for gi, lab in enumerate(['log 2', 'log 4']):
        ax.text(gi * 4.7 + 1.5, -0.78, lab, ha='center', va='center', fontsize=9.5, fontweight='bold', color=TEXT)
    ax.text(4.0, len(rows) + 0.18, 'orange outline: all 567 receipts of a STOP for regency 2 are followed by "Last regency: 1, next regency: 1"\n= the regency did not advance (nobody joined, nobody installed)',
            ha='center', va='center', fontsize=8.1, color=TEXT2)
    ax.text(1.5, 1.0, 'no STOP for regency 2', ha='center', va='center', fontsize=8, color=MUTED)
    ax.grid(False)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_xlabel('"Last regency, next regency" printed after the receipt  (shade = log scale of the count)')
    ax.set_title('(b) "Last regency / next regency" after each received leader-change message', fontsize=9.8, pad=8)

    # (c) latency per CID
    ax = fig.add_subplot(gs[1, 0])
    q = per[per.cid >= 1].copy()
    q['hit'] = q.lc_lines_in_cid_span.fillna(0) > 0
    data = [('log 1', q[q.log == 'log 1'].decide_latency_excl_lc_lines, LOG_COLOR[1]), ('log 2', q[q.log == 'log 2'].decide_latency_excl_lc_lines, LOG_COLOR[2]),
            ('log 3', q[q.log == 'log 3'].decide_latency_excl_lc_lines, LOG_COLOR[3]), ('log 4', q[(q.log == 'log 4') & ~q.hit].decide_latency_excl_lc_lines, LOG_COLOR[4])]
    for k, (lab, v, c) in enumerate(data):
        v = v.astype(float).dropna()
        bp = ax.boxplot([v], positions=[k], widths=0.5, whis=(5, 95), showfliers=False, patch_artist=True, manage_ticks=False,
                        medianprops=dict(color=TEXT, linewidth=1.6), whiskerprops=dict(color=c, linewidth=1.2), capprops=dict(color=c, linewidth=1.2),
                        boxprops=dict(facecolor=c, edgecolor=c, alpha=0.55, linewidth=1.2))
    hit = q[(q.log == 'log 4') & q.hit]
    ax.scatter(np.full(len(hit), 4.0) + np.linspace(-0.12, 0.12, len(hit)), hit.decide_latency_excl_lc_lines.astype(float), s=34, color=REPLICA_COLOR[1], edgecolor=SURFACE, linewidth=0.9, zorder=4)
    ax.set_xticks(range(5))
    ax.set_xticklabels(['log 1\nregency 0', 'log 2\nregency 1', 'log 3\nregency 0', 'log 4\nregency 1\n(CIDs without\nSTOP(2) lines)', 'log 4: the %d\nCIDs with\nSTOP(2) lines' % len(hit)], fontsize=8.2)
    ax.set_ylabel('lines from first PROPOSE to first "Deciding"\n(leader-change lines excluded)')
    ax.set_xlim(-0.6, 4.6)
    ax.grid(axis='x', visible=False)
    ax.set_title('(c) Decision latency of CIDs 1-999 (lines, not seconds): median, IQR, 5-95%', fontsize=9.8, pad=8)

    # (d) rank grid
    ax = fig.add_subplot(gs[1, 1])
    stages = [('STOP(1): first receipt', 'STOP 1st receipt'), ('STOPDATA(1): first receipt at the new leader', 'STOPDATA receipt'),
              ('WRITE at ts 1 ("Sending WRITE message for CID 0, timestamp 1")', 'WRITE ts 1 (inferred)'), ('ACCEPT at ts 1 ("Sending ACCEPT message, cId:0, I am:N")', 'ACCEPT ts 1')]
    ylabels = []
    yy = 0
    cm2 = LinearSegmentedColormap.from_list('rk', [SEQ[0], SEQ[2], SEQ[4], SEQ[6]])
    for lab in ['log 2', 'log 4']:
        for key, short in stages:
            d = order[(order.log == lab) & (order.stage == key)]
            for rep in range(N):
                r = d[d.replica == rep]
                if not len(r):
                    ax.add_patch(plt.Rectangle((rep - 0.46, yy - 0.44), 0.92, 0.88, facecolor=SURFACE, edgecolor=GRID, linewidth=1.0))
                    ax.text(rep, yy, 'leader' if key.startswith('STOPDATA') else '-', ha='center', va='center', fontsize=8, color=MUTED)
                    continue
                lo, hi = int(r.rank_first.iloc[0]), int(r.rank_last.iloc[0])
                m = (lo + hi) / 2
                ax.add_patch(plt.Rectangle((rep - 0.46, yy - 0.44), 0.92, 0.88, facecolor=cm2((m - 1) / 3), edgecolor=SURFACE, linewidth=1.2))
                ax.text(rep, yy, str(lo) if lo == hi else '%d or %d' % (lo, hi), ha='center', va='center', fontsize=8.8 if lo == hi else 8,
                        color='white' if (m - 1) / 3 > 0.45 else TEXT)
            ylabels.append('%s: %s' % (lab, short.replace('\n', ' ')))
            yy += 1
        yy += 0.35
    ax.set_xlim(-0.6, 3.6)
    ax.set_ylim(yy - 0.2, -0.7)
    ys = []
    yy = 0
    for lab in ['log 2', 'log 4']:
        for _ in stages:
            ys.append(yy)
            yy += 1
        yy += 0.35
    ax.set_yticks(ys)
    ax.set_yticklabels(ylabels, fontsize=7.9)
    ax.set_xticks(range(N))
    ax.set_xticklabels(['replica %d' % k for k in range(N)], fontsize=8.6)
    ax.xaxis.set_ticks_position('top')
    ax.grid(False)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_title('(d) Order of the replicas in the recovery (1 = first, 4 = last; darker = later)', fontsize=9.8, pad=24)
    fig.text(0.5, 0.012, 'Receipts carry "from replica N" (tagged); "Sending ACCEPT ... I am:N" is tagged too.  "Sending STOP / STOPDATA / WRITE ts 1" lines carry no replica id: starters / joiners and the WRITE ts 1 order are INFERRED\n'
             'from line order (causality), see csv/q4_send_inference.csv and csv/q6_recovery_response_order.csv.  Only two logs went through a leader change: first / last counts in (d) are anecdotes, not statistics.\n'
             '(c): "CIDs with STOP(2) lines" = CIDs whose line span contains a line of the stalled regency 2 (the 9 single re-transmissions, 7 lines each, touch 11 CIDs because CID spans overlap); those lines are subtracted.',
             ha='center', va='bottom', fontsize=8, color=TEXT2)
    save(fig, 'q6_regency_analysis.png')


def main():
    style()
    evs = {i: load_events(i) for i in LOGS}
    q1 = pd.read_csv(os.path.join(CSV_DIR, 'q1_cid_progress.csv'))
    q2 = pd.read_csv(os.path.join(CSV_DIR, 'q2_first_last_per_cid.csv'))
    inv, snd, prs, chk, ldr, ordr, integ = [], [], [], [], [], [], []
    send_inf_all = pd.read_csv(os.path.join(CSV_DIR, 'q4_send_inference.csv'))
    for i in LOGS:
        ev = evs[i]
        si = send_inf_all[send_inf_all.log == LOGS[i]['label']]
        inv.append(inventory(i, ev, q1, si))
        snd.append(sender_table(i, ev, si))
        p, c = state_pair_table(i, ev)
        prs.append(p)
        chk.append(c)
        ldr.append(leader_roles(i, ev))
        if len(lc_events(ev)):
            ordr.append(recovery_order(i, ev, q2, si))
        integ.append(integrity(i, ev, q1))
    inv = pd.concat(inv, ignore_index=True)
    snd = pd.concat([s for s in snd if len(s)], ignore_index=True)
    prs = pd.concat([p for p in prs if len(p)], ignore_index=True)
    chk = pd.concat([c for c in chk if len(c)], ignore_index=True)
    ldr = pd.concat(ldr, ignore_index=True)
    ordr = pd.concat(ordr, ignore_index=True)
    integ = pd.DataFrame(integ)
    per = effect_tables(evs, q1)
    summ, tests = effect_summary(per)
    write_csv(inv, 'q6_regency_inventory.csv')
    write_csv(snd, 'q6_stop_senders.csv')
    write_csv(prs, 'q6_state_pairs.csv')
    write_csv(chk, 'q6_pairing_check.csv')
    write_csv(ldr, 'q6_leader_roles.csv')
    write_csv(ordr, 'q6_recovery_response_order.csv')
    write_csv(per, 'q6_regency2_effect_per_cid.csv')
    write_csv(pd.concat([summ.assign(table='group summary (decision latency in lines, leader-change lines excluded)'),
                         tests.assign(table='Mann-Whitney tests (Holm-corrected over the 6 comparisons)')], ignore_index=True), 'q6_regency2_effect_summary.csv')
    write_csv(integ, 'q6_integrity_checks.csv')
    plot_q6(inv, snd, prs, per, ordr)
    pd.set_option('display.width', 280); pd.set_option('display.max_columns', 60); pd.set_option('display.max_colwidth', 130); pd.set_option('display.max_rows', 300)
    print(inv.T.to_string())
    print(snd.to_string())
    print(prs.to_string())
    print(chk.to_string())
    print(ldr.to_string())
    print(ordr.to_string())
    print(summ.to_string())
    print(tests.T.to_string())
    print(integ.T.to_string())


if __name__ == '__main__':
    main()
