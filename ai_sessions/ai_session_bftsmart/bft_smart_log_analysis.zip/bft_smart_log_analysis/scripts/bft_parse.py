#!/usr/bin/env python3
"""
bft_parse.py - tolerant parser for the BFT-SMaRt console logs (4 replicas + 1 client share one stdout).

Why "tolerant": the client prints "Invocation N" and ", returned value: V" to the same stream as the
replicas.  In the logs this text is spliced into replica lines:
  * logs 2-4 (no [replicaN] prefix): concatenation, nothing is lost, e.g.
        "Invocation 12-- Processing paxos msg with id 11"
  * log 1 ([replicaN] prefix): the client text OVERWRITES characters of the replica line, e.g.
        ", returned value: 3f context msg with id 2"      (was "[replica0] -- Out of context msg with id 2")
    so the head of a replica line (incl. the replica prefix) can be lost, and a line can be torn in two.
The parser matches the distinctive TAIL of every message (it survives in almost all cases), flags every
event whose head was lost (`tail_only`), records every physical line that is not a clean single message,
and never guesses a replica that cannot be read from the line itself (prefix, "I am:N", or a torn-head join).

Public API
    parse_log(path, prefixed) -> (events, issues)
CLI:  python3 bft_parse.py <log_path> <prefixed:0|1> <out_events.csv> <out_issues.csv>
"""
import re
import sys
import csv

PREFIX_RE = re.compile(r'^\[?replica(\d)\] ?')

# (kind, head_literal, tail_regex, group names).  head_literal = the text that precedes the tail in an undamaged
# message; "" means the regex already contains the whole message.
_PATTERNS = [
    # --- normal chain ---------------------------------------------------------------------
    ('propose_recv', 'PROPOSE received ', r"from:(\d+), for consensus cId:(\d+), I am:(\d+)", ('sender', 'cid', 'iam')),
    ('write_recv',   'WRITE received ',   r"from:(\d+), for consensus cId:(\d+)(?!\d|, I am)", ('sender', 'cid')),
    ('propose_exec', 'Executing propose for ', r"cId:(\d+), Epoch Timestamp:(\d+)(?!\d)", ('cid', 'ts')),
    ('write_send',   'Sending ',          r"[A-Z]+ for cId:(\d+), I am:(\d+)(?!\d)", ('cid', 'iam')),
    ('write_comp',   'WRITE ',            r"[a-z]+ for cId:(\d+), I am:(\d+)(?!\d)", ('cid', 'iam')),
    ('accept_send',  'Sending ACCEPT message', r", cId:(\d+), I am:(\d+)(?!\d)", ('cid', 'iam')),
    ('write_send0',  'Sending ',          r"WRITE for (\d+)(?!\d)", ('cid',)),
    ('write_count',  'I have ',           r"(\d)?, WRITE's for cId:(\d+), Epoch timestamp:(\d+),", ('k', 'cid', 'ts')),
    ('accept_count', 'I have ',           r"(\d)? ACCEPTs for cId:(\d+), Timestamp:(\d+)(?!\d)", ('k', 'cid', 'ts')),
    ('accept_recv',  'ACCEPT ',          r"(?:from|rom|om|m) (\d+) for consensus (\d+)(?!\d)", ('sender', 'cid')),
    ('quorum_set',   'Setting ',          r"consensus (\d+) QuorumWrite tiemstamp to (\d+) and value(?: \[[-\d, ]*\]?)?", ('cid', 'ts')),
    ('spec_proof',   'Creating cryptographic proof for speculative ', r"ACCEPT message from consensus (\d+)(?!\d)", ('cid',)),
    ('spec_accept',  'Speculative ACCEPT ', r"message for consensus (\d+) matches the written value, sending it to the other replicas", ('cid',)),
    ('decide',       '',                  r"(?:Deciding|eciding|ciding|iding|ding|ing|ng) consensus (\d+)(?!\d)(?! QuorumWrite)", ('cid',)),
    ('exec',         '',                  r"(?:\((\d+)\) Counter |\) Counter |(?:Counter|ounter|unter|nter|ter|er|r) )?was incremented\. Current value = (\d+)(?!\d)", ('k', 'value')),
    ('paxos_msg',    'Processing ',       r"(?:paxos|axos|xos|os) msg with id (\d+)(?!\d)", ('cid',)),
    ('ooc',          'Out of ',           r"(?:context|ontext|ntext|text|ext|xt) msg with id (\d+)(?!\d)", ('cid',)),
    ('msg_id_amb',   'Processing paxos msg w', r"(?:ith|th|h) id (\d+)(?!\d)", ('cid',)),            # head lost: paxos or ooc
    # --- timeouts / leader change (always complete, nothing is lost in logs 2-4) -------------
    ('lc_timeout',   '', r"The following requests timed out: \[\[(\d+):(-?\d+):(\d+)\]\]", ('client', 'seq', 'op')),
    ('lc_forward',   '', r"Forwarding requests \[(\d+):(-?\d+):(\d+)\] to leader", ('client', 'seq', 'op')),
    ('lc_attempt',   '', r"Attempting to start leader change for requests \[\[(\d+):(-?\d+):(\d+)\]\]", ('client', 'seq', 'op')),
    ('lc_send_stop', '', r"Sending STOP message to install regency (\d+) with (\d+) request\(s\) to relay", ('regency', 'nreq')),
    ('lc_retransmit', '', r"Re-transmitting STOP message to install regency (\d+)", ('regency',)),
    ('lc_recv',      '', r"Received leader change message of type (STOPDATA|STOP|SYNC) for regency (\d+) from replica (\d+)", ('mtype', 'regency', 'sender')),
    ('lc_state',     '', r"Last regency: (\d+), next regency: (\d+)", ('last', 'next')),
    ('lc_send_stopdata', '', r"Sending STOPDATA of regency (\d+)", ('regency',)),
    ('lc_no_ooc_sync', '', r"No out of context SYNC for regency (\d+)", ('regency',)),
    ('lc_send_sync', '', r"Sending SYNC message for regency (\d+)", ('regency',)),
    ('lc_no_proof',  '', r"I did not install any proof of last decided consensus (-?\d+)", ('lastcid',)),
    ('sync_write',   '', r"Sending WRITE message for CID (\d+), timestamp (\d+), value(?: \[[-\d, ]*\]?)?", ('cid', 'ts')),
    # --- start-up -----------------------------------------------------------------------------
    ('st_uptodate',  '', r"Replica state is up to date", ()),
    ('st_retrieve',  '', r"Retrieving State", ()),
    ('st_ready',     '', r"Ready to process operations", ()),
    ('st_session',   '', r"Session Created, active clients=(\d+)", ('value',)),
    ('st_view',      '', r"Using view stored on disk", ()),
    ('st_tls',       '', r"SSL/TLS handshake complete!, Id:(\d+)", ('value',)),
    # --- last-resort fragments (head lost completely) ---------------------------------------------
    ('cid_iam_amb',  'Sending WRITE for|WRITE computed for', r" for cId:(\d+), I am:(\d+)(?!\d)", ('cid', 'iam')),
    ('decide_amb',   'Deciding', r" consensus (\d+)(?!\d)(?! QuorumWrite)", ('cid',)),    # 'Deciding' lost; only 'consensus N' left
]
PATTERNS = [(k, h, re.compile(rx), g) for k, h, rx, g in _PATTERNS]
CLIENT_PATTERNS = [('client_inv', re.compile(r"Invocation (\d+)"), ('value',)),
                   ('client_ret', re.compile(r", returned value: (\d+)"), ('value',))]

# a client number glued to a following single digit counter ("..value: 1042 ACCEPTs") -> split with a space
_GLUE_RE = re.compile(r"(, returned value: \d+)(\d)(, WRITE's for cId:| ACCEPTs for cId:)")

FULL_MSG_RE = re.compile(
    r"^(?:-- (?:"
    r"Processing paxos msg with id \d+|Out of context msg with id \d+|"
    r"PROPOSE received from:\d+, for consensus cId:\d+, I am:\d+|WRITE received from:\d+, for consensus cId:\d+|"
    r"Executing propose for cId:\d+, Epoch Timestamp:\d+|Sending WRITE for \d+|Sending WRITE for cId:\d+, I am:\d+|"
    r"WRITE computed for cId:\d+, I am:\d+|Sending ACCEPT message, cId:\d+, I am:\d+|"
    r"I have \d+, WRITE's for cId:\d+, Epoch timestamp:\d+,|I have \d+ ACCEPTs for cId:\d+, Timestamp:\d+ |"
    r"ACCEPT from \d+ for consensus \d+|Setting consensus \d+ QuorumWrite tiemstamp to \d+ and value \[[-\d, ]*\]|"
    r"Creating cryptographic proof for speculative ACCEPT message from consensus \d+|"
    r"Speculative ACCEPT message for consensus \d+ matches the written value, sending it to the other replicas|"
    r"Deciding consensus \d+|Replica state is up to date|Retrieving State|Session Created, active clients=\d+|"
    r"The following requests timed out: \[\[\d+:-?\d+:\d+\]\]|Forwarding requests \[\d+:-?\d+:\d+\] to leader|"
    r"Attempting to start leader change for requests \[\[\d+:-?\d+:\d+\]\]|"
    r"Sending STOP message to install regency \d+ with \d+ request\(s\) to relay|"
    r"Re-transmitting STOP message to install regency \d+|"
    r"Received leader change message of type (?:STOPDATA|STOP|SYNC) for regency \d+ from replica \d+|"
    r"Last regency: \d+, next regency: \d+|Sending STOPDATA of regency \d+|No out of context SYNC for regency \d+|"
    r"Sending SYNC message for regency \d+|I did not install any proof of last decided consensus -?\d+|"
    r"Sending WRITE message for CID \d+, timestamp \d+, value \[[-\d, ]*\]|"
    r"Using view stored on disk|SSL/TLS handshake complete!, Id:\d+  ## CipherSuite: \S+|"
    r"ID = \d+|N = \d+|F = \d+|Port \(client <-> server\) = \d+|Port \(server <-> server\) = \d+|"
    r"requestTimeout = \d+|maxBatch = \d+|Binded replica to IP address \S+|Optimizations:  Read-only Requests: \w+|"
    r"SSL/TLS enabled, protocol version: \S+|In current view: .*|)"
    r"|\(\d+\) Counter was incremented\. Current value = \d+"
    r"|\s*#{10,}\s*|\s*Ready to process operations\s*)$")

_TEMPLATES = """
-- Processing paxos msg with id #
-- Out of context msg with id #
-- PROPOSE received from:#, for consensus cId:#, I am:#
-- WRITE received from:#, for consensus cId:#
-- Executing propose for cId:#, Epoch Timestamp:#
-- Sending WRITE for #
-- Sending WRITE for cId:#, I am:#
-- WRITE computed for cId:#, I am:#
-- Sending ACCEPT message, cId:#, I am:#
-- I have #, WRITE's for cId:#, Epoch timestamp:#,
-- I have # ACCEPTs for cId:#, Timestamp:#
-- ACCEPT from # for consensus #
-- Setting consensus # QuorumWrite tiemstamp to # and value [
-- Creating cryptographic proof for speculative ACCEPT message from consensus #
-- Speculative ACCEPT message for consensus # matches the written value, sending it to the other replicas
-- Deciding consensus #
(#) Counter was incremented. Current value = #
Invocation #
, returned value: #
-- Replica state is up to date
-- Retrieving State
-- Session Created, active clients=#
-- Sending WRITE message for CID #, timestamp #, value [
"""
_TEMPLATE_BLOB = _TEMPLATES.replace('\n', '\x01')


def _explained_fragment(frag: str) -> bool:
    """True if `frag` is a piece (digits->#) of one known message template."""
    f = re.sub(r'\d+', '#', frag).strip().strip('-[] ')
    return f == '' or f in _TEMPLATE_BLOB


def _scan(rest: str):
    """Find non-overlapping events in `rest`: replica messages first, then client tokens on what is left."""
    rest = _GLUE_RE.sub(r'\1 \2\3', rest)
    cand = []
    for kind, head, rx, gnames in PATTERNS:
        for m in rx.finditer(rest):
            cand.append((m.start(), m.end(), kind, head, gnames, m))
    # earliest start first; among equal starts prefer the longer match and the more specific (earlier-listed) kind
    order = {k: i for i, (k, *_r) in enumerate(PATTERNS)}
    cand.sort(key=lambda c: (c[0], -(c[1] - c[0]), order[c[2]]))
    out, last_end = [], -1
    for s, e, kind, head, gnames, m in cand:
        if s < last_end:
            continue
        out.append((s, e, kind, head, gnames, m))
        last_end = e
    masked = list(rest)
    for s, e, *_ in out:
        for i in range(s, e):
            masked[i] = '\x00'
    masked = ''.join(masked)
    for kind, rx, gnames in CLIENT_PATTERNS:
        for m in rx.finditer(masked):
            out.append((m.start(), m.end(), kind, '', gnames, m))
    out.sort(key=lambda c: c[0])
    consumed = [False] * len(rest)
    for s, e, *_ in out:
        for i in range(s, e):
            consumed[i] = True
    leftover = ''.join(ch for ch, c in zip(rest, consumed) if not c)
    return rest, out, leftover


def _head_ok(rest: str, st: int, kind: str, head: str, m) -> bool:
    if kind in ('client_inv', 'client_ret'):
        return True
    if kind == 'decide':
        return m.group(0).startswith('Deciding')
    if kind == 'exec':
        return m.group(1) is not None
    if kind in ('msg_id_amb', 'cid_iam_amb', 'decide_amb'):
        return False
    if head == '':
        return True
    before = rest[:st]
    return before.endswith(head)


def parse_log(path: str, prefixed: bool):
    events, issues = [], []
    pending_torn = None            # (line_no, replica) of a torn head awaiting its tail on the next line
    last_inv, last_ret = -1, 0     # sequence repair for client numbers glued to other digits
    with open(path, 'r', errors='replace') as fh:
        for ln, raw in enumerate(fh, 1):
            s = raw.rstrip('\n')
            if s.strip() == '':
                issues.append({'line': ln, 'klass': 'blank', 'raw': '', 'note': 'empty line (stray newline left by a splice)',
                               'events_recovered': ''})
                pending_torn = None
                continue
            pm = PREFIX_RE.match(s)
            prefix_rep = int(pm.group(1)) if pm else None
            rest0 = s[pm.end():] if pm else s
            rest, found, leftover = _scan(rest0)
            is_banner = bool(re.match(r'^\s*(?:#{10,}|Ready to process operations)\s*$', rest0))
            clean = bool(FULL_MSG_RE.match(rest0)) and (not prefixed or prefix_rep is not None)
            note, klass = '', ('clean' if clean else None)
            if clean and prefixed and not s.startswith('[replica'):
                klass, note = 'prefix_bracket_lost', "line starts with 'replica%d]' ('[' overwritten); content intact" % prefix_rep
            frag = re.sub(r'(?:-- |\[|\]|\s)+', ' ', leftover).strip()
            kinds = [f[2] for f in found]
            tail_only_flags = {}
            for idx, (st, en, kind, head, gnames, m) in enumerate(found):
                tail_only_flags[idx] = not _head_ok(rest, st, kind, head, m)
            any_tail_only = any(tail_only_flags.values())
            if klass is None:
                n_rep_msgs = sum(1 for k in kinds if k not in ('client_inv', 'client_ret'))
                has_client = any(k in ('client_inv', 'client_ret') for k in kinds)
                if not found:
                    if _explained_fragment(frag) and prefix_rep is not None:
                        klass, note = 'torn_head', 'head of a message cut by the splice; its tail is expected on the next line'
                    elif is_banner:
                        klass = 'clean'
                    else:
                        klass, note = 'unparsed', 'no known message found'
                elif not _explained_fragment(frag):
                    klass, note = 'unparsed_residue', 'events recovered, but unexplained leftover=%r' % frag[:60]
                elif any_tail_only:
                    klass, note = 'damaged_recovered', 'head of a message lost (client text overwrote it); tail parsed; leftover=%r' % frag[:40]
                elif n_rep_msgs == 0:
                    klass = 'client_only'
                elif has_client and n_rep_msgs == 1:
                    klass = 'spliced_client'
                elif (not has_client) and n_rep_msgs >= 2:
                    klass = 'spliced_concat'
                else:
                    klass = 'spliced_mixed'
            join_rep = None
            if pending_torn is not None and prefixed and prefix_rep is None and found:
                join_rep = pending_torn[1]
                note = (note + '; ' if note else '') + 'replica taken from torn head on line %d' % pending_torn[0]
            pending_torn = (ln, prefix_rep) if klass == 'torn_head' else None

            first_rep_event = True
            for pos, (st, en, kind, head, gnames, m) in enumerate(found):
                e = {'kind': kind}
                for name, val in zip(gnames, m.groups()):
                    e[name] = None if val is None else (val if name == 'mtype' else int(val))
                rep, rep_src = None, 'none'
                if kind in ('client_inv', 'client_ret'):
                    rep_src = 'client'
                    v = e['value']
                    if kind == 'client_inv':
                        exp = last_inv + 1
                        if v != exp and str(v).startswith(str(exp)):
                            e['value'] = v = exp
                        last_inv = v
                    else:
                        exp = last_ret + 1
                        if v != exp and str(v).startswith(str(exp)):
                            e['value'] = v = exp
                        last_ret = v
                else:
                    if prefixed and first_rep_event:
                        if prefix_rep is not None and st <= 120:
                            rep, rep_src = prefix_rep, 'prefix'
                        elif join_rep is not None:
                            rep, rep_src = join_rep, 'joined_torn_head'
                    first_rep_event = False
                    iam = e.get('iam')
                    if iam is not None:
                        if rep is not None and rep != iam:
                            rep_src = 'CONFLICT(prefix=%s,iam=%s)' % (rep, iam)
                        elif rep is None:
                            rep, rep_src = iam, 'iam'
                        else:
                            rep_src = rep_src + '+iam'
                ev = {'line': ln, 'pos': pos, 'kind': kind, 'rep': rep, 'rep_src': rep_src,
                      'sender': e.get('sender'), 'cid': e.get('cid'), 'ts': e.get('ts'), 'k': e.get('k'),
                      'value': e.get('value'), 'regency': e.get('regency'), 'mtype': e.get('mtype'),
                      'last': e.get('last'), 'next': e.get('next'), 'client': e.get('client'), 'seq': e.get('seq'),
                      'tail_only': int(tail_only_flags[pos]), 'line_class': klass}
                events.append(ev)
            if klass != 'clean':
                issues.append({'line': ln, 'klass': klass, 'raw': s[:240], 'note': note,
                               'events_recovered': ';'.join(kinds)})
    return events, issues


EVENT_COLS = ['line', 'pos', 'kind', 'rep', 'rep_src', 'sender', 'cid', 'ts', 'k', 'value', 'regency', 'mtype',
              'last', 'next', 'client', 'seq', 'tail_only', 'line_class']
ISSUE_COLS = ['line', 'klass', 'raw', 'note', 'events_recovered']


def main():
    path, prefixed, out_ev, out_is = sys.argv[1], sys.argv[2] == '1', sys.argv[3], sys.argv[4]
    events, issues = parse_log(path, prefixed)
    with open(out_ev, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=EVENT_COLS, extrasaction='ignore')
        w.writeheader()
        w.writerows(events)
    with open(out_is, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=ISSUE_COLS, extrasaction='ignore')
        w.writeheader()
        w.writerows(issues)
    print('%s: %d events, %d non-clean lines' % (path, len(events), len(issues)))


if __name__ == '__main__':
    main()
