#!/usr/bin/env python3
"""
q4_leader_change_timeouts.py - Question 4: analyse leader change and timeout.

What it does
  * greps every log for the leader-change vocabulary (so "this log has no regency / timeout events" is backed by a count),
  * lists every timeout / forward / attempt / STOP / STOPDATA / SYNC / state line of logs 2 and 4 with its line number,
  * infers (by causality, always labelled as inference) which replica sent each untagged STOP / STOPDATA line,
  * builds a milestone table (line numbers) of the recovery in logs 2 and 4,
  * lists the 188 "Re-transmitting STOP message to install regency 2" lines of log 4,
  * documents the start-up difference (how many "Ready to process operations" banners precede the first PROPOSE).

Outputs
  csv/q4_keyword_counts.csv        log, keyword, n_lines, first_line, last_line (backs "no regency events" for logs 1 and 3)
  csv/q4_summary_per_log.csv       one row per log: counts of every leader-change message, first/last line, regencies, verdict
  csv/q4_timeline_events.csv       one row per leader-change/timeout line (logs 2, 4) + one explicit "no events" row for logs 1, 3
  csv/q4_milestones.csv            ordered recovery milestones with line numbers and offsets from the first timeout (logs 2, 4)
  csv/q4_send_inference.csv        causality-based sender inference for the untagged STOP / STOPDATA send lines
  csv/q4_retransmissions_log4.csv  every STOP(2) re-transmission of log 4 with CID in progress, phase (load / idle tail), gaps
  csv/q4_startup_race.csv          start-up banners vs first PROPOSE vs CID-0 outcome at timestamp 0, one row per log
  plots/q4_leader_change_timeline.png
Run:  python3 -I scripts/q4_leader_change_timeouts.py        (needs 00_parse_logs.py and q1_consensus_progress.py first)
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lc_helpers import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

KEYWORDS = [
    ('regency (any mention)', r'regency'),
    ('requests timed out', r'requests timed out'),
    ('Forwarding requests', r'Forwarding requests'),
    ('Attempting to start leader change', r'Attempting to start leader change'),
    ('Sending STOP message', r'Sending STOP message'),
    ('Re-transmitting STOP', r'Re-transmitting STOP'),
    ('Received leader change message', r'Received leader change message'),
    ('Last regency / next regency', r'Last regency'),
    ('Sending STOPDATA', r'Sending STOPDATA'),
    ('Sending SYNC', r'Sending SYNC'),
    ('Sending WRITE message for CID (SYNC phase)', r'Sending WRITE message for CID'),
    ('No out of context SYNC', r'No out of context SYNC'),
    ('did not install any proof', r'did not install any proof'),
    ('Exception / ERROR / WARN / SEVERE', r'Exception|ERROR|WARN|SEVERE'),
]

PHASE = {
    'lc_timeout': '1 timeout', 'lc_forward': '1 timeout', 'lc_attempt': '2 start leader change',
    'lc_send_stop': '3 STOP', 'lc_retransmit': '3 STOP', 'lc_send_stopdata': '4 STOPDATA', 'lc_no_ooc_sync': '4 STOPDATA',
    'lc_send_sync': '5 SYNC', 'lc_no_proof': '5 SYNC', 'sync_write': '6 resume at higher timestamp', 'lc_state': 'state line',
}


def phase_of(r):
    if r.kind == 'lc_recv':
        return {'STOP': '3 STOP', 'STOPDATA': '4 STOPDATA', 'SYNC': '5 SYNC'}.get(r.mtype, '?')
    return PHASE.get(r.kind, '?')


def short(i, line, width=150):
    t = raw(i, line, 400).replace('\t', ' ')
    if 'value [' in t:
        t = t[:t.index('value [') + 7] + '...]'
    return t[:width].strip()


def keyword_counts():
    import re
    rows = []
    for i in LOGS:
        L = raw_lines(i)
        for lab, pat in KEYWORDS:
            rx = re.compile(pat)
            hits = [n + 1 for n, t in enumerate(L) if rx.search(t)]
            rows.append(dict(log=LOGS[i]['label'], file=LOGS[i]['file'], keyword=lab, regex=pat, n_lines=len(hits),
                             first_line=hits[0] if hits else None, last_line=hits[-1] if hits else None))
    return pd.DataFrame(rows)


def startup_table(evs, q1):
    rows = []
    for i in LOGS:
        ev = evs[i]
        ready = ev[ev.kind == 'st_ready'].sort_values('line')
        p0 = int(ev[(ev.kind == 'propose_recv') & (ev.cid == 0)].line.min())
        a0 = ev[(ev.kind == 'accept_send') & (ev.cid == 0) & (ev.attempt == 0)]
        d0 = ev[(ev.kind == 'decide') & (ev.cid == 0)]
        d0_ts0 = d0[d0.attempt == 0]
        tmo = ev[ev.kind == 'lc_timeout']
        rd = [int(x) for x in ready.line]
        reps = [('%s' % (int(r) if pd.notna(r) else '?')) for r in ready.rep] if LOGS[i]['prefixed'] else ['n/a'] * len(rd)
        rows.append(dict(
            log=LOGS[i]['label'], file=LOGS[i]['file'], ready_banner_lines='|'.join(map(str, rd)),
            ready_banner_replica='|'.join(reps), first_propose_line_cid0=p0,
            ready_banners_before_first_propose=sum(1 for x in rd if x < p0),
            ready_banners_after_first_propose=sum(1 for x in rd if x > p0),
            accept_send_lines_cid0_ts0=len(a0), cid0_decided_at_ts0=bool(len(d0_ts0) > 0),
            first_timeout_line=int(tmo.line.min()) if len(tmo) else None,
            cid0_first_decide_line=int(d0.line.min()), cid0_epoch_ts_of_decision=int(q1[(q1.log == LOGS[i]['label']) & (q1.cid == 0)].max_epoch_ts.iloc[0]),
            outcome=('CID 0 decided at ts 0 (all 4 banners before the first PROPOSE); no timeout' if len(tmo) == 0 else
                     'CID 0 ts 0 stalled (%d of 4 ACCEPTs sent; %d banners after the first PROPOSE) -> request timeout -> leader change -> CID 0 re-run at ts 1'
                     % (len(a0), sum(1 for x in rd if x > p0)))))
    return pd.DataFrame(rows)


def build_timeline(i, ev, q1, send_inf):
    """All leader-change / timeout / SYNC-phase lines of one log, plus the start-up banners and CID-0 milestones."""
    d = lc_events(ev)
    last_ret = int(ev[ev.kind == 'client_ret'].line.max())
    rows = []
    inf = {}
    for _, r in send_inf.iterrows():
        inf[(r.message, int(r.send_line))] = r
    for r in d.itertuples():
        sender, how, cand = None, '', ''
        if r.kind == 'lc_recv':
            sender, how = int(r.sender), 'tagged ("from replica N" = sender of the received message; receiver not tagged)'
        elif r.kind in ('lc_send_stop', 'lc_send_stopdata'):
            msg = 'STOP' if r.kind == 'lc_send_stop' else 'STOPDATA'
            x = inf.get((msg, int(r.line)))
            if x is not None:
                cand = x.candidate_senders
                if pd.notna(x.assigned_sender):
                    sender, how = int(x.assigned_sender), 'INFERRED (unique feasible assignment, causality)'
                else:
                    how = 'INFERRED candidates only (%s)' % cand
        elif r.kind == 'lc_send_sync':
            sender, how = 1, 'INFERRED: new leader of regency 1 (all SYNC receipts say "from replica 1")'
        elif r.kind == 'lc_retransmit':
            sender, how = 1, 'INFERRED: all STOP(2) receipts say "from replica 1"'
        else:
            how = 'not tagged'
        req = ''
        if r.kind in ('lc_timeout', 'lc_forward', 'lc_attempt'):
            t = raw(i, int(r.line), 300)
            if '[' in t:
                req = t[t.index('['):].strip()
        rows.append(dict(
            log=LOGS[i]['label'], line=int(r.line), phase=phase_of(r), kind=r.kind,
            regency=int(r.regency) if pd.notna(r.regency) else None, msg_type=r.mtype if pd.notna(r.mtype) else '',
            sender=sender, sender_basis=how, cid_in_progress=cid_at_line(q1, int(r.line)),
            after_last_client_reply=bool(r.line > last_ret), request=req, text=short(i, int(r.line))))
    tl = pd.DataFrame(rows)
    # "Last regency: a, next regency: b" values of the state lines
    st = d[['line', 'last', 'next']].rename(columns={'last': 'last_regency', 'next': 'next_regency'})
    tl = tl.merge(st, on='line', how='left')
    for c in ('last_regency', 'next_regency'):
        tl[c] = tl[c].astype('Int64')
    return tl.sort_values('line').reset_index(drop=True)


def milestones(i, ev, q1):
    """Ordered recovery milestones (line numbers).  Only logs with a leader change."""
    rows = []

    def add(label, line, basis='parsed event'):
        if line is None or (isinstance(line, float) and np.isnan(line)):
            return
        rows.append(dict(log=LOGS[i]['label'], milestone=label, line=int(line), basis=basis, evidence=short(i, int(line))))

    ready = ev[ev.kind == 'st_ready'].sort_values('line').line.tolist()
    add('1st "Ready to process operations" banner', ready[0])
    add('2nd banner', ready[1])
    add('first PROPOSE of CID 0 (ts 0, leader 0)', ev[(ev.kind == 'propose_recv') & (ev.cid == 0)].line.min())
    add('3rd banner (after the first PROPOSE)', ready[2])
    add('4th banner (after the first PROPOSE)', ready[3])
    a0 = ev[(ev.kind == 'accept_send') & (ev.cid == 0) & (ev.attempt == 0)].line
    add('last "Sending ACCEPT" of CID 0 at ts 0 (only %d of 4 sent -> no quorum)' % len(a0), a0.max())
    tmo = ev[ev.kind == 'lc_timeout'].sort_values('line')
    add('first "The following requests timed out"', tmo.line.iloc[0])
    add('first "Forwarding requests ... to leader"', ev[ev.kind == 'lc_forward'].line.min())
    att = ev[ev.kind == 'lc_attempt'].sort_values('line')
    add('first "Attempting to start leader change" (starter 1)', att.line.iloc[0])
    st1 = ev[(ev.kind == 'lc_send_stop') & (ev.regency == 1)].sort_values('line')
    add('first "Sending STOP message to install regency 1"', st1.line.iloc[0])
    fr = first_receipts(ev, 'STOP', 1)
    for _, r in fr.iterrows():
        extra = {1: ' (first STOP seen)', 2: ' = F+1 (join threshold; count pooled over all receivers)',
                 3: ' = 2F+1 (install threshold; count pooled over all receivers)', 4: ' = all four replicas'}[int(r['rank'])]
        add('STOP(1) from replica %d first received; distinct senders seen so far = %d%s' % (r.sender, r['rank'], extra), r.first_line)
    sd = ev[(ev.kind == 'lc_send_stopdata') & (ev.regency == 1)].sort_values('line')
    add('first "Sending STOPDATA of regency 1" (a replica that has installed regency 1 reports to the new leader)', sd.line.min())
    st = ev[(ev.kind == 'lc_state') & (ev['last'] == 1)].sort_values('line')
    add('first "Last regency: 1" state line', st.line.min())
    for _, r in first_receipts(ev, 'STOPDATA', 1).iterrows():
        add('STOPDATA from replica %d first received (#%d at the leader)' % (r.sender, r['rank']), r.first_line)
    sy = ev[ev.kind == 'lc_send_sync'].line.min()
    add('"Sending SYNC message for regency 1" (new leader 1)', sy)
    add('first SYNC received', ev[(ev.kind == 'lc_recv') & (ev.mtype == 'SYNC')].line.min())
    sw = ev[ev.kind == 'sync_write'].sort_values('line')
    add('first "Sending WRITE message for CID 0, timestamp 1"', sw.line.iloc[0])
    add('last "Sending WRITE message for CID 0, timestamp 1" (4th)', sw.line.iloc[-1])
    a1 = ev[(ev.kind == 'accept_send') & (ev.cid == 0) & (ev.attempt == 1)].sort_values('line')
    add('first "Sending ACCEPT" of CID 0 at ts 1', a1.line.min())
    d0 = ev[(ev.kind == 'decide') & (ev.cid == 0)].sort_values('line')
    add('first "Deciding consensus 0" (ts 1)', d0.line.min())
    add('last "Deciding consensus 0" (4th replica)', d0.line.max())
    cr = ev[(ev.kind == 'client_ret') & (ev.cid == 0)].line.min()
    add('client reply of request 1 (CID 0): ", returned value: 1"', cr)
    add('first PROPOSE of CID 1 (leader 1)', ev[(ev.kind == 'propose_recv') & (ev.cid == 1)].line.min())
    # regency-2 attempt (log 4)
    s2 = ev[(ev.kind == 'lc_send_stop') & (ev.regency == 2)].sort_values('line')
    if len(s2):
        add('3rd "The following requests timed out" (an already forwarded request times out again)', tmo.line.iloc[-1])
        add('3rd "Attempting to start leader change"', att.line.iloc[-1])
        add('"Sending STOP message to install regency 2" (only replica 1 ever sends one)', s2.line.iloc[0])
        r2 = ev[(ev.kind == 'lc_recv') & (ev.mtype == 'STOP') & (ev.regency == 2)].sort_values('line')
        add('first STOP(2) received (from replica 1)', r2.line.min())
        rt = ev[ev.kind == 'lc_retransmit'].sort_values('line')
        add('first "Re-transmitting STOP message to install regency 2"', rt.line.iloc[0])
        last_ret = int(ev[ev.kind == 'client_ret'].line.max())
        add('last client reply (", returned value: 1000")', last_ret)
        add('first re-transmission after the last client reply (idle tail)', rt[rt.line > last_ret].line.min())
        add('last re-transmission', rt.line.iloc[-1])
        add('last line of the file', len(raw_lines(i)) - 1 if raw_lines(i)[-1] == '' else len(raw_lines(i)), 'file length')
    m = pd.DataFrame(rows)
    t0 = int(tmo.line.iloc[0])
    m['lines_after_first_timeout'] = m.line - t0
    return m


def retransmissions(i, ev, q1):
    rt = ev[ev.kind == 'lc_retransmit'].sort_values('line').reset_index(drop=True)
    last_ret = int(ev[ev.kind == 'client_ret'].line.max())
    rcv = ev[(ev.kind == 'lc_recv') & (ev.mtype == 'STOP') & (ev.regency == 2)].line.values
    rows = []
    prev_line, prev_cid = None, None
    s2 = ev[(ev.kind == 'lc_send_stop') & (ev.regency == 2)].line.min()
    for n, r in rt.iterrows():
        ln = int(r.line)
        cid = cid_at_line(q1, ln)
        nxt = rt.line.iloc[n + 1] if n + 1 < len(rt) else 10 ** 9
        n_rcv = int(((rcv > ln) & (rcv < nxt)).sum())
        ref_line = prev_line if prev_line is not None else int(s2)
        rows.append(dict(
            log=LOGS[i]['label'], retransmission_no=n + 1, line=ln, phase='idle tail (after last client reply)' if ln > last_ret else 'during the 1000-CID run',
            cid_in_progress=cid, gap_lines_since_previous=ln - ref_line, gap_cids_since_previous=(cid - prev_cid) if prev_cid is not None else None,
            receipts_of_STOP2_before_next_retransmission=n_rcv, text=short(i, ln)))
        prev_line, prev_cid = ln, cid
    return pd.DataFrame(rows)


def summary_row(i, ev, mil, rt, kw):
    d = lc_events(ev)
    cnt = d.kind.value_counts().to_dict()
    recv = d[d.kind == 'lc_recv']
    tmo = d[d.kind == 'lc_timeout']
    has = len(d) > 0
    regs_sent = sorted(set(int(x) for x in d[d.kind.isin(['lc_send_stop', 'lc_retransmit'])].regency.dropna()))
    regs_recv = sorted(set(int(x) for x in recv.regency.dropna()))
    inst = sorted(install_lines(ev))
    r = dict(
        log=LOGS[i]['label'], file=LOGS[i]['file'], has_timeout_or_leader_change_lines='yes' if has else 'NO - none of the leader-change messages occurs',
        n_requests_timed_out=cnt.get('lc_timeout', 0), n_forwarding=cnt.get('lc_forward', 0), n_attempt_leader_change=cnt.get('lc_attempt', 0),
        n_sending_STOP=cnt.get('lc_send_stop', 0), n_retransmitting_STOP=cnt.get('lc_retransmit', 0),
        n_received_STOP=int((recv.mtype == 'STOP').sum()), n_received_STOPDATA=int((recv.mtype == 'STOPDATA').sum()), n_received_SYNC=int((recv.mtype == 'SYNC').sum()),
        n_sending_STOPDATA=cnt.get('lc_send_stopdata', 0), n_sending_SYNC=cnt.get('lc_send_sync', 0), n_last_next_regency_lines=cnt.get('lc_state', 0),
        n_no_out_of_context_SYNC=cnt.get('lc_no_ooc_sync', 0), n_no_proof_lines=cnt.get('lc_no_proof', 0), n_sync_phase_WRITE_ts1=cnt.get('sync_write', 0),
        first_line=int(d.line.min()) if has else None, last_line=int(d.line.max()) if has else None,
        timeout_lines='|'.join(str(int(x)) for x in tmo.line) if len(tmo) else 'none',
        regencies_with_STOP_sent=','.join(map(str, regs_sent)) if regs_sent else 'none', regencies_with_STOP_received=','.join(map(str, regs_recv)) if regs_recv else 'none',
        regencies_installed_after_regency_0=','.join(map(str, inst)) if inst else 'none (regency 0 only, no leader change)',
        regencies_attempted_never_installed=(','.join(str(x) for x in regs_sent if x not in inst) or 'none'),
        timed_out_request=(raw(i, int(tmo.line.iloc[0]), 200).split('[[')[1].split(']]')[0] if len(tmo) else 'none'))
    if has:
        t0 = int(tmo.line.iloc[0])
        rr = ev[(ev.kind == 'client_ret') & (ev.cid == 0)].line.min()
        r['lines_first_timeout_to_cid0_reply'] = int(rr - t0)
    return r


def plot_q4(tls, ev2, ev4, rt4, q1_4):
    """(a)/(b) swimlane timelines of logs 2 and 4 from start-up to the first decision after the leader change;
    (c) STOP(2) re-transmissions of log 4: whole file and zoom on the idle tail."""
    import matplotlib.gridspec as gridspec
    L_BAN, L_PRO, L_AC0 = 'start-up banner\n"Ready to process operations"', 'PROPOSE of CID 0 (ts 0)', 'ACCEPT of CID 0 sent (ts 0)'
    L_TMO, L_FWD, L_ATT = 'request timed out', 'forwarded to leader', 'attempt to start\nleader change'
    L_STP, L_STR, L_SDS, L_SDR = 'STOP sent', 'STOP received', 'STOPDATA sent', 'STOPDATA received'
    L_SYS, L_SYR, L_WR1, L_AC1, L_DEC = 'SYNC sent', 'SYNC received', 'WRITE at ts 1 sent', 'ACCEPT at ts 1 sent', 'decision of CID 0\n(4 replicas)'
    lanes = [L_BAN, L_PRO, L_AC0, L_TMO, L_FWD, L_ATT, L_STP, L_STR, L_SDS, L_SDR, L_SYS, L_SYR, L_WR1, L_AC1, L_DEC]
    lane_of = {n: k for k, n in enumerate(lanes)}
    fig = plt.figure(figsize=(13.4, 16.2))
    gs = gridspec.GridSpec(3, 1, height_ratios=[1.0, 1.0, 0.62], hspace=0.36, left=0.17, right=0.985, top=0.957, bottom=0.085, figure=fig)
    UNTAG = MUTED
    xlo, xhi = 55, 345
    for pi, (i, ev, ttl) in enumerate([(2, ev2, '(a) log 2 (main_2.log): start-up, timeout, leader change to regency 1, CID 0 re-run at ts 1 (lines 55-345)'),
                                        (4, ev4, '(b) log 4 (main_4.log): the same sequence, plus a STOP for regency 2 that nobody else joins (lines 55-345)')]):
        ax = fig.add_subplot(gs[pi])
        tl = tls[i]
        pts = []   # (lane, line, color, marker)
        for r in ev[ev.kind == 'st_ready'].itertuples():
            pts.append((L_BAN, r.line, UNTAG, 'o'))
        for r in ev[(ev.kind == 'propose_recv') & (ev.cid == 0)].itertuples():
            pts.append((L_PRO, r.line, UNTAG, 'o'))
        for r in ev[(ev.kind == 'accept_send') & (ev.cid == 0) & (ev.attempt == 0)].itertuples():
            pts.append((L_AC0, r.line, UNTAG, 'o'))
        for r in tl.itertuples():
            if r.kind == 'lc_timeout':
                pts.append((L_TMO, r.line, UNTAG, 'o'))
            elif r.kind == 'lc_forward':
                pts.append((L_FWD, r.line, UNTAG, 'o'))
            elif r.kind == 'lc_attempt':
                pts.append((L_ATT, r.line, UNTAG, 'o'))
            elif r.kind == 'lc_send_stop':
                pts.append((L_STP, r.line, UNTAG, 'D' if r.regency == 2 else 'o'))
            elif r.kind == 'lc_send_stopdata':
                pts.append((L_SDS, r.line, UNTAG, 'o'))
            elif r.kind == 'lc_send_sync':
                pts.append((L_SYS, r.line, UNTAG, 'o'))
            elif r.kind == 'lc_recv':
                lane = {'STOP': L_STR, 'STOPDATA': L_SDR, 'SYNC': L_SYR}[r.msg_type]
                pts.append((lane, r.line, REPLICA_COLOR[int(r.sender)], 'D' if r.regency == 2 else 'o'))
        for r in ev[ev.kind == 'sync_write'].itertuples():
            pts.append((L_WR1, r.line, UNTAG, 'o'))
        for r in ev[(ev.kind == 'accept_send') & (ev.cid == 0) & (ev.attempt == 1)].itertuples():
            pts.append((L_AC1, r.line, UNTAG, 'o'))
        for r in ev[(ev.kind == 'decide') & (ev.cid == 0)].itertuples():
            pts.append((L_DEC, r.line, UNTAG, 'o'))
        for lane, x, c, mk in pts:
            if xlo <= x <= xhi:
                ax.scatter([x], [lane_of[lane]], s=44, color=c, marker=mk, edgecolor=SURFACE, linewidth=0.9, zorder=3)
        ready = sorted(int(x) for x in ev[ev.kind == 'st_ready'].line)
        kw = dict(fontsize=8, color=TEXT2, va='center')
        kwa = dict(fontsize=8, color=TEXT2, va='center', arrowprops=dict(arrowstyle='-', color=MUTED, lw=0.8))
        p0 = int(ev[(ev.kind == 'propose_recv') & (ev.cid == 0)].line.min())
        ax.text(ready[3] + 6, lane_of[L_BAN], '<- banners 3 and 4 (lines %d, %d) come after the first PROPOSE (line %d)' % (ready[2], ready[3], p0), **kw)
        a0l = ev[(ev.kind == 'accept_send') & (ev.cid == 0) & (ev.attempt == 0)].line
        ax.text(int(a0l.max()) + 8, lane_of[L_AC0], '<- only 2 of 4 replicas send an ACCEPT: no quorum, CID 0 not decided at ts 0', **kw)
        stp = tl[(tl.kind == 'lc_send_stop') & (tl.regency == 1)].sort_values('line')
        ax.annotate('starters 0 and 3 (inferred); joiners 1 and 2 (lines %d, %d)\nsend STOP after 2 distinct STOPs were seen' % (stp.line.iloc[2], stp.line.iloc[3]),
                    xy=(int(stp.line.iloc[2]), lane_of[L_STP]), xytext=(236, lane_of[L_FWD] - 0.2), **kwa)
        sy = int(tl[tl.kind == 'lc_send_sync'].line.iloc[0])
        ax.annotate('SYNC sent by the new leader (replica 1), line %d' % sy, xy=(sy, lane_of[L_SYS]), xytext=(sy + 30, lane_of[L_SYS] - 0.85), **kwa)
        if i == 4:
            ax.annotate('3rd timeout (195) -> attempt (196) -> STOP for regency 2\n(201, diamond): only replica 1 ever sends one', xy=(201, lane_of[L_STP]),
                        xytext=(236, lane_of[L_STP] - 0.95), **kwa)
        dec = ev[(ev.kind == 'decide') & (ev.cid == 0)].line
        ax.annotate('CID 0 decided at ts 1 (lines %d-%d)' % (dec.min(), dec.max()), xy=(dec.min(), lane_of[L_DEC]), xytext=(dec.min() - 118, lane_of[L_DEC] - 0.9), **kwa)
        ax.set_xlim(xlo, xhi)
        ax.set_ylim(len(lanes) - 0.4, -0.7)
        ax.set_yticks(range(len(lanes)))
        ax.set_yticklabels(lanes, fontsize=8.3)
        ax.set_xlabel('line number in the log file (no clock: only the order of lines is known)')
        ax.grid(axis='y', visible=True)
        ax.set_title(ttl, fontsize=10, pad=8)
        if pi == 0:
            hs = [plt.Line2D([0], [0], marker='o', ls='', color=REPLICA_COLOR[k], markersize=7, label='sender = replica %d' % k) for k in range(4)]
            hs.append(plt.Line2D([0], [0], marker='o', ls='', color=UNTAG, markersize=7, label='line carries no replica id'))
            hs.append(plt.Line2D([0], [0], marker='D', ls='', color=UNTAG, markersize=6, label='regency 2 (diamond)'))
            ax.legend(handles=hs, ncol=6, loc='lower center', bbox_to_anchor=(0.45, 1.09), fontsize=8, columnspacing=1.2, handletextpad=0.3)
    # (c) re-transmissions: whole file and zoom on the idle tail
    sub = gridspec.GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[2], width_ratios=[1.25, 1.0], wspace=0.22)
    n_lines = len(raw_lines(4)) - 1
    last_ret = int(ev4[ev4.kind == 'client_ret'].line.max())
    x = rt4.line.values
    y = np.arange(1, len(rt4) + 1)
    load = rt4[rt4.phase.str.startswith('during')]
    tail = rt4[~rt4.phase.str.startswith('during')]
    ax = fig.add_subplot(sub[0])
    ax.step(np.r_[0, x, n_lines], np.r_[0, y, y[-1]], where='post', color=REPLICA_COLOR[1], lw=2.0)
    ax.scatter(load.line, load.retransmission_no, s=34, color=REPLICA_COLOR[1], edgecolor=SURFACE, linewidth=0.9, zorder=3)
    ax.axvline(last_ret, color=MUTED, lw=1.0, ls=(0, (4, 3)))
    ax.text(last_ret - 2500, 120, 'last client reply\n(line %s)' % format(last_ret, ','), ha='right', va='center', fontsize=8.3, color=TEXT2)
    ax.text(3000, 62, '%d single re-transmissions while the 1000 CIDs are ordered\n(CIDs %s)' % (len(load), ', '.join(str(c) for c in load.cid_in_progress)),
            fontsize=8.3, color=TEXT2, va='center')
    ax.text(last_ret - 2500, 195, '+%d in the idle tail' % len(tail), ha='right', va='center', fontsize=8.3, color=TEXT2)
    ax.set_xlim(0, n_lines)
    ax.set_ylim(0, 205)
    ax.set_xlabel('line number in log 4 (main_4.log)')
    ax.set_ylabel('cumulative "Re-transmitting STOP message\nto install regency 2" lines')
    ax.set_title('(c) log 4: whole file', fontsize=10, pad=8)
    ax2 = fig.add_subplot(sub[1])
    ax2.step(np.r_[last_ret, x[x > last_ret], n_lines], np.r_[9, y[x > last_ret], y[-1]], where='post', color=REPLICA_COLOR[1], lw=2.0)
    ax2.axvline(last_ret, color=MUTED, lw=1.0, ls=(0, (4, 3)))
    ax2.text(last_ret + 40, 180, 'last client reply, line %s' % format(last_ret, ','), fontsize=8.3, color=TEXT2, va='center')
    ax2.text(last_ret + 440, 42, '%d re-transmissions in %s lines:\none every 7 lines = 1 "Re-transmitting" line\n+ 3 x "Received ... STOP ... from replica 1"\n+ 3 x "Last regency: 1, next regency: 1"'
             % (len(tail), format(int(tail.line.max() - tail.line.min()), ',')), fontsize=8.0, color=TEXT2, va='center')
    ax2.set_xlim(last_ret - 100, n_lines + 20)
    ax2.set_ylim(0, 205)
    ax2.set_xlabel('line number in log 4 (zoom on the end of the file)')
    ax2.set_title('(c, zoom) idle tail after the last client reply', fontsize=10, pad=8)
    tot = len(rt4) + 1
    fig.text(0.5, 0.047, 'STOP for regency 2: %d broadcasts (1 "Sending STOP" at line 201 + %d re-transmissions) x 3 receivers = %d receipts, every one "from replica 1"; '
             'no other replica ever sends a STOP for regency 2.' % (tot, len(rt4), 3 * tot), ha='center', fontsize=8.6, color=TEXT)
    fig.text(0.5, 0.017, 'Colour = replica named in the "from replica N" field of a received message; grey = the line carries no replica id (senders of STOP / STOPDATA / SYNC are inferred in csv/q4_send_inference.csv).\n'
             'Panels (a) and (b) show lines 55-345 of each file; no wall-clock time exists in the logs, so distances are in lines, not in seconds.', ha='center', fontsize=8, color=TEXT2)
    save(fig, 'q4_leader_change_timeline.png')


def main():
    style()
    evs = {i: load_events(i) for i in LOGS}
    q1 = pd.read_csv(os.path.join(CSV_DIR, 'q1_cid_progress.csv'))
    q1l = {i: q1[q1.log == LOGS[i]['label']] for i in LOGS}

    kw = keyword_counts()
    write_csv(kw, 'q4_keyword_counts.csv')

    su = startup_table(evs, q1)
    write_csv(su, 'q4_startup_race.csv')

    tls, mils, sends = {}, {}, []
    for i in (2, 4):
        ev = evs[i]
        inf = [stop_send_inference(ev, 1), send_inference(ev, 'lc_send_stopdata', 'STOPDATA', 1)]
        if len(ev[(ev.kind == 'lc_send_stop') & (ev.regency == 2)]):
            inf.append(stop_send_inference(ev, 2))
        si = pd.concat(inf, ignore_index=True)
        si.insert(0, 'log', LOGS[i]['label'])
        sends.append(si)
        tls[i] = build_timeline(i, ev, q1l[i], si)
        mils[i] = milestones(i, ev, q1l[i])
    # explicit "no events" rows for logs 1 and 3
    empty = []
    for i in (1, 3):
        empty.append(dict(log=LOGS[i]['label'], line=None, phase='none', kind='no_leader_change_events', regency=None, msg_type='', sender=None,
                          sender_basis='', cid_in_progress=None, after_last_client_reply=None, request='', last_regency=None, next_regency=None,
                          text='no timeout / forwarding / STOP / STOPDATA / SYNC / "regency" line in the whole file (see q4_keyword_counts.csv: 0 matches)'))
    timeline = pd.concat([tls[2], tls[4], pd.DataFrame(empty)], ignore_index=True)
    cols = ['log', 'line', 'phase', 'kind', 'regency', 'msg_type', 'sender', 'sender_basis', 'last_regency', 'next_regency', 'cid_in_progress',
            'after_last_client_reply', 'request', 'text']
    timeline = timeline[cols]
    timeline['_k'] = timeline.log.map({'log 1': 1, 'log 2': 2, 'log 3': 3, 'log 4': 4})
    timeline = timeline.sort_values(['_k', 'line'], kind='stable').drop(columns='_k')
    write_csv(timeline, 'q4_timeline_events.csv')
    write_csv(pd.concat(sends, ignore_index=True), 'q4_send_inference.csv')
    mil = pd.concat([mils[2].sort_values('line'), mils[4].sort_values('line')], ignore_index=True)
    write_csv(mil, 'q4_milestones.csv')

    rt4 = retransmissions(4, evs[4], q1l[4])
    write_csv(rt4, 'q4_retransmissions_log4.csv')

    rows = []
    for i in LOGS:
        rows.append(summary_row(i, evs[i], mils.get(i), rt4 if i == 4 else None, kw))
    summ = pd.DataFrame(rows)
    write_csv(summ, 'q4_summary_per_log.csv')

    plot_q4(tls, evs[2], evs[4], rt4, q1l[4])

    pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40); pd.set_option('display.max_colwidth', 90)
    print(su.T.to_string())
    print(summ.T.to_string())
    print(mil[['log', 'milestone', 'line', 'lines_after_first_timeout']].to_string())
    print(pd.concat(sends).to_string())
    print(rt4.head(12).to_string())
    print(rt4.phase.value_counts())
    print(kw.pivot(index='keyword', columns='log', values='n_lines'))


if __name__ == '__main__':
    main()
