#!/usr/bin/env python3
"""
q1_consensus_progress.py - Question 1: consensus progress / CIDs, PROPOSE-WRITE-ACCEPT events, decisions and executed
requests, timeout events, leader-change events, unusual messages - measurable differences between the four logs.

Outputs
  csv/q1_event_counts.csv    tidy table: log, group, event, count, per_cid, expected_if_normal (for 1000 CIDs)
  csv/q1_cid_progress.csv    one row per (log, CID): first/last lines, PROPOSE line, decision lines, execution lines,
                             client-reply line, #attempts (CID 0 is retried in logs 2 and 4), counts of votes, ...
  csv/q1_notable_lines.csv   every non-routine line (start-up banners, timeouts, STOP/STOPDATA/SYNC, ...) with its line no.
  plots/q1_progress_and_counts.png
Run:  python3 -I scripts/q1_consensus_progress.py      (needs 00_parse_logs.py first)
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

N_CID = 1000

# (group, key, description, expected count for 1000 CIDs in a run without recovery or None)
EVENTS = [
    ('PROPOSE',  'propose_recv',  'PROPOSE received from:L (I am:N)', 4 * N_CID),
    ('PROPOSE',  'propose_exec',  'Executing propose for cId, Epoch Timestamp', 4 * N_CID),
    ('WRITE',    'write_send',    'Sending WRITE for cId:C, I am:N', 4 * N_CID),
    ('WRITE',    'write_comp',    'WRITE computed for cId:C, I am:N', 4 * N_CID),
    ('WRITE',    'write_recv',    'WRITE received from:X (max 3 per replica and CID)', 12 * N_CID),
    ('WRITE',    'write_quorum',  "I have 3, WRITE's  (WRITE quorum reached)", 4 * N_CID),
    ('ACCEPT',   'accept_send',   'Sending ACCEPT message, cId:C, I am:N', 4 * N_CID),
    ('ACCEPT',   'spec_accept',   'Speculative ACCEPT ... sending it to the other replicas', 4 * N_CID),
    ('ACCEPT',   'accept_recv',   'ACCEPT from X (up to 3 per replica and CID, own ACCEPT included)', 12 * N_CID),
    ('ACCEPT',   'accept_quorum', 'I have 3 ACCEPTs  (ACCEPT quorum reached)', 4 * N_CID),
    ('DECISION', 'decide',        'Deciding consensus C', 4 * N_CID),
    ('DECISION', 'exec',          'Counter was incremented (ordered execution)', 4 * N_CID),
    ('CLIENT',   'client_ret',    'client ", returned value: V" (reply)', N_CID),
    ('CLIENT',   'client_inv',    'client "Invocation N"', N_CID),
    ('UNUSUAL',  'ooc',           'Out of context msg with id C', None),
    ('UNUSUAL',  'paxos_msg',     'Processing paxos msg with id C', None),
    ('TIMEOUT',  'lc_timeout',    'The following requests timed out', 0),
    ('TIMEOUT',  'lc_forward',    'Forwarding requests ... to leader', 0),
    ('LEADER CHANGE', 'lc_attempt',  'Attempting to start leader change', 0),
    ('LEADER CHANGE', 'lc_send_stop', 'Sending STOP message to install regency R', 0),
    ('LEADER CHANGE', 'lc_retransmit', 'Re-transmitting STOP message to install regency R', 0),
    ('LEADER CHANGE', 'lc_recv_STOP', 'Received ... type STOP', 0),
    ('LEADER CHANGE', 'lc_recv_STOPDATA', 'Received ... type STOPDATA', 0),
    ('LEADER CHANGE', 'lc_recv_SYNC', 'Received ... type SYNC', 0),
    ('LEADER CHANGE', 'lc_state',    'Last regency: a, next regency: b', 0),
    ('LEADER CHANGE', 'lc_send_stopdata', 'Sending STOPDATA of regency R', 0),
    ('LEADER CHANGE', 'lc_send_sync', 'Sending SYNC message for regency R', 0),
    ('LEADER CHANGE', 'lc_no_ooc_sync', 'No out of context SYNC for regency R', 0),
    ('LEADER CHANGE', 'lc_no_proof', 'I did not install any proof of last decided consensus', 0),
    ('LEADER CHANGE', 'sync_write', 'Sending WRITE message for CID, timestamp T (SYNC phase)', 0),
    ('START-UP', 'st_retrieve',   'Retrieving State', 4),
    ('START-UP', 'st_uptodate',   'Replica state is up to date', 4),
    ('START-UP', 'st_ready',      'Ready to process operations', 4),
]


def event_frame(ev):
    """Add synthetic kinds: write_quorum, accept_quorum, lc_recv_<type>."""
    ev = ev.copy()
    ev['key'] = ev['kind']
    ev.loc[(ev.kind == 'write_count') & (ev.k == 3), 'key'] = 'write_quorum'
    ev.loc[(ev.kind == 'accept_count') & (ev.k == 3), 'key'] = 'accept_quorum'
    m = ev.kind == 'lc_recv'
    ev.loc[m, 'key'] = 'lc_recv_' + ev.loc[m, 'mtype'].astype(str)
    return ev


def cid_progress(i, ev):
    d = ev[ev.cid.notna() & ev.kind.isin(['propose_recv', 'propose_exec', 'write_send', 'write_recv', 'write_count',
                                          'accept_send', 'accept_recv', 'accept_count', 'decide', 'exec', 'ooc',
                                          'quorum_set', 'spec_accept', 'spec_proof', 'sync_write'])]
    out = d.groupby('cid').line.agg(first_line='min', last_line='max')
    out['first_propose_line'] = ev[ev.kind == 'propose_recv'].groupby('cid').line.min()
    g = ev[ev.kind == 'decide'].groupby('cid').line.agg(['min', 'max', 'count'])
    out['first_decide_line'], out['last_decide_line'], out['n_decide_lines'] = g['min'], g['max'], g['count']
    g = ev[ev.kind == 'exec'].groupby('cid').line.agg(['min', 'max', 'count'])
    out['first_exec_line'], out['last_exec_line'], out['n_exec_lines'] = g['min'], g['max'], g['count']
    out['client_reply_line'] = ev[ev.kind == 'client_ret'].groupby('cid').line.min()
    out['n_attempts'] = ev[ev.cid.notna()].groupby('cid').attempt.max() + 1
    ts = ev[ev.kind.isin(['write_count', 'accept_count', 'propose_exec'])].groupby('cid').ts.max()
    out['max_epoch_ts'] = ts
    out['n_write_recv'] = ev[ev.kind == 'write_recv'].groupby('cid').size()
    out['n_accept_recv'] = ev[ev.kind == 'accept_recv'].groupby('cid').size()
    out['n_ooc'] = ev[ev.kind == 'ooc'].groupby('cid').size()
    out['n_accept_send'] = ev[ev.kind == 'accept_send'].groupby('cid').size()
    out['n_write_send'] = ev[ev.kind == 'write_send'].groupby('cid').size()
    out['propose_leader'] = ev[ev.kind == 'propose_recv'].groupby('cid').sender.agg(lambda s: ','.join(str(int(x)) for x in sorted(s.dropna().unique())))
    out['decide_latency_lines'] = out.first_decide_line - out.first_propose_line
    out = out.reset_index()
    out.insert(0, 'log', LOGS[i]['label'])
    for c in out.columns:
        if c not in ('log', 'propose_leader'):
            out[c] = out[c].astype('Int64') if c != 'decide_latency_lines' else out[c].astype('Int64')
    return out


def main():
    style()
    count_rows, prog, notable = [], [], []
    evs = {}
    for i in LOGS:
        ev = event_frame(load_events(i))
        evs[i] = ev
        n_cids = ev.loc[ev.cid.notna() & ev.kind.isin(['decide']), 'cid'].nunique()
        for group, key, desc, exp in EVENTS:
            c = int((ev.key == key).sum())
            count_rows.append(dict(log=LOGS[i]['label'], group=group, event=key, description=desc, count=c,
                                   per_cid=round(c / N_CID, 3), expected_if_normal=exp,
                                   diff_vs_expected=(c - exp) if exp is not None else None))
        prog.append(cid_progress(i, ev))
        nb = ev[ev.kind.isin(['st_ready', 'st_uptodate', 'st_retrieve', 'st_session', 'sync_write', 'lc_timeout', 'lc_forward',
                              'lc_attempt', 'lc_send_stop', 'lc_retransmit', 'lc_recv', 'lc_state', 'lc_send_stopdata',
                              'lc_no_ooc_sync', 'lc_send_sync', 'lc_no_proof'])]
        t = nb[['line', 'kind', 'mtype', 'regency', 'sender', 'last', 'next', 'cid', 'ts']].copy()
        t.insert(0, 'log', LOGS[i]['label'])
        notable.append(t)
        # first lines of the normal chain, for orientation
        for k in ('propose_recv', 'decide', 'client_ret'):
            r = ev[ev.kind == k].sort_values('line').head(1)
            if len(r):
                t2 = r[['line', 'kind', 'cid']].copy()
                t2.insert(0, 'log', LOGS[i]['label'])
                notable.append(t2)
    counts = pd.DataFrame(count_rows)
    write_csv(counts, 'q1_event_counts.csv')
    progress = pd.concat(prog, ignore_index=True)
    write_csv(progress, 'q1_cid_progress.csv')
    nt = pd.concat(notable, ignore_index=True).sort_values(['log', 'line'], kind='stable')
    write_csv(nt, 'q1_notable_lines.csv')

    # ------------------------------------------------------------------ plot
    fig = plt.figure(figsize=(12.2, 8.6))
    gs = fig.add_gridspec(2, 2, height_ratios=[0.8, 1.0], width_ratios=[1.15, 1.0], hspace=0.42, wspace=0.30)
    # (a) decision latency in log lines: distribution of CIDs 1..999 per log, CID 0 marked
    ax = fig.add_subplot(gs[0, :])
    rng = np.random.default_rng(1)
    stats = {}
    for row, i in enumerate((1, 2, 3, 4)):
        p = progress[progress.log == LOGS[i]['label']]
        rest = p[p.cid > 0].decide_latency_lines.astype(float).to_numpy()
        y0 = 3 - row
        ax.scatter(rest, y0 + rng.uniform(-0.22, 0.22, len(rest)), s=4, color=LOG_COLOR[i], alpha=0.30, linewidths=0)
        q1, med, q3 = np.percentile(rest, [25, 50, 75])
        ax.plot([q1, q3], [y0, y0], color=TEXT, lw=4.0, solid_capstyle='butt', alpha=0.85)
        ax.plot([med, med], [y0 - 0.3, y0 + 0.3], color=SURFACE, lw=1.6)
        c0 = float(p[p.cid == 0].decide_latency_lines.iloc[0])
        ax.scatter([c0], [y0], s=70, color=LOG_COLOR[i], edgecolor=SURFACE, linewidth=2, zorder=5)
        txt = 'CID 0: %d lines' % c0
        if i in (2, 4):
            txt += '  (stalled at ts 0, then timeouts + leader change)'
        ax.text(c0 + 4, y0 + 0.30, txt, va='center', fontsize=8.5, color=TEXT)
        stats[i] = 'CIDs 1-999: median %d, IQR %d-%d, max %d' % (med, q1, q3, rest.max())
    ax.set_yticks([3, 2, 1, 0])
    ax.set_yticklabels(['%s (%s)\n%s' % (LOGS[i]['label'], LOGS[i]['file'], stats[i]) for i in (1, 2, 3, 4)], fontsize=8)
    ax.set_xlim(45, 330)
    ax.set_ylim(-0.6, 3.6)
    ax.set_xlabel('log lines from first PROPOSE of the CID to its first "Deciding consensus"  (a proxy for duration; there are no clock times)')
    ax.set_title('(a) Per-CID decision latency in log lines: black bar = IQR of CIDs 1-999, dots = every CID, big dot = CID 0')
    ax.grid(axis='y', visible=False)

    # (b) core chain counts per CID (per replica for sends / decisions)
    ax = fig.add_subplot(gs[1, 0])
    core = [('propose_recv', 'PROPOSE\nreceived'), ('write_send', 'WRITE\nsent'), ('write_recv', 'WRITE\nreceived'),
            ('accept_send', 'ACCEPT\nsent'), ('accept_recv', 'ACCEPT\nreceived'), ('decide', 'decisions'), ('exec', 'executions')]
    x = np.arange(len(core))
    w = 0.19
    for j, i in enumerate((1, 2, 3, 4)):
        vals = [counts[(counts.log == LOGS[i]['label']) & (counts.event == k)]['count'].iloc[0] / N_CID for k, _ in core]
        ax.bar(x + (j - 1.5) * (w + 0.015), vals, w, color=LOG_COLOR[i], label=LOGS[i]['label'], edgecolor=SURFACE, linewidth=1.5)
    ax.set_xticks(x)
    ax.set_xticklabels([l for _, l in core], fontsize=8)
    ax.set_ylabel('events per CID (4 replicas together)')
    ax.set_title('(b) Normal chain: same volume in all four logs')
    ax.grid(axis='x', visible=False)
    ax.legend(ncol=4, loc='upper left')
    ax.set_ylim(0, 14.5)

    # (c) recovery events (logs 1 and 3 have none -> only logs 2 and 4 are drawn)
    ax = fig.add_subplot(gs[1, 1])
    rec = [('lc_timeout', 'requests timed out'), ('lc_forward', 'forwarded to leader'), ('lc_attempt', 'leader change started (timer)'),
           ('lc_send_stop', 'STOP sent'), ('lc_recv_STOP', 'STOP received'), ('lc_send_stopdata', 'STOPDATA sent'),
           ('lc_send_sync', 'SYNC sent'), ('sync_write', 'WRITE at ts 1 (after SYNC)'), ('lc_retransmit', 'STOP re-transmitted')]
    y = np.arange(len(rec))[::-1]
    h = 0.34
    for j, i in enumerate((2, 4)):
        vals = [int(counts[(counts.log == LOGS[i]['label']) & (counts.event == k)]['count'].iloc[0]) for k, _ in rec]
        yy = y + (0.5 - j) * (h + 0.04)
        ax.barh(yy, [max(v - 0.6, 0.0) for v in vals], h, left=0.6, color=LOG_COLOR[i], edgecolor=SURFACE, linewidth=1.5, label=LOGS[i]['label'])
        for y_, v in zip(yy, vals):
            ax.text(max(v, 1) * 1.12, y_, str(v), va='center', fontsize=8, color=TEXT2)
    ax.set_xscale('log')
    ax.set_xlim(0.6, 1500)
    ax.set_yticks(y)
    ax.set_yticklabels([l for _, l in rec], fontsize=8)
    ax.set_xlabel('number of log lines (log axis)')
    ax.set_title('(c) Recovery events - zero in logs 1 and 3')
    ax.grid(axis='y', visible=False)
    ax.legend(loc='lower right')
    save(fig, 'q1_progress_and_counts.png')
    print('Q1 done')


if __name__ == '__main__':
    main()
