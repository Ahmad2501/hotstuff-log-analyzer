#!/usr/bin/env python3
"""
q2_first_last_senders.py - Question 2: for every consensus ID (CID), which replica is the first / the last to SEND a
WRITE and an ACCEPT?  Statistics, tests and plots, compared across the four logs.

How "sending order" is defined (the logs have no clock, so it is LINE ORDER inside one log file):
  * WRITE  : line order of  "Sending WRITE for cId:C, I am:N"        (N = sending replica, printed in the line itself)
  * ACCEPT : line order of  "Sending ACCEPT message, cId:C, I am:N"  (printed when replica N reaches its WRITE quorum;
             the speculative ACCEPT is broadcast a little later - see the log-1 cross-check below)
  * CID 0 of logs 2 and 4 runs twice: epoch ts 0 stalls, ts 1 follows the leader change.  The ts-1 WRITE lines
    ("Sending WRITE message for CID 0, timestamp 1") carry no replica id.  Their senders are INFERRED from the rule
    "a replica logs its WRITE before the first 'WRITE received from:<replica>' line"; the candidates are listed in the
    columns first_write_candidates / last_write_candidates and the order is marked write_sender_inferred = 1.
Population of the summary statistics: CIDs 1..999 of every log (999 CIDs, one epoch each, no recovery involved).
CID 0 is reported in the per-CID file (both attempts) and discussed separately.

Outputs (csv/ and plots/)
  q2_first_last_per_cid.csv        per (log, CID, attempt): first/last WRITE sender + line, first/last ACCEPT sender + line,
                                   complete send order, candidates for inferred senders, receive-order cross-check,
                                   log 1 only: first/last by the actual speculative-ACCEPT broadcast line
  q2_summary_by_replica.csv        log x message x {first,last} x replica: count, share, Wilson CI, chi-square vs uniform,
                                   chi-square among the three followers, Holm-adjusted p-values (family = 16 tests)
  q2_mean_rank.csv                 log x message x replica: mean sending rank (1 = first .. 4 = last), CI, Friedman test, Kendall W
  q2_pairwise_precedence.csv       P(replica i sends before replica j) per log and message
  q2_role_pooled.csv               leader vs follower share per log and pooled over the 4 logs (binomial test vs 25 %),
                                   and shares by ring offset (leader+k) pooled
  q2_cross_log_tests.csv           chi-square homogeneity tests between logs (by replica id and by role relative to leader)
  q2_stability_blocks.csv          are the shares stable over the run? (3 blocks of 333 CIDs, chi-square homogeneity)
  q2_independence_check.csv        lag-1 repeat rate of the first/last sender vs the rate expected for independent CIDs
  q2_method_crosscheck.csv         agreement of the send-line definition with receive-line and (log 1) broadcast-line definitions
  q2_evidence_examples.csv         three example CIDs with line numbers for every log x message x position x replica
  plots/q2_first_last_shares.png, plots/q2_mean_rank.png
"""
import os
import sys
from itertools import permutations
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def holm(pvals):
    """Holm step-down adjusted p-values."""
    p = np.asarray(pvals, float)
    n = len(p)
    adj = np.empty(n)
    running = 0.0
    for rank, idx in enumerate(np.argsort(p)):
        running = max(running, (n - rank) * p[idx])
        adj[idx] = min(1.0, running)
    return adj


def infer_sync_write_senders(ev):
    """ts-1 WRITE of CID 0 (logs 2 and 4): the lines carry no replica id.
    Returns (lines, feasible_orders).  A permutation is feasible when each replica's WRITE line precedes the first
    'WRITE received from:<replica>' line of that replica."""
    sw = ev[ev.kind == 'sync_write'].sort_values('line')
    lines = [int(x) for x in sw.line]
    first_recv = ev[(ev.kind == 'write_recv') & (ev.attempt == 1)].groupby('sender').line.min().to_dict()
    feas = [p for p in permutations(range(N)) if all(lines[j] < first_recv.get(p[j], 1e18) for j in range(N))]
    return lines, feas


def per_cid_table(i, ev):
    ev = ev.copy()
    w = ev[ev.kind == 'write_send'].sort_values(['line', 'pos'])
    a = ev[ev.kind == 'accept_send'].sort_values(['line', 'pos'])
    worders, aorders = {}, {}
    for (cid, att), g in w.groupby(['cid', 'attempt']):
        worders[(int(cid), int(att))] = [(int(r.line), int(r.rep), 0) for r in g.itertuples()]
    for (cid, att), g in a.groupby(['cid', 'attempt']):
        aorders[(int(cid), int(att))] = [(int(r.line), int(r.rep), 0) for r in g.itertuples()]
    leader_by_cid = ev[ev.kind == 'propose_recv'].groupby('cid').sender.agg(lambda s: int(s.mode().iloc[0]))
    # --- ts-1 attempt of CID 0 (logs 2 and 4)
    sync_leader, feas, sync_lines = None, [], []
    if (ev.kind == 'sync_write').any():
        sync_leader = int(ev[(ev.kind == 'lc_recv') & (ev.mtype == 'SYNC')].sender.mode().iloc[0])   # the sender of SYNC = new leader
        sync_lines, feas = infer_sync_write_senders(ev)
        if len(feas) >= 1:
            lead_first = [p for p in feas if p[0] == sync_leader]
            chosen = feas[0] if len(feas) == 1 else (lead_first[0] if len(lead_first) == 1 else None)
            if chosen is not None:
                worders[(0, 1)] = [(sync_lines[j], chosen[j], 1) for j in range(N)]
    # --- log 1 only: actual broadcast order of the speculative ACCEPT (line carries the [replicaN] prefix)
    spec_order = {}
    if LOGS[i]['prefixed']:
        sp = fill_by_elimination(ev, 'spec_accept')
        sp = sp[sp.kind == 'spec_accept'].dropna(subset=['rep']).sort_values(['line', 'pos'])
        for cid, g in sp.groupby('cid'):
            if len(g) == N and g.rep.nunique() == N:
                spec_order[int(cid)] = [(int(r.line), int(r.rep)) for r in g.itertuples()]
    recv_w = ev[ev.kind == 'write_recv']
    recv_a = ev[ev.kind == 'accept_recv']
    cids = sorted(ev.loc[ev.kind == 'propose_recv', 'cid'].dropna().astype(int).unique())   # consensus instances = CIDs with a PROPOSE
    # (the client "Invocation N" tokens of log 1 are partly garbled and would create phantom CIDs, so they do not define the list)
    rows = []
    for cid in cids:
        for att in sorted(int(x) for x in ev[(ev.cid == cid)].attempt.unique()):
            wl, al = worders.get((cid, att), []), aorders.get((cid, att), [])
            leader = sync_leader if (cid == 0 and att == 1) else int(leader_by_cid.get(cid, -1))
            rw = recv_w[(recv_w.cid == cid) & (recv_w.attempt == att)].sort_values(['line', 'pos'])
            ra = recv_a[(recv_a.cid == cid) & (recv_a.attempt == att)].sort_values(['line', 'pos'])
            row = dict(log=LOGS[i]['label'], cid=cid, attempt=att, epoch_ts=att, leader=leader,
                       n_write_send=len(wl), n_accept_send=len(al))
            for tag, lst in (('write', wl), ('accept', al)):
                if lst:
                    row['first_%s_sender' % tag], row['first_%s_line' % tag] = lst[0][1], lst[0][0]
                    row['last_%s_sender' % tag], row['last_%s_line' % tag] = lst[-1][1], lst[-1][0]
                    row['%s_send_order' % tag] = '>'.join(str(x[1]) for x in lst)
                    row['%s_send_lines' % tag] = '>'.join(str(x[0]) for x in lst)
                    row['%s_sender_inferred' % tag] = int(any(x[2] for x in lst))
            row['first_write_candidates'] = str(wl[0][1]) if wl else ''
            row['last_write_candidates'] = str(wl[-1][1]) if wl else ''
            row['complete_write'] = int(len(wl) == N)
            row['complete_accept'] = int(len(al) == N)
            row['first_write_recv_sender'] = int(rw.iloc[0].sender) if len(rw) else None
            row['last_write_recv_sender'] = int(rw.iloc[-1].sender) if len(rw) else None
            row['first_accept_recv_sender'] = int(ra.iloc[0].sender) if len(ra) else None
            row['last_accept_recv_sender'] = int(ra.iloc[-1].sender) if len(ra) else None
            if att == 0 and cid in spec_order:
                row['first_spec_accept_sender_log1'], row['first_spec_accept_line_log1'] = spec_order[cid][0][1], spec_order[cid][0][0]
                row['last_spec_accept_sender_log1'], row['last_spec_accept_line_log1'] = spec_order[cid][-1][1], spec_order[cid][-1][0]
            note = ''
            if cid == 0 and att == 1 and feas:
                fo = ' ; '.join('>'.join(str(x) for x in p) for p in feas)
                row['first_write_candidates'] = '|'.join(str(x) for x in sorted(set(p[0] for p in feas)))
                row['last_write_candidates'] = '|'.join(str(x) for x in sorted(set(p[-1] for p in feas)))
                note = ('ts-1 WRITE senders INFERRED (lines %s carry no replica id); %d order(s) consistent with the receive lines: %s%s'
                        % ('/'.join(str(x) for x in sync_lines), len(feas), fo,
                           '; chosen = new leader first (its own "no proof" line directly follows "Sending SYNC message")' if len(feas) > 1 else ''))
            if cid == 0 and att == 0 and 0 < len(al) < N:
                note = 'ts 0 stalled: only %d replicas sent ACCEPT (replicas %s)' % (len(al), ','.join(str(x[1]) for x in al))
            row['note'] = note
            rows.append(row)
    return pd.DataFrame(rows)


def rank_matrix(df, tag):
    """CIDs x replicas matrix of sending rank (1 = first) for complete CIDs."""
    rows = []
    for r in df[df['complete_%s' % tag] == 1].itertuples():
        order = [int(x) for x in getattr(r, '%s_send_order' % tag).split('>')]
        rk = {rep: k + 1 for k, rep in enumerate(order)}
        rows.append((r.cid, r.leader, *[rk[rep] for rep in range(N)]))
    return pd.DataFrame(rows, columns=['cid', 'leader', 'r0', 'r1', 'r2', 'r3'])


def main():
    style()
    per_cid, summ, ranks, pairs, xlog, pooled_rows, stab, indep, ev_rows = [], [], [], [], [], [], [], [], []
    shares = {}      # (log, tag, pos) -> counts per replica
    leader_main = {}
    main_dfs = {}
    for i in LOGS:
        ev = load_events(i)
        df = per_cid_table(i, ev)
        per_cid.append(df)
        main_df = df[(df.cid >= 1) & (df.attempt == 0)].copy()      # steady-state CIDs 1..999
        assert len(main_df) == 999, (i, len(main_df))
        leaders = main_df.leader.unique()
        assert len(leaders) == 1, (i, leaders)
        leader_main[i] = int(leaders[0])
        main_dfs[i] = main_df
        for tag, label in (('write', 'WRITE'), ('accept', 'ACCEPT')):
            d = main_df[main_df['complete_%s' % tag] == 1]
            assert len(d) == 999, (i, tag, len(d))
            n = len(d)
            for pos in ('first', 'last'):
                col = '%s_%s_sender' % (pos, tag)
                cnt = d[col].astype(int).value_counts().reindex(range(N), fill_value=0)
                chi, p_uni = stats.chisquare(cnt.values)
                nl = cnt.drop(leader_main[i])
                chi_nl, p_nl = stats.chisquare(nl.values)
                shares[(i, tag, pos)] = cnt
                for rep in range(N):
                    lo, hi = wilson(int(cnt[rep]), n)
                    summ.append(dict(log=LOGS[i]['label'], message=label, position=pos, replica=rep,
                                     is_leader=int(rep == leader_main[i]), n_cids=n, count=int(cnt[rep]),
                                     share_pct=round(100 * cnt[rep] / n, 2), wilson95_lo_pct=round(100 * lo, 2),
                                     wilson95_hi_pct=round(100 * hi, 2), expected_if_uniform_pct=25.0,
                                     chi2_vs_uniform=round(chi, 2), p_vs_uniform=p_uni,
                                     chi2_followers_equal=round(chi_nl, 3), p_followers_equal=p_nl))
                # evidence examples with line numbers (three CIDs per replica)
                for rep in range(N):
                    ex = d[d[col] == rep].head(3)
                    for k, r in enumerate(ex.itertuples(), 1):
                        ev_rows.append(dict(log=LOGS[i]['label'], message=label, position=pos, replica=rep, example=k, cid=r.cid,
                                            line=getattr(r, '%s_%s_line' % (pos, tag)),
                                            send_order_in_cid=getattr(r, '%s_send_order' % tag),
                                            send_lines_in_cid=getattr(r, '%s_send_lines' % tag)))
                # independence: lag-1 repeat rate vs expected under independence
                dd = d.sort_values('cid')
                seq = dd[col].astype(int).to_numpy()
                pr = cnt.to_numpy() / n
                exp_rep = float((pr ** 2).sum())
                obs_rep = float((seq[1:] == seq[:-1]).mean())
                z = (obs_rep - exp_rep) / np.sqrt(exp_rep * (1 - exp_rep) / (n - 1))
                indep.append(dict(log=LOGS[i]['label'], message=label, position=pos, n_pairs=n - 1,
                                  repeat_rate_observed=round(obs_rep, 4), repeat_rate_expected_if_independent=round(exp_rep, 4),
                                  z=round(z, 2), p_two_sided=2 * stats.norm.sf(abs(z))))
                # stability over the run: 3 blocks of 333 CIDs
                blocks = np.array_split(np.arange(n), 3)
                tab = np.array([[int((seq[b] == rep).sum()) for rep in range(N)] for b in blocks])
                keep = tab.sum(axis=0) > 0
                chi_b, p_b, dof_b, _ = stats.chi2_contingency(tab[:, keep])
                for bi, b in enumerate(blocks, 1):
                    stab.append(dict(log=LOGS[i]['label'], message=label, position=pos, block=bi,
                                     cid_from=int(dd.cid.iloc[b[0]]), cid_to=int(dd.cid.iloc[b[-1]]),
                                     share_r0_pct=round(100 * tab[bi - 1, 0] / len(b), 1), share_r1_pct=round(100 * tab[bi - 1, 1] / len(b), 1),
                                     share_r2_pct=round(100 * tab[bi - 1, 2] / len(b), 1), share_r3_pct=round(100 * tab[bi - 1, 3] / len(b), 1),
                                     chi2_homogeneity=round(chi_b, 2), dof=dof_b, p_homogeneity=p_b))
            rk = rank_matrix(main_df, tag)
            mat = rk[['r0', 'r1', 'r2', 'r3']].to_numpy()
            fr = stats.friedmanchisquare(*[mat[:, k] for k in range(N)])
            W = fr.statistic / (len(mat) * (N - 1))
            nonl = [k for k in range(N) if k != leader_main[i]]
            sub = mat[:, nonl]
            sub_rank = sub.argsort(axis=1).argsort(axis=1) + 1
            frn = stats.friedmanchisquare(*[sub_rank[:, k] for k in range(3)])
            for rep in range(N):
                m = mat[:, rep].mean()
                se = mat[:, rep].std(ddof=1) / np.sqrt(len(mat))
                ranks.append(dict(log=LOGS[i]['label'], message=label, replica=rep, is_leader=int(rep == leader_main[i]),
                                  n_cids=len(mat), mean_rank=round(m, 3), ci95_lo=round(m - 1.96 * se, 3),
                                  ci95_hi=round(m + 1.96 * se, 3), sd_rank=round(mat[:, rep].std(ddof=1), 3),
                                  friedman_chi2_all=round(fr.statistic, 2), friedman_p_all=fr.pvalue,
                                  kendall_W_all=round(W, 3), friedman_p_followers=frn.pvalue))
            for a in range(N):
                for b in range(N):
                    if a != b:
                        pairs.append(dict(log=LOGS[i]['label'], message=label, replica_i=a, replica_j=b,
                                          p_i_before_j=round(float((mat[:, a] < mat[:, b]).mean()), 4), n_cids=len(mat)))
    # Holm adjustment inside the two families of 16 tests (4 logs x 2 messages x 2 positions)
    sdf = pd.DataFrame(summ)
    keys = sdf.drop_duplicates(['log', 'message', 'position'])[['log', 'message', 'position', 'p_vs_uniform', 'p_followers_equal']].reset_index(drop=True)
    keys['p_vs_uniform_holm'] = holm(keys.p_vs_uniform.values)
    keys['p_followers_equal_holm'] = holm(keys.p_followers_equal.values)
    sdf = sdf.merge(keys[['log', 'message', 'position', 'p_vs_uniform_holm', 'p_followers_equal_holm']], on=['log', 'message', 'position'])
    write_csv(pd.concat(per_cid, ignore_index=True), 'q2_first_last_per_cid.csv')
    write_csv(sdf, 'q2_summary_by_replica.csv')
    write_csv(pd.DataFrame(ranks), 'q2_mean_rank.csv')
    write_csv(pd.DataFrame(pairs), 'q2_pairwise_precedence.csv')
    stdf = pd.DataFrame(stab)
    ukeys = stdf.drop_duplicates(['log', 'message', 'position'])[['log', 'message', 'position', 'p_homogeneity']].reset_index(drop=True)
    ukeys['p_homogeneity_holm'] = holm(ukeys.p_homogeneity.values)           # family = 16 tests
    stdf = stdf.merge(ukeys[['log', 'message', 'position', 'p_homogeneity_holm']], on=['log', 'message', 'position'])
    write_csv(stdf, 'q2_stability_blocks.csv')
    indf = pd.DataFrame(indep)
    indf['p_two_sided_holm'] = holm(indf.p_two_sided.values)                 # family = 16 tests
    write_csv(indf, 'q2_independence_check.csv')
    write_csv(pd.DataFrame(ev_rows), 'q2_evidence_examples.csv')

    # ---------------- role-pooled: leader vs follower, and shares by ring offset (leader + k)
    def role_counts(i, tag, pos):
        cnt = shares[(i, tag, pos)]
        L = leader_main[i]
        return np.array([cnt[(L + k) % N] for k in range(N)])
    for tag, label in (('write', 'WRITE'), ('accept', 'ACCEPT')):
        for pos in ('first', 'last'):
            tot = np.zeros(N, int)
            for i in LOGS:
                rc = role_counts(i, tag, pos)
                tot += rc
                n = int(rc.sum())
                lo, hi = wilson(int(rc[0]), n)
                bt = stats.binomtest(int(rc[0]), n, 0.25)
                pooled_rows.append(dict(scope=LOGS[i]['label'], message=label, position=pos, leader_replica=leader_main[i],
                                        n_cids=n, leader_count=int(rc[0]), leader_share_pct=round(100 * rc[0] / n, 2),
                                        wilson95_lo_pct=round(100 * lo, 2), wilson95_hi_pct=round(100 * hi, 2),
                                        expected_pct=25.0, p_binomial_vs_25=bt.pvalue,
                                        share_offset1_pct=round(100 * rc[1] / n, 2), share_offset2_pct=round(100 * rc[2] / n, 2),
                                        share_offset3_pct=round(100 * rc[3] / n, 2)))
            n = int(tot.sum())
            lo, hi = wilson(int(tot[0]), n)
            bt = stats.binomtest(int(tot[0]), n, 0.25)
            chi_f, p_f = stats.chisquare(tot[1:])
            pooled_rows.append(dict(scope='all 4 logs pooled', message=label, position=pos, leader_replica=-1, n_cids=n,
                                    leader_count=int(tot[0]), leader_share_pct=round(100 * tot[0] / n, 2),
                                    wilson95_lo_pct=round(100 * lo, 2), wilson95_hi_pct=round(100 * hi, 2), expected_pct=25.0,
                                    p_binomial_vs_25=bt.pvalue, share_offset1_pct=round(100 * tot[1] / n, 2),
                                    share_offset2_pct=round(100 * tot[2] / n, 2), share_offset3_pct=round(100 * tot[3] / n, 2),
                                    chi2_offsets_1to3_equal=round(chi_f, 3), p_offsets_1to3_equal=p_f))
    write_csv(pd.DataFrame(pooled_rows), 'q2_role_pooled.csv')

    # ---------------- cross-log homogeneity tests: by replica id and by role (0 = leader, 1 = leader+1 ...)
    comparisons = [(1, 3, 'same leader (replica 0), no recovery events'),
                   (2, 4, 'same leader (replica 1 after regency 1), recovery at CID 0'),
                   (1, 2, 'different leader'), (3, 4, 'different leader'), (1, 4, 'different leader'), (3, 2, 'different leader')]
    for tag, label in (('write', 'WRITE'), ('accept', 'ACCEPT')):
        for pos in ('first', 'last'):
            for a, b, why in comparisons:
                for by in ('replica_id', 'role_rel_leader'):
                    if by == 'replica_id':
                        ta, tb = shares[(a, tag, pos)].to_numpy(), shares[(b, tag, pos)].to_numpy()
                    else:
                        ta, tb = role_counts(a, tag, pos), role_counts(b, tag, pos)
                    tab = np.vstack([ta, tb])
                    tab = tab[:, tab.sum(axis=0) > 0]
                    chi, p, dof, _ = stats.chi2_contingency(tab)
                    xlog.append(dict(message=label, position=pos, log_a='log %d' % a, log_b='log %d' % b, relation=why, compared_by=by,
                                     chi2=round(chi, 2), dof=dof, p_value=p))
    xdf = pd.DataFrame(xlog)
    xdf['p_holm'] = holm(xdf.p_value.values)      # one family: 48 comparisons
    xdf['verdict'] = np.where(xdf.p_holm < 0.01, 'differ (Holm p<0.01)', np.where(xdf.p_holm < 0.05, 'weak (Holm 0.01<=p<0.05)', 'no significant difference'))
    write_csv(xdf, 'q2_cross_log_tests.csv')

    # ---------------- method cross-checks
    chk = []
    allc = pd.concat(per_cid, ignore_index=True)
    for i in LOGS:
        d = allc[(allc.log == LOGS[i]['label']) & (allc.cid >= 1) & (allc.attempt == 0)]
        r = dict(log=LOGS[i]['label'], n_cids=len(d),
                 first_write_send_eq_first_write_recv_pct=round(100 * (d.first_write_sender == d.first_write_recv_sender).mean(), 1),
                 last_write_send_eq_last_write_recv_pct=round(100 * (d.last_write_sender == d.last_write_recv_sender).mean(), 1),
                 first_accept_send_eq_first_accept_recv_pct=round(100 * (d.first_accept_sender == d.first_accept_recv_sender).mean(), 1),
                 last_accept_send_eq_last_accept_recv_pct=round(100 * (d.last_accept_sender == d.last_accept_recv_sender).mean(), 1))
        if LOGS[i]['prefixed']:
            s = d.dropna(subset=['first_spec_accept_sender_log1'])
            r['n_cids_with_4_broadcast_lines'] = len(s)
            r['first_accept_send_eq_first_broadcast_pct'] = round(100 * (s.first_accept_sender == s.first_spec_accept_sender_log1).mean(), 1)
            r['last_accept_send_eq_last_broadcast_pct'] = round(100 * (s.last_accept_sender == s.last_spec_accept_sender_log1).mean(), 1)
            for pos in ('first', 'last'):
                c = s['%s_spec_accept_sender_log1' % pos].astype(int).value_counts().reindex(range(N), fill_value=0)
                for rep in range(N):
                    r['%s_broadcast_share_r%d_pct' % (pos, rep)] = round(100 * c[rep] / len(s), 1)
                r['%s_broadcast_chi2_p_uniform' % pos] = stats.chisquare(c.values).pvalue
        chk.append(r)
    write_csv(pd.DataFrame(chk), 'q2_method_crosscheck.csv')

    # ---------------- plot 1: first / last shares (2 x 2 panels, groups = logs, bars = replicas)
    fig, axes = plt.subplots(2, 2, figsize=(12.6, 8.0))
    panels = [('write', 'first', 'WRITE - first sender'), ('write', 'last', 'WRITE - last sender'),
              ('accept', 'first', 'ACCEPT - first sender'), ('accept', 'last', 'ACCEPT - last sender')]
    for ax, (tag, pos, title) in zip(axes.ravel(), panels):
        w = 0.19
        for gi, i in enumerate((1, 2, 3, 4)):
            cnt = shares[(i, tag, pos)]
            n = cnt.sum()
            for rep in range(N):
                xx = gi + (rep - 1.5) * (w + 0.015)
                v = 100 * cnt[rep] / n
                ax.bar(xx, v, w, color=REPLICA_COLOR[rep], edgecolor=SURFACE, linewidth=1.5)
                lead = rep == leader_main[i]
                if lead or v == 100 * cnt.max() / n:
                    ax.text(xx, v + 1.0, ('%.0f%%' % v) + ('\nL' if lead else ''), ha='center', va='bottom', fontsize=7.6, color=TEXT,
                            zorder=5, bbox=dict(facecolor=SURFACE, edgecolor='none', pad=0.8))
        ax.axhline(25, color=MUTED, lw=1.0, zorder=1)
        ax.text(1.012, 25, '25 %\nuniform', transform=ax.get_yaxis_transform(), fontsize=7.5, color=TEXT2, ha='left', va='center', clip_on=False)
        ax.set_xticks(range(4))
        ax.set_xticklabels(['%s\n%s' % (LOGS[i]['label'], LOGS[i]['file']) for i in (1, 2, 3, 4)], fontsize=8.5)
        ax.set_ylim(0, 85 if tag == 'write' else 42)
        ax.set_ylabel('% of CIDs 1-999')
        ax.set_title(title)
        ax.grid(axis='x', visible=False)
    handles = [plt.Rectangle((0, 0), 1, 1, color=REPLICA_COLOR[r]) for r in range(N)]
    fig.legend(handles, ['replica %d' % r for r in range(N)], loc='upper center', ncol=4, bbox_to_anchor=(0.5, 1.0), fontsize=9)
    fig.text(0.5, -0.005, 'L = leader of the CID (replica 0 in logs 1 and 3; replica 1 in logs 2 and 4). '
             'Order = line order of "Sending WRITE ..., I am:N" and "Sending ACCEPT message ..., I am:N". Labels: leader bar and tallest bar.',
             ha='center', fontsize=8, color=TEXT2)
    fig.tight_layout(rect=(0, 0.02, 1, 0.96), w_pad=3.0)
    save(fig, 'q2_first_last_shares.png')

    # ---------------- plot 2: mean sending rank with 95% CI
    fig, axes = plt.subplots(1, 2, figsize=(12.0, 4.6), sharex=True)
    rk = pd.DataFrame(ranks)
    for ax, label in zip(axes, ('WRITE', 'ACCEPT')):
        for gi, i in enumerate((1, 2, 3, 4)):
            for rep in range(N):
                r = rk[(rk.log == LOGS[i]['label']) & (rk.message == label) & (rk.replica == rep)].iloc[0]
                y = 3 - gi + (1.5 - rep) * 0.17
                ax.plot([r.ci95_lo, r.ci95_hi], [y, y], color=REPLICA_COLOR[rep], lw=2.0)
                ax.scatter([r.mean_rank], [y], s=46, color=REPLICA_COLOR[rep], edgecolor=SURFACE, linewidth=1.6, zorder=4)
                if rep == leader_main[i]:
                    ax.text(r.ci95_hi + 0.04, y, 'L %.2f' % r.mean_rank, va='center', fontsize=7.6, color=TEXT)
        ax.axvline(2.5, color=MUTED, lw=1.0, zorder=1)
        ax.set_yticks([3, 2, 1, 0])
        ax.set_yticklabels(['%s (%s)' % (LOGS[i]['label'], LOGS[i]['file']) for i in (1, 2, 3, 4)], fontsize=8.5)
        ax.set_xlim(1.0, 4.0)
        ax.set_ylim(-0.6, 3.6)
        ax.set_xlabel('mean position in the sending order (1 = first ... 4 = last), 95% CI; 2.5 = no preference')
        ax.set_title('%s sending rank per replica' % label)
        ax.grid(axis='y', visible=False)
    handles = [plt.Line2D([0], [0], marker='o', color=REPLICA_COLOR[r], lw=2, markersize=6) for r in range(N)]
    fig.legend(handles, ['replica %d' % r for r in range(N)], loc='upper center', ncol=4, bbox_to_anchor=(0.5, 1.03), fontsize=9)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    save(fig, 'q2_mean_rank.png')
    print('Q2 done')


if __name__ == '__main__':
    main()
