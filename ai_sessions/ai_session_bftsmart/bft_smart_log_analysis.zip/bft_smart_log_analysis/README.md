# BFT-SMaRt logs: consensus, views and leader change - analysis files

Scripts, tables (CSV) and plots behind the written report. The report answers six questions about four console logs of a BFT-SMaRt run (4 replicas, 1 client, 1,000 requests): consensus progress (Q1), first and last WRITE/ACCEPT senders (Q2), views and vote order (Q3), timeouts and leader change (Q4), ordering of events (Q5) and regencies (Q6). Every claim in the report carries line numbers; the numbers are in the CSV files, and csv/check_claims.csv lists 318 of them that were re-derived from the raw logs by an independent script.

## Run it again

1. Python 3 with pandas, numpy, scipy and matplotlib.
2. Copy the four logs into `logs/` under these names (the paths are set in `scripts/common.py`):

   | File in `logs/` | Original name | Notes |
   |---|---|---|
   | `log1_main.log` | `main.log` | log 1, the only log with `[replicaN]` prefixes |
   | `log2_main_2.log` | `main_2.log` | log 2 |
   | `log3_main_3.log` | `main_3.log` | log 3 |
   | `log4_main_4.log` | `main_4.log` | log 4 |

3. `bash scripts/run_all.sh` (about 2 minutes). It rebuilds every CSV and every plot and then re-checks the quoted numbers. In the environment where the report was produced, a clean re-run reproduced all CSV tables value for value and all plots byte for byte (other library versions may change the bytes of a plot).

## Conventions

- **Line** is the 1-based physical line number in the original log file. The logs have no wall-clock time, so "earlier" and "later" always mean an earlier or later line in the same file. Distances are in lines, never in seconds.
- **Log 1 to log 4** are `main.log`, `main_2.log`, `main_3.log` and `main_4.log`.
- **ts / timestamp** is the epoch timestamp of the consensus protocol for a CID (0 for a first attempt, 1 for the retry of CID 0 in logs 2 and 4), not a clock time.
- **View** is (regency, leader, epoch timestamp); the membership view `ID:0` is the same in all logs.
- **Tagged or inferred.** Only log 1 has `[replicaN]` prefixes. In the other logs a line is attributed to a replica only where `I am:N` or `from replica N` is printed; every other attribution is inferred from line order and is labelled so (columns `*_inferred`, `basis`, `sender_basis`).
- **Quorum** is the 3rd WRITE and the 3rd ACCEPT (N = 4, F = 1). A leader change is joined after STOPs from F + 1 = 2 distinct replicas and installed after 3.

## Main table per question

| Question | Main CSV | Plot |
|---|---|---|
| Q1 | `csv/q1_cid_progress.csv` | `plots/q1_progress_and_counts.png` |
| Q2 | `csv/q2_first_last_per_cid.csv` | `plots/q2_first_last_shares.png`, `plots/q2_mean_rank.png` |
| Q3 | `csv/q3_views.csv` | `plots/q3_views_vote_order.png` |
| Q4 | `csv/q4_timeline_events.csv` | `plots/q4_leader_change_timeline.png` |
| Q5 | `csv/q5_chain_per_cid.csv` | `plots/q5_event_ordering.png` |
| Q6 | `csv/q6_regency_inventory.csv` | `plots/q6_regency_analysis.png` |

## Scripts

| File | What it does |
|---|---|
| `scripts/run_all.sh` | Runs every step below in order (parse, q1 to q6, check_claims, make_readme); about 2 minutes. Stops with a message if a log is missing. |
| `scripts/common.py` | Shared constants (N=4, F=1, quorum = 3rd vote, join threshold 2 STOPs, install threshold 3 STOPs), log paths, table loader and writer, plot style. |
| `scripts/bft_parse.py` | Tolerant parser. Matches the tail of every message because client output overwrote or was glued to replica lines; classifies every damaged line. |
| `scripts/00_parse_logs.py` | Runs the parser on the four logs. Writes csv/parsed/*.csv and csv/q0_parse_quality.csv. |
| `scripts/q1_consensus_progress.py` | Q1: progress per CID, event counts, notable lines; plot q1. |
| `scripts/q2_first_last_senders.py` | Q2: first and last WRITE and ACCEPT sender per CID, shares, tests, mean rank; plots q2. |
| `scripts/q3_views_vote_order.py` | Q3: views (regency, leader, epoch timestamp), match of log entries with views, shared patterns, vote order; plot q3. |
| `scripts/lc_helpers.py` | Helpers shared by q4 to q6: leader-change vocabulary, raw-line access, causality-based inference of untagged senders. |
| `scripts/q4_leader_change_timeouts.py` | Q4: timeouts and leader change (timeline, milestones, sender inference, STOP re-transmissions, start-up race); plot q4. |
| `scripts/q5_event_ordering.py` | Q5: ordering of the normal chain and of the recovery chain, causality checks, relationships from the task text; plot q5. |
| `scripts/q6_regency_analysis.py` | Q6: regency inventory, STOP senders, last/next regency pairs, leader roles, recovery order, effect of the never-installed regency; plot q6. |
| `scripts/check_claims.py` | Independent check: re-derives 318 numbers and line numbers quoted in the report from the raw logs with plain regular expressions (no parser) and writes csv/check_claims.csv. |
| `scripts/make_readme.py` | This manifest: writes README.md and checks that every file is listed and exists. |

## CSV tables (61 files; every column is named in the header row)

### Parsing (all questions)

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q0_parse_quality.csv` | 4 x 20 | One row per log: lines per damage class (blank, client-only, spliced, damaged head, torn head, lost bracket, unparsed), recovered client tokens, events with a lost head, prefix-versus-'I am' conflicts, decision lines. |
| `csv/parsed/events_log1.csv` | 128,371 x 18 | Log 1: one row per recognised message: line, position in line, kind, replica and where it was read from, sender, CID, timestamp, vote count, regency, message type, last/next regency, client number, tail_only flag, line class. |
| `csv/parsed/events_log2.csv` | 129,173 x 18 | Log 2: same columns as events_log1.csv (replica only where 'I am:N' is printed). |
| `csv/parsed/events_log3.csv` | 129,072 x 18 | Log 3: same columns as events_log1.csv (replica only where 'I am:N' is printed). |
| `csv/parsed/events_log4.csv` | 130,612 x 18 | Log 4: same columns as events_log1.csv (replica only where 'I am:N' is printed). |
| `csv/parsed/issues_log1.csv` | 2,282 x 5 | Log 1: one row per physical line that is not one clean message: line, class, raw text, note, events recovered from it. Class 'unparsed' is empty. |
| `csv/parsed/issues_log2.csv` | 2,677 x 5 | Log 2: same columns as issues_log1.csv. |
| `csv/parsed/issues_log3.csv` | 2,723 x 5 | Log 3: same columns as issues_log1.csv. |
| `csv/parsed/issues_log4.csv` | 2,746 x 5 | Log 4: same columns as issues_log1.csv. |

### Q1 progress, events, unusual lines

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q1_cid_progress.csv` (main) | 4,000 x 21 | One row per (log, CID): first/last line, PROPOSE line, first/last decision line and count, execution lines, client-reply line, attempts, highest epoch timestamp, WRITE/ACCEPT counts, out-of-context lines, PROPOSE sender, decision latency in lines. |
| `csv/q1_event_counts.csv` | 132 x 8 | Count of every event type per log with the count expected for 1,000 CIDs and the difference. |
| `csv/q1_notable_lines.csv` | 1,535 x 10 | Every non-routine line (start-up banners, timeouts, forwarding, STOP, STOPDATA, SYNC, regency state lines) with line, type, regency, sender, CID, timestamp. |

### Q2 first and last senders

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q2_first_last_per_cid.csv` (main) | 4,002 x 34 | One row per (log, CID, attempt): first/last WRITE sender and line, first/last ACCEPT sender and line, full send order, candidates where the sender is inferred, receive-order cross-check, log 1 speculative-ACCEPT order. |
| `csv/q2_summary_by_replica.csv` | 64 x 17 | Per log, message, first/last and replica: count, share, Wilson 95 % interval, chi-square against uniform and among the followers, Holm-adjusted p. |
| `csv/q2_mean_rank.csv` | 32 x 13 | Mean sending rank per replica (1 = first, 4 = last) with 95 % interval, Friedman test, Kendall W. |
| `csv/q2_pairwise_precedence.csv` | 96 x 6 | Probability that replica i sends before replica j, per log and message. |
| `csv/q2_role_pooled.csv` | 20 x 16 | Leader versus follower shares per log and pooled over the four logs, binomial test against 25 %, shares by ring offset (leader + k). |
| `csv/q2_cross_log_tests.csv` | 48 x 11 | Chi-square homogeneity tests between logs, by replica id and by role relative to the leader. |
| `csv/q2_stability_blocks.csv` | 48 x 14 | Shares in three blocks of 333 CIDs with a homogeneity test: is the pattern stable over the run? |
| `csv/q2_independence_check.csv` | 16 x 9 | Lag-1 repeat rate of the first/last sender against the rate expected if CIDs were independent. |
| `csv/q2_method_crosscheck.csv` | 4 x 19 | Agreement of the send-line definition with the receive-line definition and (log 1) the broadcast-line definition. |
| `csv/q2_evidence_examples.csv` | 192 x 9 | Three example CIDs with the line number of every send, per log, message, position and replica. |

### Q3 views and vote order

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q3_views.csv` (main) | 9 x 15 | One row per (log, view): regency, leader, epoch timestamp, leader = regency mod 4 check, membership view, status (installed or only attempted), CIDs and decided CIDs, first/last line. |
| `csv/q3_view_log_entry_matches.csv` | 63 x 8 | Per (log, view, check): how many log-line fields agree with the view, with the mismatching lines. |
| `csv/q3_view_pattern_signature.csv` | 8 x 24 | Per (log, view): events and lines per CID (means, medians, IQR), leader first/last shares. |
| `csv/q3_view_pattern_similarity.csv` | 60 x 15 | Pairwise view comparison per metric: test, effect size, Holm-adjusted p, verdict. |
| `csv/q3_view_pattern_pairs.csv` | 6 x 7 | One verdict per pair of views (how many of the 10 metrics differ). |
| `csv/q3_vote_order_global.csv` | 8,002 x 13 | Per (log, view, CID, message): order in which the senders first appear in the received-vote lines (merged stream). |
| `csv/q3_vote_order_per_receiver_log1.csv` | 3,996 x 17 | Log 1 only, per (CID, receiver): exact order of remote WRITEs and ACCEPTs, closing vote, position of the own ACCEPT. |
| `csv/q3_vote_order_summary.csv` | 248 x 12 | Shares (Wilson interval) of first / last / closing vote by sender and by role, per view and vantage point. |
| `csv/q3_vote_order_tests.csv` | 51 x 8 | Tests of the vote-order shares: uniform, followers equal, homogeneity between views. |
| `csv/q3_vote_position_by_role_log1.csv` | 29 x 12 | Log 1: share of every position per vote group (follower at leader, leader at follower, ...) and message. |
| `csv/q3_vote_precedence_log1.csv` | 24 x 7 | Log 1: probability that the vote of sender x arrives before the vote of sender y at the same receiver. |
| `csv/q3_closing_vote_inference.csv` | 5 x 16 | Precision and coverage of the adjacency inference of the closing vote (log 1) and closing-vote shares by role in all logs. |
| `csv/q3_per_receiver_completeness_log1.csv` | 5 x 2 | Log 1: how many (CID, receiver) pairs have a complete vote order, how many were completed by elimination. |

### Q4 timeouts and leader change

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q4_timeline_events.csv` (main) | 1,461 x 14 | One row per leader-change or timeout line of logs 2 and 4 (plus an explicit no-events row for logs 1 and 3): line, phase, kind, regency, type, sender and its basis (tagged or inferred), last/next regency, CID in progress, text. |
| `csv/q4_keyword_counts.csv` | 56 x 7 | Per log and keyword (timeout, regency, STOP, SYNC, error, ...): number of lines, first and last line; backs 'no events' for logs 1 and 3. |
| `csv/q4_summary_per_log.csv` | 4 x 26 | One row per log: count of every leader-change message, first/last line, regencies installed or attempted. |
| `csv/q4_milestones.csv` | 65 x 6 | Ordered milestones of the recovery in logs 2 and 4 with line numbers and distance from the first timeout. |
| `csv/q4_send_inference.csv` | 15 x 11 | Causality-based inference of the sender of each untagged STOP / STOPDATA / SYNC line: feasible assignments, assigned sender, role. |
| `csv/q4_retransmissions_log4.csv` | 188 x 9 | The 188 re-transmissions of the STOP for regency 2 in log 4: line, phase, CID in progress, gaps, receipts. |
| `csv/q4_startup_race.csv` | 4 x 13 | Start-up banners against first PROPOSE against the outcome of CID 0 at timestamp 0, one row per log. |

### Q5 ordering of events

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q5_chain_per_cid.csv` (main) | 4,002 x 38 | One row per (log, CID, attempt): first/last line and count of every chain stage (invocation, PROPOSE, executing propose, WRITE sent, WRITE quorum, ACCEPT sent, ACCEPT quorum, decision, execution, reply), regency, leader, pooled-order verdict. |
| `csv/q5_chain_link_checks.csv` | 36 x 13 | Per log and link L0 to L8: CIDs checked, incomplete, violations, largest inversion, example lines. |
| `csv/q5_chain_per_replica.csv` | 56 x 6 | Exact within-replica order test per log, link and replica. |
| `csv/q5_causality_checks.csv` | 12 x 8 | Per log: 'received before sent' counts for WRITE and ACCEPT, and the position of the client reply among the execution lines. |
| `csv/q5_cross_cid_order.csv` | 47 x 5 | Order of decisions, executions and replies across consecutive CIDs. |
| `csv/q5_relationship_checks.csv` | 42 x 8 | The relationships listed in the task (leader PROPOSE, WRITE for every PROPOSE, same value, ...) with counts of cases that hold and exceptions. |
| `csv/q5_stage_offsets.csv` | 36 x 12 | Per log and stage: median and quartiles of the line offset from the first PROPOSE of the CID. |
| `csv/q5_recovery_chain.csv` | 37 x 13 | Logs 2 and 4: the recovery stages from timeout to client reply with first/last line, counts, order rule and verdict; the regency-2 side branch of log 4. |
| `csv/q5_cid0_attempts.csv` | 6 x 23 | CID 0 at ts 0 and at ts 1 (one attempt in logs 1 and 3): stage counts, regency, leader, value digest. |

### Q6 regency analysis

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/q6_regency_inventory.csv` (main) | 7 x 24 | One row per (log, regency): status (installed, attempted, none), STOP/STOPDATA/SYNC counts, distinct STOP senders, thresholds reached, expected and observed leader, CIDs decided. |
| `csv/q6_stop_senders.csv` | 17 x 11 | Per (log, message type, regency, sender): receipts, first/last line, rank, role, basis (tagged or inferred). |
| `csv/q6_state_pairs.csv` | 12 x 9 | Counts of the 'Last regency / next regency' pairs per received message type and regency, with their meaning. |
| `csv/q6_pairing_check.csv` | 2 x 8 | Validation of the pairing between receipt lines and state lines. |
| `csv/q6_leader_roles.csv` | 24 x 13 | PROPOSE senders per regency in effect (leader check, replaced leader) and follower activity. |
| `csv/q6_recovery_response_order.csv` | 30 x 8 | Order of the replicas in STOP, STOPDATA, WRITE ts 1 and ACCEPT ts 1 (logs 2 and 4), tagged or inferred. |
| `csv/q6_regency2_effect_per_cid.csv` | 4,000 x 14 | Per (log, CID): decision latency in lines with and without leader-change lines inside the window. |
| `csv/q6_regency2_effect_summary.csv` | 11 x 25 | Group medians and Mann-Whitney tests (Holm-corrected) with effect sizes: did the never-installed regency change later CIDs? |
| `csv/q6_integrity_checks.csv` | 4 x 13 | Per log: decisions, executions, replies in order, leader and timestamp of CIDs 1 and above. |

### Independent check of the report

| File | Rows x columns | What it contains |
|---|---|---|
| `csv/check_claims.csv` | 318 x 5 | One row per claim quoted in the report (318 claims), re-derived from the raw logs: section, claim, expected, found, status (all PASS). |

## Plots (7 files, one or more per question)

| File | Question | What it shows |
|---|---|---|
| `plots/q1_progress_and_counts.png` | Q1 | (a) decision latency of every CID in the four logs, CID 0 highlighted; (b) normal-chain events per CID; (c) recovery events, log 2 against log 4. |
| `plots/q2_first_last_shares.png` | Q2 | Share of CIDs in which each replica is the first or last WRITE and ACCEPT sender, per log; the leader is marked, 25 % is the chance level. |
| `plots/q2_mean_rank.png` | Q2 | Mean sending rank of each replica (1 = first, 4 = last) with 95 % interval, WRITE and ACCEPT, per log. |
| `plots/q3_views_vote_order.png` | Q3 | (a) first and last vote by role in every view; (b) position of the WRITE votes per receiver in log 1; (c) the same for ACCEPT. |
| `plots/q4_leader_change_timeline.png` | Q4 | (a) and (b) lines 55 to 345 of logs 2 and 4: start-up, timeout, STOP, STOPDATA, SYNC, WRITE/ACCEPT at ts 1, decision; (c) cumulative STOP re-transmissions for regency 2 in log 4. |
| `plots/q5_event_ordering.png` | Q5 | (a) line offset of every stage of the normal chain; (b) order violations per link and log; (c) CID 0 per attempt; (d) recovery chain of logs 2 and 4. |
| `plots/q6_regency_analysis.png` | Q6 | (a) distinct STOP senders per regency against the thresholds; (b) 'Last regency / next regency' pairs; (c) decision latency by group; (d) order of the replicas in the recovery. |

## What could still be wrong

The report ends with a section of that name. In short: the logs have no clock, so only line order is evidence; log 1 lost characters where client text overwrote replica text; in logs 2 to 4 the receiving replica is not printed and several senders are inferred; a regency was seen installed only twice (regencies 0 and 1), so "leader = regency mod 4" is verified for those two only; each log is a single run.
