#!/usr/bin/env python3
"""BFT-SMaRt log analysis: line-numbered, source-derived, deterministic.
Run: python analyze.py [output-directory] [log1 log2 log3 log4]
Requires Python standard library and matplotlib for six PNG figures.
Never turns logged global order into a network latency measurement.
"""
import csv, re, sys, time, hashlib, math, json
from pathlib import Path
from collections import Counter, defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

DEFAULT = [Path('/mnt/data/main(7).log'),Path('/mnt/data/main_2(3).log'),Path('/mnt/data/main_3(3).log'),Path('/mnt/data/main_4(3).log')]
OUT = Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/bftsmart_fresh')
PATHS = [Path(p) for p in sys.argv[2:]] if len(sys.argv)>2 else DEFAULT
OUT.mkdir(parents=True,exist_ok=True)
P = {k:re.compile(v,re.I) for k,v in {
 'propose':r'PROPOSE received from:\s*(\d+), for consensus cId:\s*(\d+), I am:\s*(\d+)',
 'execute_propose':r'Executing propose for cId:\s*(\d+), Epoch Timestamp:\s*(\d+)',
 'send_write':r'Sending WRITE for cId:\s*(\d+), I am:\s*(\d+)',
 'recover_write':r'Sending WRITE message for CID\s*(\d+), timestamp\s*(\d+)',
 'send_accept':r'Sending ACCEPT message, cId:\s*(\d+), I am:\s*(\d+)',
 'recv_write':r'WRITE received from:\s*(\d+), for consensus cId:\s*(\d+)',
 'recv_accept':r'ACCEPT from\s*(\d+) for consensus\s*(\d+)',
 'writes':r'I have\s*(\d+), WRITE\x27s for cId:\s*(\d+), Epoch timestamp:\s*(\d+)',
 'accepts':r'I have\s*(\d+) ACCEPTs for cId:\s*(\d+), Timestamp:\s*(\d+)',
 'decision':r'Deciding consensus\s*(\d+)',
 'execute':r'Counter was incremented\. Current value\s*=\s*(\d+)',
 'reply':r'returned value:\s*(\d+)',
 'timeout':r'The following requests timed out:',
 'forward':r'Forwarding requests',
 'attempt':r'Attempting to start leader change',
 'send_stop':r'Sending STOP message to install regency\s*(\d+)',
 'retransmit_stop':r'Re-transmitting STOP message to install regency\s*(\d+)',
 'recv_lc':r'Received leader change message of type\s*(STOPDATA|STOP|SYNC) for regency\s*(\d+) from replica\s*(\d+)',
 'send_stopdata':r'Sending STOPDATA of regency\s*(\d+)',
 'send_sync':r'Sending SYNC message for regency\s*(\d+)',
 'reg_pair':r'Last regency:\s*(\d+), next regency:\s*(\d+)',
 'out_context':r'Out of context msg with id\s*(\d+)',
 'quorumwrite':r'Setting consensus\s*(\d+) QuorumWrite tiemstamp to\s*(\d+)',
}.items()}

def csv_save(filename,fields,rows):
 with (OUT/filename).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def evidence_lines(es,top=4):
 a=[str(x) for x in sorted(es)[:top]];return ';'.join(a)

def strict_sender(e):
 return e.get('replica') if e.get('replica') is not None else e.get('iam')

class Parsed:
 def __init__(self,path):
  self.path=path;self.name=path.name; self.count=Counter();self.idx=defaultdict(list);self.cids=defaultdict(lambda:defaultdict(list));self.issues=[];self.bytes=path.stat().st_size;self.lines=0;self.chars=0;self.words=0;self.wpc=0;self.splices=0;self.hash=hashlib.sha256(path.read_bytes()).hexdigest();self.regex_token_pieces=0
  self.parse()
 def parse(self):
  with self.path.open(encoding='utf-8',errors='replace') as f:
   for lno,raw in enumerate(f,1):
    self.lines=lno; self.chars+=len(raw);self.words+=len(raw.split())
    # the surrogate is deliberately NOT an OpenAI tokenizer; only an optional lexical proxy
    self.regex_token_pieces+=len(re.findall(r'[A-Za-z]+|\d+|[^A-Za-z\d\s]+',raw))
    line=raw.rstrip('\n\r')
    pr=re.search(r'^\[replica([0-3])\]\s*',line)
    tagged=int(pr.group(1)) if pr else None
    norm=line[pr.end():] if pr else line
    # Multiple physical stream fragments can be interleaved on a single line.
    if (len(re.findall(r'(?<!^)-- ',norm))>=2 or (('Counter was incremented' in norm) and norm.count('Counter was incremented')>1) or (('Counter was incremented' in norm) and '-- ' in norm and not norm.lstrip().startswith('--')) or ('returned value:' in norm and ('-- ' in norm or 'Counter was incremented' in norm)) or ('Invocation' in norm and '-- ' in norm) or '\ufffd' in norm):
     self.splices+=1
     why='spliced_or_mixed_client_output' if '\ufffd' not in norm else 'invalid_utf8_replacement'
     self.issues.append(dict(log=self.name,line=lno,problem=why,raw_text=line[:1300]))
    for kind,rgx in P.items():
     for m in rgx.finditer(norm):
      if kind=='reply':
       self.count['reply_candidate_substrings']+=1
       suffix=norm[m.end():].strip()
       if suffix or int(m.group(1))>1000:
        self.issues.append(dict(log=self.name,line=lno,problem='unparseable_spliced_client_reply',raw_text=line[:1300]))
        continue
      e=dict(log=self.name,kind=kind,line=lno,replica=tagged,iam=None,cid=None,epoch=None,sender=None,regency=None,quantity=None,raw=norm[:350])
      g=m.groups()
      if kind=='propose':e.update(sender=int(g[0]),cid=int(g[1]),iam=int(g[2]))
      elif kind=='execute_propose':e.update(cid=int(g[0]),epoch=int(g[1]))
      elif kind in ('send_write','send_accept'):e.update(cid=int(g[0]),iam=int(g[1]))
      elif kind=='recover_write':e.update(cid=int(g[0]),epoch=int(g[1]))
      elif kind in ('recv_write','recv_accept'):e.update(sender=int(g[0]),cid=int(g[1]))
      elif kind in ('writes','accepts'):e.update(quantity=int(g[0]),cid=int(g[1]),epoch=int(g[2]))
      elif kind in ('decision','execute','reply','out_context'):e.update(cid=int(g[0]))
      elif kind=='quorumwrite':e.update(cid=int(g[0]),epoch=int(g[1]))
      elif kind=='recv_lc':e.update(message_type=g[0].upper(),regency=int(g[1]),sender=int(g[2]))
      elif kind in ('send_stop','retransmit_stop','send_stopdata','send_sync'):e.update(regency=int(g[0]))
      elif kind=='reg_pair':e.update(last_reg=int(g[0]),next_reg=int(g[1]))
      self.idx[kind].append(e);self.count[kind]+=1
      if e['cid'] is not None and kind not in ('execute','reply','out_context'):
       self.cids[e['cid']][kind].append(e)
    # Explicitly record incomplete protocol prefix lines; do not treat as full events
    if re.search(r'(?:\bPROPOSE received|\bSending WRITE for cId:|\bSending ACCEPT message|\bDeciding consensus|\bReceived leader change message)',norm) and not any(rgx.search(norm) for k,rgx in P.items() if k in ('propose','send_write','send_accept','decision','recv_lc')):
     self.issues.append(dict(log=self.name,line=lno,problem='unparsed_protocol_line',raw_text=line[:1300]))
    if norm.strip().startswith(', returned value:') and not P['reply'].search(norm):
     self.issues.append(dict(log=self.name,line=lno,problem='unparsed_client_reply',raw_text=line[:1300]))

started=time.perf_counter();logs=[Parsed(p) for p in PATHS]

# Q1 summaries — count exact pattern matches, never substitute damaged-log absence for failure
rows=[]
for d in logs:
 allcids=sorted(set(d.cids.keys()))
 decids={e['cid'] for e in d.idx['decision']}
 replies=[e['cid'] for e in d.idx['reply']]
 rows.append(dict(log=d.name,sha256=d.hash,physical_lines=d.lines,bytes=d.bytes,first_cid=min(allcids) if allcids else '',last_cid=max(allcids) if allcids else '',unique_cids=len(allcids),propose_received=d.count['propose'],write_sends=d.count['send_write'],recovery_write_sends_unknown_sender=d.count['recover_write'],write_receipts=d.count['recv_write'],write_quorum_3_or_more=sum(e['quantity']>=3 for e in d.idx['writes']),accept_sends=d.count['send_accept'],accept_receipts=d.count['recv_accept'],accept_quorum_3_or_more=sum(e['quantity']>=3 for e in d.idx['accepts']),decision_lines=d.count['decision'],distinct_decided_cids=len(decids),execution_counter_lines=d.count['execute'],max_executed_counter=max((e['cid'] for e in d.idx['execute']),default=''),client_reply_lines=d.count['reply'],client_reply_candidate_substrings=d.count['reply_candidate_substrings'],unparseable_reply_candidates=d.count['reply_candidate_substrings']-d.count['reply'],max_client_reply=max(replies) if replies else '',timeouts=d.count['timeout'],forwarded_requests=d.count['forward'],leader_change_attempts=d.count['attempt'],stop_sends=d.count['send_stop'],stopdata_sends=d.count['send_stopdata'],sync_sends=d.count['send_sync'],received_lc_messages=d.count['recv_lc'],stop_retransmissions=d.count['retransmit_stop'],out_of_context_messages=d.count['out_context'],spliced_physical_lines=d.splices,first_proposal_line=evidence_lines([e['line'] for e in d.idx['propose']],1),last_decision_line=evidence_lines([e['line'] for e in d.idx['decision'][-1:]],1),last_reply_line=evidence_lines([e['line'] for e in d.idx['reply'][-1:]],1),first_timeout_line=evidence_lines([e['line'] for e in d.idx['timeout']],1)))
q1fields=list(rows[0]);csv_save('q1_consensus_progress.csv',q1fields,rows)

# Q2 first/last SEND order, at each CID, always only explicit 'I am:N'.
q2=[];rankstat=defaultdict(Counter);receiving=[]
for d in logs:
 for cid in range(1000):
  for phase,kind in [('WRITE','send_write'),('ACCEPT','send_accept')]:
   ev=sorted(d.cids[cid][kind],key=lambda x:x['line'])
   recovery_boundary=min((x['line'] for x in d.cids[cid]['recover_write']),default=None)
   if cid==0 and kind=='send_accept' and recovery_boundary is not None:
    ev=[e for e in ev if e['line']<recovery_boundary]
   observed=[]
   for e in ev:
    if e['iam'] not in observed:observed.append(e['iam'])
   first=observed[0] if observed else '';last=observed[-1] if observed else ''
   for label,sender in [('first',first),('last',last)]:
    if sender!='':rankstat[(d.name,phase,label)][sender]+=1
   q2.append(dict(log=d.name,cid=cid,phase=phase,epoch='0 (normal path; inferred from proposal for CID)',identified_senders=len(observed),complete_four_senders=len(observed)==4,first_sender=first,first_sender_line=ev[0]['line'] if ev else '',last_sender=last,last_sender_line=next((e['line'] for e in reversed(ev) if e['iam']==last),'') if ev else '',send_order='>'.join(map(str,observed)),send_line_numbers=';'.join(f"{e['iam']}:{e['line']}" for e in ev),evidence_basis='I am:N explicit; physical line order; not network latency'))
  if d.cids[cid]['recover_write']:
   es=d.cids[cid]['recover_write']
   q2.append(dict(log=d.name,cid=cid,phase='WRITE_RECOVERY',epoch=es[0]['epoch'],identified_senders=0,complete_four_senders=False,first_sender='',first_sender_line='',last_sender='',last_sender_line='',send_order='',send_line_numbers=';'.join(f"unknown:{e['line']}" for e in es),evidence_basis='Recovery WRITE lines lack sender ID; cannot rank'))
   recovery_accepts=sorted([e for e in d.cids[cid]['send_accept'] if e['line']>=min(x['line'] for x in es)],key=lambda x:x['line'])
   if recovery_accepts:
    observed=[];first_line_by_rep={}
    for e in recovery_accepts:
     if e['iam'] not in observed:
      observed.append(e['iam']);first_line_by_rep[e['iam']]=e['line']
    q2.append(dict(log=d.name,cid=cid,phase='ACCEPT_RECOVERY',epoch=es[0]['epoch'],identified_senders=len(observed),complete_four_senders=len(observed)==4,first_sender=observed[0] if observed else '',first_sender_line=first_line_by_rep.get(observed[0],'') if observed else '',last_sender=observed[-1] if observed else '',last_sender_line=first_line_by_rep.get(observed[-1],'') if observed else '',send_order='>'.join(map(str,observed)),send_line_numbers=';'.join(f"{e['iam']}:{e['line']}" for e in recovery_accepts),evidence_basis='I am:N explicit; epoch inferred by being after recovery WRITE; observed sender order, not latency'))
q2fields=list(q2[0]);csv_save('q2_per_cid_send_order.csv',q2fields,q2)

# Q3 CID / regency / leader / epoch tuples. For normal CID 0 run2 & run4, two attempts.
q3=[]
for d in logs:
 recovered=bool(d.idx['send_sync'])
 for cid in range(1000):
  ats=[0,1] if cid==0 and recovered else [0]
  for epoch in ats:
   regency=(1 if recovered and (cid>0 or epoch==1) else 0)
   leader=regency%4
   propos=[e for e in d.cids[cid]['propose'] if epoch==0]
   w=[e for e in d.cids[cid]['writes'] if e['epoch']==epoch]
   a=[e for e in d.cids[cid]['accepts'] if e['epoch']==epoch]
   re=[e for e in d.cids[cid]['recover_write'] if e['epoch']==epoch]
   q3.append(dict(log=d.name,cid=cid,regency=regency,leader_inferred_from_regency_mod_N=leader,epoch_timestamp=epoch,membership_view_id=0,proposer_ids_observed=';'.join(map(str,sorted({e['sender'] for e in propos}))),propose_lines=evidence_lines([e['line'] for e in propos],4),write_quorum_lines=evidence_lines([e['line'] for e in w if e['quantity']>=3],3),accept_quorum_lines=evidence_lines([e['line'] for e in a if e['quantity']>=3],3),recovery_write_lines=evidence_lines([e['line'] for e in re],4),decision_lines=evidence_lines([e['line'] for e in d.cids[cid]['decision']],4) if (not recovered or cid>0 or epoch==1) else '',view_attribution='inferred from SYNC/regency and PROPOSE sender; epoch directly from quorum lines; membership ID:0 constant',pattern='recovery_epoch_1' if re else 'normal_epoch_0',installed_regency_proof=';'.join(map(str,[e['line'] for e in d.idx['send_sync'][:1]])) if regency==1 else ''))
q3fields=list(q3[0]);csv_save('q3_regency_leader_epoch_views.csv',q3fields,q3)

# Q4 full timeouts + leader-change events chronological; each sender is only explicit where present.
q4=[]
for d in logs:
 es=sorted([e for k in ('timeout','forward','attempt','send_stop','retransmit_stop','recv_lc','send_stopdata','send_sync','reg_pair','recover_write') for e in d.idx[k]],key=lambda e:e['line'])
 for e in es:
  q4.append(dict(log=d.name,line=e['line'],kind=e['kind'],regency=e.get('regency') if e.get('regency') is not None else '',sender_replica=e.get('sender') if e.get('sender') is not None else '',sender_basis='explicit from replica N' if e.get('sender') is not None else 'unknown (line has no sender)',last_regency=e.get('last_reg',''),next_regency=e.get('next_reg',''),cid=e.get('cid') if e.get('cid') is not None else '',epoch=e.get('epoch') if e.get('epoch') is not None else '',raw_text=e['raw']))
q4fields=['log','line','kind','regency','sender_replica','sender_basis','last_regency','next_regency','cid','epoch','raw_text'];csv_save('q4_timeouts_leader_change_timeline.csv',q4fields,q4)

# Q5 phase chain per (cid,epoch) with nearest observed log line / no invented execution cause.
q5=[]
for d in logs:
 reply_lookup=defaultdict(list);ex_lookup=defaultdict(list)
 for e in d.idx['execute']:ex_lookup[e['cid']-1].append(e['line'])
 for e in d.idx['reply']:reply_lookup[e['cid']-1].append(e['line'])
 recovered=bool(d.idx['send_sync'])
 for cid in range(1000):
  for epoch in ([0,1] if cid==0 and recovered else [0]):
   props=sorted([e['line'] for e in d.cids[cid]['propose']] if epoch==0 else [])
   sw=sorted([e['line'] for e in d.cids[cid]['send_write']] if epoch==0 else [e['line'] for e in d.cids[cid]['recover_write'] if e['epoch']==1])
   wq=sorted([e['line'] for e in d.cids[cid]['writes'] if e['epoch']==epoch and e['quantity']>=3])
   ac=sorted([e['line'] for e in d.cids[cid]['send_accept']] if epoch==0 else [e['line'] for e in d.cids[cid]['send_accept'] if e['line']>=sw[0]] if sw else [])
   aq=sorted([e['line'] for e in d.cids[cid]['accepts'] if e['epoch']==epoch and e['quantity']>=3])
   dec=sorted([e['line'] for e in d.cids[cid]['decision']]) if (not recovered or epoch==1 or cid>0) else []
   exe=sorted(ex_lookup[cid]) if (not recovered or epoch==1 or cid>0) else []
   rep=sorted(reply_lookup[cid]) if (not recovered or epoch==1 or cid>0) else []
   stage=[props,sw,wq,ac,aq,dec,exe,rep]
   firsts=[s[0] if s else None for s in stage]
   recorded=[x for x in firsts if x is not None]
   nonmonotonic=any(a>b for a,b in zip(recorded,recorded[1:]))
   q5.append(dict(log=d.name,cid=cid,epoch=epoch,regency_inferred=(1 if recovered and (epoch==1 or cid>0) else 0),propose_first_line=firsts[0] or '',write_send_first_line=firsts[1] or '',write_quorum_first_line=firsts[2] or '',accept_send_first_line=firsts[3] or '',accept_quorum_first_line=firsts[4] or '',local_decision_first_line=firsts[5] or '',application_execution_first_line=firsts[6] or '',client_reply_first_line=firsts[7] or '',number_of_stages_recorded=sum(x is not None for x in firsts),full_eight_stages_recorded=all(x is not None for x in firsts),observed_out_of_stage_order=nonmonotonic,all_decision_lines=evidence_lines(dec,4),all_write_quorum_lines=evidence_lines(wq,4),all_accept_quorum_lines=evidence_lines(aq,4),recovery_note='SYNC resumes same CID at higher epoch; no required new PROPOSE log record' if epoch==1 else '',method_note='line number order only; execution/reply counter n+1 is correlated with CID n (inference); log losses are not protocol failures'))
q5fields=list(q5[0]);csv_save('q5_consensus_chain_by_cid_epoch.csv',q5fields,q5)

# Q6 regency counts; distinguish installation from mere attempt, START senders are not derivable.
q6=[]
for d in logs:
 allregs=sorted({0}|{e['regency'] for k in ('send_stop','retransmit_stop','recv_lc','send_stopdata','send_sync') for e in d.idx[k] if e.get('regency') is not None})
 for reg in allregs:
  sends=[e for e in d.idx['send_stop'] if e['regency']==reg]
  retrans=[e for e in d.idx['retransmit_stop'] if e['regency']==reg]
  rstop=[e for e in d.idx['recv_lc'] if e['regency']==reg and e['message_type']=='STOP']
  rstopdata=[e for e in d.idx['recv_lc'] if e['regency']==reg and e['message_type']=='STOPDATA']
  rsync=[e for e in d.idx['recv_lc'] if e['regency']==reg and e['message_type']=='SYNC']
  sdata=[e for e in d.idx['send_stopdata'] if e['regency']==reg]
  ssync=[e for e in d.idx['send_sync'] if e['regency']==reg]
  froms=sorted({e['sender'] for e in rstop})
  pairs=[e for e in d.idx['reg_pair'] if e.get('next_reg')==reg]
  installed=(reg==0 or bool(ssync and any(e['sender']==reg%4 and e['cid']>=1 for e in d.idx['propose'])))
  # no meaningful 'regency 2 installed' evidence if no SYNC2 or new leader proposals
  q6.append(dict(log=d.name,regency=reg,leader_by_regency_mod_4=reg%4,installation_state='initial_baseline' if reg==0 else 'installed_sustained_by_SYNC_and_proposal' if installed else 'attempted_not_installed',stop_send_lines_count=len(sends),stop_retransmission_count=len(retrans),first_retransmission_line=retrans[0]['line'] if retrans else '',last_retransmission_line=retrans[-1]['line'] if retrans else '',stop_send_lines=evidence_lines([e['line'] for e in sends],8),received_stop_message_count=len(rstop),distinct_stop_sender_count=len(froms),distinct_stop_senders=';'.join(map(str,froms)),f_plus_1_met_in_combined_log=(len(froms)>=2),stop_receive_first_lines=';'.join(f"{e['sender']}:{e['line']}" for e in sorted(rstop,key=lambda x:x['line'])[:8]),stopdata_sent_count=len(sdata),stopdata_received_count=len(rstopdata),sync_sent_count=len(ssync),sync_received_count=len(rsync),regency_pair_lines=evidence_lines([e['line'] for e in pairs],8),no_advance_pair_count=sum(e.get('last_reg')==reg and e.get('next_reg')==reg for e in d.idx['reg_pair']),first_event_line=min([e['line'] for e in (sends+rstop+ssync+rsync)] or [1]),last_event_line=max([e['line'] for e in (sends+rstop+ssync+rsync)] or [1]),sender_inference_warning='STOP sending lines do not identify the initiating replica; received STOP from N establishes only distinct message origin',threshold_warning='F+1 observed globally; recipient-specific threshold not demonstrated in untagged combined logs',later_cid_decisions_after_first_event=sum(e['line']>min([x['line'] for x in sends+rstop] or [d.lines+1]) for e in d.idx['decision']) if reg>0 else '',has_regency_change_events=reg>0))
q6fields=list(q6[0]);csv_save('q6_regency_analysis.csv',q6fields,q6)

issues=[x for d in logs for x in d.issues];csv_save('unparsed_spliced_lines.csv',['log','line','problem','raw_text'],issues)
# Q3 supplemental: vote-receipt ordering. The untagged merged stream has no safe receiver ID.
q3votes=[];q3vstat=defaultdict(Counter)
for d in logs:
 for cid in range(1000):
  for kind,phase in [('recv_write','WRITE'),('recv_accept','ACCEPT')]:
   events=sorted(d.cids[cid][kind],key=lambda e:e['line'])
   if d.name=='main(7).log':
    recgroups=defaultdict(list)
    for e in events:
     if e['replica'] is not None:recgroups[e['replica']].append(e)
    groups=[('explicit_receiver',int(n),es) for n,es in sorted(recgroups.items())]
   else:
    groups=[('unknown_merged_receivers','',events)]
   for basis,receiver,evs in groups:
    seen=[]
    for e in evs:
     if e['sender'] not in seen:seen.append(e['sender'])
    if d.name=='main(7).log':
     for lab,rep in [('first',seen[0] if seen else None),('last',seen[-1] if seen else None)]:
      if rep is not None:q3vstat[(d.name,phase,lab)][rep]+=1
    q3votes.append(dict(log=d.name,cid=cid,phase=phase,receiver_replica=receiver,receiver_identity_basis=basis,unique_senders_recorded=len(seen),first_observed_sender=seen[0] if seen else '',last_observed_sender=seen[-1] if seen else '',observed_receive_order='>'.join(map(str,seen)),sender_and_line=';'.join(f"{e['sender']}:{e['line']}" for e in evs),interpretation='Only global merged line order across multiple unknown receivers; NOT receiver-specific vote order' if basis=='unknown_merged_receivers' else 'Per-receiver observed log order; not wall-clock or network latency'))
q3vfields=list(q3votes[0]);csv_save('q3_vote_receipt_order.csv',q3vfields,q3votes)

# Separate token-focused accounting: no access to internal tokens. Char-equivalent is NOT model usage.
usage=[]
for d in logs:
 usage.append(dict(file=d.name,bytes=d.bytes,characters_including_newlines=d.chars,physical_lines=d.lines,whitespace_separated_words=d.words,regex_lexical_pieces_not_model_tokens=d.regex_token_pieces,estimate_tokens_at_4_chars_per_token=round(d.chars/4),rough_range_low_chars_div_5=round(d.chars/5),rough_range_high_chars_div_3=round(d.chars/3),sha256=d.hash,actual_gpt6_input_tokens='UNAVAILABLE',actual_gpt6_output_tokens='UNAVAILABLE',actual_gpt6_reasoning_tokens='UNAVAILABLE',actual_gpt6_total_tokens='UNAVAILABLE',note='Raw file token-equivalent is not actual context consumption; logs processed via Python file I/O.'))
usage.append(dict(file='TOTAL_4_FILES',bytes=sum(x['bytes'] for x in usage),characters_including_newlines=sum(x['characters_including_newlines'] for x in usage),physical_lines=sum(x['physical_lines'] for x in usage),whitespace_separated_words=sum(x['whitespace_separated_words'] for x in usage),regex_lexical_pieces_not_model_tokens=sum(x['regex_lexical_pieces_not_model_tokens'] for x in usage),estimate_tokens_at_4_chars_per_token=sum(x['estimate_tokens_at_4_chars_per_token'] for x in usage),rough_range_low_chars_div_5=sum(x['rough_range_low_chars_div_5'] for x in usage),rough_range_high_chars_div_3=sum(x['rough_range_high_chars_div_3'] for x in usage),sha256='',actual_gpt6_input_tokens='UNAVAILABLE',actual_gpt6_output_tokens='UNAVAILABLE',actual_gpt6_reasoning_tokens='UNAVAILABLE',actual_gpt6_total_tokens='UNAVAILABLE',note='This is the number of tokens IF all raw file text were passed through a 4-char/token proxy, NOT tokens used in this session.'))
csv_save('token_usage_raw_text_estimates.csv',list(usage[0]),usage)

plt.rcParams.update({'font.size':10,'figure.dpi':140,'axes.spines.top':False,'axes.spines.right':False})
names=[d.name for d in logs]
# plot 1 count grouped bars
fig,ax=plt.subplots(figsize=(12,5));stages=['propose_received','write_sends','accept_sends','decision_lines','client_reply_lines'];xx=list(range(4));width=.16
for j,k in enumerate(stages):ax.bar([i+(j-2)*width for i in xx],[r[k] for r in rows],width,label=k.replace('_',' '))
ax.set_xticks(xx,names);ax.set_ylabel('Number of recorded log events');ax.set_title('Q1. Recorded protocol events and client replies (not unique operations)');ax.legend(fontsize=8,ncol=3);ax.grid(axis='y',alpha=.17);fig.tight_layout();fig.savefig(OUT/'q1_consensus_progress.png');plt.close(fig)
# plot 2: first AND last per CID for WRITE/ACCEPT in one four-panel figure.
fig,axes=plt.subplots(2,2,figsize=(13,9),sharex=True)
for i,phase in enumerate(['WRITE','ACCEPT']):
 for j,rank in enumerate(['first','last']):
  ax=axes[i][j];bottom=[0]*4
  for rep in range(4):
   vals=[rankstat[(name,phase,rank)][rep] for name in names]
   ax.bar(xx,vals,bottom=bottom,label=f'Replica {rep}');bottom=[x+y for x,y in zip(bottom,vals)]
  ax.set_ylabel('Number of CIDs');ax.set_title(f'Q2. {phase}: {rank} observed sender per CID')
  ax.legend(ncol=4,fontsize=7);ax.grid(axis='y',alpha=.15)
  ax.set_xticks(xx,names,rotation=12)
fig.tight_layout();fig.savefig(OUT/'q2_replica_sender_order.png');plt.close(fig)
# plot 3: color map of inferred active regency by CID plus attempted-only regency2 note
import numpy as np
reg=np.zeros((4,1000))
for j,d in enumerate(logs):
 if d.idx['send_sync']:reg[j,1:]=1;reg[j,0]=.5
fig,ax=plt.subplots(figsize=(11,3.7));ax.imshow(reg,aspect='auto',interpolation='nearest',vmin=0,vmax=1,cmap='viridis');ax.set_yticks(xx,names);ax.set_xlabel('Consensus ID');ax.set_title('Q3. CID-regency mapping (inferred; CID 0 recovery shown as 0.5)');fig.tight_layout();fig.savefig(OUT/'q3_views.png');plt.close(fig)
# Supplemental Q3 vote-receipt order: only tagged receiver identities are safe.
fig,axes=plt.subplots(2,1,figsize=(10,7),sharex=True)
for ax,phase in zip(axes,['WRITE','ACCEPT']):
  xreceivers=list(range(4));w=.19
  for rep in range(4):
   vals=[sum(1 for r in q3votes if r['log']=='main(7).log' and r['phase']==phase and r['receiver_replica']==rec and r['last_observed_sender']==rep) for rec in xreceivers]
   ax.bar([j+(rep-1.5)*w for j in xreceivers],vals,w,label=f'Sender {rep}')
  ax.set_ylabel('CIDs where sender last');ax.set_title(f'Q3. Last observed {phase} sender at explicitly tagged receiver');ax.legend(ncol=4,fontsize=8);ax.grid(axis='y',alpha=.15)
axes[-1].set_xticks(list(range(4)),[f'Receiver {r}' for r in range(4)]);fig.tight_layout();fig.savefig(OUT/'q3_vote_receipt_order_tagged_log.png');plt.close(fig)
# plot 4: event category by physical line, no clock time; color and legend stable.
fig,ax=plt.subplots(figsize=(11,5));lckinds=['timeout','forward','attempt','send_stop','retransmit_stop','recv_lc','send_stopdata','send_sync']
shown=set()
for j,d in enumerate(logs):
 for k,kind in enumerate(lckinds):
  ev=d.idx[kind]
  if ev:
   ax.scatter([e['line'] for e in ev],[j+(k-3.5)*.075]*len(ev),s=10,alpha=.7,color=plt.cm.tab10(k),label=kind if kind not in shown else None)
   shown.add(kind)
ax.set_xscale('symlog',linthresh=500);ax.set_yticks(xx,names);ax.set_xlabel('Physical line number (symlog; NOT elapsed time)');ax.set_title('Q4. Timeout and leader-change activity by file line');ax.legend(ncol=4,fontsize=8);fig.tight_layout();fig.savefig(OUT/'q4_timeouts_leader_change.png');plt.close(fig)
# plot 5: detected stage presence per CID (does not infer missing events caused failure)
fig,ax=plt.subplots(figsize=(11,5));stagekeys=['propose_first_line','write_send_first_line','write_quorum_first_line','accept_send_first_line','accept_quorum_first_line','local_decision_first_line','application_execution_first_line','client_reply_first_line']
rec=defaultdict(dict)
for d in logs:
 for key in stagekeys:
  rec[d.name][key]=sum(bool(x[key]) for x in q5 if x['log']==d.name and x['epoch']==0 and (x['cid']!=0 or not d.idx['send_sync']))
# Use union of epochs for recovered CID 0, to show final completed attempt
for d in logs:
 if d.idx['send_sync']:
  for key in stagekeys:
   rec[d.name][key]=sum(any(bool(x[key]) for x in q5 if x['log']==d.name and x['cid']==cid) for cid in range(1000))
left=list(range(4));width=.1
for i,k in enumerate(stagekeys):ax.bar([v+(i-3.5)*width for v in left],[rec[name][k] for name in names],width,label=k.replace('_first_line','').replace('_',' '))
ax.set_ylim(0,1200);ax.set_xticks(left,names);ax.set_ylabel('CIDs with evidence recorded');ax.set_title('Q5. Recorded consensus-chain stage coverage (missing records ≠ failures)');ax.legend(ncol=4,fontsize=7);fig.tight_layout();fig.savefig(OUT/'q5_consensus_chain.png');plt.close(fig)
# plot 6 stop message origin summary separate from line send count
fig,ax=plt.subplots(figsize=(10,4));xpos=list(range(4));w=.33
s1=[next((x['received_stop_message_count'] for x in q6 if x['log']==name and x['regency']==1),0) for name in names]
s2=[next((x['received_stop_message_count'] for x in q6 if x['log']==name and x['regency']==2),0) for name in names]
ax.bar([x-w/2 for x in xpos],s1,w,label='Regency 1');ax.bar([x+w/2 for x in xpos],s2,w,label='Regency 2 (attempted only)');ax.set_xticks(xpos,names);ax.set_ylabel('Received STOP records (not distinct senders)');ax.set_title('Q6. STOP receive records by regency');ax.legend();ax.grid(axis='y',alpha=.15);fig.tight_layout();fig.savefig(OUT/'q6_regencies.png');plt.close(fig)

# Additional proxy visualization. This is deliberately not labeled GPT-6 token usage.
fig,ax=plt.subplots(figsize=(9,4.5))
ax.bar([d.name for d in logs],[d.chars/4/1e6 for d in logs],label='characters / 4',color='tab:blue')
ax.set_ylabel('Million token-equivalents (rough character proxy)')
ax.set_title('Raw log text sizes; NOT actual GPT-6 model token usage')
ax.grid(axis='y',alpha=.15);fig.tight_layout();fig.savefig(OUT/'token_usage_raw_text_proxy.png');plt.close(fig)
seconds=time.perf_counter()-started
with (OUT/'machine_summary.json').open('w') as f:json.dump(dict(runtime_seconds_python_file_processing_and_plot_generation=seconds,files=[{k:v for k,v in r.items() if k in ('log','physical_lines','sha256','propose_received','write_sends','recovery_write_sends_unknown_sender','accept_sends','decision_lines','client_reply_lines','timeouts','stop_sends','stop_retransmissions','sync_sends','spliced_physical_lines')} for r in rows],q6=q6,issue_count=len(issues),total_text_token_equivalent_4chars=usage[-1]['estimate_tokens_at_4_chars_per_token'],actual_model_tokens_available=False),f,indent=2)
print('Processed',len(logs),'files in',round(seconds,3),'s; issue rows:',len(issues),'\nSummary')
for r in rows:print(r['log'],{x:r[x] for x in ('physical_lines','propose_received','write_sends','accept_sends','decision_lines','client_reply_lines','timeouts','stop_sends','stop_retransmissions','sync_sends','spliced_physical_lines')})
print('Token-equivalent at chars/4:',usage[-1]['estimate_tokens_at_4_chars_per_token'])
print('Q6')
for r in q6:print(r['log'],'reg',r['regency'],r['installation_state'],'STOP recv',r['received_stop_message_count'],'senders',r['distinct_stop_senders'],'no advance',r['no_advance_pair_count'],'last event',r['last_event_line'])
