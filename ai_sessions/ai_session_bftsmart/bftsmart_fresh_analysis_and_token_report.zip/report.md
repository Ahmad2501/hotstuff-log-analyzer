# Fresh BFT-SMaRt log analysis and token accounting

## Short summary

Four **distinct** uploaded log files were analyzed from scratch. All contain consensus IDs (CIDs) 0–999 and evidence of application execution reaching counter 1000. Two files (`main(7).log` and `main_3(3).log`) contain **no observed regency-change events**. In `main_2(3).log` and `main_4(3).log`, an incomplete initial CID-0 attempt at epoch timestamp 0 is followed by timeouts, STOP/STOPDATA/SYNC, installed regency 1, recovery of the **same CID 0 at epoch timestamp 1**, and subsequent decisions under proposer/leader replica 1. `main_4(3).log` also attempts regency 2, **but no installation of regency 2 is logged**: only replica 1 is observed sending STOP-2, and repeated retransmissions continue after client reply 1000.

**Token question:** The four *raw files* contain **27,236,178 characters** (513,991 physical lines), approximately **6,809,045 token-equivalents using a crude characters/4 proxy**. This is **NOT the number of tokens consumed by GPT-6**, and is not an OpenAI tokenizer result. The complete raw logs were read by a local Python script rather than necessarily passed in full through the model context. Actual GPT-6 input, output, hidden reasoning, tool-context, and total token usage cannot be retrieved from this chat. Python log-processing/plotting took 14.89 seconds in the measured run; that is **not** the model's end-to-end analysis time. See `token_usage_raw_text_estimates.csv` and `token_usage_raw_text_proxy.png`.

## Measurement conventions and caveats

- The logs **do not have wall-clock timestamps**. Every time-related plot uses physical source-line index; elapsed time, network delay, and late arrival in milliseconds cannot be measured.
- `Epoch Timestamp`/`Timestamp` is the **protocol attempt timestamp for a CID**, not wall-clock time. Normal CIDs often restart at epoch 0 under a new regency after CID 0 recovers at epoch 1.
- Membership view `ID:0` (e.g., `main(7).log` line 21; `main_2(3).log` line 21) is **not** a regency or epoch. Operational “view” here is the `(regency, leader, epoch)` tuple; the leader is inferred as `regency mod N` (`N=4`, `F=1`, e.g. `main_2(3).log` lines 12–13).
- Only `main(7).log` has `[replicaN]` labels identifying the **logging receiver**. Other files use explicit `I am:N` and `from replica N` where available. `Sending STOP` and `Sending WRITE message for CID 0, timestamp 1` have no sender, and **no sender is invented**.
- “First/last” means order of **identified logged sender events** in the combined file, not network latency. When an expected sender record is missing, `last` is only **last observed**. For untagged logs, interleaved WRITE/ACCEPT receipt messages cannot safely be assigned to a particular receiver.
- Log lines can contain mixed client/protocol fragments. We retain suspicious lines and separately mark unsafe client-reply values. A missing or corrupted event record **is not evidence that the protocol failed**.
- Quorum phases use the log's own “I have 3 WRITE's” and “I have 3 ACCEPTs” assertions. We did not reconstruct message-value hashes independently for every CID.

## Q1. Measurable consensus differences — one table per log

### `main(7).log`

| Metric | Result | Representative source lines |
|:--|--:|:--|
| CID range | 0–999 | 84, 127936–127963 |
| PROPOSE receptions | 3,979 | 84, 90–96 |
| Regular WRITE sends | 3,996 | 87, 101–107 |
| ACCEPT sends | 3,991 | 114, 127, 133, 145 |
| Local decisions | 3,995 | 168, 127936, 127944, 127963 |
| Client reply markers / safely parsed | 857 / **19** | one ambiguous splice at 127489; consult diagnostics |
| Maximum observed application counter | 1000 | 127943, 127945, 127948, 127965 |
| Timeouts / regency changes | 0 / **none observed** | entire file scanned; first CID-0 PROPOSE at 84 |

The lower counts are **log-capture limitations**, not evidence of a broken replica. At least 13 CIDs lack one identified WRITE or ACCEPT sender record (`q2_per_cid_send_order.csv`), and many reply fragments cannot be safely interpreted. At line 127489, for example, `returned value: 9972, WRITE's...` is visibly a splice, not a valid client reply value 9,972. Unlike the other files, this is the only source with explicit receiver tags for received votes.

### `main_2(3).log`

| Metric | Result | Representative source lines |
|:--|--:|:--|
| CID range | 0–999 | 76, 128225 |
| PROPOSE receptions | 4,000 | 76–82; 332 |
| Regular WRITE sends | 4,000 | 84, 100, 124 |
| Unattributed recovery WRITEs | 4 | 221–258 |
| ACCEPT sends | 4,002 | 105, 115, 246 |
| Local decisions | 4,000 | 301–322; 128225 |
| Client reply markers / safely parsed | 1,000 / 971 | 330; 128202 |
| Application counter max | 1000 | 128201, 128226, 128228 |
| Timeout lines | 6 | 163, 165, 167, 169, 171, 174 |
| Regency | 0 to **installed 1** | STOP 173–195, SYNC 213–220 |

CID 0's initial epoch 0 reached a WRITE quorum but no recorded three-ACCEPT quorum (lines 104–148); only after installed regency 1 did CID 0 reach epoch 1 ACCEPT quorum/decision (lines 245–322). Replica 1 subsequently proposed CID 1 (line 332), with no recorded later CID proposal from former leader replica 0.

### `main_3(3).log`

| Metric | Result | Representative source lines |
|:--|--:|:--|
| CID range | 0–999 | 84, 128118 |
| PROPOSE / regular WRITE sends / ACCEPT sends | 4,000 / 4,000 / 4,000 | 84, 96, 115 |
| Local decisions | 4,000 | 180, 185, 195, 204; 128100–128118 |
| Client reply markers / safely parsed | 1,000 / 959 | 211, 128126 |
| Application counter max | 1000 | 128120–128125 |
| Timeouts / regency changes | 0 / **none observed** | whole-file scan |

This is a clean **protocol-event-count baseline**: one thousand CIDs each have four recorded PROPOSE, WRITE and ACCEPT sends and decisions. Some client output is still spliced (see `unparsed_spliced_lines.csv`), hence the distinction between markers and safely isolated reply lines.

### `main_4(3).log`

| Metric | Result | Representative source lines |
|:--|--:|:--|
| CID range | 0–999 | 75, 128410 |
| PROPOSE receptions / regular WRITE sends | 4,000 / 4,000 | 75, 84; 341 |
| Unattributed recovery WRITEs | 4 | 230–265 |
| ACCEPT sends / local decisions | 4,002 / 4,000 | 102, 116, 253, 257, 263, 278; 308 |
| Client reply markers / safely parsed | 1,000 / 957 | 339; 128414 |
| Application counter max | 1000 | 128412–128413 |
| Timeout lines | 7 | 163, 165, 167, 169, 171, 174, 195 |
| Regencies | installed 0 and 1; **2 attempted only** | 201–232, 129634–129668 |
| Re-transmitted STOP-2 lines | **188** | 7306, 129662 |

The later regency-2 exchange is unusually persistent: **567** received STOP-2 records are all explicitly **from replica 1** (first line 210, last line 129667). `Last regency: 1, next regency: 1` appears **573** times (e.g. 200, 211, 129668), consistent with local no-advance states. The last client response occurs at line 128414, but STOP-2 retransmission continues to line 129662, so the event persists after the recorded client workload finishes.

## Q2. Which replica sends WRITE/ACCEPT first and last?

For each of the 1,000 CIDs per file, `q2_per_cid_send_order.csv` provides first/last replica, exact send line, full recorded order, completeness flag, and recovery-attempt rows. These summary counts are for **normal path** first/last observations, including incomplete rows and treating each sender's first unique appearance as its position. A recovered CID 0 is further separated in rows `WRITE_RECOVERY` (unknown senders) and `ACCEPT_RECOVERY` (explicit senders).

**First observed WRITE sender counts (replicas 0,1,2,3):**

| File | R0 | R1 | R2 | R3 | Most frequent first |
|:--|--:|--:|--:|--:|:--|
| `main(7).log` | **711** | 92 | 111 | 86 | R0, regency-0 leader |
| `main_2(3).log` | 132 | **624** | 126 | 118 | R1, regency-1 leader |
| `main_3(3).log` | **618** | 114 | 128 | 140 | R0, regency-0 leader |
| `main_4(3).log` | 115 | **624** | 132 | 129 | R1, regency-1 leader |

For instance, CID 0 of tagged `main(7).log` shows WRITE sending R0/R3/R1/R2 at lines **87/101/104/107** and ACCEPT sending R0/R2/R1/R3 at lines **114/127/133/145**. In `main_2(3).log`, after recovery the CID 1 proposal is explicitly from R1 (line **332**) and R1 sends WRITE at **336**. `main_4(3).log` has equivalent R1 activity at **341** and **344**. (The order of the CID 0 WRITE sends in `main(7).log` is 0 → 3 → 1 → 2, so do not infer a chronological order of the replica IDs from their numeric labels.)

**Last observed WRITE sender counts (replicas 0,1,2,3):**

| File | R0 | R1 | R2 | R3 |
|:--|--:|--:|--:|--:|
| `main(7).log` | 61 | 314 | 316 | 309 |
| `main_2(3).log` | 313 | 50 | 335 | 302 |
| `main_3(3).log` | 73 | 304 | 312 | 311 |
| `main_4(3).log` | 315 | 59 | 322 | 304 |

For **ACCEPT** sends, first and last positions are far more balanced. For example, `main_3(3).log` has R0/R1/R2/R3 first ACCEPT counts **203/279/263/255** and last ACCEPT counts **247/228/263/262**. The role of leader predicts much of the first-WRITE pattern; it does not establish a slow/faulty replica. In `main(7).log`, four CIDs have only 3 identifiable WRITE senders and nine have only 3 identifiable ACCEPT senders, so the last sender for these CIDs is *last recorded*, not guaranteed last actual. The other three files have 4 regular WRITE and 4 regular ACCEPT senders per CID **except** the epoch-0 CID 0 ACCEPT phase split from epoch 1 in the recovery logs.

The dedicated chart `q2_replica_sender_order.png` shows four panels: WRITE first, WRITE last, ACCEPT first and ACCEPT last, across all four logs. The complete line-by-line evidence is in the CSV.

## Q3. Operational views and vote receipt order

The membership view is **ID:0 throughout**, not to be confused with protocol regency (e.g. `main_2(3).log` line 21). Operational grouping is:

| File | CID 0 | CIDs 1–999 | Regency 2 |
|:--|:--|:--|:--|
| `main(7).log` | (reg 0, leader 0, epoch 0) | (0,0,0) | none |
| `main_2(3).log` | (0,0,0) **then** (1,1,1) | (1,1,0) | none |
| `main_3(3).log` | (0,0,0) | (0,0,0) | none |
| `main_4(3).log` | (0,0,0) **then** (1,1,1) | (1,1,0) | **attempted, not installed** |

Epoch-0 CID 0 WRITE quorum / absent ACCEPT quorum is visible in `main_2(3).log` at **104–148** and in `main_4(3).log` at **101–149**. Epoch-1 quorums occur at **245–305** and **252–318** respectively. Note that the *regency* remains 1 for later CIDs while their **epoch timestamp returns to 0** on the normal path; do not mislabel them epoch 1.

**Receiving votes:** `main(7).log` permits per-receiver analysis due to explicit `[replicaN]` prefixes. In its WRITE receipts, the first external WRITE at receiving replicas 1,2,3 is most often from **replica 0** (638, 686 and 648 of 1000 CIDs, respectively); at receiver 0 the first external WRITE is relatively distributed among replicas 1,2,3 (319/318/363). ACCEPT first/last is more variable (see `q3_vote_receipt_order.csv` and `q3_vote_receipt_order_tagged_log.png`). These are logged receipt orders, not necessarily physical network-arrival speeds.

In the three **untagged** logs, `WRITE received from:N` and `ACCEPT from N` identify a **sender**, but not the receiving replica. The per-CID merged order is exported for transparency and explicitly marked `unknown_merged_receivers`. We **do not** claim to know an individual replica's first/last received vote from that merged stream.

## Q4. Timeouts and leader changes

| File | Timeout reports | STOP sent | STOP-2 retransmitted | Installed change |
|:--|--:|--:|--:|:--|
| `main(7).log` | 0 | 0 | 0 | None observed |
| `main_2(3).log` | 6 | 4 | 0 | 0 → 1 |
| `main_3(3).log` | 0 | 0 | 0 | None observed |
| `main_4(3).log` | 7 | 5 | **188** | 0 → 1; 2 attempted |

For `main_2(3).log`, the recovery branch is **timeout 163 → forward 164 → attempted change 172 → STOP 173 → STOPDATA 197 → SYNC 213 → epoch-1 WRITE 221**. In `main_4(3).log`, corresponding evidence is **163, 164, 172, 173, 197, 222, 230**, while STOP-2 appears unexpectedly at **201** and later continues through **129667**. The scatter plot x axis is line number, **not** seconds.

There are no literal `ERROR`, `WARN` or Java `Exception` markers among the searched patterns. However, `Out of context msg` occurs thousands of times (`q1_consensus_progress.csv`), and `I did not install any proof of last decided consensus -1` appears during recovery (`main_2(3).log` line 214; `main_4(3).log` line 223). These should be classified as **unusual or diagnostic messages, not automatic proof of consensus failure**.

## Q5. Normal chain vs recovery ordering

**Normal CID 0 example (`main_3(3).log`):**

`PROPOSE` **84** → `WRITE` **96** → 3-WRITE quorum **114** → `ACCEPT send` **115** → 3-ACCEPT quorum **179** → local decision **180** → application increment **206** → client reply **211**.

**Recovered CID 0 (`main_2(3).log`):**

- Epoch 0: PROPOSE **76** → WRITE **84** → WRITE quorum **104** → ACCEPT send **105**, but no recorded 3-ACCEPT quorum or decision within that attempt (two ACCEPTs at **147–148**).
- Recovery: timeout **163** → STOP **173** → STOPDATA **197** → SYNC **213** → same CID 0, timestamp 1 WRITE **221** → epoch-1 WRITE quorum **245** → ACCEPT send **246** → ACCEPT quorum **300** → decision **301** → execution **324** → client reply **330**.

**Recovered CID 0 (`main_4(3).log`):**

Epoch 0: PROPOSE **75**, WRITE **84**, WRITE quorum **101**, ACCEPT send **102**, no epoch-0 ACCEPT quorum. Timeout **163** → STOP **173** → STOPDATA **197** → SYNC **222** → same CID 0 at epoch 1 WRITE **230** → WRITE quorum **252** → ACCEPT send **253** → ACCEPT quorum **306** → decision **308** → execution **313** → reply **339**.

A recovery branch **does not replace** the normal consensus phases; it creates a new attempt of the same CID at a higher epoch. `q5_consensus_chain_by_cid_epoch.csv` preserves separate CID 0 rows at epochs 0 and 1. The local decision and client response are evidence of successful recovery, *not* that the original epoch-0 consensus committed.

In the tagged `main(7).log`, the event counts and malformed client output show that phase-count gaps cannot be treated as protocol violations. Many first-occurrence global line indices across **different replicas** are non-monotonic; this reflects merged-log interleaving and does not establish a violation of each replica's local protocol state.

## Q6. Regency analysis: evidence first, hypotheses second

| Log | Regency | Status | Leader | Distinct received STOP senders | STOP receipt records | Evidence |
|:--|--:|:--|--:|:--|--:|:--|
| `main(7).log` | 0 | baseline; no change | 0 | none | 0 | Entire log scanned; CID 0 starts line 84 |
| `main_2(3).log` | 0 | initial, replaced | 0 | — | — | Lines 76–175 |
| `main_2(3).log` | 1 | **installed** | 1 | 0,1,2,3 | 12 | STOP 177–210, SYNC 213, proposal 332 |
| `main_3(3).log` | 0 | baseline; no change | 0 | none | 0 | Entire log scanned; line 84 |
| `main_4(3).log` | 0 | initial, replaced | 0 | — | — | Lines 75–176 |
| `main_4(3).log` | 1 | **installed** | 1 | 0,1,2,3 | 12 | STOP 177–218, SYNC 222, proposal 341 |
| `main_4(3).log` | 2 | **attempted, not installed** | candidate leader 2 | **1 only** | **567** | STOP send 201; receive 210; last 129667 |

### Senders, F+1, and who joined

`F=1` in the configuration (`main_2(3).log` line 13), so a threshold of `F+1=2` distinct senders is required for the specified join criterion. The first observed **received** STOP origin IDs in regency 1 are replicas **0, 3, 1, 2** in that order: `main_2(3).log` lines **177, 183, 188, 195**; `main_4(3).log` lines **177, 183, 191, 202**. Thus at least two distinct STOP origins appear in the **combined** log, but there is no tagged receiving replica to prove exactly when each local receiver reached F+1. **The initiator and followers cannot be established definitively**: `Sending STOP` has no sender ID, even if the order of received messages is suggestive.

The replaced leader was replica 0 in regency 0 and the new leader is replica 1 in regency 1. After SYNC, CID 1 PROPOSE is explicitly `from:1` in `main_2(3).log` line **332** and `main_4(3).log` line **341**. No later CID proposal from replica 0 was identified in either file; this is evidence it did not **continue proposing as leader**, not that it became inactive (it still participates in consensus).

### What happened to attempted regency 2 in `main_4(3).log`?

**Evidence:** STOP-2 is sent at line **201**; received STOP-2 messages are all `from replica 1` (first **210**, last **129667**), with **567** such received messages and **188** STOP-2 retransmission lines (**7306–129662**). Local state prints `Last regency: 1, next regency: 1` **573** times (first at **200**, last **129668**). Four early lines (**203, 205, 213, 232**) instead show `Last regency: 1, next regency: 2` — a **candidate next regency**, not proof of installation. No `Sending SYNC message for regency 2`, no proposal from leader 2 and no installed regency-2 evidence was found. Only one distinct STOP-2 sender is present, below the global F+1 threshold. CID 999 decisions occur at **128385–128410** and client reply 1000 at **128414**, before the final STOP-2 retransmissions.

**Hypothesis (not proven cause):** regency 2 may have lacked sufficient distinct STOP senders to progress, and its retransmission machinery kept retrying even after the workload had completed. The combined-log evidence supports **non-installation**, not a causal explanation for *why* its messages continued. Importantly, later CIDs did still decide while this regency-2 activity existed; no later-CID decision interruption is established by these logs.

### Was there a systematic slow or misbehaving replica?

No replica is proven faulty or late by these logs. Leader-associated WRITE-first ordering is clear, but accepting-phase order is more balanced. The datasets contain no wall-clock timestamps. The untagged combined logs do not identify receivers, so they cannot support conclusions about per-replica reception latency. A lost/spliced printed event is not proof of nonparticipation.

## Reproducibility and file inventory

| File | What it contains |
|:--|:--|
| `analyze.py` | Full source parser, event extraction, six question analyses, all plots and raw-text token proxy |
| `verify.py` | Independent source-text and line-reference verification of exported CSVs |
| `q1_consensus_progress.csv` + `.png` | One row/log: event counts, distinct CIDs, line evidence, incomplete output |
| `q2_per_cid_send_order.csv` + `q2_replica_sender_order.png` | CID-by-CID first/last WRITE/ACCEPT senders, source lines, recovery attempts |
| `q3_regency_leader_epoch_views.csv` + `q3_views.png` | CID/regency/leader/epoch tuples and quorum references |
| `q3_vote_receipt_order.csv` + `q3_vote_receipt_order_tagged_log.png` | Receiver-specific voting evidence for tagged log; merged-only order for untagged logs |
| `q4_timeouts_leader_change_timeline.csv` + `.png` | Event-by-event recovery / leader-change chronological lines |
| `q5_consensus_chain_by_cid_epoch.csv` + `q5_consensus_chain.png` | Consensus phases for each CID/epoch with evidence and missing-stage flags |
| `q6_regency_analysis.csv` + `q6_regencies.png` | Installed vs attempted regencies, STOP senders, F+1 caveats, stagnation |
| `unparsed_spliced_lines.csv` | All flagged ambiguous/mixed physical lines (including unsafe reply values) |
| `token_usage_raw_text_estimates.csv` + `token_usage_raw_text_proxy.png` | Raw source sizes; **not billed/inferred model token consumption** |
| `machine_summary.json` | Machine-produced summary and local script runtime |
| `verification_result.json` | **223,313** successful independent checks, 0 failures |

### Suggested reproducible commands

```bash
python analyze.py ./results 'main(7).log' 'main_2(3).log' 'main_3(3).log' 'main_4(3).log'
python verify.py ./results .
```

For convenience, the scripts default to the `/mnt/data/` file names from this session when no explicit source paths are passed. CSV and plots are regenerated from source; no source logs are modified.

## Token accounting: what can and cannot be claimed in a thesis

| Item | Result | Classification |
|:--|--:|:--|
| Raw bytes/ASCII characters of 4 logs | **27,236,178** | Exact source measurement |
| Physical source lines | **513,991** | Exact source measurement |
| Whitespace-separated words | **4,662,109** | Exact text metric; *not* tokens |
| Characters / 4 | **6,809,045** | Very rough **token-equivalent proxy** |
| Characters / 5 to characters / 3 | **5,447,236–9,078,726** | Sensitivity range for proxy, **not a confidence interval** |
| OpenAI/GPT-6 raw log tokens | **Unknown** | No GPT-6 tokenizer provided in environment |
| Actual GPT-6 input tokens used | **Unknown** | No model usage API/telemetry available in this chat |
| Actual GPT-6 output/reasoning tokens used | **Unknown** | Same limitation |
| Actual GPT-6 **total tokens** used | **Unknown** | Cannot infer from source size |
| Local Python scan + plot generation | **14.89 seconds** | Measured local execution time; **not total AI analysis duration** |
| Actual model dollar cost | **Unknown** | No billing-meter information |

**Critical:** If the logs were processed through file I/O with deterministic Python code, their millions of raw-text token-equivalents are **not necessarily the model's input tokens**. Do **not** write that GPT-6 used 6.8 million tokens. A defensible thesis statement is: *“The four log datasets contained 27.24 million characters, corresponding to approximately 6.81 million token-equivalents under a simple four-characters-per-token proxy. This measures dataset size, not model token consumption; actual GPT-6 token usage was not available.”*
