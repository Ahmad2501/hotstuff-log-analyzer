#!/usr/bin/env python3
"""Verify count fields and line references from the fresh analysis against raw logs."""
from pathlib import Path
from collections import Counter
import csv, re, json, hashlib, sys
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/bftsmart_fresh')
INPUT_DIR=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/mnt/data')
INPUTS={name:INPUT_DIR/name for name in ['main(7).log','main_2(3).log','main_3(3).log','main_4(3).log']}
source={k:['']+p.read_text(encoding='utf-8',errors='replace').splitlines() for k,p in INPUTS.items()}
checks=Counter();bad=[]
def check(ok,detail):
 checks['checked']+=1
 if not ok:
  checks['failed']+=1
  if len(bad)<35:bad.append(detail)
def rows(name):return list(csv.DictReader((ROOT/name).open(encoding='utf-8',newline='')))
def present(name,line,needle):
 try:return needle in source[name][int(line)]
 except (ValueError,IndexError):return False
for r in rows('q1_consensus_progress.csv'):
 n=r['log'];s=source[n]
 check(len(s)-1==int(r['physical_lines']),(n,'length mismatch'))
 check(hashlib.sha256(INPUTS[n].read_bytes()).hexdigest()==r['sha256'],(n,'hash mismatch'))
 for col,pat in [('propose_received',r'PROPOSE received from:\d+, for consensus cId:\d+, I am:\d+'),('write_sends',r'Sending WRITE for cId:\d+, I am:\d+'),('accept_sends',r'Sending ACCEPT message, cId:\d+, I am:\d+'),('decision_lines',r'Deciding consensus \d+'),('client_reply_candidate_substrings',r'returned value:\s*\d+'),('stop_retransmissions',r'Re-transmitting STOP message to install regency \d+')]:
  val=sum(bool(re.search(pat,t)) for t in s[1:]);check(val==int(r[col]),(n,col,val,r[col]))
for r in rows('q1_consensus_progress.csv'):
 n=r['log'];valid=sum(bool(re.search(r'returned value:\s*([0-9]+)\s*$',t)) and int(re.search(r'returned value:\s*([0-9]+)\s*$',t).group(1))<=1000 for t in source[n][1:]);check(valid==int(r['client_reply_lines']),(n,'safe replies',valid,r['client_reply_lines']))
for r in rows('q2_per_cid_send_order.csv'):
 n=r['log'];cid=r['cid'];ph=r['phase']
 if ph in ['WRITE','ACCEPT','ACCEPT_RECOVERY']:
  for pair in filter(None,r['send_line_numbers'].split(';')):
   who,ln=pair.split(':');needle=('Sending WRITE for cId:' if ph=='WRITE' else 'Sending ACCEPT message, cId:')+cid+', I am:'+who
   check(present(n,ln,needle),(n,'q2',cid,ph,who,ln))
  if r['send_line_numbers']:
   pairs=[x.split(':') for x in r['send_line_numbers'].split(';')]
   check(r['first_sender']==pairs[0][0] and int(r['first_sender_line'])==int(pairs[0][1]),(n,'first',cid))
   check(r['last_sender']==pairs[-1][0] and int(r['last_sender_line'])==int(next(ln for rep,ln in pairs if rep==r['last_sender'])),(n,'last',cid))
 else:
  for pair in filter(None,r['send_line_numbers'].split(';')):
   _,ln=pair.split(':');check(present(n,ln,'Sending WRITE message for CID '+cid),(n,'recovery',cid,ln))
for r in rows('q3_regency_leader_epoch_views.csv'):
 n=r['log'];cid=r['cid'];epoch=r['epoch_timestamp'];check(int(r['leader_inferred_from_regency_mod_N'])==int(r['regency'])%4,(n,'reg-leader',cid))
 for col,needle in [('propose_lines','PROPOSE received from:'),('write_quorum_lines',"WRITE's for cId:"+cid),('accept_quorum_lines','ACCEPTs for cId:'+cid),('recovery_write_lines','Sending WRITE message for CID '+cid)]:
  for ln in filter(None,r[col].split(';')):
   check(present(n,ln,needle),(n,'q3',cid,epoch,col,ln))
for r in rows('q3_vote_receipt_order.csv'):
 n=r['log'];cid=r['cid'];needle=('WRITE received from:' if r['phase']=='WRITE' else 'ACCEPT from ')
 for pair in filter(None,r['sender_and_line'].split(';')):
  who,ln=pair.split(':');check(present(n,ln,needle),(n,'q3votes',cid,r['phase'],ln))
for r in rows('q4_timeouts_leader_change_timeline.csv'):
 n=r['log'];ln=r['line']
 pattern={'timeout':'The following requests timed out:', 'forward':'Forwarding requests','attempt':'Attempting to start leader change','send_stop':'Sending STOP message','retransmit_stop':'Re-transmitting STOP','recv_lc':'Received leader change message','send_stopdata':'Sending STOPDATA','send_sync':'Sending SYNC','reg_pair':'Last regency:', 'recover_write':'Sending WRITE message'}[r['kind']]
 check(present(n,ln,pattern),(n,'q4',r['kind'],ln))
for r in rows('q5_consensus_chain_by_cid_epoch.csv'):
 n=r['log'];cid=r['cid'];epoch=r['epoch']
 for col,need in [('propose_first_line','PROPOSE received'),('write_send_first_line','Sending WRITE'),('write_quorum_first_line',"WRITE's for cId:"+cid),('accept_send_first_line','Sending ACCEPT'),('accept_quorum_first_line','ACCEPTs for cId:'+cid),('local_decision_first_line','Deciding consensus '+cid),('application_execution_first_line','Counter was incremented'),('client_reply_first_line','returned value:')]:
  if r[col]:check(present(n,r[col],need),(n,'q5',cid,epoch,col,r[col]))
for r in rows('q6_regency_analysis.csv'):
 n=r['log'];reg=r['regency']
 for ln in filter(None,r['stop_send_lines'].split(';')):check(present(n,ln,'Sending STOP message to install regency '+reg),(n,'q6_stop',reg,ln))
 if r['first_retransmission_line']:check(present(n,r['first_retransmission_line'],'Re-transmitting STOP message to install regency '+reg),(n,'q6_retrans',reg))
 for pair in filter(None,r['stop_receive_first_lines'].split(';')):
  who,ln=pair.split(':');check(present(n,ln,'STOP for regency '+reg+' from replica '+who),(n,'q6_stop_recv',reg,ln))
 if reg=='2' and n=='main_4(3).log':
  check(int(r['sync_sent_count'])==0,(n,'reg2 no sync'))
  check(r['distinct_stop_senders']=='1',(n,'reg2 sender1 only'))
issues=rows('unparsed_spliced_lines.csv')
for r in issues:check(r['raw_text']==source[r['log']][int(r['line'])][:1300],(r['log'],'issue',r['line']))
out=dict(checks=dict(checks),failures=bad,files=sorted(INPUTS.keys()),interpretation='Source log entries and CSV line references verified. This does NOT prove AI model token usage.')
(ROOT/'verification_result.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2)[:8000]);sys.exit(1 if bad else 0)
