# Fresh, source-evidenced BFT-SMaRt analysis

Start with `report.md`. The package contains analysis for **all six questions**, exact line references, scripts, six core CSVs, six core PNG charts, supplementary vote-order data, and token-usage proxy tables. The uploaded source logs are **not** duplicated in this ZIP.

**Token interpretation:** `token_usage_raw_text_estimates.csv` records raw file sizes and a `characters / 4` approximation. The actual number of GPT-6 model tokens used by this conversation is **not exposed** and cannot be derived from file size or local script runtime.

Run (with Python 3 and matplotlib available):

```bash
python analyze.py ./results 'main(7).log' 'main_2(3).log' 'main_3(3).log' 'main_4(3).log'
python verify.py ./results .
```

The verification result from this run is in `verification_result.json` (223,313 passing checks). All CSVs have named columns. Physical source line numbers are 1-based. The script never attributes a receiver in untagged logs without an explicit sender/receiver tag, and no elapsed times are calculated from protocol epoch timestamps.
