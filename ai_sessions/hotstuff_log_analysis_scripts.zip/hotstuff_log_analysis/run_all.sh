#!/usr/bin/env bash
# run_all.sh - rebuild every result file from the raw logs and run the four comparisons.
#   usage:  ./run_all.sh LOGDIR [OUTDIR]
#     LOGDIR  folder with main.log, main_2.log, main_3.log, main_4.log (read only)
#     OUTDIR  where the result files and the parse cache go (default: ./out next to this script)
#   Step 1 runs the Python analysis (Parts 1-4), step 2 re-computes the same numbers with grep / awk / sed / sort / comm,
#   step 3 compares the two value by value. The run stops with an error if any comparison reports a mismatch.
#   Needs: bash, python3 with scipy, GNU grep, awk (mawk or gawk), sed, sort, comm, cut, wc, mktemp.
set -eu
if [ $# -lt 1 ]; then echo "usage: $0 LOGDIR [OUTDIR]" >&2; exit 2; fi
HERE=$(cd "$(dirname "$0")" && pwd)
LOGDIR=$(cd "$1" && pwd)
OUT=${2:-$HERE/out}
mkdir -p "$OUT"
OUT=$(cd "$OUT" && pwd)
export HS_LOGDIR="$LOGDIR" HS_OUT="$OUT"
S="$HERE/scripts"
for r in main main_2 main_3 main_4; do
  [ -f "$LOGDIR/$r.log" ] || { echo "missing $LOGDIR/$r.log" >&2; exit 2; }
done

echo "== 1/3 Python analysis (the logs are parsed once and cached in $OUT/parsed.pkl)"
python3 "$S/part1_counts.py"   > "$OUT/part1.md"
python3 "$S/part2_votes.py"    > "$OUT/part2.md"
python3 "$S/part3_views.py"    > "$OUT/part3.md"
python3 "$S/part4_ordering.py" > "$OUT/part4.md"
python3 "$S/part4_examples.py" > /dev/null

echo "== 2/3 independent re-computation with grep / awk / sed / sort / comm"
bash "$S/verify_counts.sh" "$LOGDIR" "$OUT/verify_counts.tsv"
bash "$S/verify_votes.sh"  "$LOGDIR" "$OUT/verify_votes.tsv"
bash "$S/verify_views.sh"  "$LOGDIR" "$OUT/views_work" > "$OUT/verify_views.txt"
bash "$S/verify_order.sh"  "$LOGDIR" "$OUT/verify_order.tsv"

echo "== 3/3 comparison (shell result against Python result)"
{
  python3 "$S/compare_counts.py"
  python3 "$S/compare_votes.py"
  python3 "$S/compare_views.py"
  python3 "$S/compare_order.py"
} | tee "$OUT/comparison.txt"
if grep -Eq '[1-9][0-9]* mismatches' "$OUT/comparison.txt"; then
  echo "MISMATCHES FOUND - see $OUT/comparison.txt" >&2
  exit 1
fi
echo "All comparisons report 0 mismatches."
