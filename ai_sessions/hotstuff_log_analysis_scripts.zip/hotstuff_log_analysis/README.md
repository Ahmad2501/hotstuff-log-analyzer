# HotStuff four-run log analysis - scripts, results and report generator

Everything here reads the four raw logs (`main.log`, `main_2.log`, `main_3.log`, `main_4.log`) and never changes them.
Every number in the report comes from two independent computations: a Python analysis and a shell re-computation
(grep / awk / sed / sort / comm). `run_all.sh` runs both and compares them value by value.

## Quick start

    ./run_all.sh /path/to/the/logs            # results go to ./out, takes about 2 minutes
    ./run_all.sh /path/to/the/logs /tmp/out   # results go to /tmp/out instead

The run ends with these lines (0 mismatches in every comparison, exit status 0):

    (a) grep/awk vs (b) python-re: 1036 counts compared, 0 mismatches
    (c) part1.json (analysis script) vs (b): 444 counts compared, 0 mismatches
    compared 581 non-zero metrics (awk vs python): 0 mismatches
    compared 33 values (grep/awk/comm vs python): 0 mismatches
    243 values compared, 0 mismatches
    All comparisons report 0 mismatches.

On the logs of this report the rebuilt result files in the output folder were byte-identical to the files stored in `out/`.

## Requirements

bash, python3 with scipy (chi-square, binomial, Fisher and hypergeometric p-values), GNU grep (`grep -E`), awk, sed, sort, comm, cut,
wc, mktemp. Tested with Python 3.13, SciPy 1.18, GNU grep 3.11 and mawk 1.3.4 on Linux. The awk programs avoid gawk-only features
and regex interval expressions (`{n}`); macOS / BSD tools were not tested.

## Layout

| Path | What it is |
| :--- | :--- |
| `run_all.sh LOGDIR [OUTDIR]` | Runs steps 1-3 below and stops with an error on any mismatch. |
| `scripts/hsparse.py`, `common.py`, `mdutil.py` | Log parser (one event per line, call site cross-checked), parse cache `OUTDIR/parsed.pkl` (about 170 MB, delete it to re-parse), markdown / JSON helpers. |
| `scripts/patterns.py` | The 37 exact `grep -E` patterns of Part 1 (same text as in `verify_counts.sh`). |
| `scripts/part1_counts.py`, `part1_extra.py` | Part 1: counts per run, rates per 1,000 views, outcome of timeouts, TC verification, anatomy of `block too old`, commit / decide / execute chain. Writes `part1.md`, `part1.json`. |
| `scripts/part2_votes.py` | Part 2: participation, complete vote sequences, first / last position, processed order, proposal reception. Writes `part2.md`, `part2.json`. |
| `scripts/part3_views.py`, `views.py`, `viewtable.py` | Part 3: views per run, shared views, event classes, timeout views, bursts, timeline, view number against (view number, proposer). Writes `part3.md`, `part3.json`. |
| `scripts/part4_ordering.py`, `part4_examples.py` | Part 4: the ordering checks O1-O10, classes N / L / X, gap blocks, commit rule, stage latencies; verbatim log excerpts E1-E6. Writes `part4.md`, `part4.json`, `part4_examples.md`. |
| `scripts/verify_counts.sh`, `verify_votes.sh`, `verify_views.sh`, `verify_order.sh` (+ `verify_order.awk`) | Independent shell re-computation of Parts 1-4. Their arguments (`LOGDIR`, output file or work folder) are described in the header of each file. |
| `scripts/compare_counts.py`, `compare_votes.py`, `compare_views.py`, `compare_order.py` | Compare the shell output with the Python output and print `N compared, M mismatches`. |
| `report/` | Generator of the report text from `out/`: `extra.py` (stall window, timer length), `build.py` (writes `report_full.md` and the two tab files), `sec_*.py` (one function per section), `lib.py`, `audit.py` (flags numbers in the text that are in no result file). |
| `report/report_full.md`, `tab_excerpts.md`, `tab_evidence.md` | The report text as generated. |
| `out/` | Result files for the four logs of this report. |

## Definitions the scripts share

- Active phase = the log lines before the first `Stopping clients...` line (client load, 10 s); drain phase = the lines after it (2.5 s).
- Event order = physical line order in the file; the 1 ms timestamps are used only for durations.
- A vote is received at the collector (leader of view v+1) as `CollectVote(from N): <hash>`; the vote itself is not logged.
- A complete vote sequence = exactly four `CollectVote` lines from four distinct senders for one block at one collector.
- Class N / L / X of a view: complete collector chain / QC formed but a timeout or TC advance won the race / fewer than 3 distinct votes.

## Running one part by hand

    export HS_LOGDIR=/path/to/the/logs HS_OUT=$PWD/out
    python3 scripts/part2_votes.py > out/part2.md
    bash scripts/verify_votes.sh "$HS_LOGDIR" out/verify_votes.tsv
    python3 scripts/compare_votes.py

`HS_LOGDIR` is the folder with the logs (default: the current folder); `HS_OUT` is the output folder (default: `out` next to `scripts`).

## Rebuilding the report text

    cd report && python3 extra.py && python3 build.py

`extra.py` has the main_2 stall window (views 896-925) written in as a constant; it is specific to these logs.
