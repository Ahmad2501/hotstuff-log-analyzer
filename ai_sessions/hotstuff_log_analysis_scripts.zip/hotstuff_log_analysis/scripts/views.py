#!/usr/bin/env python3
"""views.py - annotate every protocol event with the view it belongs to and build per-replica / per-view indexes.

Annotation keys added to each event dict (when determinable):
    v      : the view the event is ABOUT (see assign rules below)
    cv     : the replica's own current view when the event was logged (from its last 'Advanced to view N'; initial 1)
    phase  : 'active' (before the 'Stopping clients...' line) or 'drain' (after it)

Assignment rules for v (documented so every number can be re-derived):
    RECV_PROPOSAL, TRY_COMMIT, BLOCK_EXISTS, PRUNE_FORK -> view of the block printed in the message
    PRE_COMMIT / COMMIT / DECIDE / EXEC                   -> view of the TRY_COMMIT that triggered it (same replica, latest)
                                                             (bv = view of the block printed in the message)
    ADVANCE_ENTER                                         -> view of the QC carried in the sync info (TC view if no QC)
    ON_NEW_VIEW / HQC_UPDATED / HQC_NOT_UPDATED / FAIL_VERIFY_SYNCINFO -> view of the QC of the replica's latest ADVANCE_ENTER
    ADVANCED                                              -> the view that was entered ('Advanced to view N')
    QC_DISPATCH                                           -> N in '(current : N)'
    COLLECT_VOTE / CACHE_MISS / NO_BLOCK_FOR_VOTE / FETCH_* / ON_REQUEST_BLOCK -> view of the block with that hash
    BLOCK_TOO_OLD                                         -> view of the block of the same replica's latest COLLECT_VOTE
    LOCAL_TIMEOUT                                         -> replica's current view
    LOCAL_TIMEOUT_VIEW / STOP_VOTING / REMOTE_TIMEOUT / NOT_ENOUGH_TIMEOUTS -> the view printed in the message
    REMOTE_TIMEOUT_2ND / FAIL_CREATE_SYNCINFO             -> view of the same replica's latest REMOTE_TIMEOUT
    DELAY_PROPOSAL                                        -> proposal view printed in the message
    PROPOSAL_TOO_OLD                                      -> block view printed in the message
    FAIL_CREATE_PROPOSAL / VOTERULE_LIVENESS_FAIL         -> replica's current view
"""
import collections
import common

H = common.H

PROTOCOL_EVENTS = {
    "RECV_PROPOSAL", "TRY_COMMIT", "BLOCK_EXISTS", "PRUNE_FORK", "PRE_COMMIT", "COMMIT", "DECIDE", "EXEC",
    "ADVANCE_ENTER", "ON_NEW_VIEW", "HQC_UPDATED", "HQC_NOT_UPDATED", "FAIL_VERIFY_SYNCINFO", "ADVANCED",
    "QC_DISPATCH", "COLLECT_VOTE", "CACHE_MISS", "NO_BLOCK_FOR_VOTE", "FETCH_ATTEMPT", "FETCH_OK", "ON_REQUEST_BLOCK",
    "BLOCK_TOO_OLD", "LOCAL_TIMEOUT", "LOCAL_TIMEOUT_VIEW", "STOP_VOTING", "REMOTE_TIMEOUT", "NOT_ENOUGH_TIMEOUTS",
    "REMOTE_TIMEOUT_2ND", "FAIL_CREATE_SYNCINFO", "DELAY_PROPOSAL", "PROPOSAL_TOO_OLD", "FAIL_CREATE_PROPOSAL",
    "VOTERULE_LIVENESS_FAIL", "BATCH_HASH", "PROPOSE_INIT",
}


def annotate(run_data):
    evs = run_data["events"]
    reg = run_data["blocks"]
    stop_n = next(e["n"] for e in evs if e["ev"] == "CTRL_STOP_CLIENTS")
    start_n = next(e["n"] for e in evs if e["ev"] == "CLIENT_START")
    cur = {r: 1 for r in H.REPLICAS}
    last_enter = {}
    last_trycommit_view = {}
    last_vote_hash = {}
    last_remote_view = {}
    last_trigger = {}
    pending_dispatch = {}
    for e in evs:
        e["phase"] = "pre" if e["n"] < start_n else ("active" if e["n"] < stop_n else "drain")
        r = e["r"]
        ev = e["ev"]
        e["v"] = None
        if r is None or ev is None:
            continue
        e["cv"] = cur[r]
        if ev in ("RECV_PROPOSAL", "TRY_COMMIT", "BLOCK_EXISTS", "PRUNE_FORK"):
            e["v"] = e["blk"]["view"] if e.get("blk") else None
            if ev == "RECV_PROPOSAL":
                last_trigger[r] = "RECV_PROPOSAL"
            if ev == "TRY_COMMIT" and e["blk"]:
                last_trycommit_view[r] = e["blk"]["view"]
        elif ev in ("PRE_COMMIT", "COMMIT", "DECIDE", "EXEC"):
            e["v"] = last_trycommit_view.get(r)
            e["bv"] = e["blk"]["view"] if e.get("blk") else None
        elif ev == "ADVANCE_ENTER":
            if e["qc"]:
                e["v"] = e["qc"][1]
            elif e["tc"]:
                e["v"] = e["tc"][0]
            e["trigger"] = last_trigger.get(r)
            last_enter[r] = e
        elif ev in ("ON_NEW_VIEW",):
            e["v"] = None  # filled when the following ADVANCE_ENTER arrives
            e["local_qc"] = bool(pending_dispatch.pop(r, False))   # True = QC formed by THIS replica's vote collection
            last_trigger[r] = "ON_NEW_VIEW_LOCAL" if e["local_qc"] else "ON_NEW_VIEW_OTHER"
        elif ev in ("HQC_UPDATED", "HQC_NOT_UPDATED", "FAIL_VERIFY_SYNCINFO"):
            le = last_enter.get(r)
            e["v"] = le["v"] if le else None
            e["enter_n"] = le["n"] if le else None
            e["trigger"] = le["trigger"] if le else None
        elif ev == "ADVANCED":
            e["v"] = e["view"]
            cur[r] = e["view"]
            le = last_enter.get(r)
            e["trigger"] = le["trigger"] if le else None
        elif ev == "QC_DISPATCH":
            e["v"] = e["view"]
            pending_dispatch[r] = True
        elif ev in ("COLLECT_VOTE", "CACHE_MISS", "NO_BLOCK_FOR_VOTE", "FETCH_ATTEMPT", "FETCH_OK", "ON_REQUEST_BLOCK"):
            b = reg.get(e.get("hash"))
            e["v"] = b["view"] if b else None
            if ev == "COLLECT_VOTE":
                last_vote_hash[r] = e["hash"]
        elif ev == "BLOCK_TOO_OLD":
            b = reg.get(last_vote_hash.get(r))
            e["v"] = b["view"] if b else None
            e["vote_hash"] = last_vote_hash.get(r)
        elif ev == "LOCAL_TIMEOUT":
            e["v"] = cur[r]
        elif ev in ("LOCAL_TIMEOUT_VIEW", "STOP_VOTING", "NOT_ENOUGH_TIMEOUTS"):
            e["v"] = e["view"]
        elif ev == "REMOTE_TIMEOUT":
            e["v"] = e["view"]
            last_remote_view[r] = e["view"]
            last_trigger[r] = "REMOTE_TIMEOUT"
        elif ev in ("REMOTE_TIMEOUT_2ND", "FAIL_CREATE_SYNCINFO"):
            e["v"] = last_remote_view.get(r)
            if ev == "REMOTE_TIMEOUT_2ND":
                last_trigger[r] = "REMOTE_TIMEOUT_2ND"
        elif ev == "DELAY_PROPOSAL":
            e["v"] = e.get("prop_view")
        elif ev == "PROPOSAL_TOO_OLD":
            e["v"] = e.get("blk_view")
        elif ev in ("FAIL_CREATE_PROPOSAL", "VOTERULE_LIVENESS_FAIL"):
            e["v"] = cur[r]
    # second pass: ON_NEW_VIEW takes the view of the ADVANCE_ENTER that follows it on the same replica
    nxt = {}
    for e in reversed(evs):
        r = e["r"]
        if r is None or e["ev"] is None:
            continue
        if e["ev"] == "ADVANCE_ENTER":
            nxt[r] = e
        elif e["ev"] == "ON_NEW_VIEW":
            ne = nxt.get(r)
            e["v"] = ne["v"] if ne else None
            e["enter_n"] = ne["n"] if ne else None
    return run_data


def proposers_by_view(run_data):
    pv = collections.defaultdict(set)
    for h, b in run_data["blocks"].items():
        pv[b["view"]].add(b["proposer"])
    return pv


def hashes_by_view(run_data):
    hv = collections.defaultdict(set)
    for h, b in run_data["blocks"].items():
        hv[b["view"]].add(h)
    return hv


def load_annotated(force=False):
    D = common.load(force=force)
    for r in D:
        if "annotated" not in D[r]:
            annotate(D[r])
            D[r]["annotated"] = True
    return D
