#!/usr/bin/env python3
"""Part 4 - does every run follow the expected causal order of chained HotStuff, and what happens when it does not?

Expected chain (n=4, quorum 3, leader(v) = v mod 4 + 1; votes for B_v go to leader(v+1) = the 'collector'):

  proposer p=leader(v):  advanceView(QC_{v-1}) -> HighQC updated -> 'Advanced to view v' -> TryCommit(B_v)  [= proposal created]
  receivers (3):         'Received proposal B_v' -> advanceView(attached QC_{v-1}) -> HighQC updated / not -> [Advanced to view v]
                         -> TryCommit(B_v) [= proposal accepted, vote sent]
  collector c=leader(v+1): CollectVote(from s) x >=3 distinct -> 'CollectVote: dispatching event for new view' [= QC_v formed]
                         -> OnNewView -> advanceView(QC_v) -> HighQC updated -> 'Advanced to view v+1' -> TryCommit(B_{v+1}) carrying QC_v
  every replica after TryCommit(B_v): CommitRule PRE_COMMIT / COMMIT / DECIDE -> EXEC   (consecutive-view three-chain)
  no QC: OnLocalTimeout / OnRemoteTimeout -> timeout certificate (TC) -> 'Advanced to view v+1' through the TC.

Ordering primitive = physical line number in the log (the four replicas are interleaved in ONE file; timestamps have <=3 ms inversions).
Scope: blocks / dispatches of the ACTIVE phase (before the first 'Stopping clients...' line); views 3 .. last-1 for per-view classes.
"""
import collections
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import views            # noqa: E402
import mdutil           # noqa: E402
import part1_extra as X  # noqa: E402

H = views.H
RUNS = H.RUNS
R4 = H.REPLICAS
LEADER = H.leader_of
D = views.load_annotated()
OUTDIR = os.environ.get("HS_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out"))
SKIP = {"COLLECT_VOTE", "CACHE_MISS", "BLOCK_TOO_OLD", "BATCH_HASH"}      # lines of other goroutines that may interleave a chain


class Ix:
    pass


def build(rd):
    ix = Ix()
    evs = rd["events"]
    ix.evs = evs
    ix.reg = rd["blocks"]
    hv = collections.defaultdict(set)
    for h, b in ix.reg.items():
        hv[b["view"]].add(h)
    ix.multi_view = sorted(v for v, s in hv.items() if len(s) > 1)
    ix.by_view = {v: sorted(s)[0] for v, s in hv.items()}
    ix.stream = {r: [] for r in R4}
    ix.pos = {}
    ix.recv, ix.try_ = {}, {}
    ix.enter = collections.defaultdict(list)
    ix.adv = collections.defaultdict(list)
    ix.votes = collections.defaultdict(list)
    ix.alld = collections.defaultdict(list)
    ix.too_old = collections.defaultdict(list)           # (replica, block view) -> [PROPOSAL_TOO_OLD]
    ix.loc_to = collections.defaultdict(set)             # view -> replicas that logged OnLocalTimeout in it
    ix.loc_first = {}                                    # (replica, view) -> first OnLocalTimeout line
    ix.delay = []                                        # DELAY_PROPOSAL events
    ix.tc_by = collections.defaultdict(set)              # view -> replicas that formed a TC ('second advance')
    ix.stop_n = next(e["n"] for e in evs if e["ev"] == "CTRL_STOP_CLIENTS")
    ix.first_prop = {}
    for e in evs:
        r = e["r"]
        if e["ev"] in ("TRY_COMMIT", "RECV_PROPOSAL") and e.get("blk"):
            ix.first_prop.setdefault(e["blk"]["view"], e["n"])
        if r not in ix.stream:
            continue
        ix.pos[e["n"]] = (r, len(ix.stream[r]))
        ix.stream[r].append(e)
        ev = e["ev"]
        if ev == "RECV_PROPOSAL" and e["blk"]:
            ix.recv.setdefault((r, e["blk"]["hash"]), e)
        elif ev == "TRY_COMMIT" and e["blk"]:
            ix.try_.setdefault((r, e["blk"]["hash"]), e)
        elif ev == "ADVANCE_ENTER" and e["qc"]:
            ix.enter[(r, e["qc"][0])].append(e)
        elif ev == "ADVANCED":
            ix.adv[(r, e["view"])].append(e)
        elif ev == "QC_DISPATCH":
            ix.alld[r].append(e)
        elif ev == "COLLECT_VOTE":
            ix.votes[(r, e["hash"])].append(e)
        elif ev == "PROPOSAL_TOO_OLD":
            ix.too_old[(r, e.get("blk_view"))].append(e)
        elif ev in ("LOCAL_TIMEOUT", "LOCAL_TIMEOUT_VIEW") and e.get("v") is not None:
            ix.loc_to[e["v"]].add(r)
            ix.loc_first.setdefault((r, e["v"]), e["n"])
        elif ev == "DELAY_PROPOSAL":
            ix.delay.append(e)
        elif ev == "REMOTE_TIMEOUT_2ND" and e.get("v") is not None:
            ix.tc_by[e["v"]].add(r)
    ix.qc_ids_of = {}
    for h, b in ix.reg.items():
        if b["qc_hash"] not in ix.qc_ids_of and len(b["qc_ids"]) > 0:
            ix.qc_ids_of[b["qc_hash"]] = tuple(b["qc_ids"])
    ix.vmax = max(ix.by_view)
    return ix


def distinct_votes(ix, c, h):
    seen, out = set(), []
    for e in ix.votes.get((c, h), []):
        if e["from_id"] not in seen:
            seen.add(e["from_id"])
            out.append(e)
    return out


def assign_dispatch(ix):
    """QC_DISPATCH line -> block hash: per collector, blocks ordered by the line of their 3rd distinct CollectVote;
    each gets the first still-unclaimed dispatch line after it (the dispatch is logged once >=3 verified votes exist)."""
    asg = {}                                  # (collector, hash) -> dispatch event
    owner = {}                                # dispatch line -> hash
    for c in R4:
        items = []
        for (cc, h) in list(ix.votes.keys()):
            if cc != c:
                continue
            ds = distinct_votes(ix, c, h)
            if len(ds) >= 3:
                items.append((ds[2]["n"], h))
        items.sort()
        claimed = set()
        pend = list(ix.alld[c])
        for n3, h in items:
            cand = [e for e in pend if e["n"] > n3 and e["n"] not in claimed]
            if cand:
                claimed.add(cand[0]["n"])
                asg[(c, h)] = cand[0]
                owner[cand[0]["n"]] = h
    return asg, owner


def chain_check(ix, c, d, hstar, wview):
    """Causal chain at the collector after QC dispatch d for the block of view wview (hash hstar).
    Other lines of the same replica may be interleaved between the dispatch and the QC being processed (timeouts are handled by the same
    event loop), but the view must not be advanced by anything else before the QC is processed.
    Returns (status, detail, info): status 'complete' or a short reason."""
    st = ix.stream[c]
    i = ix.pos[d["n"]][1]
    cur = d["view"]
    info = {"between": []}
    if cur != wview:
        return "late: dispatch printed 'current : %d' (> v=%d), the collector had already advanced" % (cur, wview), None, info
    qe = None
    for e in st[i + 1:]:
        ev = e["ev"]
        if ev == "ADVANCED":
            return "tc: the view was advanced by %s before the QC was processed" % e.get("trigger"), e.get("trigger"), info
        if ev == "ADVANCE_ENTER" and e["qc"] and e["qc"][0] == hstar:
            qe = e
            break
        if ev in ("RECV_PROPOSAL", "TRY_COMMIT", "QC_DISPATCH"):
            return "next activity (%s) before the QC was processed" % ev, ev, info
        if ev not in SKIP:
            info["between"].append(ev)
    if qe is None:
        return "QC never processed", None, info
    # the advanceView must be the body of an OnNewView
    j = ix.pos[qe["n"]][1]
    k = j - 1
    while k >= 0 and st[k]["ev"] in SKIP:
        k -= 1
    if k < 0 or st[k]["ev"] != "ON_NEW_VIEW":
        return "advanceView(QC_v) not preceded by OnNewView", st[k]["ev"] if k >= 0 else None, info
    if info["between"] and info["between"][-1] == "ON_NEW_VIEW":
        info["between"].pop()
    info["qc"] = qe["qc"]
    info["enter"] = qe
    seq = []
    for e in st[j + 1:]:
        if e["ev"] in SKIP:
            continue
        seq.append(e)
        if len(seq) == 3:
            break
    if len(seq) < 3:
        return "chain cut by the end of the log", None, info
    e1, e2, e3 = seq
    if e1["ev"] != "HQC_UPDATED" or e1.get("enter_n") != qe["n"]:
        return "HighQC not updated by QC_v", e1["ev"], info
    if e2["ev"] != "ADVANCED" or e2["view"] != cur + 1:
        return "no 'Advanced to view v+1' right after HighQC update", e2["ev"], info
    info["adv"] = e2
    b = e3["blk"] if e3["ev"] == "TRY_COMMIT" else None
    if b is None or not (b["view"] == cur + 1 and b["proposer"] == c and b["qc_hash"] == hstar and tuple(b["qc_ids"]) == tuple(qe["qc"][2])):
        return "no TryCommit(B_{v+1}) carrying QC_v right after the advance", e3["ev"], info
    info["try"] = e3
    return "complete", None, info


def pct(a, b):
    return f"{100.0 * a / b:.2f}%" if b else "n/a"


def quant(xs, q):
    if not xs:
        return float("nan")
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * (len(xs) - 1) + 0.5))]


def analyse(run):
    rd = D[run]
    ix = build(rd)
    reg = ix.reg
    R = collections.OrderedDict()
    flat = {}

    # ------------------------------------------------------------------------------------------------ blocks and QC fields
    nb = len(reg)
    par_eq = sum(1 for b in reg.values() if b["parent"] == b["qc_hash"])
    qc3 = sum(1 for b in reg.values() if len(b["qc_ids"]) == 3 and len(set(b["qc_ids"])) == 3)
    gap = collections.Counter()
    qcv_eq = 0
    qcv_tested = 0
    for b in reg.values():
        p = reg.get(b["parent"])
        if p is not None and b["view"] >= 1:
            gap[b["view"] - p["view"]] += 1
            qcv_tested += 1
            qcv_eq += (b["qc_view"] == p["view"])
    R["blocks"] = dict(n=nb, parent_eq_qc=par_eq, qc_three_distinct=qc3, parent_known=qcv_tested, qc_view_eq_parent_view=qcv_eq, gap=dict(gap),
                       multi_hash_views=len(ix.multi_view))
    flat["blocks"] = nb
    flat["blocks_parent_eq_qc"] = par_eq
    for g, n in gap.items():
        flat[f"gap{g}"] = n

    # ------------------------------------------------------------------------------------------------ dispatch assignment
    asg, owner = assign_dispatch(ix)
    act_disp = [(c, d) for c in R4 for d in ix.alld[c] if d["n"] < ix.stop_n]
    all_disp = [(c, d) for c in R4 for d in ix.alld[c]]
    matched_act = sum(1 for c, d in act_disp if d["n"] in owner)
    flat["dispatch_active"] = len(act_disp)
    flat["dispatch_active_matched"] = matched_act
    flat["dispatch_total"] = len(all_disp)

    # ------------------------------------------------------------------------------------------------ per-view loop
    vr = [v for v in range(3, ix.vmax) if ix.first_prop.get(v) is not None and ix.first_prop[v] < ix.stop_n]
    flat["views_tested"] = len(vr)
    cnt = collections.defaultdict(collections.Counter)
    ex = collections.defaultdict(list)

    def rec(step, label, example=None):
        cnt[step][label] += 1
        if not label.startswith("pass") and example is not None and len(ex[step]) < 8:
            ex[step].append(example)

    lat = collections.defaultdict(list)
    cls = {}
    nonN = []
    for v in vr:
        h = ix.by_view[v]
        b = reg[h]
        p, c = LEADER(v), LEADER(v + 1)
        # O1 / O2 : proposer before the first receipt
        recvs = [ix.recv[(x, h)]["n"] for x in R4 if (x, h) in ix.recv]
        tp = ix.try_.get((p, h))
        if recvs and tp is not None:
            rec("O1", "pass" if tp["n"] < min(recvs) else "FAIL", (v, tp["n"], min(recvs)))
        advp = [a["n"] for a in ix.adv.get((p, v), [])]
        if recvs and advp:
            rec("O2", "pass" if min(advp) < min(recvs) else "FAIL", (v, min(advp), min(recvs)))
        # O3 / O4 / O5 : the three receivers
        for x in R4:
            rv = ix.recv.get((x, h))
            if rv is None:
                continue
            i0 = ix.pos[rv["n"]][1]
            nxt = None
            for e in ix.stream[x][i0 + 1:i0 + 80]:
                if e["ev"] == "ADVANCE_ENTER":
                    nxt = e
                    break
                if e["ev"] in ("RECV_PROPOSAL", "TRY_COMMIT"):
                    break
            if nxt is None or not nxt["qc"] or nxt["qc"][0] != b["qc_hash"]:
                rec("O3", "FAIL", (v, x, rv["n"]))
                continue
            rec("O3", "pass")
            tc = ix.try_.get((x, h))
            if tc is None:
                tooold = [t for t in ix.too_old.get((x, v), []) if rv["n"] < t["n"]]
                if not tooold:
                    lab = "FAIL: no TryCommit and no 'too old' line"
                else:
                    t = tooold[0]
                    lf = ix.loc_first.get((x, v))
                    if t["last_vote"] == v and lf is not None and lf < rv["n"]:
                        lab = "rejected 'too old': replica had already timed out in view v (last voted view = v), no vote"
                    elif t["last_vote"] > v:
                        lab = "rejected 'too old': replica had already voted/stopped in a later view (last voted view > v), no vote"
                    else:
                        lab = "rejected 'too old': other"
                rec("O4", lab, (v, x, rv["n"]))
                continue
            rec("O4", "pass" if nxt["n"] < tc["n"] else "FAIL", (v, x, nxt["n"], tc["n"]))
            kind = None
            j = ix.pos[nxt["n"]][1]
            for e in ix.stream[x][j + 1:j + 6]:
                if e["ev"] in ("HQC_UPDATED", "HQC_NOT_UPDATED", "FAIL_VERIFY_SYNCINFO") and e.get("enter_n") == nxt["n"]:
                    kind = e["ev"]
                    break
            adv_here = [a for a in ix.adv.get((x, v), []) if nxt["n"] < a["n"] < tc["n"]]
            early = [a for a in ix.adv.get((x, v), []) if a["n"] < nxt["n"]]
            etrig = early[0].get("trigger") if early else "?"
            if kind == "HQC_UPDATED" and adv_here:
                lab = "HighQC updated, then 'Advanced to view v', then TryCommit"
            elif kind == "HQC_UPDATED":
                lab = "HighQC updated; replica was already in view v (entered v earlier via %s)" % etrig
            elif kind == "HQC_NOT_UPDATED":
                lab = "HighQC not updated (QC already known); " + ("then 'Advanced to view v'" if adv_here else "replica was already in view v (entered v earlier via %s)" % etrig)
            else:
                lab = "other: %s" % kind
            rec("O5", lab)
        # O6 : every vote line follows the voter's own TryCommit(B_v)
        for e in ix.votes.get((c, h), []):
            s = e["from_id"]
            ts = ix.try_.get((s, h))
            if ts is None:
                rec("O6", "FAIL: voter has no TryCommit(B_v)", (v, s, e["n"]))
            else:
                rec("O6", "pass" if ts["n"] < e["n"] else "FAIL: vote line before TryCommit", (v, s, ts["n"], e["n"]))
        # O6b : every TryCommit(B_v) is followed by a vote line at the collector
        for s in R4:
            ts = ix.try_.get((s, h))
            if ts is None:
                continue
            got = [e for e in ix.votes.get((c, h), []) if e["from_id"] == s]
            if got:
                rec("O6b", "pass", None)
            else:
                lf = ix.loc_first.get((s, v))
                rec("O6b", "no CollectVote line at the collector; the voter logged OnLocalTimeout in view v %s its TryCommit" % ("after" if lf and lf > ts["n"] else "before" if lf else "- never (FAIL)"), (v, s, ts["n"]))
        # quorum / dispatch
        ds = distinct_votes(ix, c, h)
        d = asg.get((c, h))
        nd = len(ds)
        flat_key = "votes_distinct_%d" % min(nd, 4)
        flat[flat_key] = flat.get(flat_key, 0) + 1
        if d is None:
            cls[v] = "X"
            nonN.append(v)
            rec("O7", ("no dispatch, %d distinct vote line(s) (<3)" % nd) if nd < 3 else "FAIL: >=3 distinct vote lines but no dispatch", (v, c, nd))
            continue
        before = {e["from_id"] for e in ds if e["n"] < d["n"]}
        after = [e for e in ds if e["n"] > d["n"]]
        rec("O7", ("pass (%d distinct vote lines before the dispatch)" % len(before)) if len(before) >= 3 else "FAIL (%d)" % len(before))
        ids = ix.qc_ids_of.get(h)
        if ids is None:
            rec("O8", "n/a: QC_v is never printed in a later block")
        else:
            ok = set(ids) <= before and len(ids) == 3 and len(set(ids)) == 3
            rec("O8", "pass" if ok else "FAIL", (v, ids, sorted(before)))
            rec("O8b", ("pass: late vote line(s) after the dispatch, sender outside QC.IDs" if all(e["from_id"] not in ids for e in after) else "FAIL: late vote line from a member of QC.IDs") if after else "no vote line after the dispatch")
        conf = [e for e in ix.enter.get((c, h), []) if e["n"] > d["n"]]
        rec("O7c", "pass" if conf else "FAIL: dispatched QC never processed", (v, c))
        st, found, info = chain_check(ix, c, d, h, v)
        if st == "complete":
            cls[v] = "N"
            rec("O9", "pass" if not info["between"] else "pass, with timeout-handling lines of the same replica between dispatch and OnNewView")
            rec("O10", "pass")
            t_try_p = tp["t"] if tp else None
            if recvs and t_try_p is not None:
                lat["propagation"].append(min(ix.recv[(x, h)]["t"] for x in R4 if (x, h) in ix.recv) - t_try_p)
            for x in R4:
                rv, tcx = ix.recv.get((x, h)), ix.try_.get((x, h))
                if rv and tcx:
                    lat["receiver"].append(tcx["t"] - rv["t"])
                vts = [e for e in ds if e["from_id"] == x]
                if tcx and vts:
                    lat["vote_own" if x == c else "vote_net"].append(vts[0]["t"] - tcx["t"])
            lat["verify"].append(d["t"] - ds[2]["t"])
            lat["adv"].append(info["adv"]["t"] - d["t"])
            lat["propose"].append(info["try"]["t"] - info["adv"]["t"])
            if tp:
                lat["cycle"].append(info["try"]["t"] - tp["t"])
        else:
            cls[v] = "L"
            nonN.append(v)
            rec("O9", "broken: " + ("QC formed after the collector had already advanced past v (dispatch prints current = v+1)" if st.startswith("late") else "view v+1 entered through a timeout certificate before the QC was processed" if st.startswith("tc") else st), (v, c, d["n"]))
            rec("O10", "n/a: chain broken before the next proposal")
    cc = collections.Counter(cls.values())
    R["classes"] = dict(cc)
    R["nonN"] = {v: cls[v] for v in nonN}
    flat["class_N"], flat["class_L"], flat["class_X"] = cc["N"], cc["L"], cc["X"]
    # dispatch-level chain (all active dispatches, including views 1, 2 and the last view)
    dchain = collections.Counter()
    for c, d in act_disp:
        h = owner.get(d["n"])
        if h is None:
            dchain["dispatch line without a matching block (<3 distinct vote lines before it)"] += 1
            continue
        st, found, info = chain_check(ix, c, d, h, reg[h]["view"])
        dchain["complete" if st == "complete" else "broken"] += 1
    R["dispatch_chain"] = dict(dchain)
    flat["dispatch_chain_complete"] = dchain["complete"]
    flat["dispatch_chain_broken"] = dchain["broken"]
    # ---------------------------------------------------------------------------------------------- non-N views in detail
    det = []
    for v in nonN:
        h = ix.by_view[v]
        c = LEADER(v + 1)
        ds = distinct_votes(ix, c, h)
        h1 = ix.by_view.get(v + 1)
        b1 = reg.get(h1) if h1 else None
        advc = ix.adv.get((c, v + 1), [])
        trig = advc[0].get("trigger") if advc else None
        d = asg.get((c, h))
        det.append(dict(view=v, cls=cls[v], collector=c, votes=[e["from_id"] for e in ds], dispatch_current=(d["view"] if d else None),
                        local_timeout=sorted(ix.loc_to.get(v, [])), tc_formed=sorted(ix.tc_by.get(v, [])),
                        collector_entered_next_by=trig, next_proposer=(b1["proposer"] if b1 else None),
                        next_qc_view=(b1["qc_view"] if b1 else None), next_parent_view=(reg[b1["parent"]]["view"] if b1 and b1["parent"] in reg else None)))
    R["nonN_detail"] = det
    too = [e for e in ix.evs if e["ev"] == "PROPOSAL_TOO_OLD" and e["r"] in R4]
    flat["too_old_proposals"] = len(too)
    flat["too_old_proposals_lv_eq_v"] = sum(1 for e in too if e["last_vote"] == e["blk_view"])
    flat["too_old_proposals_lv_gt_v"] = sum(1 for e in too if e["last_vote"] > e["blk_view"])
    R["too_old_list"] = [dict(replica=e["r"], line=e["n"], view=e["blk_view"], last_voted=e["last_vote"]) for e in too]
    dl = [dict(replica=e["r"], line=e["n"], prop_view=e.get("prop_view"), local_view=e.get("local_view"), phase=e["phase"]) for e in ix.delay]
    R["delayed_proposals"] = dl
    flat["delay_proposal_total"] = len(dl)
    flat["delay_proposal_active"] = sum(1 for e in ix.delay if e["n"] < ix.stop_n)
    gap_blocks = sorted(b["view"] for b in reg.values() if b["parent"] in reg and b["view"] - reg[b["parent"]]["view"] > 1 and 3 <= b["view"] <= ix.vmax and ix.first_prop.get(b["view"], 10 ** 12) < ix.stop_n)
    nxt_views = sorted(v + 1 for v in nonN)
    R["gap_blocks"] = gap_blocks
    R["gap_equals_nonN_next"] = (gap_blocks == nxt_views)
    flat["gap_blocks_active"] = len(gap_blocks)
    # ---------------------------------------------------------------------------------------------- entering views
    ent = collections.defaultdict(collections.Counter)
    jumps = collections.Counter()
    nonmono = 0
    for r in R4:
        prev = None
        for e in ix.stream[r]:
            if e["ev"] != "ADVANCED":
                continue
            if prev is not None:
                dlt = e["view"] - prev
                jumps[str(dlt) if dlt <= 3 else ">3"] += 1
                nonmono += (dlt <= 0)
                ent[e["phase"]][e.get("trigger")] += 1
            prev = e["view"]
    R["entering"] = {ph: dict(cn) for ph, cn in ent.items()}
    R["jumps"] = dict(jumps)
    R["nonmonotone"] = nonmono
    # ---------------------------------------------------------------------------------------------- commit chain
    cch = X.commit_chain(H, rd)
    R["gaps_tab"] = {str(g): dict(cn) for g, cn in cch["gaps_tab"].items()}
    two = collections.Counter()
    for g, cn in cch["gaps_tab"].items():
        if g[1] is None or g[2] is None:
            continue
        cons = (g[1] == 1 and g[2] == 1)
        for shape, n in cn.items():
            two[(cons, "DECIDE" in shape)] += n
    R["decide_vs_consecutive"] = {f"consecutive={a},decide_logged={b}": n for (a, b), n in two.items()}
    flat["decide_consecutive_logged"] = two[(True, True)]
    flat["decide_consecutive_missing"] = two[(True, False)]
    flat["decide_nonconsecutive_logged"] = two[(False, True)]
    flat["decide_nonconsecutive_missing"] = two[(False, False)]
    # ---------------------------------------------------------------------------------------------- results
    R["steps"] = {k: dict(v) for k, v in cnt.items()}
    R["examples"] = {k: v for k, v in ex.items()}
    R["latency"] = {k: dict(n=len(v), median=statistics.median(v), p90=quant(v, 0.9), p99=quant(v, 0.99), max=max(v), min=min(v)) for k, v in lat.items() if v}
    for k, v in cnt.items():
        for lab, n in v.items():
            flat["%s|%s" % (k, lab)] = n
    return R, flat


def main():
    out = []
    P = out.append
    J = {}
    F = {}
    for run in RUNS:
        J[run], F[run] = analyse(run)

    names = {
        "O1": "O1  TryCommit(B_v) at the proposer comes BEFORE the first 'Received proposal' of B_v at any other replica",
        "O2": "O2  'Advanced to view v' at the proposer comes BEFORE the first 'Received proposal' of B_v",
        "O3": "O3  receiver: the next advanceView line after 'Received proposal' carries exactly the QC attached to B_v",
        "O4": "O4  receiver: that advanceView comes BEFORE the receiver's TryCommit(B_v) (validation = vote)",
        "O5": "O5  receiver: effect of the attached QC (HighQC / view change) before TryCommit",
        "O6": "O6  collector: every 'CollectVote(from s)' line for B_v comes AFTER s's own TryCommit(B_v) line",
        "O6b": "O6b every TryCommit(B_v) is answered by a 'CollectVote(from s)' line for B_v at the collector",
        "O7": "O7  collector: a QC dispatch exists only when >=3 distinct 'CollectVote' lines for B_v precede it",
        "O7c": "O7c the dispatched QC is later processed by advanceView at the collector (hash of B_v)",
        "O8": "O8  QC_v.IDs: 3 distinct replicas, every one of them had a CollectVote line BEFORE the dispatch",
        "O8b": "O8b vote line(s) logged AFTER the dispatch (late votes)",
        "O9": "O9  collector chain: dispatch -> OnNewView -> advanceView(QC_v) -> HighQC updated -> 'Advanced to view v+1' (consecutive lines of that replica)",
        "O10": "O10 collector: TryCommit(B_{v+1}) right after 'Advanced to view v+1', proposer = collector, cert = QC_v (same hash and IDs)",
    }
    P("## 4A. Step-by-step ordering checks (views 3 .. last-1 of the active phase; receiver / vote checks count replica x view)\n")
    P("Every non-passing outcome is listed explicitly (nothing is dropped silently). Order = physical line order.\n")
    P(mdutil.table(["check"] + RUNS, [
        ["views tested"] + [F[r]["views_tested"] for r in RUNS],
        ["views with more than one distinct block hash"] + [J[r]["blocks"]["multi_hash_views"] for r in RUNS],
    ]))
    P("")
    for k in ["O1", "O2", "O3", "O4", "O5", "O6", "O6b", "O7", "O7c", "O8", "O8b", "O9", "O10"]:
        labels = sorted({lb for r in RUNS for lb in J[r]["steps"].get(k, {})}, key=lambda x: (not x.startswith("pass"), x))
        rows = [[lb] + [J[r]["steps"].get(k, {}).get(lb, 0) for r in RUNS] for lb in labels]
        rows.append(["**tested**"] + [sum(J[r]["steps"].get(k, {}).values()) for r in RUNS])
        P(f"**{names[k]}**\n")
        P(mdutil.table(["outcome"] + RUNS, rows))
        P("")

    P("## 4B. View classes: N = complete ordered chain, L = QC formed but the collector had already left the view, X = no QC\n")
    rows = [
        ["N  dispatch -> OnNewView -> advanceView(QC_v) -> HighQC updated -> Advanced v+1 -> TryCommit(B_{v+1}) with QC_v"] + [J[r]["classes"].get("N", 0) for r in RUNS],
        ["L  QC_v formed (dispatch logged) but the chain is broken (timeout/TC advance won the race)"] + [J[r]["classes"].get("L", 0) for r in RUNS],
        ["X  fewer than 3 distinct CollectVote lines: no QC for B_v"] + [J[r]["classes"].get("X", 0) for r in RUNS],
        ["views tested"] + [F[r]["views_tested"] for r in RUNS],
        ["share N"] + [pct(J[r]["classes"].get("N", 0), F[r]["views_tested"]) for r in RUNS],
        ["blocks whose parent is NOT view-1 (view gap) in the tested range"] + [F[r]["gap_blocks_active"] for r in RUNS],
        ["set of those blocks == {v+1 : v of class L or X}"] + [("yes" if J[r]["gap_equals_nonN_next"] else "NO") for r in RUNS],
    ]
    P(mdutil.table(["class"] + RUNS, rows))
    P("")
    P("Dispatch lines (all QC_DISPATCH lines of the active phase, including views 1-2 and the last view): collector chain complete / broken / without a matching block\n")
    rows = []
    for lab in ["complete", "broken", "dispatch line without a matching block (<3 distinct vote lines before it)"]:
        rows.append([lab] + [J[r]["dispatch_chain"].get(lab, 0) for r in RUNS])
    rows.append(["QC_DISPATCH lines in the active phase"] + [F[r]["dispatch_active"] for r in RUNS])
    P(mdutil.table(["collector chain after a dispatch"] + RUNS, rows))
    P("")
    P("Views of class L / X in detail (local timeout = replicas that logged OnLocalTimeout in that view; TC = replicas that formed a timeout certificate for it):\n")
    rows = []
    for r in RUNS:
        for dd in J[r]["nonN_detail"]:
            rows.append([r, dd["view"], dd["cls"], "hs%d" % dd["collector"], "".join(str(x) for x in dd["votes"]) or "-",
                         "".join(str(x) for x in dd["local_timeout"]) or "-", "".join(str(x) for x in dd["tc_formed"]) or "-",
                         dd["collector_entered_next_by"], "hs%s" % dd["next_proposer"], dd["next_qc_view"], dd["next_parent_view"]])
    if rows:
        P(mdutil.table(["run", "view v", "class", "collector", "CollectVote senders", "local timeout at", "TC formed at", "collector entered v+1 by", "B_{v+1} proposer", "B_{v+1} QC view", "B_{v+1} parent view"], rows, align="lrllllllrrr"))
    P("")

    P("## 4C. How replicas entered views (trigger of every 'Advanced to view N' after each replica's first one; active / drain) and monotonicity\n")
    trig_names = ["RECV_PROPOSAL", "ON_NEW_VIEW_LOCAL", "REMOTE_TIMEOUT_2ND", "REMOTE_TIMEOUT", "ON_NEW_VIEW_OTHER"]
    rows = []
    for t in trig_names:
        rows.append([t] + ["%s / %s" % (mdutil.fmt(J[r]["entering"].get("active", {}).get(t, 0)), mdutil.fmt(J[r]["entering"].get("drain", {}).get(t, 0))) for r in RUNS])
    rows.append(["total"] + ["%s / %s" % (mdutil.fmt(sum(J[r]["entering"].get("active", {}).values())), mdutil.fmt(sum(J[r]["entering"].get("drain", {}).values()))) for r in RUNS])
    rows.append(["view step = +1 / +2 / +3 / >3 (all phases)"] + [" / ".join(str(J[r]["jumps"].get(k, 0)) for k in ["1", "2", "3", ">3"]) for r in RUNS])
    rows.append(["advances that do not increase the view"] + [J[r]["nonmonotone"] for r in RUNS])
    P(mdutil.table(["trigger"] + RUNS, rows))
    P("")

    P("## 4D. Commit rule vs. consecutive certified views (every TryCommit with a known 3-chain, all phases)\n")
    rows = []
    for key, lab in [("consecutive=True,decide_logged=True", "b1,b2,b3 in consecutive views, DECIDE logged"),
                     ("consecutive=True,decide_logged=False", "b1,b2,b3 in consecutive views, DECIDE missing"),
                     ("consecutive=False,decide_logged=True", "NOT consecutive, DECIDE logged"),
                     ("consecutive=False,decide_logged=False", "NOT consecutive, DECIDE not logged")]:
        rows.append([lab] + [J[r]["decide_vs_consecutive"].get(key, 0) for r in RUNS])
    P(mdutil.table(["situation"] + RUNS, rows))
    P("")
    P("Gap triple = (view(B_v)-view(b1), view(b1)-view(b2), view(b2)-view(b3)) and the commit-rule lines logged after TryCommit(B_v) (triples other than (1, 1, 1)):\n")
    rows = []
    for r in RUNS:
        for g, cn in sorted(J[r]["gaps_tab"].items(), key=lambda kv: -sum(kv[1].values())):
            if g == "(1, 1, 1)":
                continue
            rows.append([r, g, "; ".join("%s x%d" % (s, n) for s, n in sorted(cn.items(), key=lambda kv: -kv[1]))])
    P(mdutil.table(["run", "gaps (b->b1, b1->b2, b2->b3)", "lines logged after TryCommit (count)"], rows, align="lll"))
    P("")

    P("## 4E. Block fields: a proposal carries the QC of its parent\n")
    rows = [
        ["distinct blocks (hash) seen in the log"] + [J[r]["blocks"]["n"] for r in RUNS],
        ["blocks whose 'parent' hash == 'cert' QC hash"] + [J[r]["blocks"]["parent_eq_qc"] for r in RUNS],
        ["blocks whose cert lists 3 distinct signers"] + [J[r]["blocks"]["qc_three_distinct"] for r in RUNS],
        ["blocks with known parent; QC view == parent view"] + ["%d / %d" % (J[r]["blocks"]["qc_view_eq_parent_view"], J[r]["blocks"]["parent_known"]) for r in RUNS],
        ["parent-link view gap (1 / 2 / 3 / more)"] + [" / ".join(str(J[r]["blocks"]["gap"].get(g, 0)) for g in (1, 2, 3)) + " / " + str(sum(n for g, n in J[r]["blocks"]["gap"].items() if g > 3)) for r in RUNS],
    ]
    P(mdutil.table(["property"] + RUNS, rows))
    P("")

    P("## 4F. Stage latencies inside class-N views (ms from the log timestamps, resolution 1 ms; median / p90 / max)\n")
    stage = [("propagation", "proposer TryCommit(B_v) -> first 'Received proposal'"), ("receiver", "'Received proposal' -> TryCommit(B_v) at the receiver"),
             ("vote_net", "voter TryCommit(B_v) -> its CollectVote line at the collector (voter != collector)"), ("vote_own", "collector TryCommit(B_v) -> its own CollectVote line"),
             ("verify", "3rd distinct CollectVote line -> QC dispatch"), ("adv", "QC dispatch -> 'Advanced to view v+1' at the collector"),
             ("propose", "'Advanced to view v+1' -> TryCommit(B_{v+1}) at the collector"), ("cycle", "TryCommit(B_v) at p -> TryCommit(B_{v+1}) at the collector")]
    rows = []
    for k, lab in stage:
        rows.append([lab] + ["%s / %s / %s" % (mdutil.fmt(float(J[r]["latency"].get(k, {}).get("median", float("nan"))), 1), mdutil.fmt(float(J[r]["latency"].get(k, {}).get("p90", float("nan"))), 0), mdutil.fmt(float(J[r]["latency"].get(k, {}).get("max", float("nan"))), 0)) for r in RUNS])
    P(mdutil.table(["stage"] + RUNS, rows))
    P("")
    print("\n".join(out))
    mdutil.dump_json(dict(runs=J, flat=F), os.path.join(OUTDIR, "part4.json"))


if __name__ == "__main__":
    main()
