#!/usr/bin/env python3
"""common.py - loads (and caches) the parsed logs; shared by all analysis scripts."""
import os
import sys
import pickle

SCRIPTS = os.path.dirname(os.path.abspath(__file__))
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)
import hsparse as H  # noqa: E402

OUT = os.environ.get("HS_OUT", os.path.join(os.path.dirname(SCRIPTS), "out"))      # cache + result files
CACHE = os.path.join(OUT, "parsed.pkl")


def load(force=False):
    if not force and os.path.exists(CACHE):
        with open(CACHE, "rb") as f:
            return pickle.load(f)
    data = {}
    for run, path in H.LOGS.items():
        evs = H.parse_log(path)
        reg, coll = H.build_block_registry(evs)
        data[run] = dict(events=evs, blocks=reg, collisions=coll)
    os.makedirs(OUT, exist_ok=True)
    with open(CACHE, "wb") as f:
        pickle.dump(data, f)
    return data
