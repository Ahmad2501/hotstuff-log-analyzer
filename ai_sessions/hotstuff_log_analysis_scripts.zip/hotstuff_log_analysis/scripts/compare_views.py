#!/usr/bin/env python3
"""compare_views.py - check verify_views.sh output (grep/awk/comm) against part3.json (Python).
   usage: compare_views.py [verify_views.txt] [part3.json]"""
import itertools
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("HS_OUT", os.path.join(HERE, "..", "out"))
txt = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT, "verify_views.txt")
j3 = json.load(open(sys.argv[2] if len(sys.argv) > 2 else os.path.join(OUT, "part3.json")))
sh = {}
for ln in open(txt):
    if "=" in ln and not ln.startswith("=="):
        k, v = ln.split("=", 1)
        sh[k.strip()] = v.split("#")[0].strip()
RUNS = ["main", "main_2", "main_3", "main_4"]
bad = 0
n = 0


def chk(name, a, b):
    global bad, n
    n += 1
    if str(a) != str(b):
        bad += 1
        print("MISMATCH", name, "shell:", a, "python:", b)


cov = j3["coverage"]
chk("views_in_all_four", sh["views_in_all_four"], cov["inter4"])
chk("active_views_in_all_four", sh["active_views_in_all_four"], cov["inter4_active"])
chk("views_in_union", sh["views_in_union"], cov["union"])
for a in RUNS:
    for b in RUNS:
        chk(f"pair.{a}.{b}", sh[f"pair.{a}.{b}"], cov["pairwise"][a][b])
T = j3["timeouts"]
for r in RUNS:
    chk(f"local_timeout_views_active.{r}", sh[f"local_timeout_views_active.{r}"], len(T["per_run"][r]["active"]))
all4 = ",".join(str(v) for v in T["all4_active"])
chk("timeout_views_in_all_four", sh["timeout_views_in_all_four"], all4)
chk("local_timeout_views_in_all_four", sh["local_timeout_views_in_all_four"], ",".join(str(v) for v in T["all4_local"]))
for a, b in itertools.combinations(RUNS, 2):
    s = sorted(set(T["per_run"][a]["active"]) & set(T["per_run"][b]["active"]))
    chk(f"timeout_overlap.{a}.{b}", sh[f"timeout_overlap.{a}.{b}"], ",".join(map(str, s)))
chk("distinct_view_numbers == distinct (view,proposer) pairs", sh["distinct_view_numbers"], sh["distinct_view_proposer_pairs"])
chk("proposer_not_leader_view", sh["proposer_not_leader_view"], 0)
print(f"compared {n} values (grep/awk/comm vs python): {bad} mismatches")
