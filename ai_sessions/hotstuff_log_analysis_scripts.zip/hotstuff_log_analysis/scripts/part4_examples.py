#!/usr/bin/env python3
"""part4_examples.py - verbatim excerpts from the raw logs that illustrate the Part-4 findings (written to out/part4_examples.md).
Each excerpt = the log lines of selected replicas inside a physical line range, restricted to the event types that matter for the chain.
Columns kept: physical line number, logger, message (timestamp and source-file columns are dropped to save space; they are in the log)."""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hsparse as H     # noqa: E402
import views            # noqa: E402

D = views.load_annotated()
OUT = os.environ.get("HS_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out"))
KEEP = {"RECV_PROPOSAL", "TRY_COMMIT", "ADVANCE_ENTER", "HQC_UPDATED", "HQC_NOT_UPDATED", "FAIL_VERIFY_SYNCINFO", "ADVANCED", "ON_NEW_VIEW", "COLLECT_VOTE", "QC_DISPATCH",
        "LOCAL_TIMEOUT_VIEW", "REMOTE_TIMEOUT", "NOT_ENOUGH_TIMEOUTS", "REMOTE_TIMEOUT_2ND", "PROPOSAL_TOO_OLD", "DELAY_PROPOSAL", "BLOCK_TOO_OLD"}


def name_of(msg):
    for rx, nm in H.MSG_RULES:
        if rx.search(msg):
            return nm
    return None


def excerpt(run, replicas, a, b, keep=KEEP, extra_types=(), maxlen=250):
    path = H.LOGS[run]
    out = []
    with open(path) as f:
        for n, line in enumerate(f, 1):
            if n < a:
                continue
            if n > b:
                break
            p = line.rstrip("\n").split("\t", 4)
            if len(p) < 5:
                continue
            lg, msg = p[2], p[4]
            if lg not in replicas:
                continue
            nm = name_of(msg)
            if nm in keep or nm in extra_types:
                out.append(f"{n:>7}  {lg}  {msg[:maxlen]}")
    return out


def line_of(run, ev, r, pred=lambda e: True, after=0):
    for e in D[run]["events"]:
        if e["n"] > after and e["ev"] == ev and e["r"] == r and pred(e):
            return e["n"]
    return None


def main():
    res = []
    P = res.append
    # ------------------------------------------------------------------ E1: a normal view (main, view 1000: proposer hs1, collector hs2)
    run, v = "main", 1000
    a = line_of(run, "TRY_COMMIT", 1, lambda e: e["blk"]["view"] == v)
    c = (v + 1) % 4 + 1
    b = line_of(run, "TRY_COMMIT", c, lambda e: e["blk"]["view"] == v + 1)
    P(f"### E1  {run}.log, view {v} (proposer hs1, collector hs{c}) - the complete normal chain, lines {a}-{b} (hs1 proposer, hs3 receiver, hs{c} collector)\n")
    P("```")
    P("\n".join(excerpt(run, {"hs1", "hs3", f"hs{c}"}, a, b)))
    P("```\n")
    # ------------------------------------------------------------------ E2: QC formed after the collector left the view (main_2, view 896)
    run, v = "main_2", 896
    c = (v + 1) % 4 + 1
    a = line_of(run, "COLLECT_VOTE", c, lambda e: e["hash"] == D[run]["blocks"] and False) if False else None
    h = [hh for hh, bb in D[run]["blocks"].items() if bb["view"] == v][0]
    a = line_of(run, "COLLECT_VOTE", c, lambda e: e["hash"] == h)
    qe = [e["n"] for e in D[run]["events"] if e["ev"] == "ADVANCE_ENTER" and e["r"] == c and e["qc"] and e["qc"][0] == h and e["n"] > a]
    b = line_of(run, "TRY_COMMIT", c, lambda e: e["blk"]["view"] == v + 1)
    b = max(b, qe[0] + 12) if qe else b + 12
    P(f"### E2  {run}.log, view {v} (collector hs{c}): QC_{v} is formed (dispatch prints current : {v}) but the TC for view {v} advances the collector first - lines {a}-{b}, hs{c} only\n")
    P("```")
    P("\n".join(excerpt(run, {f"hs{c}"}, a - 1, b)))
    P("```\n")
    # ------------------------------------------------------------------ E3: dispatch printed with the NEXT view (main_3, view 2968)
    run, v = "main_3", 2968
    c = (v + 1) % 4 + 1
    h = [hh for hh, bb in D[run]["blocks"].items() if bb["view"] == v][0]
    a = line_of(run, "COLLECT_VOTE", c, lambda e: e["hash"] == h)
    qe = [e["n"] for e in D[run]["events"] if e["ev"] == "ADVANCE_ENTER" and e["r"] == c and e["qc"] and e["qc"][0] == h and e["n"] > a]
    b = qe[0] + 3
    P(f"### E3  {run}.log, view {v} (collector hs{c}): TC-driven advance to {v + 1} first, QC_{v} dispatched afterwards (dispatch prints current : {v + 1}) - lines {a}-{b}, hs{c} only\n")
    P("```")
    P("\n".join(excerpt(run, {f"hs{c}"}, a - 1, b)))
    P("```\n")
    # ------------------------------------------------------------------ E4: no QC (main_2, view 897: only one distinct CollectVote)
    run, v = "main_2", 897
    c = (v + 1) % 4 + 1
    h = [hh for hh, bb in D[run]["blocks"].items() if bb["view"] == v][0]
    a = line_of(run, "COLLECT_VOTE", c, lambda e: e["hash"] == h)
    allv = [e["n"] for e in D[run]["events"] if e["ev"] == "COLLECT_VOTE" and e["r"] == c and e["hash"] == h]
    b = allv[-1] + 1
    P(f"### E4  {run}.log, view {v} (collector hs{c}): votes for B_{v} that reach the collector (all lines of this hash) - lines {a}-{b}\n")
    P("```")
    P("\n".join(excerpt(run, {f"hs{c}"}, a, b, keep={"COLLECT_VOTE", "QC_DISPATCH", "BLOCK_TOO_OLD"}, extra_types=("CACHE_MISS",))))
    P("```\n")
    # ------------------------------------------------------------------ E5: proposals arrive out of order (main_4, hs4, views 1672/1673)
    run, rep = "main_4", 4
    n = [d["line"] for d in []]  # placeholder (kept for clarity)
    dl = [e for e in D[run]["events"] if e["ev"] == "DELAY_PROPOSAL"][0]
    a, b = dl["n"] - 8, dl["n"] + 22
    P(f"### E5  {run}.log, hs{rep}: B_{dl['prop_view']} arrives before B_{dl['prop_view'] - 1} ('Delaying proposal until after next view change') - lines {a}-{b}, hs{rep} only\n")
    P("```")
    P("\n".join(excerpt(run, {f"hs{rep}"}, a, b)))
    P("```\n")
    # ------------------------------------------------------------------ E6: a proposal rejected as 'too old' (main, view 397 at hs1)
    run = "main"
    to = [e for e in D[run]["events"] if e["ev"] == "PROPOSAL_TOO_OLD"][0]
    a, b = to["n"] - 40, to["n"] + 2
    P(f"### E6  {run}.log, hs1: B_{to['blk_view']} reaches hs1 after hs1 has already voted in view {to['last_vote']} - lines {a}-{b}, hs1 only\n")
    P("```")
    P("\n".join(excerpt(run, {"hs1"}, a, b)))
    P("```\n")
    txt = "\n".join(res)
    with open(os.path.join(OUT, "part4_examples.md"), "w") as f:
        f.write(txt)
    print(txt)


if __name__ == "__main__":
    main()
