"""Tiny helpers to print GitHub-flavoured markdown tables and to dump JSON."""
import json
import os


def fmt(x, nd=1):
    if isinstance(x, float):
        if x != x:
            return "n/a"
        return f"{x:,.{nd}f}"
    if isinstance(x, int):
        return f"{x:,}"
    return str(x)


def table(headers, rows, align=None, nd=1):
    """headers: list[str]; rows: list[list]; align: string like 'lrrr'."""
    align = align or ("l" + "r" * (len(headers) - 1))
    out = []
    out.append("| " + " | ".join(headers) + " |")
    sep = []
    for a in align:
        sep.append(":---" if a == "l" else ("---:" if a == "r" else ":---:"))
    out.append("| " + " | ".join(sep) + " |")
    for r in rows:
        out.append("| " + " | ".join(fmt(c, nd) for c in r) + " |")
    return "\n".join(out)


def dump_json(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, sort_keys=True, default=str)
