#!/usr/bin/env python3
"""Part 1 - pattern counts per run (raw-line regex == grep semantics), active/drain split, rates, and relation to view progression."""
import re
import sys
import collections
import statistics
import math
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import views            # noqa: E402
import mdutil           # noqa: E402
import part1_extra      # noqa: E402
from scipy import stats  # noqa: E402

H = views.H
RUNS = H.RUNS
D = views.load_annotated()

# --------------------------------------------------------------------------------------------------------------
# 1A. exact patterns (ERE, same text that is used in verify_counts.sh)
# --------------------------------------------------------------------------------------------------------------
from patterns import PATTERNS  # noqa: E402


def raw_lines(run):
    with open(H.LOGS[run], errors="replace") as f:
        return [ln.rstrip("\n") for ln in f]


def count_patterns():
    res = {}
    for run in RUNS:
        lines = raw_lines(run)
        stop_n = next(i for i, ln in enumerate(lines, 1) if "Stopping clients..." in ln)
        start_n = next(i for i, ln in enumerate(lines, 1) if "Starting to send commands" in ln)
        for label, pat in PATTERNS:
            rx = re.compile(pat)
            tot = act = drain = 0
            for i, ln in enumerate(lines, 1):
                if rx.search(ln):
                    tot += 1
                    if i < stop_n:
                        act += 1
                    elif i > stop_n:
                        drain += 1
            res[(run, label)] = (tot, act, drain)
        res[(run, "_stop_n")] = stop_n
    return res


C = count_patterns()


def views_stats():
    out = {}
    for run in RUNS:
        evs = D[run]["events"]
        stop = next(e for e in evs if e["ev"] == "CTRL_STOP_CLIENTS")
        start = next(e for e in evs if e["ev"] == "CLIENT_START")
        first = {}
        for e in evs:
            if e["ev"] in ("TRY_COMMIT", "RECV_PROPOSAL") and e["blk"]:
                first.setdefault(e["blk"]["view"], (e["t"], e["n"]))
        blocks = sorted(v for v in first if v >= 1)
        v_act = sum(1 for v in blocks if first[v][1] < stop["n"])
        adv_max_all = max(e["view"] for e in evs if e["ev"] == "ADVANCED")
        adv_max_act = max(e["view"] for e in evs if e["ev"] == "ADVANCED" and e["n"] < stop["n"])
        done = next((e for e in evs if e["ev"] == "CLIENT_DONE"), None)
        out[run] = dict(blocks=len(blocks), v_act=v_act, v_drain=len(blocks) - v_act, max_view_entered=adv_max_all,
                        max_view_active=adv_max_act, active_s=(stop["t"] - start["t"]) / 1000.0,
                        executed=done.get("executed") if done else None, client_timeouts=done.get("timeouts") if done else None,
                        qc_formed=sum(1 for e in evs if e["ev"] == "QC_DISPATCH"))
        out[run]["views_per_s"] = out[run]["v_act"] / out[run]["active_s"]
    return out


VS = views_stats()


def poisson_homog(counts, expos):
    tot = sum(counts)
    E = sum(expos)
    exp = [tot * e / E for e in expos]
    chi = sum((c - x) ** 2 / x for c, x in zip(counts, exp) if x > 0)
    return chi, stats.chi2.sf(chi, len(counts) - 1)


def main():
    out = []
    P = out.append
    P("## 1A. Pattern counts: total (active phase / drain phase) - raw-line regex, identical to the grep commands in verify_counts.sh\n")
    hdr = ["Pattern (ERE)"] + [f"{r}" for r in RUNS] + ["main_2 / mean(other 3), active rate"]
    rows = []
    for label, pat in PATTERNS:
        row = [f"`{pat}`" if False else label]
        for run in RUNS:
            t, a, d = C[(run, label)]
            row.append(f"{t:,} ({a:,} / {d:,})")
        acts = [C[(run, label)][1] for run in RUNS]
        rates = [acts[i] / VS[RUNS[i]]["v_act"] for i in range(4)]
        base = statistics.mean([rates[0], rates[2], rates[3]])
        row.append(f"{rates[1] / base:.2f}x" if base > 0 else "n/a")
        rows.append(row)
    P(mdutil.table(hdr, rows, align="lrrrrr"))
    P("")
    P("Active phase = lines before 'Stopping clients...' (10.0 s of client load); drain phase = the 2.5 s after it. Ratio = main_2 active events per active view divided by the mean of the same ratio in main, main_3, main_4.\n")

    P("## 1B. Run-level view progression\n")
    hdr = ["metric"] + RUNS
    rows = []
    for key, name in [("active_s", "client-load duration (s)"), ("blocks", "views with a proposal (total)"), ("v_act", "views with a proposal first seen in active phase"),
                      ("v_drain", "views with a proposal first seen in drain phase"), ("max_view_active", "highest view entered (active phase, any replica)"),
                      ("max_view_entered", "highest view entered (whole log)"), ("qc_formed", "QCs formed by vote collection"), ("views_per_s", "active-phase proposals per second"),
                      ("executed", "client: commands executed"), ("client_timeouts", "client: command timeouts")]:
        rows.append([name] + [VS[r][key] if not isinstance(VS[r][key], float) else round(VS[r][key], 1) for r in RUNS])
    P(mdutil.table(hdr, rows))
    P("")

    P("## 1C. Rate comparison of active-phase events per 1,000 proposed views, with homogeneity test across the 4 runs\n")
    sel = ["P1  block too old", "P1b 'too old, last voted view was' (proposal path)", "P2  Failed to verify sync info", "P3b   OnLocalTimeout: <view>",
           "P3a   OnLocalTimeout (bare, line end)", "P4a   OnRemoteTimeout (advancing view)", "P4b   OnRemoteTimeout (second advance)", "P5  not enough timeouts",
           "P5b Failed to create sync info (overlapping sigs)", "P6  HighQC updated", "P7  HighQC not updated", "P8  view advancement (Advanced to view)",
           "P9b CommitRule PRE_COMMIT", "P9c CommitRule COMMIT", "P9d CommitRule DECIDE", "P9e EXEC", "X1  Received proposal", "X2  CollectVote(from N)",
           "X3  QC formed (dispatching event for new view)", "X4  Local cache miss for block", "P8b   OnNewView"]
    hdr = ["pattern (active phase)"] + [f"{r} /1k views" for r in RUNS] + ["chi2 4 runs (df=3)", "p 4 runs", "chi2 main/main_3/main_4 (df=2)", "p 3 runs"]
    rows = []
    for label in sel:
        counts = [C[(r, label)][1] for r in RUNS]
        expos = [VS[r]["v_act"] for r in RUNS]
        chi, p = poisson_homog(counts, expos)
        c3 = [counts[0], counts[2], counts[3]]
        e3 = [expos[0], expos[2], expos[3]]
        chi3, p3 = poisson_homog(c3, e3)
        rows.append([label] + [f"{1000 * c / e:,.1f}" for c, e in zip(counts, expos)] + [f"{chi:,.1f}", f"{p:.2g}", f"{chi3:,.1f}", f"{p3:.2g}"])
    P(mdutil.table(hdr, rows, align="lrrrrrrrr"))
    P("")
    P("(p-values assume independent events; timeouts and late votes are clustered, so treat p only as a rough guide, not as proof.)\n")

    # ---------------------------------------------------------------------------------------------------------
    # 1D. advance causes (what moved each replica into a new view)
    # ---------------------------------------------------------------------------------------------------------
    P("## 1D. What caused each 'Advanced to view N' (trigger = the event that preceded the advanceView call on that replica)\n")
    hdr = ["trigger"] + [f"{r} act / drain" for r in RUNS]
    trig_names = collections.OrderedDict([("RECV_PROPOSAL", "attached QC of a received proposal"), ("ON_NEW_VIEW_LOCAL", "QC formed locally from votes (collector)"),
                                          ("REMOTE_TIMEOUT_2ND", "timeout certificate (TC) formed from timeout messages"), ("REMOTE_TIMEOUT", "QC inside a remote timeout message"),
                                          ("ON_NEW_VIEW_OTHER", "other OnNewView (QC already known)")])
    rows = []
    for tk, tn in trig_names.items():
        row = [f"{tn}"]
        for r in RUNS:
            a = sum(1 for e in D[r]["events"] if e["ev"] == "ADVANCED" and e.get("trigger") == tk and e["phase"] == "active")
            d = sum(1 for e in D[r]["events"] if e["ev"] == "ADVANCED" and e.get("trigger") == tk and e["phase"] == "drain")
            row.append(f"{a:,} / {d:,}")
        rows.append(row)
    row = ["total ADVANCED"]
    for r in RUNS:
        a = sum(1 for e in D[r]["events"] if e["ev"] == "ADVANCED" and e["phase"] == "active")
        d = sum(1 for e in D[r]["events"] if e["ev"] == "ADVANCED" and e["phase"] == "drain")
        row.append(f"{a:,} / {d:,}")
    rows.append(row)
    P(mdutil.table(hdr, rows))
    P("")

    P("## 1E. HighQC updated / not updated by trigger (all phases)\n")
    hdr = ["outcome  <-  trigger"] + RUNS
    keys = [("HQC_UPDATED", "RECV_PROPOSAL"), ("HQC_UPDATED", "ON_NEW_VIEW_LOCAL"), ("HQC_UPDATED", "REMOTE_TIMEOUT"), ("HQC_UPDATED", "ON_NEW_VIEW_OTHER"),
            ("HQC_NOT_UPDATED", "ON_NEW_VIEW_OTHER"), ("HQC_NOT_UPDATED", "REMOTE_TIMEOUT"), ("HQC_NOT_UPDATED", "REMOTE_TIMEOUT_2ND"),
            ("HQC_NOT_UPDATED", "RECV_PROPOSAL"), ("HQC_NOT_UPDATED", "ON_NEW_VIEW_LOCAL"), ("FAIL_VERIFY_SYNCINFO", "REMOTE_TIMEOUT_2ND"), ("FAIL_VERIFY_SYNCINFO", "REMOTE_TIMEOUT")]
    rows = []
    for ev, tk in keys:
        rows.append([f"{ev} <- {tk}"] + [sum(1 for e in D[r]["events"] if e["ev"] == ev and e.get("trigger") == tk) for r in RUNS])
    rows.append(["HQC_UPDATED total"] + [sum(1 for e in D[r]["events"] if e["ev"] == "HQC_UPDATED") for r in RUNS])
    rows.append(["HQC_NOT_UPDATED total"] + [sum(1 for e in D[r]["events"] if e["ev"] == "HQC_NOT_UPDATED") for r in RUNS])
    rows.append(["HQC_UPDATED per proposed view"] + [round(sum(1 for e in D[r]["events"] if e["ev"] == "HQC_UPDATED") / VS[r]["blocks"], 3) for r in RUNS])
    rows.append(["HQC_NOT_UPDATED per proposed view"] + [round(sum(1 for e in D[r]["events"] if e["ev"] == "HQC_NOT_UPDATED") / VS[r]["blocks"], 3) for r in RUNS])
    P(mdutil.table(hdr, rows, nd=3))
    P("")

    # ---------------------------------------------------------------------------------------------------------
    # 1F. timeouts anatomy (active phase): views with local timeouts, number of replicas, outcome
    # ---------------------------------------------------------------------------------------------------------
    P("## 1F. Anatomy of active-phase local timeouts (views where >=1 replica logged 'OnLocalTimeout: V')\n")
    anat = {}
    for r in RUNS:
        evs = D[r]["events"]
        lto = collections.defaultdict(set)
        for e in evs:
            if e["ev"] == "LOCAL_TIMEOUT_VIEW" and e["phase"] == "active":
                lto[e["view"]].add(e["r"])
        qc_formed = {e["v"] for e in evs if e["ev"] == "QC_DISPATCH"}
        tc_adv = collections.defaultdict(set)      # timed-out view -> replicas advanced via TC (ADVANCE_ENTER trigger 2ND then ADVANCED)
        byn = {e["n"]: e for e in evs}
        for e in evs:
            if e["ev"] == "ADVANCED" and e.get("trigger") == "REMOTE_TIMEOUT_2ND":
                tc_adv[e["view"] - 1].add(e["r"])
        hist = collections.Counter(len(s) for s in lto.values())
        cat = collections.Counter()
        for v, s in lto.items():
            qc = v in qc_formed
            tc = bool(tc_adv.get(v))
            cat[("QC formed, no TC advance" if (qc and not tc) else ("QC formed AND TC advance" if (qc and tc) else ("TC advance, no QC" if tc else "neither QC nor TC advance")))] += 1
        anat[r] = dict(n_views=len(lto), hist=dict(hist), cat=dict(cat), n_events=sum(len(s) for s in lto.values()))
    hdr = ["metric"] + RUNS
    rows = [["views with >=1 local timeout (active)"] + [anat[r]["n_views"] for r in RUNS],
            ["... as share of active views (%)"] + [round(100 * anat[r]["n_views"] / VS[r]["v_act"], 2) for r in RUNS],
            ["local-timeout events (replica x view)"] + [anat[r]["n_events"] for r in RUNS]]
    for k in (1, 2, 3, 4):
        rows.append([f"views where exactly {k} replica(s) timed out"] + [anat[r]["hist"].get(k, 0) for r in RUNS])
    for cname in ["QC formed, no TC advance", "QC formed AND TC advance", "TC advance, no QC", "neither QC nor TC advance"]:
        rows.append([f"outcome: {cname}"] + [anat[r]["cat"].get(cname, 0) for r in RUNS])
    P(mdutil.table(hdr, rows))
    P("")

    # timeouts per replica: who fires first
    P("## 1G. Timeout events by replica (active phase)\n")
    hdr = ["event"] + [f"{r}: hs1/hs2/hs3/hs4" for r in RUNS]
    rows = []
    for ev in ["LOCAL_TIMEOUT_VIEW", "LOCAL_TIMEOUT", "NOT_ENOUGH_TIMEOUTS", "REMOTE_TIMEOUT_2ND", "FAIL_VERIFY_SYNCINFO", "BLOCK_TOO_OLD", "CACHE_MISS", "PROPOSAL_TOO_OLD"]:
        row = [ev]
        for r in RUNS:
            c = collections.Counter(e["r"] for e in D[r]["events"] if e["ev"] == ev and e["phase"] == "active")
            row.append("/".join(str(c.get(k, 0)) for k in H.REPLICAS))
        rows.append(row)
    # timeout messages by sender id
    row = ["REMOTE_TIMEOUT by sender ID (msg 'ID:')"]
    for r in RUNS:
        c = collections.Counter(e["from_id"] for e in D[r]["events"] if e["ev"] == "REMOTE_TIMEOUT" and e["phase"] == "active")
        row.append("/".join(str(c.get(k, 0)) for k in H.REPLICAS))
    rows.append(row)
    P(mdutil.table(hdr, rows, align="lrrrr"))
    P("")

    s1h, tabs = part1_extra.section_1h(H, D, C, RUNS)
    P(s1h)
    s1i, rt = part1_extra.section_1i(H, D, RUNS, C)
    P(s1i)
    s1j, bto = part1_extra.section_1j(H, D, RUNS)
    P(s1j)
    s1k, chain = part1_extra.section_1k(H, D, RUNS)
    P(s1k)

    print("\n".join(out))
    for r in RUNS:                                   # do not dump the long hash lists
        for k in chain[r]["per"]:
            chain[r]["per"][k].pop("exec_hashes", None)
    mdutil.dump_json(dict(patterns={f"{r}|{l}": C[(r, l)] for r in RUNS for l, _ in PATTERNS}, views=VS, anat=anat,
                          tc_consistency={r: {f"{a}/{b}": v for (a, b), v in tabs[r].items()} for r in RUNS},
                          remote_timeout_outcomes={r: dict(rt[r]) for r in RUNS},
                          chain={r: dict(per=chain[r]["per"], r1={str(k): v for k, v in chain[r]["r1"].items()}, r2={str(k): v for k, v in chain[r]["r2"].items()},
                                         same_prefix=chain[r]["same_prefix"], same_len=chain[r]["same_len"], prefix_len=chain[r]["prefix_len"],
                                         parent_gap=dict(chain[r]["parent_gap"])) for r in RUNS}), os.path.join(os.environ.get("HS_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")), "part1.json"))


if __name__ == "__main__":
    main()
