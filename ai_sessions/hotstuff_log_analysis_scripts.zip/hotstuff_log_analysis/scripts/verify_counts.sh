#!/usr/bin/env bash
# verify_counts.sh - independent re-count of every Part-1 pattern with plain grep (GNU grep -E) and awk.
#   usage:  ./verify_counts.sh [LOGDIR] [OUT_TSV]
#   LOGDIR  directory holding main.log main_2.log main_3.log main_4.log   (default .)
#   OUT_TSV machine-readable result (default ./verify_counts.tsv): id <TAB> run <TAB> scope <TAB> count
# Scopes: total = whole file; active = lines BEFORE the first 'Stopping clients...' line; drain = lines AFTER it;
#         hs1..hs4 = lines written by that replica logger (tab-separated field 3).
set -u
LOGDIR=${1:-.}
OUT=${2:-./verify_counts.tsv}
RUNS="main main_2 main_3 main_4"
TAB=$(printf '\t')

# id|label|ERE (identical text to PATTERNS in part1_counts.py)
read -r -d '' PATS <<'PEOF'
P1|block too old|block too old
P1b|too old, last voted view was (proposal path)|too old, last voted view was
P2|Failed to verify sync info|Failed to verify sync info
P2a|  ... timeout certificate / ecdsa signature|Failed to verify sync info: failed to verify timeout certificate: ecdsa: failed to verify signature from replica
P2b|  ... quorum certificate / block not found|Failed to verify sync info: failed to verify quorum certificate: block not found
P3|OnLocalTimeout (substring)|OnLocalTimeout
P3a|  OnLocalTimeout (bare, line end)|OnLocalTimeout$
P3b|  OnLocalTimeout: <view>|OnLocalTimeout: [0-9]+$
P3c|  Stopped voting for timed out view|Stopped voting for timed out view
P4|OnRemoteTimeout (substring)|OnRemoteTimeout
P4a|  OnRemoteTimeout (advancing view)|OnRemoteTimeout \(advancing view\)
P4b|  OnRemoteTimeout (second advance)|OnRemoteTimeout \(second advance\)
P5|not enough timeouts|not enough timeouts
P5b|Failed to create sync info (overlapping sigs)|Failed to create sync info
P6|HighQC updated|advanceView: Successfully updated HighQC
P7|HighQC not updated|advanceView: HighQC not updated
P8|view advancement (Advanced to view)|advanceView: Advanced to view
P8a|  advanceView entered (every call)|advanceView: \{
P8b|  OnNewView|OnNewView
P9a|TryCommit|TryCommit:
P9b|CommitRule PRE_COMMIT|CommitRule - PRE_COMMIT
P9c|CommitRule COMMIT|CommitRule - COMMIT
P9d|CommitRule DECIDE|CommitRule - DECIDE
P9e|EXEC|EXEC:
X1|Received proposal|Received proposal
X2|CollectVote(from N)|CollectVote\(from
X3|QC formed (dispatching event for new view)|CollectVote: dispatching event for new view
X4|Local cache miss for block|Local cache miss for block
X5|Could not find block for vote|Could not find block for vote
X6|Delaying proposal until after next view change|Delaying proposal until after next view change
X7|Failed to create proposal (no command batch)|Failed to create proposal
X8|block already exists (WARN)|block already exists
X9|PruneToHeight: found forked block|found forked block
X10|Attempting to fetch block|Attempting to fetch block
X11|On RequestBlock|On RequestBlock
X12|client: Command timed out|Command timed out
X13|VoteRule: liveness condition failed|VoteRule: liveness condition failed
PEOF

: > "$OUT"
printf '%-5s %-52s' "id" "pattern (ERE in verify_counts.sh)"
for r in $RUNS; do printf ' | %-26s' "$r total (active/drain)"; done; echo
for r in $RUNS; do
  f="$LOGDIR/$r.log"
  [ -r "$f" ] || { echo "cannot read $f" >&2; exit 1; }
  STOP=$(grep -n 'Stopping clients\.\.\.' "$f" | head -1 | cut -d: -f1)
  eval "STOP_$r=$STOP"
done

while IFS='|' read -r id label ere; do
  [ -z "$id" ] && continue
  printf '%-5s %-52s' "$id" "$label"
  for r in $RUNS; do
    f="$LOGDIR/$r.log"; eval "STOP=\$STOP_$r"
    tot=$(grep -cE -- "$ere" "$f")
    act=$(head -n $((STOP-1)) "$f" | grep -cE -- "$ere")
    drn=$(tail -n +$((STOP+1)) "$f" | grep -cE -- "$ere")
    printf ' | %6s (%6s / %5s)  ' "$tot" "$act" "$drn"
    printf '%s\t%s\ttotal\t%s\n%s\t%s\tactive\t%s\n%s\t%s\tdrain\t%s\n' "$id" "$r" "$tot" "$id" "$r" "$act" "$id" "$r" "$drn" >> "$OUT"
    for k in 1 2 3 4; do
      c=$(grep -cE -- "^[^${TAB}]*${TAB}[A-Z]+${TAB}hs${k}${TAB}.*${ere}" "$f")
      printf '%s\t%s\ths%s\t%s\n' "$id" "$r" "$k" "$c" >> "$OUT"
    done
  done
  echo
done <<< "$PATS"

echo
echo "STOP line (first 'Stopping clients...') per run:"; for r in $RUNS; do eval "echo \"  $r: line \$STOP_$r of \$(wc -l < $LOGDIR/$r.log)\""; done

# ---- derived numbers that do not come from a single pattern ------------------------------------------------------
echo
echo "Distinct views that carry a proposal (view >= 1) seen in 'Received proposal' or 'TryCommit' lines:"
for r in $RUNS; do
  f="$LOGDIR/$r.log"
  n=$(grep -E 'Received proposal|TryCommit:' "$f" | grep -oE 'proposer: [0-9]+, view: [0-9]+' | sed -E 's/.*view: //' | sort -un | awk '$1>=1' | wc -l)
  echo "  $r: $n"
  printf 'DV1\t%s\ttotal\t%s\n' "$r" "$n" >> "$OUT"
done
echo
echo "Per-replica EXEC lines: view numbers strictly increasing? (awk) and number of EXEC lines"
for r in $RUNS; do
  f="$LOGDIR/$r.log"
  for k in 1 2 3 4; do
    awk -F'\t' -v L="hs$k" '$3==L && $0 ~ /EXEC:/ { if (match($0,/proposer: [0-9]+, view: [0-9]+/)) { s=substr($0,RSTART,RLENGTH); sub(/.*view: /,"",s); v=s+0; n++; if (n>1 && v<=last) bad++; last=v } }
         END { printf "  %s hs%s: EXEC lines=%d  non-increasing steps=%d  last executed view=%d\n", "'"$r"'", "'"$k"'", n, bad+0, last }' "$f"
  done
done
echo
echo "wrote $OUT"
