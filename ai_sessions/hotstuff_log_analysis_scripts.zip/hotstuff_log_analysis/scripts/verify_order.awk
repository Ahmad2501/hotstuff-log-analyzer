# verify_order.awk - independent (awk only) re-computation of the Part-4 ordering checks straight from one raw log file.
#   usage (called by verify_order.sh):  awk -F'\t' -v run=NAME -v STOP=<line of 'Stopping clients...'> -v CYC=<file for cycle times> -f verify_order.awk LOG
#   output: TSV  run <TAB> metric <TAB> value
#
# A log line is   <timestamp> <TAB> <level> <TAB> <logger hsK> <TAB> <source file:line> <TAB> <message>
# Ordering primitive = physical line number NR (the four replicas are interleaved in one file).
# Event types are recognised from the message text only (the same patterns as the grep table in verify_counts.sh):
#   RECV  'Received proposal: Block{...}'          TRY   'TryCommit: Block{...}'
#   ENTER 'advanceView: { ...QC{ hash: H, view: V, IDs: [ a b c ] }...}'    HQCU 'advanceView: Successfully updated HighQC'
#   HQCN  'advanceView: HighQC not updated, ...'     HQCF 'advanceView: Failed to verify sync info: ...'
#   ADV   'advanceView: Advanced to view N'          ONV   'OnNewView (from network: ...)'
#   VOTE  'CollectVote(from N): HASH'                DISP  'CollectVote: dispatching event for new view (current : N)'
#   SKIPC 'Local cache miss for block: ...'  SKIPB 'block too old'  SKIPH 'Hash: ...'   (lines of other goroutines that may interleave a chain)
#   PRE/COM/DEC/EXEC  'CommitRule - PRE_COMMIT/COMMIT/DECIDE: ...' / 'EXEC: ...'
# Block structure printed in the log:  Block{ hash: H parent: P, proposer: N, view: V , cert: QC{ hash: Q, view: W, IDs: [ a b c ] } }

function evtype(m) {
  if (m ~ /^Received proposal: /) return "RECV"
  if (m ~ /^TryCommit: /) return "TRY"
  if (m ~ /^advanceView: \{/) return "ENTER"
  if (m ~ /^advanceView: Successfully updated HighQC/) return "HQCU"
  if (m ~ /^advanceView: HighQC not updated/) return "HQCN"
  if (m ~ /^advanceView: Failed to verify sync info/) return "HQCF"
  if (m ~ /^advanceView: Advanced to view /) return "ADV"
  if (m ~ /^OnNewView \(from network/) return "ONV"
  if (m ~ /^CollectVote\(from [0-9]+\): /) return "VOTE"
  if (m ~ /^CollectVote: dispatching event/) return "DISP"
  if (m ~ /^Local cache miss for block: /) return "SKIPC"
  if (m == "block too old") return "SKIPB"
  if (m ~ /^Hash: /) return "SKIPH"
  if (m ~ /^CommitRule - PRE_COMMIT: /) return "PRE"
  if (m ~ /^CommitRule - COMMIT: /) return "COM"
  if (m ~ /^CommitRule - DECIDE: /) return "DEC"
  if (m ~ /^EXEC: /) return "EXEC"
  if (m ~ /^failed to verify incoming vote: /) return "TOOOLD"
  if (m ~ /^Delaying proposal until after next view change/) return "DELAY"
  if (m == "OnLocalTimeout") return "LTO"
  if (m ~ /^OnLocalTimeout: [0-9]+$/) return "LTOV"
  return "OTHER"
}
function parse_block(m,    t, nt, a, i, ids) {
  if (!match(m, /Block\{ hash: [^ ]+ parent: [^,]+, proposer: [0-9]+, view: [0-9]+ , cert: QC\{ hash: [^,]+, view: [0-9]+, IDs: \[[^]]*\]/)) return 0
  t = substr(m, RSTART, RLENGTH); gsub(/[][{},:]/, " ", t); nt = split(t, a, " ")
  BH = a[3]; BP = a[5]; BN = a[7] + 0; BV = a[9] + 0; BQ = a[13]; BW = a[15] + 0
  ids = ""; for (i = 17; i <= nt; i++) ids = ids (ids == "" ? "" : " ") a[i]
  BIDS = ids
  return 1
}
function parse_qc(m,    t, nt, a, i, ids) {
  QH = ""; QIDS = ""
  if (!match(m, /QC\{ hash: [^,]+, view: [0-9]+, IDs: \[[^]]*\]/)) return 0
  t = substr(m, RSTART, RLENGTH); gsub(/[][{},:]/, " ", t); nt = split(t, a, " ")
  QH = a[3]; QV = a[5] + 0
  ids = ""; for (i = 7; i <= nt; i++) ids = ids (ids == "" ? "" : " ") a[i]
  QIDS = ids
  return 1
}
function tsms(s,    hh, mm, ss, ms) {
  hh = substr(s, 12, 2) + 0; mm = substr(s, 15, 2) + 0; ss = substr(s, 18, 2) + 0; ms = substr(s, 21, 3) + 0
  return ((hh * 60 + mm) * 60 + ss) * 1000 + ms
}
function fin(k, reason) { chres[chain[k]] = reason; chain[k] = "" }
# one step of the collector chain  dispatch -> [other lines] -> OnNewView, advanceView(QC_v) -> HighQC updated -> Advanced to v+1 -> TryCommit(B_{v+1}) with QC_v
function chain_step(k, ev, pt,    h) {
  h = chain[k]
  if (stg[k] == 0) {
    if (ev == "ADV") { fin(k, "tc"); return }
    if (ev == "ENTER" && QH == h) {
      if (pt != "ONV") { fin(k, "noonv"); return }
      if (lastb[k] == "ONV") bcount[k]--
      if (bcount[k] > 0) btw[h] = 1
      stg[k] = 1; qeids[k] = QIDS; return
    }
    if (ev == "RECV" || ev == "TRY" || ev == "DISP") { fin(k, "next"); return }
    bcount[k]++; lastb[k] = ev; return
  }
  if (stg[k] == 1) { if (ev != "HQCU") { fin(k, "nohqc"); return } stg[k] = 2; return }
  if (stg[k] == 2) { if (ev != "ADV" || curV != dcur[k] + 1) { fin(k, "noadv"); return } stg[k] = 3; return }
  if (stg[k] == 3) {
    if (ev == "TRY" && BV == dcur[k] + 1 && BN == k && BQ == h && BIDS == qeids[k]) { chtryt[h] = tsms($1); fin(k, "complete") }
    else fin(k, "notry")
  }
}

BEGIN { vmax = 0; for (k = 1; k <= 4; k++) { curv[k] = 1; chain[k] = ""; await[k] = ""; hqwait[k] = ""; prevtype[k] = "" } }

{
  lg = $3
  if (lg !~ /^hs[1-4]$/) next
  K = substr(lg, 3) + 0
  msg = $5
  ev = evtype(msg)
  has_blk = 0
  if (index(msg, "Block{ hash: ") > 0) has_blk = parse_block(msg)
  curV = -1
  if (ev == "ENTER") parse_qc(msg)
  else if (ev == "ADV") { t = msg; sub(/^advanceView: Advanced to view /, "", t); curV = t + 0 }
  pt = prevtype[K]
  # ---- block registry (first sighting wins) and first proposal line per view
  if (has_blk) {
    h = BH
    if (!(h in bview)) { bview[h] = BV; bprop[h] = BN; bpar[h] = BP; bqc[h] = BQ; bqcv[h] = BW; nblk++; hl[nblk] = h }
    if (BIDS != "" && !(BQ in qcids)) qcids[BQ] = BIDS
    if (BV > vmax) vmax = BV
    if (!(BV in byview)) byview[BV] = h
    if ((ev == "RECV" || ev == "TRY") && !(BV in fprop)) fprop[BV] = NR
  }
  # ---- collector chain (needs the event type only; handled before the event's own bookkeeping)
  isskip = (ev ~ /^SKIP/ || ev == "VOTE") ? 1 : 0
  if (chain[K] != "" && !isskip) chain_step(K, ev, pt)

  if (ev == "RECV" && has_blk) {
    h = BH
    if (await[K] != "") { o3res[K, await[K]] = 0; await[K] = "" }
    if (!((K, h) in recvn)) { recvn[K, h] = NR; await[K] = h }
  } else if (ev == "TRY" && has_blk) {
    h = BH
    if (await[K] != "") { o3res[K, await[K]] = 0; await[K] = "" }
    if (!((K, h) in tryn)) { tryn[K, h] = NR; tryt[K, h] = tsms($1) }
    ng++; grh[ng] = h; grd[ng] = 0; curgrp[K] = ng
  } else if (ev == "ENTER") {
    if (QH != "") qenter_last[K, QH] = NR
    if (await[K] != "") {
      h = await[K]
      o3res[K, h] = (QH == bqc[h]) ? 1 : 0
      enterl[K, h] = NR
      await[K] = ""
      if (o3res[K, h]) hqwait[K] = h; else hqwait[K] = ""
    } else hqwait[K] = ""
  } else if (ev == "HQCU" || ev == "HQCN" || ev == "HQCF") {
    if (hqwait[K] != "") { hqk[K, hqwait[K]] = ev; hqwait[K] = "" }
  } else if (ev == "ADV") {
    curv[K] = curV
    if (!((K, curV) in advn)) advn[K, curV] = NR
    advc[K, curV]++; advl[K, curV, advc[K, curV]] = NR
  } else if (ev == "VOTE") {
    s = msg; sub(/^CollectVote\(from /, "", s); sub(/\).*$/, "", s); s = s + 0
    hh = msg; sub(/^CollectVote\(from [0-9]+\): /, "", hh)
    nvl[K, hh]++; vl[K, hh, nvl[K, hh]] = NR; vsd[K, hh, nvl[K, hh]] = s
    if (!((K, hh, s) in vfirst)) {
      vfirst[K, hh, s] = NR; dcount[K, hh]++
      if (dcount[K, hh] == 3) { q[K, ++qt[K]] = hh }
    }
  } else if (ev == "DISP") {
    t = msg; sub(/^CollectVote: dispatching event for new view \(current : /, "", t); sub(/\)$/, "", t); cur = t + 0
    if (NR < STOP) ndisp_act++
    if (qh[K] < qt[K]) {
      h = q[K, ++qh[K]]
      disp[K, h] = NR; dispcur[K, h] = cur
      if (cur != bview[h]) chres[h] = "late"
      else { chain[K] = h; stg[K] = 0; dcur[K] = cur; bcount[K] = 0; lastb[K] = "" }
    } else if (NR < STOP) unmatched_act++
  } else if (ev == "PRE" || ev == "COM") {
  } else if (ev == "DEC") {
    if (curgrp[K] > 0) grd[curgrp[K]] = 1
  } else if (ev == "TOOOLD") {
    # 'failed to verify incoming vote: block view N too old, last voted view was M'
    t = msg; sub(/^failed to verify incoming vote: block view /, "", t); nw = split(t, tw, " ")
    nn = tw[1] + 0; lv = tw[nw] + 0
    to_n[K, nn]++; to_line[K, nn, to_n[K, nn]] = NR; to_lv[K, nn, to_n[K, nn]] = lv
    ntoold++; if (lv == nn) ntoold_eq++; else ntoold_gt++
  } else if (ev == "DELAY") {
    ndelay++; if (NR < STOP) ndelay_act++
  } else if (ev == "LTO") {
    if (!((K, curv[K]) in locf)) locf[K, curv[K]] = NR
  } else if (ev == "LTOV") {
    t = msg; sub(/^OnLocalTimeout: /, "", t); t = t + 0
    if (!((K, t) in locf)) locf[K, t] = NR
  }
  if (!isskip) prevtype[K] = ev
}

END {
  for (k = 1; k <= 4; k++) if (chain[k] != "") fin(k, "cut")
  # ------------------------------------------------------------------------------------------------ blocks
  for (i = 1; i <= nblk; i++) {
    h = hl[i]
    if (bpar[h] == bqc[h]) peq++
    if (bview[h] >= 1 && (bpar[h] in bview)) gap[bview[h] - bview[bpar[h]]]++
  }
  out("blocks", nblk); out("blocks_parent_eq_qc", peq + 0)
  for (g in gap) out("gap" g, gap[g])
  # ------------------------------------------------------------------------------------------------ per view
  for (v = 3; v < vmax; v++) {
    if (!(v in fprop) || fprop[v] >= STOP) continue
    h = byview[v]; p = bprop[h]; c = (v + 1) % 4 + 1
    vt++
    fr = 0; nr = 0
    for (x = 1; x <= 4; x++) if ((x, h) in recvn) { nr++; if (fr == 0 || recvn[x, h] < fr) fr = recvn[x, h] }
    if (nr > 0 && ((p, h) in tryn)) { o1t++; if (tryn[p, h] < fr) o1p++ }
    if (nr > 0 && ((p, v) in advn)) { o2t++; if (advn[p, v] < fr) o2p++ }
    for (x = 1; x <= 4; x++) {
      if (!((x, h) in recvn)) continue
      o3t++
      if (!((x, h) in o3res) || o3res[x, h] != 1) continue
      o3p++
      if ((x, h) in tryn) {
        o4t++; if (enterl[x, h] < tryn[x, h]) o4p++
        k5 = hqk[x, h]; ab = 0
        for (i = 1; i <= advc[x, v]; i++) if (advl[x, v, i] > enterl[x, h] && advl[x, v, i] < tryn[x, h]) ab = 1
        if (k5 == "HQCU" && ab) o5_ua++
        else if (k5 == "HQCU") o5_u_already++
        else if (k5 == "HQCN" && ab) o5_n_adv++
        else if (k5 == "HQCN") o5_n_already++
        else o5_other++
      } else {
        o4t++; o4_rej++
        found = 0
        for (i = 1; i <= to_n[x, v]; i++) if (!found && to_line[x, v, i] > recvn[x, h]) {
          found = 1
          if (to_lv[x, v, i] == v && ((x, v) in locf) && locf[x, v] < recvn[x, h]) o4_rej_timeout++
          else if (to_lv[x, v, i] > v) o4_rej_later++
          else o4_rej_other++
        }
        if (!found) o4_rej_nolines++
      }
    }
    # votes at the collector
    for (i = 1; i <= nvl[c, h]; i++) {
      s = vsd[c, h, i]; o6t++
      if (((s, h) in tryn) && tryn[s, h] < vl[c, h, i]) o6p++
    }
    for (s = 1; s <= 4; s++) if ((s, h) in tryn) { o6bt++; if ((c, h, s) in vfirst) o6bp++ }
    nd = dcount[c, h] + 0
    if ((c, h) in disp) {
      d = disp[c, h]
      nb = 0; na = 0
      for (s = 1; s <= 4; s++) if ((c, h, s) in vfirst) { if (vfirst[c, h, s] < d) nb++; else if (vfirst[c, h, s] > d) na++ }
      if (nb >= 3) { if (nb == 3) o7p3++; else o7p4++ } else o7f++
      if (h in qcids) {
        m = split(qcids[h], q2, " ")
        ok = (m == 3 && q2[1] != q2[2] && q2[1] != q2[3] && q2[2] != q2[3])
        for (i = 1; i <= m; i++) { if (!((c, h, q2[i]) in vfirst) || vfirst[c, h, q2[i]] >= d) ok = 0; inids[q2[i]] = 1 }
        if (ok) o8p++; else o8f++
        late_in = 0
        for (s = 1; s <= 4; s++) if (((c, h, s) in vfirst) && vfirst[c, h, s] > d && (s in inids)) late_in = 1
        if (na == 0) o8b_none++
        else if (late_in) o8b_bad++
        else o8b_out++
        for (s = 1; s <= 4; s++) delete inids[s]
      } else o8na++
      if (qenter_last[c, h] > d) o7c++
      if (chres[h] == "complete") {
        cN++
        if (btw[h]) interleaved++
        if ((p, h) in tryt) { ncyc++; print chtryt[h] - tryt[p, h] > CYC }
      } else cL++
    } else {
      cX++
      if (nd == 1) o7_nd1++; else if (nd == 2) o7_nd2++; else o7_ndother++
    }
  }
  out("views_tested", vt)
  out("o1_pass", o1p + 0); out("o1_tested", o1t + 0); out("o2_pass", o2p + 0); out("o2_tested", o2t + 0)
  out("o3_pass", o3p + 0); out("o3_tested", o3t + 0)
  out("o4_pass", o4p + 0); out("o4_tested", o4t + 0); out("o4_rejected", o4_rej + 0)
  out("o4_rej_timeout_v", o4_rej_timeout + 0); out("o4_rej_later_view", o4_rej_later + 0); out("o4_rej_other", o4_rej_other + o4_rej_nolines + 0)
  out("o5_updated_then_advanced", o5_ua + 0); out("o5_updated_already_in_v", o5_u_already + 0)
  out("o5_notupdated_then_advanced", o5_n_adv + 0); out("o5_notupdated_already_in_v", o5_n_already + 0); out("o5_other", o5_other + 0)
  out("o6_pass", o6p + 0); out("o6_tested", o6t + 0); out("o6b_pass", o6bp + 0); out("o6b_tested", o6bt + 0)
  out("o7_pass_3distinct", o7p3 + 0); out("o7_pass_4distinct", o7p4 + 0); out("o7_fail", o7f + 0)
  out("o7_nodispatch_1distinct", o7_nd1 + 0); out("o7_nodispatch_2distinct", o7_nd2 + 0); out("o7_nodispatch_other", o7_ndother + 0)
  out("o7c_pass", o7c + 0)
  out("o8_pass", o8p + 0); out("o8_fail", o8f + 0); out("o8_not_printed", o8na + 0)
  out("o8b_no_late_vote", o8b_none + 0); out("o8b_late_outside_ids", o8b_out + 0); out("o8b_late_inside_ids", o8b_bad + 0)
  out("class_N", cN + 0); out("class_L", cL + 0); out("class_X", cX + 0); out("class_N_interleaved", interleaved + 0)
  # ------------------------------------------------------------------------------------------------ dispatch level (active phase)
  out("dispatch_active", ndisp_act + 0); out("dispatch_unmatched", unmatched_act + 0)
  for (k in disp) {
    split(k, kk, SUBSEP)
    if (disp[k] < STOP) { if (chres[kk[2]] == "complete") dc++; else db++ }
  }
  out("dispatch_chain_complete", dc + 0); out("dispatch_chain_broken", db + 0)
  # ------------------------------------------------------------------------------------------------ view gaps vs broken chains
  for (v = 3; v < vmax; v++) {
    if (!(v in fprop) || fprop[v] >= STOP) continue
    h = byview[v]; c = (v + 1) % 4 + 1
    if (!(((c, h) in disp) && chres[h] == "complete")) nxt[v + 1] = 1
  }
  for (i = 1; i <= nblk; i++) {
    h = hl[i]; w = bview[h]
    if ((bpar[h] in bview) && w - bview[bpar[h]] > 1 && w >= 3 && w <= vmax && (w in fprop) && fprop[w] < STOP) { gapb++; gset[w] = 1 }
  }
  nn2 = 0; same = 1
  for (w in nxt) { nn2++; if (!(w in gset)) same = 0 }
  if (nn2 != gapb) same = 0
  out("gap_blocks_active", gapb + 0); out("gap_blocks_equal_next_of_nonN", same)
  # ------------------------------------------------------------------------------------------------ DECIDE vs consecutive views
  for (i = 1; i <= ng; i++) {
    h = grh[i]
    if (!(h in bview)) continue
    b1 = bqc[h]; if (!(b1 in bview)) continue
    b2 = bqc[b1]; if (!(b2 in bview)) continue
    b3 = bqc[b2]; if (!(b3 in bview)) continue
    cons = (bview[b1] == bview[b2] + 1 && bview[b2] == bview[b3] + 1) ? 1 : 0
    tally[cons "," grd[i]]++
  }
  out("decide_consecutive_logged", tally["1,1"] + 0); out("decide_consecutive_missing", tally["1,0"] + 0)
  out("decide_nonconsecutive_logged", tally["0,1"] + 0); out("decide_nonconsecutive_missing", tally["0,0"] + 0)
  # ------------------------------------------------------------------------------------------------ other pattern counts used in the text
  out("too_old_proposals", ntoold + 0); out("too_old_proposals_lv_eq_v", ntoold_eq + 0); out("too_old_proposals_lv_gt_v", ntoold_gt + 0)
  out("delay_proposal_total", ndelay + 0); out("delay_proposal_active", ndelay_act + 0)
  out("cycle_n", ncyc + 0)
}
function out(name, val) { printf "%s\t%s\t%s\n", run, name, val }
