#!/usr/bin/env python3
"""compare_counts.py - cross-check three independent counts of every Part-1 pattern:
     (a) grep/awk  -> verify_counts.tsv   (written by verify_counts.sh)
     (b) Python re on the raw lines (this file; logger = tab-separated field 3, active/drain split at 'Stopping clients...')
     (c) the event-parser based numbers in out/part1.json (if present)
   usage: compare_counts.py [verify_counts.tsv] [part1.json]"""
import json
import os
import re
import sys
import collections

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from patterns import PATTERNS          # noqa: E402
import hsparse as H                    # noqa: E402

tsv = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.environ.get("HS_OUT", os.path.join(HERE, "..", "out")), "verify_counts.tsv")
p1 = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.environ.get("HS_OUT", os.path.join(HERE, "..", "out")), "part1.json")

shell = {}
with open(tsv) as f:
    for ln in f:
        pid, run, scope, n = ln.rstrip("\n").split("\t")
        shell[(pid, run, scope)] = int(n)

py = {}
for run in H.RUNS:
    with open(H.LOGS[run], errors="replace") as f:
        lines = [ln.rstrip("\n") for ln in f]
    stop = next(i for i, ln in enumerate(lines, 1) if "Stopping clients..." in ln)
    for label, ere in PATTERNS:
        pid = label.split()[0]
        rx = re.compile(ere)
        c = collections.Counter()
        for i, ln in enumerate(lines, 1):
            if rx.search(ln):
                c["total"] += 1
                if i < stop:
                    c["active"] += 1
                elif i > stop:
                    c["drain"] += 1
                parts = ln.split("\t")
                if len(parts) > 3 and re.fullmatch(r"hs[1-4]", parts[2]):
                    c[parts[2]] += 1
        for scope in ("total", "active", "drain", "hs1", "hs2", "hs3", "hs4"):
            py[(pid, run, scope)] = c[scope]

bad = 0
for key, v in sorted(py.items()):
    s = shell.get(key)
    if s != v:
        bad += 1
        print("MISMATCH grep vs python-re:", key, s, v)
print(f"(a) grep/awk vs (b) python-re: {len(py)} counts compared, {bad} mismatches")

if os.path.exists(p1):
    j = json.load(open(p1))["patterns"]
    bad2 = 0
    n2 = 0
    for k, (t, a, d) in j.items():
        run, label = k.split("|", 1)
        pid = label.split()[0]
        for scope, v in (("total", t), ("active", a), ("drain", d)):
            n2 += 1
            if py[(pid, run, scope)] != v:
                bad2 += 1
                print("MISMATCH part1.json vs python-re:", pid, run, scope, v, py[(pid, run, scope)])
    print(f"(c) part1.json (analysis script) vs (b): {n2} counts compared, {bad2} mismatches")
