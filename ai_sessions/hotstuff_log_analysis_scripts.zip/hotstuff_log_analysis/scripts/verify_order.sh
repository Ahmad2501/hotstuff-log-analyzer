#!/usr/bin/env bash
# verify_order.sh - independent (awk only) re-computation of the Part-4 ordering checks from the raw logs.
#   usage:  ./verify_order.sh [LOGDIR] [OUT_TSV]          (needs verify_order.awk in the same directory)
#   Output TSV columns: run <TAB> metric <TAB> value
# What is checked (all line-order based, active phase = before the first 'Stopping clients...' line, views 3 .. last-1):
#   o1/o2  proposer's TryCommit(B_v) and 'Advanced to view v' precede the first 'Received proposal' of B_v at another replica
#   o3/o4  at every receiver: next advanceView after 'Received proposal' carries the attached QC and precedes TryCommit(B_v)
#   o5     HighQC / view-advance outcome of that advanceView        o6/o6b  vote lines vs. the voter's TryCommit
#   o7/o8  QC dispatch only after >=3 distinct CollectVote lines; QC.IDs subset of the senders seen before the dispatch
#   class  N / L / X per view (complete collector chain / broken chain / no QC), view gaps vs broken chains
#   decide DECIDE line vs consecutive-view three-chain (all phases)       cycle  TryCommit(B_v)@proposer -> TryCommit(B_{v+1})@collector (ms)
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
LOGDIR=${1:-.}
OUT=${2:-./verify_order.tsv}
: > "$OUT"
for run in main main_2 main_3 main_4; do
  LOG="$LOGDIR/$run.log"
  STOP=$(grep -n 'Stopping clients\.\.\.' "$LOG" | head -1 | cut -d: -f1)
  CYC=$(mktemp)
  awk -F'\t' -v run="$run" -v STOP="$STOP" -v CYC="$CYC" -f "$HERE/verify_order.awk" "$LOG" >> "$OUT"
  if [ -s "$CYC" ]; then
    sort -n "$CYC" | awk -v run="$run" '{ a[NR] = $1 } END { n = NR; med = (n % 2) ? a[(n + 1) / 2] : (a[n / 2] + a[n / 2 + 1]) / 2; i = int(0.9 * (n - 1) + 0.5) + 1;
        printf "%s\tcycle_median\t%s\n%s\tcycle_p90\t%s\n%s\tcycle_max\t%s\n", run, med, run, a[i], run, a[n] }' >> "$OUT"
  fi
  rm -f "$CYC"
done
echo "wrote $OUT  ($(wc -l < "$OUT") rows)"
echo
echo "view classes N / L / X (complete collector chain / broken chain / no QC) per run:"
awk -F'\t' '$2=="class_N"{n[$1]=$3} $2=="class_L"{l[$1]=$3} $2=="class_X"{x[$1]=$3} $2=="views_tested"{t[$1]=$3} END{ for (r in t) printf "  %-7s N=%s L=%s X=%s of %s views\n", r, n[r], l[r], x[r], t[r] }' "$OUT" | sort
