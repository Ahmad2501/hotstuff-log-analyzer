#!/usr/bin/env python3
"""Part 2 - replica behaviour: proposal reception, vote collection, vote order (received order and QC 'processed' order).

Conventions (all derived from the log text, see views.py / hsparse.py):
  * collector / receiving replica of the votes for block B_v = the logger of the 'CollectVote(from N): <hash>' line
    (it is always leader(v+1) = (v+1 mod 4)+1 - verified below),
  * sender = N in 'CollectVote(from N)',
  * order = physical line number in the (interleaved) log file,
  * COMPLETE (clean) vote sequence = at one collector, for one block, exactly 4 CollectVote lines from 4 distinct senders,
  * QC 'processed' order = order of IDs in the QC that B_(v+1) carries ('QC{... IDs: [ a b c ]}').
"""
import collections
import itertools
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import views            # noqa: E402
import mdutil           # noqa: E402
from scipy import stats  # noqa: E402

H = views.H
RUNS = H.RUNS
R4 = H.REPLICAS
D = views.load_annotated()
LEADER = H.leader_of


def vote_sequences(rd):
    seqs = collections.defaultdict(list)           # (collector, hash) -> [(sender, line)]
    for e in rd["events"]:
        if e["ev"] == "COLLECT_VOTE":
            seqs[(e["r"], e["hash"])].append((e["from_id"], e["n"]))
    return seqs


def classify(seqs, reg):
    """returns dict class -> list of (collector, hash, [senders])"""
    cls = collections.defaultdict(list)
    for (c, h), lst in seqs.items():
        s = [x for x, _ in lst]
        b = reg.get(h)
        if len(s) == 4 and len(set(s)) == 4:
            cls["complete"].append((c, h, s))
        elif len(s) != len(set(s)):
            cls["with duplicate sender line (local cache miss path)"].append((c, h, s))
        else:
            cls[f"incomplete ({len(s)} distinct senders)"].append((c, h, s))
    return cls


def binom_p(k, n):
    return stats.binomtest(k, n, 0.5).pvalue if n > 0 else float("nan")


def runs_test(bits):
    n1 = sum(bits); n0 = len(bits) - n1
    if n1 == 0 or n0 == 0:
        return float("nan"), float("nan"), 0, 0
    runs = 1 + sum(1 for x, y in zip(bits, bits[1:]) if x != y)
    mu = 2 * n1 * n0 / (n1 + n0) + 1
    var = (mu - 1) * (mu - 2) / (n1 + n0 - 1)
    z = (runs - mu) / math.sqrt(var) if var > 0 else float("nan")
    return z, 2 * stats.norm.sf(abs(z)), runs, mu


def main():
    out = []
    P = out.append
    J = {}
    info = {}
    for run in RUNS:
        rd = D[run]
        reg = rd["blocks"]
        seqs = vote_sequences(rd)
        cls = classify(seqs, reg)
        n_blocks = len(reg)
        # collector sanity: is the logger of the CollectVote always leader(view+1)?
        coll_ok = collections.Counter()
        for (c, h), lst in seqs.items():
            b = reg.get(h)
            coll_ok["collector == leader(view+1)" if b and c == LEADER(b["view"] + 1) else "collector differs from leader(view+1)"] += 1
        info[run] = dict(seqs=seqs, cls=cls, coll_ok=coll_ok)

    # ----------------------------------------------------------------------------------------------------------
    P("## 2A. Participation: who receives proposals, who collects votes, whose votes arrive\n")
    for run in RUNS:
        rd = D[run]
        reg = rd["blocks"]
        evs = rd["events"]
        props = collections.Counter(b["proposer"] for b in reg.values() if b["view"] >= 1)
        recv = collections.Counter(e["r"] for e in evs if e["ev"] == "RECV_PROPOSAL")
        # distinct blocks received per replica (RECV_PROPOSAL may repeat for the same block)
        recv_blocks = collections.defaultdict(set)
        for e in evs:
            if e["ev"] == "RECV_PROPOSAL":
                recv_blocks[e["r"]].add(e["blk"]["hash"])
        cv_at = collections.Counter(e["r"] for e in evs if e["ev"] == "COLLECT_VOTE")
        cv_from = collections.Counter(e["from_id"] for e in evs if e["ev"] == "COLLECT_VOTE")
        qc_at = collections.Counter(e["r"] for e in evs if e["ev"] == "QC_DISPATCH")
        late_at = collections.Counter(e["r"] for e in evs if e["ev"] == "BLOCK_TOO_OLD")
        total_blocks = sum(props.values())
        rows = []
        for k in R4:
            others = total_blocks - props[k]
            rows.append([f"hs{k}", props[k], recv[k], len(recv_blocks[k]), others, f"{100 * len(recv_blocks[k]) / others:.2f}%",
                         cv_from[k], f"{cv_from[k] / total_blocks:.3f}", cv_at[k], qc_at[k], late_at[k]])
        P(f"**{run}**  (blocks with view >= 1: {total_blocks})\n")
        P(mdutil.table(["replica", "proposals authored", "'Received proposal' lines", "distinct blocks received", "blocks authored by others (= receivable)", "received / receivable",
                        "votes SENT (CollectVote(from k) lines at all collectors)", "votes sent per block", "votes COLLECTED (CollectVote lines logged by k)", "QCs formed at k", "'block too old' at k"],
                       rows, align="lrrrrrrrrrr"))
        P("")
        J.setdefault("participation", {})[run] = dict(authored=dict(props), recv=dict(recv), cv_from=dict(cv_from), cv_at=dict(cv_at), qc_at=dict(qc_at), late_at=dict(late_at))
    # homogeneity tests of the 4 replicas within each run
    P("Within-run homogeneity of the four replicas (chi-square against equal shares; p-values only indicative):\n")
    rows = []
    for run in RUNS:
        pj = J["participation"][run]
        for name, key in [("proposals authored", "authored"), ("'Received proposal' lines", "recv"), ("votes sent (as seen by collectors)", "cv_from"),
                          ("votes collected", "cv_at"), ("QCs formed", "qc_at"), ("'block too old' logged", "late_at")]:
            obs = [pj[key].get(k, 0) for k in R4]
            if key in ("recv",):
                # expected share is proportional to receivable blocks
                tot = sum(pj["authored"].values())
                exp_w = [tot - pj["authored"].get(k, 0) for k in R4]
                exp = [sum(obs) * w / sum(exp_w) for w in exp_w]
            else:
                exp = [sum(obs) / 4] * 4
            chi = sum((o - x) ** 2 / x for o, x in zip(obs, exp))
            rows.append([run, name, "/".join(map(str, obs)), f"{chi:.2f}", f"{stats.chi2.sf(chi, 3):.3g}"])
    P(mdutil.table(["run", "quantity", "hs1/hs2/hs3/hs4", "chi2 (df=3)", "p"], rows, align="llrrr"))
    P("")

    # ----------------------------------------------------------------------------------------------------------
    P("## 2B. Vote sequences per (collector, block): how many are complete?\n")
    names = ["complete", "with duplicate sender line (local cache miss path)", "incomplete (3 distinct senders)", "incomplete (2 distinct senders)", "incomplete (1 distinct senders)"]
    rows = []
    for nm in names:
        rows.append([nm] + [len(info[r]["cls"].get(nm, [])) for r in RUNS])
    rows.append(["all (collector, block) sequences"] + [len(info[r]["seqs"]) for r in RUNS])
    rows.append(["collector logger == leader(view+1)"] + [info[r]["coll_ok"]["collector == leader(view+1)"] for r in RUNS])
    rows.append(["collector logger != leader(view+1)"] + [info[r]["coll_ok"]["collector differs from leader(view+1)"] for r in RUNS])
    P(mdutil.table(["class"] + RUNS, rows))
    P("")
    # which sender is missing in incomplete sequences
    miss = {r: collections.Counter() for r in RUNS}
    for r in RUNS:
        for nm, lst in info[r]["cls"].items():
            if nm.startswith("incomplete"):
                for c, h, s in lst:
                    for k in R4:
                        if k not in s:
                            miss[r][k] += 1
    P("Missing sender in incomplete sequences hs1/hs2/hs3/hs4: " + "; ".join(f"{r}: " + "/".join(str(miss[r].get(k, 0)) for k in R4) for r in RUNS) + "\n")

    # ----------------------------------------------------------------------------------------------------------
    P("## 2C. Structure of the received order in COMPLETE sequences (4 lines, 4 distinct senders)\n")
    comp = {r: info[r]["cls"]["complete"] for r in RUNS}
    rows = []
    for r in RUNS:
        reg = D[r]["blocks"]
        n = len(comp[r])
        self_first = sum(1 for c, h, s in comp[r] if s[0] == c)
        prop_second = sum(1 for c, h, s in comp[r] if s[1] == reg[h]["proposer"])
        prop_pos = collections.Counter(s.index(reg[h]["proposer"]) + 1 for c, h, s in comp[r])
        both = sum(1 for c, h, s in comp[r] if s[0] == c and s[1] == reg[h]["proposer"])
        rows.append([r, n, f"{self_first} ({100 * self_first / n:.2f}%)", f"{prop_second} ({100 * prop_second / n:.2f}%)", f"{both} ({100 * both / n:.2f}%)",
                     "/".join(str(prop_pos.get(i, 0)) for i in (1, 2, 3, 4))])
    allc = sum(len(comp[r]) for r in RUNS)
    sf = sum(1 for r in RUNS for c, h, s in comp[r] if s[0] == c)
    ps = sum(1 for r in RUNS for c, h, s in comp[r] if s[1] == D[r]["blocks"][h]["proposer"])
    bo = sum(1 for r in RUNS for c, h, s in comp[r] if s[0] == c and s[1] == D[r]["blocks"][h]["proposer"])
    pp = collections.Counter(s.index(D[r]["blocks"][h]["proposer"]) + 1 for r in RUNS for c, h, s in comp[r])
    rows.append(["combined", allc, f"{sf} ({100 * sf / allc:.2f}%)", f"{ps} ({100 * ps / allc:.2f}%)", f"{bo} ({100 * bo / allc:.2f}%)", "/".join(str(pp.get(i, 0)) for i in (1, 2, 3, 4))])
    P(mdutil.table(["run", "complete sequences", "collector (receiver of the votes) is 1st", "proposer of the block is 2nd", "both", "proposer position 1st/2nd/3rd/4th"], rows, align="lrrrrr"))
    P("")
    J["structure"] = {r[0]: r[1:] for r in rows}

    # per collector: permutation structure
    P("### 2C-2. Per collector (receiving replica): the two possible orders of the last two positions\n")
    P("Every complete sequence has the form [collector, proposer, X, Y]; X,Y are the two remaining replicas. Count of 'which of the two is LAST' per collector; two-sided exact binomial test vs 50/50; Wald-Wolfowitz runs test over consecutive visits of the same collector (every 4th view).\n")
    rows = []
    tail_series = {}
    for r in RUNS:
        reg = D[r]["blocks"]
        for c in R4:
            ser = []
            for cc, h, s in comp[r]:
                if cc != c:
                    continue
                if s[0] == c and s[1] == reg[h]["proposer"]:
                    ser.append((reg[h]["view"], s[2], s[3]))
            ser.sort()
            tail_series[(r, c)] = ser
    for c in R4:
        for r in RUNS:
            ser = tail_series[(r, c)]
            if not ser:
                continue
            cands = sorted({x for _, a, b in ser for x in (a, b)})
            a_, b_ = cands[0], cands[1]
            n_last_b = sum(1 for _, a, b in ser if b == b_)
            n_last_a = len(ser) - n_last_b
            bits = [1 if b == b_ else 0 for _, a, b in ser]
            z, pz, runs, mu = runs_test(bits)
            rep = sum(1 for x, y in zip(bits, bits[1:]) if x == y)
            rows.append([f"hs{c}", r, f"hs{cands[0]}, hs{cands[1]}", len(ser), f"{n_last_a} / {n_last_b}", f"{100 * n_last_b / len(ser):.1f}%", f"{binom_p(n_last_b, len(ser)):.3g}",
                         f"{runs} (exp {mu:.0f})", f"{z:+.2f}", f"{pz:.3g}"])
    P(mdutil.table(["collector", "run", "tail candidates", "n", f"last = first cand / second cand", "share second cand last", "p (binomial)", "runs observed", "runs z", "p (runs)"], rows, align="llrrrrrrrr"))
    P("")
    J["tail"] = {f"{r}|hs{c}": dict(n=len(tail_series[(r, c)])) for r in RUNS for c in R4}
    # combined per collector
    rows = []
    homog = []
    for c in R4:
        per_run = []
        for r in RUNS:
            ser = tail_series[(r, c)]
            cands = sorted({x for _, a, b in ser for x in (a, b)})
            per_run.append((sum(1 for _, a, b in ser if b == cands[1]), sum(1 for _, a, b in ser if b == cands[0])))
        tot_b = sum(x for x, _ in per_run); tot_a = sum(y for _, y in per_run)
        chi, p, dof, _ = stats.chi2_contingency([list(x) for x in per_run])
        rows.append([f"hs{c}", f"{tot_a} / {tot_b}", f"{100 * tot_b / (tot_a + tot_b):.1f}%", f"{binom_p(tot_b, tot_a + tot_b):.3g}", f"{chi:.2f}", f"{p:.3g}"])
    P("Combined over the four runs (per collector) and homogeneity of the split across the four runs (chi2, df=3):\n")
    P(mdutil.table(["collector", "last = lower-ID cand / higher-ID cand", "share higher-ID cand last", "p (binomial vs 50%)", "chi2 across runs", "p (across runs)"], rows, align="lrrrrr"))
    P("")

    # ----------------------------------------------------------------------------------------------------------
    P("## 2D. How often is each replica FIRST / LAST in a complete vote sequence - receiver vs sender\n")
    for scope in RUNS + ["combined"]:
        use = RUNS if scope == "combined" else [scope]
        tab = {pos: collections.defaultdict(collections.Counter) for pos in ("first", "second", "third", "last")}
        n_by_c = collections.Counter()
        for r in use:
            for c, h, s in comp[r]:
                n_by_c[c] += 1
                for pos, i in (("first", 0), ("second", 1), ("third", 2), ("last", 3)):
                    tab[pos][c][s[i]] += 1
        N = sum(n_by_c.values())
        P(f"**{scope}**  ({N} complete sequences; rows = receiving replica (collector) c, columns = sending replica)\n")
        rows = []
        for c in R4:
            row = [f"hs{c} ({n_by_c[c]})"]
            for pos in ("first", "last"):
                row.append(" / ".join(f"{100 * tab[pos][c].get(j, 0) / n_by_c[c]:.1f}" for j in R4))
            rows.append(row)
        # pooled over collectors
        row = [f"all receivers ({N})"]
        for pos in ("first", "last"):
            row.append(" / ".join(f"{100 * sum(tab[pos][c].get(j, 0) for c in R4) / N:.1f}" for j in R4))
        rows.append(row)
        P(mdutil.table(["receiver c (n)", "FIRST: % of sequences, sender hs1/hs2/hs3/hs4", "LAST: % of sequences, sender hs1/hs2/hs3/hs4"], rows, align="lrr"))
        P("")
        J.setdefault("first_last", {})[scope] = {pos: {f"hs{c}": {f"hs{j}": tab[pos][c].get(j, 0) for j in R4} for c in R4} for pos in ("first", "second", "third", "last")}
        J["first_last"][scope]["n_by_collector"] = {f"hs{c}": n_by_c[c] for c in R4}

    # sender-position matrix pooled (all receivers)
    P("### 2D-2. Position of a SENDER's vote (1st..4th) pooled over all receivers, % of complete sequences\n")
    rows = []
    for scope in RUNS + ["combined"]:
        use = RUNS if scope == "combined" else [scope]
        pos = {j: collections.Counter() for j in R4}
        N = 0
        for r in use:
            for c, h, s in comp[r]:
                N += 1
                for i, j in enumerate(s):
                    pos[j][i + 1] += 1
        for j in R4:
            rows.append([scope, f"hs{j}"] + [f"{100 * pos[j][i] / N:.1f}" for i in (1, 2, 3, 4)])
    P(mdutil.table(["scope", "sender", "1st %", "2nd %", "3rd %", "4th %"], rows, align="llrrrr"))
    P("")
    rows = []
    for scope in RUNS + ["combined"]:
        use = RUNS if scope == "combined" else [scope]
        last = collections.Counter(); N = 0
        for r in use:
            for c, h, s in comp[r]:
                last[s[3]] += 1; N += 1
        obs = [last[j] for j in R4]
        chi = sum((o - N / 4) ** 2 / (N / 4) for o in obs)
        rows.append([scope, N, "/".join(map(str, obs)), "/".join(f"{100 * o / N:.1f}" for o in obs), f"{chi:.2f}", f"{stats.chi2.sf(chi, 3):.3g}"])
    P("Pooled over all receivers: how often each SENDER is the last (4th) vote, with a chi-square test against 25% each (df=3):\n")
    P(mdutil.table(["scope", "complete sequences", "last = hs1/hs2/hs3/hs4 (count)", "last (%)", "chi2", "p"], rows, align="lrrrrr"))
    P("")

    # ----------------------------------------------------------------------------------------------------------
    P("## 2E. Processed order: QC.IDs (order in which verified votes entered the QC) vs received order\n")
    rows = []
    qc_stats = {}
    for scope in RUNS + ["combined"]:
        use = RUNS if scope == "combined" else [scope]
        cmpc = collections.Counter(); exc_pos = collections.Counter(); exc_by = collections.defaultdict(collections.Counter)
        first_self = collections.Counter(); n = 0
        for r in use:
            reg = D[r]["blocks"]
            qc_ids_of = {}                      # QC for block h -> IDs, as printed in the first block (log order) that carries that QC
            for b in reg.values():
                if len(b["qc_ids"]) == 3 and b["qc_hash"] not in qc_ids_of:
                    qc_ids_of[b["qc_hash"]] = list(b["qc_ids"])
            for c, h, s in comp[r]:
                if h not in qc_ids_of:
                    cmpc["no block in the log carries a QC for this block"] += 1
                    continue
                ids = qc_ids_of[h]
                n += 1
                same = tuple(x for x in s if x in ids) == tuple(ids)
                cmpc["QC.IDs order == received order (first three received)" if s[:3] == ids else ("QC.IDs same set as first three received, different order" if set(ids) == set(s[:3]) else ("QC.IDs contains the 4th received vote" if s[3] in ids else "other"))] += 1
                ex = [x for x in R4 if x not in ids][0]
                exc_pos[s.index(ex) + 1] += 1
                exc_by[c][ex] += 1
                first_self[ids[0] == c] += 1
        qc_stats[scope] = dict(cmpc=dict(cmpc), exc_pos=dict(exc_pos), first_self=dict(first_self), n=n,
                               exc_by={f"hs{c}": {f"hs{j}": exc_by[c].get(j, 0) for j in R4} for c in R4})
        rows.append([scope, n] + [cmpc.get(k, 0) for k in ["QC.IDs order == received order (first three received)",
                                                           "QC.IDs same set as first three received, different order",
                                                           "QC.IDs contains the 4th received vote"]] +
                    ["/".join(str(exc_pos.get(i, 0)) for i in (1, 2, 3, 4)), f"{first_self.get(True, 0)} / {first_self.get(False, 0)}"])
    P(mdutil.table(["scope", "complete sequences whose QC is printed in a later block", "QC.IDs == first three received (same order)", "same three replicas, different order", "4th received vote is inside QC.IDs",
                    "excluded replica was received 1st/2nd/3rd/4th", "QC.IDs[0] == collector / not"], rows, align="lrrrrrr"))
    P("")
    P("Which replica is left OUT of the QC (the one whose vote is not among QC.IDs), by receiving replica, % of that collector's QCs:\n")
    rows = []
    for scope in RUNS + ["combined"]:
        ex = qc_stats[scope]["exc_by"]
        for c in R4:
            tot = sum(ex[f"hs{c}"].values())
            rows.append([scope, f"hs{c}", tot] + [f"{100 * ex[f'hs{c}'][f'hs{j}'] / tot:.1f}" for j in R4])
    P(mdutil.table(["scope", "receiver", "QCs", "excluded hs1 %", "excluded hs2 %", "excluded hs3 %", "excluded hs4 %"], rows, align="llrrrrr"))
    P("")
    J["qc_stats"] = qc_stats

    # ----------------------------------------------------------------------------------------------------------
    P("## 2F. Reception order of PROPOSALS ('Received proposal' line order) - the proposer is the sender, three replicas receive\n")
    rows = []
    prop_first = {}
    for scope in RUNS + ["combined"]:
        use = RUNS if scope == "combined" else [scope]
        first = collections.defaultdict(collections.Counter); last = collections.defaultdict(collections.Counter); nprop = collections.Counter()
        role_first = collections.Counter(); role_last = collections.Counter(); role_n = 0
        for r in use:
            rx = collections.defaultdict(list)
            for e in D[r]["events"]:
                if e["ev"] == "RECV_PROPOSAL":
                    h = e["blk"]["hash"]
                    if e["r"] not in [x for x, _ in rx[h]]:
                        rx[h].append((e["r"], e["n"]))
            for h, lst in rx.items():
                if len(lst) != 3:
                    continue
                b = D[r]["blocks"][h]
                p = b["proposer"]
                order = [x for x, _ in lst]
                nprop[p] += 1
                first[p][order[0]] += 1
                last[p][order[2]] += 1
                coll = LEADER(b["view"] + 1)
                role_n += 1
                role = lambda x: "next leader (collector)" if x == coll else ("previous leader" if x == (p - 2) % 4 + 1 else "other")
                role_first[role(order[0])] += 1
                role_last[role(order[2])] += 1
        prop_first[scope] = dict(n=dict(nprop), first={f"hs{p}": dict(first[p]) for p in first}, last={f"hs{p}": dict(last[p]) for p in last},
                                 role_first=dict(role_first), role_last=dict(role_last), role_n=role_n)
        for p in R4:
            if nprop[p]:
                rows.append([scope, f"hs{p}", nprop[p],
                             " / ".join(f"{100 * first[p].get(j, 0) / nprop[p]:.1f}" if j != p else "-" for j in R4),
                             " / ".join(f"{100 * last[p].get(j, 0) / nprop[p]:.1f}" if j != p else "-" for j in R4)])
    P(mdutil.table(["scope", "proposer (sender)", "blocks received by all 3 others", "FIRST to log it, % receiver hs1/hs2/hs3/hs4", "LAST to log it, % receiver hs1/hs2/hs3/hs4"], rows, align="llrrr"))
    P("")
    P("Role summary (receiver role relative to the block's proposer): share of blocks where the receiver of that role logged the proposal first / last\n")
    rows = []
    for scope in RUNS + ["combined"]:
        d = prop_first[scope]
        n = d["role_n"]
        for role in ("next leader (collector)", "previous leader", "other"):
            rows.append([scope, role, f"{100 * d['role_first'].get(role, 0) / n:.1f}", f"{100 * d['role_last'].get(role, 0) / n:.1f}"])
    P(mdutil.table(["scope", "receiver role", "% first", "% last"], rows, align="llrr"))
    P("(a role that is first/last in 1/3 of the blocks would be neutral; 'other' is a single replica per block, 'previous leader' and 'next leader' are one replica each.)\n")
    J["proposal_reception"] = prop_first

    # ----------------------------------------------------------------------------------------------------------
    P("## 2G. Replica-level counters that could point to an unusual replica (all phases; logger = the replica that wrote the line)\n")
    cnt_events = [("CACHE_MISS", "Local cache miss (vote for unknown block)"), ("NO_BLOCK_FOR_VOTE", "Could not find block for vote"), ("FETCH_ATTEMPT", "Attempting to fetch block"),
                  ("ON_REQUEST_BLOCK", "On RequestBlock (served a fetch)"), ("PRUNE_FORK", "PruneToHeight found forked block"), ("BLOCK_EXISTS", "block already exists"),
                  ("PROPOSAL_TOO_OLD", "failed to verify incoming vote: block view N too old"), ("LOCAL_TIMEOUT_VIEW", "OnLocalTimeout: V"), ("STOP_VOTING", "Stopped voting for timed out view"),
                  ("FAIL_VERIFY_SYNCINFO", "Failed to verify sync info"), ("BLOCK_TOO_OLD", "block too old (as collector)"), ("FAIL_CREATE_PROPOSAL", "Failed to create proposal")]
    rows = []
    for ev, nm in cnt_events:
        row = [nm]
        for r in RUNS:
            c = collections.Counter(e["r"] for e in D[r]["events"] if e["ev"] == ev)
            row.append("/".join(str(c.get(k, 0)) for k in R4))
        rows.append(row)
    P(mdutil.table(["counter (hs1/hs2/hs3/hs4)"] + RUNS, rows, align="lrrrr"))
    P("")
    P("Complete sequences in which the proposer is NOT the 2nd vote (receiver, proposer, other, other is the norm):\n")
    rows = []
    for r in RUNS:
        reg = D[r]["blocks"]
        odd = [(reg[h]["view"], reg[h]["proposer"], c) for c, h, s in comp[r] if s[1] != reg[h]["proposer"]]
        byp = collections.Counter(p for _, p, _ in odd)
        rows.append([r, len(comp[r]), len(odd), f"{100 * len(odd) / len(comp[r]):.2f}%", "/".join(str(byp.get(k, 0)) for k in R4)])
    P(mdutil.table(["run", "complete sequences", "proposer not 2nd", "share", "by proposer hs1/hs2/hs3/hs4"], rows, align="lrrrr"))
    P("")

    # ----------------------------------------------------------------------------------------------------------
    # flat metric dump used by compare_votes.py (same metric names as verify_votes.sh)
    flat = collections.Counter()
    for r in RUNS:
        reg = D[r]["blocks"]
        qc_ids_of = {}
        for b in reg.values():
            if len(b["qc_ids"]) == 3 and b["qc_hash"] not in qc_ids_of:
                qc_ids_of[b["qc_hash"]] = list(b["qc_ids"])
        for c, h, sq in comp[r]:
            flat[(r, "complete_n", c, "-")] += 1
            for name, i in (("first", 0), ("second", 1), ("third", 2), ("last", 3)):
                flat[(r, name, c, sq[i])] += 1
            if sq[0] == c:
                flat[(r, "collector_first", c, "-")] += 1
            pr = reg[h]["proposer"]
            if sq[1] == pr:
                flat[(r, "proposer_second", c, "-")] += 1
            flat[(r, f"proposer_pos{sq.index(pr) + 1}", c, "-")] += 1
            ids = qc_ids_of.get(h)
            if ids:
                flat[(r, "qc_n", c, "-")] += 1
                if ids == sq[:3]:
                    flat[(r, "qc_same_order", c, "-")] += 1
                elif sq[3] not in ids:
                    flat[(r, "qc_same_set_diff_order", c, "-")] += 1
                else:
                    flat[(r, "qc_contains_4th", c, "-")] += 1
                ex = [x for x in R4 if x not in ids][0]
                flat[(r, "excluded", c, ex)] += 1
                flat[(r, "excluded_pos", c, sq.index(ex) + 1)] += 1
                flat[(r, "qc_first_is_collector" if ids[0] == c else "qc_first_not_collector", c, "-")] += 1
        rx = collections.defaultdict(list)
        for e in D[r]["events"]:
            if e["ev"] == "RECV_PROPOSAL":
                hh = e["blk"]["hash"]
                if e["r"] not in rx[hh]:
                    rx[hh].append(e["r"])
        for hh, lst in rx.items():
            if len(lst) == 3:
                pr = reg[hh]["proposer"]
                flat[(r, "prop_n", pr, "-")] += 1
                flat[(r, "prop_first", pr, lst[0])] += 1
                flat[(r, "prop_last", pr, lst[2])] += 1
    J["flat"] = {f"{r}|{m}|{c}|{j}": v for (r, m, c, j), v in flat.items()}

    print("\n".join(out))
    mdutil.dump_json(J, os.path.join(os.environ.get("HS_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")), "part2.json"))


if __name__ == "__main__":
    main()
