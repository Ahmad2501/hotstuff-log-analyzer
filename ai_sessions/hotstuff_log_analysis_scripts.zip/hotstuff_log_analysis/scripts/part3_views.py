#!/usr/bin/env python3
"""Part 3 - protocol events grouped by view number: shared views, pattern classes, count differences, vote-order recurrence,
timeout views (shared / in all four runs), timeout vs view progression, and the comparison with / without proposer identity.

Per-view attribution of every event is documented in views.py (event -> view rules).  'active' = before 'Stopping clients...'.
A view 'exists' in a run when a block (proposal) for that view appears in the log.  Everything below is computed from the parsed
log events; the matching grep/awk/comm verification is in verify_views.sh."""
import collections
import itertools
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import views            # noqa: E402
import viewtable        # noqa: E402
import mdutil           # noqa: E402
from scipy import stats  # noqa: E402

H = views.H
RUNS = H.RUNS
R4 = H.REPLICAS
D = views.load_annotated()
LEADER = H.leader_of
TIMEOUT_EVENTS = viewtable.TIMEOUT_EVENTS
CORE = ["RECV_PROPOSAL", "TRY_COMMIT", "COLLECT_VOTE", "QC_DISPATCH", "HQC_UPDATED", "ADVANCED"]
CORE_STD = {"RECV_PROPOSAL": 3, "TRY_COMMIT": 4, "COLLECT_VOTE": 4, "QC_DISPATCH": 1, "HQC_UPDATED": 4, "ADVANCED": 4}
FORKISH = ["BLOCK_EXISTS", "PRUNE_FORK", "FETCH_ATTEMPT", "ON_REQUEST_BLOCK", "NO_BLOCK_FOR_VOTE", "PROPOSAL_TOO_OLD", "DELAY_PROPOSAL", "FAIL_VERIFY_SYNCINFO"]

TAB = {r: viewtable.build(D[r]) for r in RUNS}
STOP = {r: next(e for e in D[r]["events"] if e["ev"] == "CTRL_STOP_CLIENTS") for r in RUNS}
START = {r: next(e for e in D[r]["events"] if e["ev"] == "CLIENT_START") for r in RUNS}


def block_views(r):
    return {v for v, rw in TAB[r].items() if rw["has_block"] and v >= 1}


FIRST_PROPOSAL_LINE = {}
for _r in RUNS:
    _d = {}
    for _e in D[_r]["events"]:
        if _e["ev"] in ("TRY_COMMIT", "RECV_PROPOSAL") and _e["blk"]:
            _d.setdefault(_e["blk"]["view"], _e["n"])
    FIRST_PROPOSAL_LINE[_r] = _d


def is_active_view(r, v):
    """a view counts as 'active' when its first proposal line ('Received proposal' / 'TryCommit') precedes 'Stopping clients...'"""
    n = FIRST_PROPOSAL_LINE[r].get(v)
    return n is not None and n < STOP[r]["n"]


def classify(r, v):
    rw = TAB[r][v]
    c = rw["cnt"]
    if any(c[k] for k in TIMEOUT_EVENTS):
        return "T  timeout-type events in the view"
    if any(c[k] for k in FORKISH):
        return "F  fork / fetch / prune / missing-block / sync-info-failure events"
    # duplicate vote lines (local cache miss path) are counted separately: effective votes = CollectVote lines - cache misses
    if any((c[k] - (c["CACHE_MISS"] if k == "COLLECT_VOTE" else 0)) != CORE_STD[k] for k in CORE):
        return "N  non-standard core counts (no timeout events)"
    if c["CACHE_MISS"]:
        return "D  standard + duplicate vote line (local cache miss)"
    if c["BLOCK_TOO_OLD"]:
        return "L  standard + late 4th vote ('block too old')"
    return "S  standard"


def main():
    out = []
    P = out.append
    J = {}
    BV = {r: block_views(r) for r in RUNS}
    ACT = {r: {v for v in BV[r] if is_active_view(r, v)} for r in RUNS}

    # ------------------------------------------------------------------------------------------------ 3A
    P("## 3A. Which views exist in each run and which are shared?\n")
    adv_views = {r: {e["view"] for e in D[r]["events"] if e["ev"] == "ADVANCED"} for r in RUNS}
    rows = []
    for r in RUNS:
        vs = sorted(BV[r])
        rows.append([r, len(vs), f"{vs[0]}..{vs[-1]}", len(ACT[r]), len(BV[r]) - len(ACT[r]), f"{min(adv_views[r])}..{max(adv_views[r])}", len(adv_views[r]),
                     sum(1 for v in range(1, vs[-1] + 1) if v not in BV[r]),
                     sum(1 for v in vs if len({b['proposer'] for b in D[r]['blocks'].values() if b['view'] == v}) > 1) if False else 0])
    P(mdutil.table(["run", "views with a proposal", "view numbers", "of which first seen in active phase", "in drain phase", "views entered (ADVANCED) range", "views entered",
                    "gaps in 1..max (view numbers without proposal)", "views with 2 different proposals"], rows, align="lrrrrrrrr"))
    P("")
    inter4 = set.intersection(*[BV[r] for r in RUNS])
    inter4a = set.intersection(*[ACT[r] for r in RUNS])
    union = set.union(*[BV[r] for r in RUNS])
    P(f"Views with a proposal in ALL four runs: {len(inter4)}  ({min(inter4)}..{max(inter4)}, contiguous: {len(inter4) == max(inter4) - min(inter4) + 1});  "
      f"in all four runs and first seen in the active phase of each: {len(inter4a)}; union of all runs: {len(union)}.\n")
    rows = []
    for a, b in itertools.combinations_with_replacement(RUNS, 2):
        rows.append([a, b, len(BV[a] & BV[b])])
    rows2 = [[r] + [len(BV[r] & BV[s]) for s in RUNS] for r in RUNS]
    P("Pairwise number of shared views (with proposal):\n")
    P(mdutil.table(["run"] + RUNS, rows2))
    P("")
    cnt_runs = collections.Counter(sum(1 for r in RUNS if v in BV[r]) for v in union)
    P("Views by number of runs that contain them: " + ", ".join(f"{k} runs: {cnt_runs[k]}" for k in sorted(cnt_runs, reverse=True)) + "\n")
    shared3 = sorted(v for v in union if sum(1 for r in RUNS if v in BV[r]) == 3)
    P(f"Views present in exactly three runs (main, main_3, main_4; main_2 stops at {max(BV['main_2'])}): {len(shared3)}  ({shared3[0]}..{shared3[-1]}) "
      f"[main_3 ends at {max(BV['main_3'])}, main_4 at {max(BV['main_4'])}, main at {max(BV['main'])}]\n")
    J["coverage"] = dict(inter4=len(inter4), inter4_active=len(inter4a), union=len(union), by_runs=dict(cnt_runs), pairwise={a: {b: len(BV[a] & BV[b]) for b in RUNS} for a in RUNS})

    # ------------------------------------------------------------------------------------------------ 3B
    P("## 3B. Event-pattern classes per view (active-phase views)\n")
    P("Class rule (first match wins): T = any timeout-type event attributed to the view (OnLocalTimeout, OnRemoteTimeout, not enough timeouts, TC formed, Stopped voting, Failed to create sync info); "
      "F = fork/fetch/prune/missing-block/'Failed to verify sync info'; N = core counts differ from the standard view; "
      "D/L = standard core plus duplicate vote line / late 4th vote; S = standard. Standard core per view = 3 'Received proposal', 4 TryCommit, 4 CollectVote, 1 QC dispatch, 4 HighQC updates, 4 'Advanced to view'.\n")
    classes = {r: {v: classify(r, v) for v in ACT[r]} for r in RUNS}
    names = sorted({c for r in RUNS for c in classes[r].values()})
    rows = []
    for nm in names:
        rows.append([nm] + [f"{sum(1 for c in classes[r].values() if c == nm):,} ({100 * sum(1 for c in classes[r].values() if c == nm) / len(ACT[r]):.1f}%)" for r in RUNS])
    rows.append(["views in class (active phase)"] + [len(ACT[r]) for r in RUNS])
    P(mdutil.table(["class"] + RUNS, rows))
    P("")
    J["classes"] = {r: dict(collections.Counter(classes[r].values())) for r in RUNS}

    # ------------------------------------------------------------------------------------------------ 3C
    P("## 3C. Same view number in all four runs: do the runs show the same pattern?\n")
    sv = sorted(inter4a)
    cls_vec = {v: tuple(classes[r][v][0] for r in RUNS) for v in sv}
    core_sig = {v: tuple(tuple(TAB[r][v]["cnt"][k] for k in CORE) for r in RUNS) for v in sv}
    full_sig = {v: tuple(tuple(sorted((k, n) for k, n in TAB[r][v]["cnt"].items() if k not in ("BATCH_HASH",))) for r in RUNS) for v in sv}
    n_core_same = sum(1 for v in sv if len(set(core_sig[v])) == 1)
    n_full_same = sum(1 for v in sv if len(set(full_sig[v])) == 1)
    n_std4 = sum(1 for v in sv if all(c in "SLD" for c in cls_vec[v]))
    n_s4 = sum(1 for v in sv if all(c == "S" for c in cls_vec[v]))
    n_any_t = sum(1 for v in sv if any(c == "T" for c in cls_vec[v]))
    n_all_t = sum(1 for v in sv if all(c == "T" for c in cls_vec[v]))
    n_any_nonstd = sum(1 for v in sv if any(c in "TFN" for c in cls_vec[v]))
    rows = [["views shared by all four runs (active in each)", len(sv)],
            ["core counts identical in all four runs", f"{n_core_same} ({100 * n_core_same / len(sv):.1f}%)"],
            ["all four runs in the standard core (class S, L or D - only late/duplicate vote lines differ)", f"{n_std4} ({100 * n_std4 / len(sv):.1f}%)"],
            ["all four runs class S (nothing but the standard events)", f"{n_s4} ({100 * n_s4 / len(sv):.1f}%)"],
            ["full event-count signature identical in all four runs", f"{n_full_same} ({100 * n_full_same / len(sv):.1f}%)"],
            ["at least one run has a timeout-type event (class T)", f"{n_any_t} ({100 * n_any_t / len(sv):.1f}%)"],
            ["class T in all four runs", f"{n_all_t}"],
            ["at least one run in class T, F or N", f"{n_any_nonstd} ({100 * n_any_nonstd / len(sv):.1f}%)"]]
    P(mdutil.table(["measure", "value"], rows, align="lr"))
    P("")
    # which events differ the most in shared views
    diff_ev = collections.Counter()
    for v in sv:
        for ev in viewtable.COUNT_EVENTS:
            vals = {TAB[r][v]["cnt"][ev] for r in RUNS}
            if len(vals) > 1:
                diff_ev[ev] += 1
    rows = [[ev, n, f"{100 * n / len(sv):.1f}%"] for ev, n in diff_ev.most_common(14)]
    P("Events whose per-view count differs between the four runs, over the shared views:\n")
    P(mdutil.table(["event", "views where count differs in >=1 run", "share"], rows, align="lrr"))
    P("")
    # same, restricted to main/main_3/main_4 (all clean) over their shared views
    sv3 = sorted(set.intersection(*[ACT[r] for r in ("main", "main_3", "main_4")]))
    d3 = collections.Counter()
    for v in sv3:
        for ev in viewtable.COUNT_EVENTS:
            if len({TAB[r][v]["cnt"][ev] for r in ("main", "main_3", "main_4")}) > 1:
                d3[ev] += 1
    P(f"Same measure for the three similar runs only (main, main_3, main_4; {len(sv3)} shared active views):\n")
    P(mdutil.table(["event", "views where count differs in >=1 of the 3 runs", "share"], [[ev, n, f"{100 * n / len(sv3):.1f}%"] for ev, n in d3.most_common(10)], align="lrr"))
    c3 = collections.Counter()
    for v in sv3:
        cl = tuple(classes[r][v][0] for r in ("main", "main_3", "main_4"))
        c3["all three S/L/D" if all(c in "SLD" for c in cl) else ("T in all three" if all(c == "T" for c in cl) else ("T in >=1" if "T" in cl else "other"))] += 1
    P("\nClass agreement over those views: " + ", ".join(f"{k}: {v}" for k, v in c3.most_common()) + "\n")
    J["shared"] = dict(n=len(sv), core_same=n_core_same, full_same=n_full_same, std4=n_std4, s4=n_s4, any_t=n_any_t, all_t=n_all_t, n3=len(sv3), diff=dict(diff_ev), diff3=dict(d3))

    # ------------------------------------------------------------------------------------------------ 3D
    P("## 3D. Views that contain timeout-related events\n")
    TV = {}
    for r in RUNS:
        TV[r] = {ph: set() for ph in ("active", "drain", "all")}
        for v, rw in TAB[r].items():
            if v < 1 or not any(rw["cnt"][k] for k in TIMEOUT_EVENTS):
                continue
            TV[r]["all"].add(v)
            # phase of the timeout events themselves: attribute by the first timeout event of that view
            ph = None
            for e in D[r]["events"]:
                pass
        # phase by events (one pass)
        for e in D[r]["events"]:
            if e["ev"] in TIMEOUT_EVENTS and e.get("v") is not None and e["v"] >= 1:
                TV[r][e["phase"] if e["phase"] in ("active", "drain") else "active"].add(e["v"])
    rows = []
    for r in RUNS:
        loc = {e["v"] for e in D[r]["events"] if e["ev"] == "LOCAL_TIMEOUT_VIEW" and e["phase"] == "active"}
        rows.append([r, len(TV[r]["active"]), len(TV[r]["drain"]), len(TV[r]["all"]), len(loc), f"{100 * len(TV[r]['active']) / len(ACT[r]):.1f}%"])
    P(mdutil.table(["run", "views with timeout-type events: active-phase events", "drain-phase events", "views in total", "views with 'OnLocalTimeout: V' (active)", "share of active views with timeout-type events"], rows, align="lrrrrr"))
    P("")
    # intersections
    def inter(sets):
        return set.intersection(*sets)
    I_act = inter([TV[r]["active"] for r in RUNS])
    I_all = inter([TV[r]["all"] for r in RUNS])
    I_loc = inter([{e["v"] for e in D[r]["events"] if e["ev"] == "LOCAL_TIMEOUT_VIEW" and e["phase"] == "active"} for r in RUNS])
    I_act3 = inter([TV[r]["active"] for r in ("main", "main_3", "main_4")])
    P(f"Views with timeout-type events (active phase) in ALL FOUR runs: {sorted(I_act)}  |  with an 'OnLocalTimeout: V' line in all four runs: {sorted(I_loc)}  |  any phase, all four: {sorted(I_all)}")
    P(f"Views with timeout-type events (active phase) in all three similar runs (main, main_3, main_4): {sorted(I_act3)}\n")
    # overlap vs chance: for pairs of runs, number of shared timeout views vs expectation under independence among shared active views
    rows = []
    for a, b in itertools.combinations(RUNS, 2):
        pool = ACT[a] & ACT[b]
        A = TV[a]["active"] & pool; B = TV[b]["active"] & pool
        obs = len(A & B)
        exp = len(A) * len(B) / len(pool)
        # hypergeometric upper tail
        pval = stats.hypergeom.sf(obs - 1, len(pool), len(A), len(B)) if obs > 0 else 1.0
        rows.append([a, b, len(pool), len(A), len(B), obs, f"{exp:.2f}", f"{pval:.3g}", sorted(A & B)[:12]])
    P("Overlap of timeout views between two runs vs the overlap expected if timeout views were scattered independently (hypergeometric upper-tail p):\n")
    P(mdutil.table(["run A", "run B", "shared active views", "timeout views in A", "in B", "in both (observed)", "expected by chance", "p", "views in both"], rows, align="llrrrrrrl"))
    P("")
    # how many runs contain a timeout at each view
    cntv = collections.Counter()
    for v in set.union(*[TV[r]["active"] for r in RUNS]):
        cntv[sum(1 for r in RUNS if v in TV[r]["active"] and v in ACT[r])] += 1
    P("Number of runs (out of 4) in which an active-phase view has timeout-type events: " + ", ".join(f"{k} run(s): {cntv[k]} views" for k in sorted(cntv)) + "\n")
    multi = sorted(v for v in set.union(*[TV[r]["active"] for r in RUNS]) if sum(1 for r in RUNS if v in TV[r]["active"]) >= 3)
    P(f"Views with timeout-type events in >=3 runs (active phase): {multi}\n")
    J["timeouts"] = dict(per_run={r: {ph: sorted(TV[r][ph]) for ph in TV[r]} for r in RUNS}, all4_active=sorted(I_act), all4_local=sorted(I_loc), all4_any=sorted(I_all), three_runs=multi)


    # ------------------------------------------------------------------------------------------------ 3E
    P("## 3E. How timeout activity relates to view progression\n")
    # (a) outcome of the timed-out views
    rows = []
    out_cat = {}
    for r in RUNS:
        evs = D[r]["events"]
        qc_formed = {e["v"] for e in evs if e["ev"] == "QC_DISPATCH"}
        tc_adv = collections.defaultdict(set)
        for e in evs:
            if e["ev"] == "ADVANCED" and e.get("trigger") == "REMOTE_TIMEOUT_2ND":
                tc_adv[e["view"] - 1].add(e["r"])
        loc_views = {e["v"] for e in evs if e["ev"] == "LOCAL_TIMEOUT_VIEW" and e["phase"] == "active"}
        cat = collections.Counter()
        for v in loc_views:
            qc = v in qc_formed; tc = bool(tc_adv.get(v))
            cat["QC formed, nobody advanced by TC" if (qc and not tc) else ("QC formed, some replicas advanced by TC" if (qc and tc) else ("no QC, advanced by TC" if tc else "neither"))] += 1
        out_cat[r] = cat
    names = ["QC formed, nobody advanced by TC", "QC formed, some replicas advanced by TC", "no QC, advanced by TC", "neither"]
    P("Views with an 'OnLocalTimeout: V' in the active phase - did the view still produce a QC?\n")
    P(mdutil.table(["outcome of the timed-out view"] + RUNS, [[n] + [out_cat[r][n] for r in RUNS] for n in names] + [["views with OnLocalTimeout (active)"] + [sum(out_cat[r].values()) for r in RUNS]]))
    P("")
    # (b) durations
    t_enter = {}
    for r in RUNS:
        te = {}
        for e in D[r]["events"]:
            if e["ev"] == "ADVANCED":
                te.setdefault(e["view"], e["t"])
        t_enter[r] = te
    def pct(xs, p):
        xs = sorted(xs)
        if not xs:
            return float("nan")
        k = (len(xs) - 1) * p / 100.0
        f = int(k); c = min(f + 1, len(xs) - 1)
        return xs[f] + (xs[c] - xs[f]) * (k - f)
    rows = []
    for r in RUNS:
        dur = {v: t_enter[r][v + 1] - t_enter[r][v] for v in ACT[r] if v in t_enter[r] and (v + 1) in t_enter[r]}
        groups = collections.defaultdict(list)
        for v, d in dur.items():
            groups[classes[r][v][0]].append(d)
        for g in "SLDNFT":
            if groups[g]:
                xs = groups[g]
                rows.append([r, g, len(xs), f"{pct(xs, 50):.1f}", f"{sum(xs) / len(xs):.1f}", f"{pct(xs, 90):.1f}", f"{max(xs):.0f}"])
    P("Duration of a view = time from the first replica entering the view ('Advanced to view V') to the first replica entering V+1, by class (ms; log timestamps have 1 ms resolution):\n")
    P(mdutil.table(["run", "class", "views", "median", "mean", "p90", "max"], rows, align="llrrrrr"))
    P("")
    # (c) clustering of timeout views
    rows = []
    for r in RUNS:
        vs = sorted(ACT[r])
        T = {v for v in vs if classes[r][v][0] == "T"}
        a = sum(1 for v in vs if v in T and (v + 1) in T)
        b = sum(1 for v in vs if v in T and (v + 1) in ACT[r] and (v + 1) not in T)
        c = sum(1 for v in vs if v not in T and (v + 1) in T)
        d = sum(1 for v in vs if v not in T and (v + 1) in ACT[r] and (v + 1) not in T)
        odds, pf = stats.fisher_exact([[a, b], [c, d]])
        rows.append([r, len(T), a, b, c, d, f"{100 * a / (a + b):.1f}%", f"{100 * c / (c + d):.1f}%", f"{odds:.1f}", f"{pf:.3g}"])
    P("Do timeout views come in bursts?  2x2 table over consecutive active views (v, v+1): T = class T.\n")
    P(mdutil.table(["run", "T views", "T then T", "T then not-T", "not-T then T", "not-T then not-T", "P(T at v+1 | T at v)", "P(T at v+1 | not T at v)", "odds ratio", "Fisher p"], rows, align="lrrrrrrrrr"))
    P("")
    # (d) timeline per second
    P("Timeline: per second of the run (second 0 = client start, 'Stopping clients' at second 10): proposals seen for the first time / OnLocalTimeout: V lines / TC formations ('second advance')\n")
    rows = []
    tl = {}
    for r in RUNS:
        t0 = START[r]["t"]
        first_seen = {}
        for e in D[r]["events"]:
            if e["ev"] in ("TRY_COMMIT", "RECV_PROPOSAL") and e["blk"]:
                first_seen.setdefault(e["blk"]["view"], e["t"])
        pr = collections.Counter(int((t - t0) // 1000) for t in first_seen.values())
        lt = collections.Counter(int((e["t"] - t0) // 1000) for e in D[r]["events"] if e["ev"] == "LOCAL_TIMEOUT_VIEW")
        tcs = collections.Counter(int((e["t"] - t0) // 1000) for e in D[r]["events"] if e["ev"] == "REMOTE_TIMEOUT_2ND")
        tl[r] = (pr, lt, tcs)
    for sec in range(-0, 13):
        row = [sec]
        for r in RUNS:
            pr, lt, tcs = tl[r]
            row.append(f"{pr.get(sec, 0)} / {lt.get(sec, 0)} / {tcs.get(sec, 0)}")
        rows.append(row)
    P(mdutil.table(["second"] + [f"{r}: proposals / local timeouts / TCs" for r in RUNS], rows, align="lrrrr"))
    P("")
    J["timeline"] = {r: dict(proposals=dict(tl[r][0]), local=dict(tl[r][1]), tc=dict(tl[r][2])) for r in RUNS}

    # main_2 stall detail
    r = "main_2"
    t0 = START[r]["t"]
    seen = {}
    for e in D[r]["events"]:
        if e["ev"] in ("TRY_COMMIT", "RECV_PROPOSAL") and e["blk"]:
            seen.setdefault(e["blk"]["view"], e["t"] - t0)
    vs = sorted(seen)
    big = [(seen[v + 1] - seen[v], v) for v in vs if v + 1 in seen and seen[v + 1] - seen[v] >= 100]
    P(f"main_2: inter-proposal gaps >= 100 ms (gap ms, view v -> v+1): {[(round(g), v) for g, v in sorted(big, key=lambda x: x[1])]}\n")
    tv = sorted(v for v in ACT['main_2'] if classes['main_2'][v][0] == 'T')
    P(f"main_2 active views with timeout-type events: {tv}\n")
    J["main2_big_gaps"] = [(round(g), v) for g, v in sorted(big, key=lambda x: x[1])]

    # ------------------------------------------------------------------------------------------------ 3F
    P("## 3F. Same view, different run: do the vote-collection patterns recur?\n")
    comp = {}
    for r in RUNS:
        reg = D[r]["blocks"]
        seqs = collections.defaultdict(list)
        for e in D[r]["events"]:
            if e["ev"] == "COLLECT_VOTE":
                seqs[(e["r"], e["hash"])].append(e["from_id"])
        comp[r] = {}
        for (c, h), sq in seqs.items():
            if len(sq) == 4 and len(set(sq)) == 4:
                comp[r][reg[h]["view"]] = (c, reg[h]["proposer"], sq)
    def std_tail(r, v):
        x = comp[r].get(v)
        if x and x[2][0] == x[0] and x[2][1] == x[1]:
            return x[2][3]
        return None
    rows = []
    agree_all = collections.Counter()
    for a, b in itertools.combinations(RUNS, 2):
        pool = [v for v in (ACT[a] & ACT[b]) if std_tail(a, v) is not None and std_tail(b, v) is not None]
        same = sum(1 for v in pool if std_tail(a, v) == std_tail(b, v))
        pv = stats.binomtest(same, len(pool), 0.5).pvalue
        rows.append([a, b, len(pool), same, f"{100 * same / len(pool):.1f}%", f"{pv:.3g}"])
    P("(1) Which replica is LAST in the vote sequence of the same view (complete sequences of the form collector, proposer, X, Y; chance level 50%):\n")
    P(mdutil.table(["run A", "run B", "views compared", "same last sender", "agreement", "p (binomial vs 50%)"], rows, align="llrrrr"))
    P("")
    pool4 = [v for v in inter4a if all(std_tail(r, v) is not None for r in RUNS)]
    all_same = sum(1 for v in pool4 if len({std_tail(r, v) for r in RUNS}) == 1)
    P(f"All four runs agree on the last sender in {all_same} of {len(pool4)} views ({100 * all_same / len(pool4):.1f}%); if each run were an independent fair coin the expectation is 12.5% ({len(pool4) / 8:.0f} views); binomial p = {stats.binomtest(all_same, len(pool4), 0.125).pvalue:.3g}.\n")
    # (2) structure identical for the same view
    struct_ok = collections.Counter()
    for v in inter4a:
        for r in RUNS:
            x = comp[r].get(v)
            if x:
                struct_ok["collector first and proposer second" if (x[2][0] == x[0] and x[2][1] == x[1]) else "other order"] += 1
    P("(2) Collector first and proposer second, over all complete sequences of the shared views: " + ", ".join(f"{k}: {v}" for k, v in struct_ok.items()) + "\n")
    # (3) excluded replica
    def excl(r, v):
        reg = D[r]["blocks"]
        qc_ids_of = {}
        for b in reg.values():
            if len(b["qc_ids"]) == 3 and b["qc_hash"] not in qc_ids_of:
                qc_ids_of[b["qc_hash"]] = list(b["qc_ids"])
        h = next((hh for hh, b in reg.items() if b["view"] == v), None)
        ids = qc_ids_of.get(h)
        return [x for x in R4 if x not in ids][0] if ids else None
    EX = {r: {} for r in RUNS}
    for r in RUNS:
        reg = D[r]["blocks"]
        qc_ids_of = {}
        for b in reg.values():
            if len(b["qc_ids"]) == 3 and b["qc_hash"] not in qc_ids_of:
                qc_ids_of[b["qc_hash"]] = list(b["qc_ids"])
        for h, b in reg.items():
            ids = qc_ids_of.get(h)
            if ids:
                EX[r][b["view"]] = [x for x in R4 if x not in ids][0]
    rows = []
    for a, b in itertools.combinations(RUNS, 2):
        pool = [v for v in (ACT[a] & ACT[b]) if v in EX[a] and v in EX[b]]
        same = sum(1 for v in pool if EX[a][v] == EX[b][v])
        # expectation under independence given the marginal distribution of the excluded replica per view residue (= per collector)
        exp = 0.0
        for res in range(4):
            vv = [v for v in pool if v % 4 == res]
            if not vv:
                continue
            pa = collections.Counter(EX[a][v] for v in vv); pb = collections.Counter(EX[b][v] for v in vv)
            exp += len(vv) * sum((pa[k] / len(vv)) * (pb[k] / len(vv)) for k in R4)
        rows.append([a, b, len(pool), same, f"{100 * same / len(pool):.1f}%", f"{100 * exp / len(pool):.1f}%"])
    P("(3) Which replica is excluded from the QC of the same view (the 4th/late voter):\n")
    P(mdutil.table(["run A", "run B", "views compared", "same excluded replica", "agreement", "agreement expected if independent (per-collector marginals)"], rows, align="llrrrr"))
    P("")
    # (4) late vote presence co-occurrence
    rows = []
    for a, b in itertools.combinations(RUNS, 2):
        pool = sorted(ACT[a] & ACT[b])
        A = {v for v in pool if TAB[a][v]["cnt"]["BLOCK_TOO_OLD"]}; B = {v for v in pool if TAB[b][v]["cnt"]["BLOCK_TOO_OLD"]}
        both = len(A & B)
        exp = len(A) * len(B) / len(pool)
        rows.append([a, b, len(pool), len(A), len(B), both, f"{exp:.1f}"])
    P("(4) Views with a late 4th vote ('block too old') in run A / run B / both vs expected overlap if independent:\n")
    P(mdutil.table(["run A", "run B", "shared views", "late vote in A", "in B", "in both", "expected both"], rows, align="llrrrrr"))
    P("")

    # ------------------------------------------------------------------------------------------------ 3G
    P("## 3G. Matching by view number only vs by (view number, proposer)\n")
    # (i) proposer determined by view
    prop_conflict = 0
    prop_vs_leader = 0
    for v in inter4:
        props = {next(iter(TAB[r][v]["proposers"])) for r in RUNS}
        if len(props) > 1:
            prop_conflict += 1
    for r in RUNS:
        prop_vs_leader += sum(1 for v in BV[r] if TAB[r][v]["proposers"] != [LEADER(v)])
    P(f"Shared views whose proposer differs between runs: {prop_conflict};  blocks whose proposer is not leader(view) = (view mod 4)+1: {prop_vs_leader};  views with two different proposals in one run: 0.\n")
    # (ii) rebuild the comparison with composite keys
    KEY = {r: {(v, TAB[r][v]["proposers"][0]) for v in BV[r]} for r in RUNS}
    KACT = {r: {(v, TAB[r][v]["proposers"][0]) for v in ACT[r]} for r in RUNS}
    k4 = set.intersection(*[KEY[r] for r in RUNS]); k4a = set.intersection(*[KACT[r] for r in RUNS])
    kcls = {r: {(v, TAB[r][v]["proposers"][0]): classes[r][v] for v in ACT[r]} for r in RUNS}
    def kcore(k):
        return tuple(tuple(TAB[r][k[0]]["cnt"][c] for c in CORE) for r in RUNS)
    rows = []
    rows.append(["views / keys present in all four runs", len(inter4), len(k4)])
    rows.append(["... first seen in the active phase in all four", len(inter4a), len(k4a)])
    rows.append(["core counts identical in all four runs", n_core_same, sum(1 for k in k4a if len(set(kcore(k))) == 1)])
    rows.append(["class S/L/D (standard core) in all four runs", n_std4, sum(1 for k in k4a if all(kcls[r][k][0] in "SLD" for r in RUNS))])
    rows.append(["class T (timeout-type events) in >=1 run", n_any_t, sum(1 for k in k4a if any(kcls[r][k][0] == "T" for r in RUNS))])
    rows.append(["class T in all four runs", n_all_t, sum(1 for k in k4a if all(kcls[r][k][0] == "T" for r in RUNS))])
    rows.append(["views / keys with timeout-type events in all four runs (active)", len(I_act), len(set.intersection(*[{(v, TAB[r][v]['proposers'][0]) for v in TV[r]['active'] if v in BV[r]} for r in RUNS]))])
    tail_pairs_v = sum(1 for a, b in itertools.combinations(RUNS, 2) for v in (ACT[a] & ACT[b]) if std_tail(a, v) is not None and std_tail(b, v) is not None)
    tail_same_v = sum(1 for a, b in itertools.combinations(RUNS, 2) for v in (ACT[a] & ACT[b]) if std_tail(a, v) is not None and std_tail(b, v) is not None and std_tail(a, v) == std_tail(b, v))
    tail_pairs_k = sum(1 for a, b in itertools.combinations(RUNS, 2) for k in (KACT[a] & KACT[b]) if std_tail(a, k[0]) is not None and std_tail(b, k[0]) is not None)
    tail_same_k = sum(1 for a, b in itertools.combinations(RUNS, 2) for k in (KACT[a] & KACT[b]) if std_tail(a, k[0]) is not None and std_tail(b, k[0]) is not None and std_tail(a, k[0]) == std_tail(b, k[0]))
    rows.append(["pairwise comparisons of the last vote sender (pairs of runs x views)", tail_pairs_v, tail_pairs_k])
    rows.append(["... pairs with the same last sender", tail_same_v, tail_same_k])
    P(mdutil.table(["measure", "match by view number", "match by (view number, proposer)"], rows, align="lrr"))
    P("")
    P("Result: the two matchings are identical in every row, because the proposer is a function of the view number (round-robin leader). The proposer does however explain the vote order: the receiver of the votes is the next leader and the 2nd vote is always the proposer.\n")
    J["match_compare"] = rows

    # (iii) grouping by proposer as an extra dimension
    P("### 3G-2. Grouping the views by proposer (the extra dimension the key adds)\n")
    rows = []
    byp = {}
    for r in RUNS:
        for p in R4:
            vs = [v for v in ACT[r] if TAB[r][v]["proposers"] == [p]]
            cnt = collections.Counter(classes[r][v][0] for v in vs)
            odd = 0
            for v in vs:
                x = comp[r].get(v)
                if x and x[2][1] != p:
                    odd += 1
            byp[(r, p)] = (len(vs), cnt)
            rows.append([r, f"hs{p}", len(vs), f"{100 * cnt['T'] / len(vs):.1f}%", f"{100 * (cnt['L'] + cnt['D']) / len(vs):.1f}%", f"{100 * (cnt['N'] + cnt['F']) / len(vs):.1f}%", f"{100 * cnt['S'] / len(vs):.1f}%"])
    P(mdutil.table(["run", "proposer", "views led (active)", "class T %", "class L/D %", "class N/F %", "class S %"], rows, align="llrrrrr"))
    P("")
    rows = []
    for r in RUNS:
        for cl, nm in (("T", "timeout-type events"), ("L", "late 4th vote")):
            obs = [byp[(r, p)][1][cl] + (byp[(r, p)][1]["D"] if cl == "L" else 0) for p in R4]
            n = [byp[(r, p)][0] for p in R4]
            tot = sum(obs); N = sum(n)
            exp = [tot * x / N for x in n]
            chi = sum((o - e) ** 2 / e for o, e in zip(obs, exp) if e > 0)
            rows.append([r, nm, "/".join(map(str, obs)), "/".join(map(str, n)), f"{chi:.2f}", f"{stats.chi2.sf(chi, 3):.3g}"])
    P("Homogeneity of the four proposers (chi-square, df=3; indicative):\n")
    P(mdutil.table(["run", "event class", "views by proposer hs1/hs2/hs3/hs4", "views led hs1/hs2/hs3/hs4", "chi2", "p"], rows, align="llrrrr"))
    P("")

    print("\n".join(out))
    mdutil.dump_json(J, os.path.join(os.environ.get("HS_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "out")), "part3.json"))


if __name__ == "__main__":
    main()
