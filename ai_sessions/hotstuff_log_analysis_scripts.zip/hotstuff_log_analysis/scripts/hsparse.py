#!/usr/bin/env python3
"""
hsparse.py - parser for relab/hotstuff-style debug logs (4 replicas hs1..hs4 + client cli1 interleaved).

Every structured line has the form
    <timestamp>\t<LEVEL>\t<logger>\t<source-file:line>\t<message>
Anything else (stack-trace continuation lines of WARN entries, blank lines, the config banner) is ignored.

Each structured line is turned into an Event (a dict) whose 'ev' key is a stable event name.  The classifier uses
the MESSAGE TEXT, and the (file:line) call site is recorded and cross-checked by verify_sites() so that a message
can never silently map to two different call sites.
"""
import re
import sys
import collections
from datetime import datetime

import os
LOGDIR = os.environ.get("HS_LOGDIR", ".")      # directory that holds the four log files
LOGS = {name: os.path.join(LOGDIR, name + ".log") for name in ("main", "main_2", "main_3", "main_4")}
RUNS = list(LOGS)          # fixed order: main, main_2, main_3, main_4
REPLICAS = [1, 2, 3, 4]

BLOCK_RE = re.compile(
    r'Block\{ hash: (\S+) parent: (\S+), proposer: (\d+), view: (\d+) , '
    r'cert: QC\{ hash: (\S+), view: (\d+), IDs: \[([^\]]*)\] \} \}')
QC_RE = re.compile(r'QC\{ hash: (\S+), view: (\d+), IDs: \[([^\]]*)\] \}')
TC_RE = re.compile(r'TC\{ view: (\d+), IDs: \[([^\]]*)\] \}')

# (regex on message, event name).  First match wins.  Order matters only where patterns overlap.
MSG_RULES = [
    (re.compile(r'^Received proposal: '),                                   "RECV_PROPOSAL"),
    (re.compile(r'^Delaying proposal until after next view change'),        "DELAY_PROPOSAL"),
    (re.compile(r'^failed to verify incoming vote: '),                      "PROPOSAL_TOO_OLD"),   # sync.go:119
    (re.compile(r'^Propose$'),                                              "PROPOSE_INIT"),
    (re.compile(r'^OnLocalTimeout$'),                                       "LOCAL_TIMEOUT"),
    (re.compile(r'^OnLocalTimeout: (\d+)$'),                                "LOCAL_TIMEOUT_VIEW"),
    (re.compile(r'^Stopped voting for timed out view (\d+)'),               "STOP_VOTING"),
    (re.compile(r'^OnRemoteTimeout \(advancing view\): ID: (\d+), View: (\d+), SyncInfo: '), "REMOTE_TIMEOUT"),
    (re.compile(r'^OnRemoteTimeout: not enough timeouts for view (\d+)'),   "NOT_ENOUGH_TIMEOUTS"),
    (re.compile(r'^OnRemoteTimeout \(second advance\)'),                    "REMOTE_TIMEOUT_2ND"),
    (re.compile(r'^Failed to create sync info: '),                          "FAIL_CREATE_SYNCINFO"),
    (re.compile(r'^OnNewView \(from network: (true|false)\)'),              "ON_NEW_VIEW"),
    (re.compile(r'^advanceView: Failed to verify sync info: '),             "FAIL_VERIFY_SYNCINFO"),
    (re.compile(r'^advanceView: Successfully updated HighQC'),              "HQC_UPDATED"),
    (re.compile(r'^advanceView: HighQC not updated, current view: (\d+), new view: (\d+)'), "HQC_NOT_UPDATED"),
    (re.compile(r'^advanceView: Advanced to view (\d+)'),                   "ADVANCED"),
    (re.compile(r'^advanceView: \{'),                                       "ADVANCE_ENTER"),
    (re.compile(r'^Failed to create proposal: '),                           "FAIL_CREATE_PROPOSAL"),
    (re.compile(r'^CollectVote\(from (\d+)\): (\S+)$'),                     "COLLECT_VOTE"),
    (re.compile(r'^CollectVote: dispatching event for new view \(current : (\d+)\)'), "QC_DISPATCH"),
    (re.compile(r'^Local cache miss for block: (\S+)'),                     "CACHE_MISS"),
    (re.compile(r'^Could not find block for vote: (\S+?)\.?$'),             "NO_BLOCK_FOR_VOTE"),
    (re.compile(r'^block too old$'),                                        "BLOCK_TOO_OLD"),
    (re.compile(r'^TryCommit: '),                                           "TRY_COMMIT"),
    (re.compile(r'^CommitRule - PRE_COMMIT: '),                             "PRE_COMMIT"),
    (re.compile(r'^CommitRule - COMMIT: '),                                 "COMMIT"),
    (re.compile(r'^CommitRule - DECIDE: '),                                 "DECIDE"),
    (re.compile(r'^EXEC: '),                                                "EXEC"),
    (re.compile(r'^VoteRule: liveness condition failed'),                   "VOTERULE_LIVENESS_FAIL"),
    (re.compile(r'^Hash: '),                                                "BATCH_HASH"),
    (re.compile(r'^block already exists: '),                                "BLOCK_EXISTS"),
    (re.compile(r'^Attempting to fetch block: '),                           "FETCH_ATTEMPT"),
    (re.compile(r'^Successfully fetched block: '),                          "FETCH_OK"),
    (re.compile(r'^PruneToHeight: found forked block: '),                   "PRUNE_FORK"),
    (re.compile(r'^On RequestBlock: '),                                     "ON_REQUEST_BLOCK"),
    (re.compile(r'^Command timed out\.'),                                   "CLIENT_CMD_TIMEOUT"),
    (re.compile(r'^(\d+) commands sent so far'),                            "CLIENT_PROGRESS"),
    (re.compile(r'^Starting to send commands'),                             "CLIENT_START"),
    (re.compile(r'^Done sending commands'),                                 "CLIENT_DONE"),
    (re.compile(r'^Stopping clients'),                                      "CTRL_STOP_CLIENTS"),
    (re.compile(r'^Waiting 2\.5s for replicas'),                            "CTRL_WAIT"),
    (re.compile(r'^Stopping replicas'),                                     "CTRL_STOP_REPLICAS"),
    (re.compile(r'^Starting clients'),                                      "CTRL_START_CLIENTS"),
]


def parse_ids(s):
    return tuple(int(x) for x in s.split()) if s.strip() else tuple()


def parse_block(msg):
    m = BLOCK_RE.search(msg)
    if not m:
        return None
    return dict(hash=m.group(1), parent=m.group(2), proposer=int(m.group(3)), view=int(m.group(4)),
                qc_hash=m.group(5), qc_view=int(m.group(6)), qc_ids=parse_ids(m.group(7)))


def parse_ts_ms(ts):
    # 2026-06-22T14:40:41.155+0200  (all four logs share the +0200 offset, so naive parsing is consistent)
    d = datetime.strptime(ts[:23], "%Y-%m-%dT%H:%M:%S.%f")
    return d.timestamp() * 1000.0


def replica_of(logger):
    if logger.startswith("hs") and logger[2:].isdigit():
        return int(logger[2:])
    return None


def parse_log(path):
    """Return (events, meta).  events: list of dicts in FILE ORDER with keys
       n (1-based physical line number), ts, t (ms), lvl, lg, r (replica id or None), src, msg, ev + payload fields."""
    events = []
    with open(path, errors="replace") as f:
        for n, line in enumerate(f, 1):
            parts = line.rstrip("\n").split("\t", 4)
            if len(parts) < 5 or parts[1] not in ("DEBUG", "INFO", "WARN", "ERROR"):
                continue
            ts, lvl, lg, src, msg = parts
            e = dict(n=n, ts=ts, t=parse_ts_ms(ts), lvl=lvl, lg=lg, r=replica_of(lg), src=src, msg=msg, ev=None)
            for rx, name in MSG_RULES:
                m = rx.search(msg)
                if m:
                    e["ev"] = name
                    g = m.groups()
                    if name == "LOCAL_TIMEOUT_VIEW":
                        e["view"] = int(g[0])
                    elif name == "STOP_VOTING":
                        e["view"] = int(g[0])
                    elif name == "REMOTE_TIMEOUT":
                        e["from_id"], e["view"] = int(g[0]), int(g[1])
                        e["tc"] = None
                        mt = TC_RE.search(msg)
                        if mt:
                            e["tc"] = (int(mt.group(1)), parse_ids(mt.group(2)))
                        mq = QC_RE.search(msg)
                        if mq:
                            e["qc"] = (mq.group(1), int(mq.group(2)), parse_ids(mq.group(3)))
                    elif name == "NOT_ENOUGH_TIMEOUTS":
                        e["view"] = int(g[0])
                    elif name == "ON_NEW_VIEW":
                        e["from_network"] = (g[0] == "true")
                    elif name == "HQC_NOT_UPDATED":
                        e["cur"], e["new"] = int(g[0]), int(g[1])
                    elif name == "ADVANCED":
                        e["view"] = int(g[0])
                    elif name == "ADVANCE_ENTER":
                        mt = TC_RE.search(msg)
                        mq = QC_RE.search(msg)
                        e["tc"] = (int(mt.group(1)), parse_ids(mt.group(2))) if mt else None
                        e["qc"] = (mq.group(1), int(mq.group(2)), parse_ids(mq.group(3))) if mq else None
                    elif name == "COLLECT_VOTE":
                        e["from_id"], e["hash"] = int(g[0]), g[1]
                    elif name == "QC_DISPATCH":
                        e["view"] = int(g[0])
                    elif name in ("CACHE_MISS", "NO_BLOCK_FOR_VOTE"):
                        e["hash"] = g[0]
                    elif name in ("FETCH_ATTEMPT", "FETCH_OK", "ON_REQUEST_BLOCK"):
                        e["hash"] = msg.rsplit(": ", 1)[1].strip()
                    elif name == "PROPOSAL_TOO_OLD":
                        mm = re.search(r'block view (\d+) too old, last voted view was (\d+)', msg)
                        if mm:
                            e["blk_view"], e["last_vote"] = int(mm.group(1)), int(mm.group(2))
                    elif name == "DELAY_PROPOSAL":
                        mm = re.search(r'proposal view (\d+) > local view (\d+)', msg)
                        if mm:
                            e["prop_view"], e["local_view"] = int(mm.group(1)), int(mm.group(2))
                    elif name == "FAIL_VERIFY_SYNCINFO":
                        e["reason"] = msg.split("Failed to verify sync info: ", 1)[1]
                    elif name == "CLIENT_DONE":
                        mm = re.search(r'executed: (\d+), failed: (\d+), timeouts: (\d+)', msg)
                        if mm:
                            e["executed"], e["failed"], e["timeouts"] = (int(mm.group(1)), int(mm.group(2)), int(mm.group(3)))
                    elif name in ("RECV_PROPOSAL", "TRY_COMMIT", "PRE_COMMIT", "COMMIT", "DECIDE", "EXEC",
                                  "BLOCK_EXISTS", "PRUNE_FORK"):
                        e["blk"] = parse_block(msg)
                    break
            events.append(e)
    return events


def build_block_registry(events):
    """hash -> dict(view, proposer, parent, qc_hash, qc_view, qc_ids); also reports hash collisions."""
    reg = {}
    collisions = []
    for e in events:
        b = e.get("blk")
        if not b:
            continue
        h = b["hash"]
        key = (b["view"], b["proposer"], b["parent"], b["qc_hash"], b["qc_view"])
        if h in reg:
            old = reg[h]
            if (old["view"], old["proposer"], old["parent"], old["qc_hash"], old["qc_view"]) != key:
                collisions.append((h, old, b))
        else:
            reg[h] = dict(b)
    return reg, collisions


def leader_of(view, n=4):
    """Round-robin leader as observed in the logs: view 1 -> replica 2, view 2 -> 3, view 3 -> 4, view 4 -> 1 ..."""
    return (view % n) + 1


def verify_sites(all_events):
    """Each message type must map to exactly one source call-site across all runs. Returns dict ev -> set(src)."""
    sites = collections.defaultdict(set)
    for run, evs in all_events.items():
        for e in evs:
            if e["ev"]:
                sites[e["ev"]].add(e["src"])
    return sites


if __name__ == "__main__":
    for run, path in LOGS.items():
        evs = parse_log(path)
        c = collections.Counter(e["ev"] for e in evs)
        print(run, len(evs), "structured lines;", sum(1 for e in evs if e["ev"] is None), "unclassified")
        un = collections.Counter((e["src"], e["msg"][:60]) for e in evs if e["ev"] is None)
        for k, v in un.most_common(12):
            print("   unclassified:", v, k)
