#!/usr/bin/env bash
# verify_votes.sh - independent (awk only) re-computation of the Part-2 vote-order statistics straight from the raw logs.
#   usage:  ./verify_votes.sh [LOGDIR] [OUT_TSV]
#   Output TSV columns: run <TAB> metric <TAB> collector_or_proposer <TAB> sender_or_position <TAB> count
#
# Definitions (identical to part2_votes.py, but implemented without the Python parser):
#   * a vote line is  '<ts> DEBUG hsK votingmachine/votingmachine.go:55 CollectVote(from N): <hash>'
#     -> collector = logger hsK (receiver of the vote), sender = N, order = physical line order,
#   * COMPLETE sequence = for one (collector, hash): exactly 4 CollectVote lines from 4 distinct senders,
#   * proposer / QC IDs of a block come from the first 'Received proposal' / 'TryCommit' line that prints the block
#     ('Block{ hash: H parent: P, proposer: N, view: V , cert: QC{ hash: Q, view: W, IDs: [ a b c ] } }'),
#   * the QC of block H = the 'cert: QC{ hash: H ... IDs: [ a b c ]' printed in the first block that carries it,
#   * proposal reception order = order of the first 'Received proposal' line per replica for a block (blocks received by exactly 3 replicas).
set -u
LOGDIR=${1:-.}
OUT=${2:-./verify_votes.tsv}
: > "$OUT"
for run in main main_2 main_3 main_4; do
  awk -F'\t' -v run="$run" '
  {
    lg = $3; msg = $5
    if (lg !~ /^hs[1-4]$/) next
    K = substr(lg, 3) + 0
    if (msg ~ /^(Received proposal|TryCommit): Block\{ hash: /) {
      if (match(msg, /Block\{ hash: [^ ]+ parent: [^,]+, proposer: [0-9]+, view: [0-9]+ , cert: QC\{ hash: [^,]+, view: [0-9]+, IDs: \[[^]]*\]/)) {
        t = substr(msg, RSTART, RLENGTH)
        gsub(/[][{},:]/, " ", t)
        nt = split(t, a, " ")
        h = a[3]; prop[h] = a[7] + 0; qh = a[13]
        ids = ""
        for (i = 17; i <= nt; i++) ids = ids (ids == "" ? "" : " ") a[i]
        if (!(qh in qcids)) qcids[qh] = ids
        if (msg ~ /^Received proposal/) {
          key = h SUBSEP K
          if (!(key in seenrx)) { seenrx[key] = 1; nrx[h]++; rxorder[h] = rxorder[h] " " K }
        }
      }
    } else if (msg ~ /^CollectVote\(from [0-9]+\): /) {
      snd = msg; sub(/^CollectVote\(from /, "", snd); sub(/\).*$/, "", snd)
      hh = msg;  sub(/^CollectVote\(from [0-9]+\): /, "", hh)
      key = K SUBSEP hh
      nv[key]++
      sq[key] = sq[key] " " snd
    }
  }
  END {
    for (key in nv) {
      if (nv[key] != 4) continue
      split(key, kk, SUBSEP); K = kk[1] + 0; h = kk[2]
      split(substr(sq[key], 2), s, " ")
      for (i = 1; i <= 4; i++) seen[s[i]] = 1
      cnt = 0; for (x in seen) { cnt++; delete seen[x] }
      if (cnt != 4) continue
      tot[K]++
      first[K, s[1]]++; second[K, s[2]]++; third[K, s[3]]++; last[K, s[4]]++
      if (s[1] == K) cf[K]++
      p = prop[h]
      if (s[2] == p) ps[K]++
      for (i = 1; i <= 4; i++) if (s[i] == p) pp[K, i]++
      if (h in qcids) {
        m = split(qcids[h], q, " ")
        if (m == 3) {
          nq[K]++
          c4 = (s[4] == q[1] || s[4] == q[2] || s[4] == q[3])
          if (q[1] == s[1] && q[2] == s[2] && q[3] == s[3]) same[K]++
          else if (!c4) sameset[K]++
          else cont4[K]++
          for (j = 1; j <= 4; j++) if (q[1] != j && q[2] != j && q[3] != j) ex = j
          exc[K, ex]++
          for (i = 1; i <= 4; i++) if (s[i] == ex) excpos[K, i]++
          if (q[1] == K) qf[K]++; else qn[K]++
        }
      }
    }
    for (h in nrx) {
      if (nrx[h] != 3) continue
      split(substr(rxorder[h], 2), o, " ")
      P = prop[h]
      prn[P]++; prf[P, o[1]]++; prl[P, o[3]]++
    }
    for (K = 1; K <= 4; K++) {
      printf "%s\tcomplete_n\t%d\t-\t%d\n", run, K, tot[K]
      printf "%s\tcollector_first\t%d\t-\t%d\n", run, K, cf[K]
      printf "%s\tproposer_second\t%d\t-\t%d\n", run, K, ps[K]
      for (i = 1; i <= 4; i++) if (pp[K, i] > 0) printf "%s\tproposer_pos%d\t%d\t-\t%d\n", run, i, K, pp[K, i]
      for (j = 1; j <= 4; j++) {
        if (first[K, j] > 0)  printf "%s\tfirst\t%d\t%d\t%d\n",  run, K, j, first[K, j]
        if (second[K, j] > 0) printf "%s\tsecond\t%d\t%d\t%d\n", run, K, j, second[K, j]
        if (third[K, j] > 0)  printf "%s\tthird\t%d\t%d\t%d\n",  run, K, j, third[K, j]
        if (last[K, j] > 0)   printf "%s\tlast\t%d\t%d\t%d\n",   run, K, j, last[K, j]
        if (exc[K, j] > 0)    printf "%s\texcluded\t%d\t%d\t%d\n", run, K, j, exc[K, j]
      }
      for (i = 1; i <= 4; i++) if (excpos[K, i] > 0) printf "%s\texcluded_pos\t%d\t%d\t%d\n", run, K, i, excpos[K, i]
      printf "%s\tqc_n\t%d\t-\t%d\n", run, K, nq[K]
      if (same[K] > 0)    printf "%s\tqc_same_order\t%d\t-\t%d\n", run, K, same[K]
      if (sameset[K] > 0) printf "%s\tqc_same_set_diff_order\t%d\t-\t%d\n", run, K, sameset[K]
      if (cont4[K] > 0)   printf "%s\tqc_contains_4th\t%d\t-\t%d\n", run, K, cont4[K]
      if (qf[K] > 0)      printf "%s\tqc_first_is_collector\t%d\t-\t%d\n", run, K, qf[K]
      if (qn[K] > 0)      printf "%s\tqc_first_not_collector\t%d\t-\t%d\n", run, K, qn[K]
    }
    for (P = 1; P <= 4; P++) {
      printf "%s\tprop_n\t%d\t-\t%d\n", run, P, prn[P]
      for (j = 1; j <= 4; j++) {
        if (prf[P, j] > 0) printf "%s\tprop_first\t%d\t%d\t%d\n", run, P, j, prf[P, j]
        if (prl[P, j] > 0) printf "%s\tprop_last\t%d\t%d\t%d\n",  run, P, j, prl[P, j]
      }
    }
  }' "$LOGDIR/$run.log" >> "$OUT"
done

echo "wrote $OUT  ($(wc -l < "$OUT") rows)"
echo
echo "complete vote sequences per run and collector (awk):"
awk -F'\t' '$2=="complete_n" { n[$1]=n[$1] " hs" $3 "=" $5; t[$1]+=$5 } END { for (r in n) print "  " r ": total " t[r] " |" n[r] }' "$OUT" | sort
echo
echo "FIRST position per collector/sender (count) - collector should always be first:"
awk -F'\t' '$2=="first" { printf "  %s collector hs%s first=hs%s: %s\n", $1, $3, $4, $5 }' "$OUT" | sort | head -16
