"""Part 1 - extra sections (1H-1K): classification of 'Failed to verify sync info', outcome of every
'OnRemoteTimeout (advancing view)', anatomy of 'block too old', and the commit / decide / execute chain.
Imported by part1_counts.py; everything here is derived from the parsed log events (line order = ordering primitive)."""
import collections

import mdutil


def _registry(run_data):
    reg = dict(run_data["blocks"])
    for e in run_data["events"]:
        if e.get("blk") and e["blk"]["hash"] not in reg:      # genesis etc. appear only inside CommitRule lines
            reg[e["blk"]["hash"]] = e["blk"]
    return reg


# ---------------------------------------------------------------------------------------------------------------
# 1H  Failed to verify sync info
# ---------------------------------------------------------------------------------------------------------------
def tc_consistency(H, run_data):
    """For every timeout certificate (TC) that a replica built from timeout messages ('second advance'),
    check whether the latest timeout message this replica had received from each listed signer is for the TC's view."""
    evs = run_data["events"]
    fail_by_enter = {e["enter_n"]: e for e in evs if e["ev"] == "FAIL_VERIFY_SYNCINFO"}
    latest_remote = {k: {} for k in H.REPLICAS}
    latest_local = {k: None for k in H.REPLICAS}
    tab = collections.Counter()
    ex = []
    for e in evs:
        k = e["r"]
        if e["ev"] == "REMOTE_TIMEOUT":
            latest_remote[k][e["from_id"]] = e["view"]
        elif e["ev"] == "LOCAL_TIMEOUT_VIEW":
            latest_local[k] = e["view"]
        elif e["ev"] == "ADVANCE_ENTER" and e.get("trigger") == "REMOTE_TIMEOUT_2ND" and e["tc"] and e["tc"][1]:
            tv, ids = e["tc"]
            bad = []
            for s in ids:
                lv = latest_local[k] if s == k else latest_remote[k].get(s)
                if lv != tv:
                    bad.append((s, lv))
            failed = e["n"] in fail_by_enter
            tab[("consistent" if not bad else "mixed-view", "fail" if failed else "ok")] += 1
            if failed and len(ex) < 3:
                ex.append(dict(line=e["n"], replica=k, tc_view=tv, ids=list(ids), stale=bad, fail_line=fail_by_enter[e["n"]]["n"]))
    return tab, ex


def section_1h(H, D, C, RUNS):
    out = ["## 1H. 'Failed to verify sync info' - what is failing, and is it linked to anything else in the log?\n"]
    hdr = ["metric"] + RUNS
    rows = []
    rows.append(["total lines 'Failed to verify sync info'"] + [C[(r, "P2  Failed to verify sync info")][0] for r in RUNS])
    rows.append(["... of which 'timeout certificate: ecdsa: failed to verify signature'"] + [C[(r, "P2a   ... timeout certificate / ecdsa signature")][0] for r in RUNS])
    rows.append(["... of which 'quorum certificate: block not found'"] + [C[(r, "P2b   ... quorum certificate / block not found")][0] for r in RUNS])
    tabs = {r: tc_consistency(H, D[r])[0] for r in RUNS}
    rows.append(["TCs built by replicas from timeout messages (all phases)"] + [sum(tabs[r].values()) for r in RUNS])
    rows.append(["... TC whose signers' latest timeout message is for the TC view ('consistent'), accepted"] + [tabs[r][("consistent", "ok")] for r in RUNS])
    rows.append(["... consistent but verification failed"] + [tabs[r][("consistent", "fail")] for r in RUNS])
    rows.append(["... TC with >=1 signer whose latest message is for another view ('mixed-view'), verification failed"] + [tabs[r][("mixed-view", "fail")] for r in RUNS])
    rows.append(["... mixed-view but accepted"] + [tabs[r][("mixed-view", "ok")] for r in RUNS])
    out.append(mdutil.table(hdr, rows))
    out.append("")
    out.append("Reading: the association is exact - every ECDSA TC failure is a mixed-view TC and every mixed-view TC fails (see rows 5-8); "
               "the only non-TC failure is the single 'block not found' QC check in main_2.\n")
    return "\n".join(out), tabs


# ---------------------------------------------------------------------------------------------------------------
# 1I  outcome of each OnRemoteTimeout (advancing view)
# ---------------------------------------------------------------------------------------------------------------
def remote_timeout_outcomes(H, run_data):
    evs = run_data["events"]
    outc = collections.Counter()
    keep = ("REMOTE_TIMEOUT", "NOT_ENOUGH_TIMEOUTS", "REMOTE_TIMEOUT_2ND", "ADVANCE_ENTER", "HQC_UPDATED", "HQC_NOT_UPDATED", "ADVANCED",
            "FAIL_VERIFY_SYNCINFO", "FAIL_CREATE_SYNCINFO", "ON_NEW_VIEW", "RECV_PROPOSAL")
    for k in H.REPLICAS:
        st = [e for e in evs if e["r"] == k and e["ev"] in keep]
        for i, e in enumerate(st):
            if e["ev"] != "REMOTE_TIMEOUT":
                continue
            nxt, j = [], i + 1
            while j < len(st) and len(nxt) < 5 and st[j]["ev"] not in ("REMOTE_TIMEOUT", "ON_NEW_VIEW", "RECV_PROPOSAL"):
                nxt.append(st[j]["ev"]); j += 1
            if "REMOTE_TIMEOUT_2ND" in nxt:
                outc["TC formed (second advance), verification ok" if "FAIL_VERIFY_SYNCINFO" not in nxt else "TC formed (second advance), verification FAILED"] += 1
            elif "NOT_ENOUGH_TIMEOUTS" in nxt:
                outc["not enough timeouts (quorum not reached)"] += 1
            elif "FAIL_CREATE_SYNCINFO" in nxt:
                outc["Failed to create sync info (overlapping signatures)"] += 1
            else:
                outc["other"] += 1
    return outc


def section_1i(H, D, RUNS, C):
    out = ["## 1I. Outcome of every 'OnRemoteTimeout (advancing view)' line (next timeout-related line at the same replica)\n"]
    res = {r: remote_timeout_outcomes(H, D[r]) for r in RUNS}
    names = ["not enough timeouts (quorum not reached)", "TC formed (second advance), verification ok", "TC formed (second advance), verification FAILED",
             "Failed to create sync info (overlapping signatures)", "other"]
    rows = [[n] + [res[r][n] for r in RUNS] for n in names]
    rows.append(["sum = lines matching 'OnRemoteTimeout \\(advancing view\\)'"] + [sum(res[r].values()) for r in RUNS])
    rows.append(["check: P4a count from 1A"] + [C[(r, "P4a   OnRemoteTimeout (advancing view)")][0] for r in RUNS])
    out.append(mdutil.table(["outcome"] + RUNS, rows))
    out.append("")
    return "\n".join(out), res


# ---------------------------------------------------------------------------------------------------------------
# 1J  anatomy of 'block too old'
# ---------------------------------------------------------------------------------------------------------------
def block_too_old(H, run_data):
    evs, reg = run_data["events"], run_data["blocks"]
    by_view = {b["view"]: b for b in reg.values()}
    qc_dispatch_n = {(e["r"], e["v"]): e["n"] for e in evs if e["ev"] == "QC_DISPATCH"}
    res = collections.Counter(); pos = collections.Counter(); sender = collections.Counter()
    for k in H.REPLICAS:
        st = [e for e in evs if e["r"] == k]
        votes = collections.defaultdict(list)
        for e in st:
            if e["ev"] == "COLLECT_VOTE":
                votes[e["hash"]].append(e)
        for i, e in enumerate(st):
            if e["ev"] != "BLOCK_TOO_OLD":
                continue
            res["total"] += 1
            prev = st[i - 1]
            if prev["ev"] != "COLLECT_VOTE":
                res["not directly preceded by a CollectVote line"] += 1
                continue
            res["directly preceded by CollectVote(from N) for the same block"] += 1
            b = reg[prev["hash"]]
            p = [x["n"] for x in votes[prev["hash"]]].index(prev["n"]) + 1
            pos[p] += 1
            sender[prev["from_id"]] += 1
            dn = qc_dispatch_n.get((k, b["view"]))
            if dn is not None and dn < prev["n"]:
                res["QC for that block already dispatched at this collector"] += 1
            nxt = by_view.get(b["view"] + 1)
            if nxt and nxt["qc_view"] == b["view"] and prev["from_id"] not in nxt["qc_ids"]:
                res["voter not listed in QC.IDs of the next block's attached QC"] += 1
    return res, pos, sender


def section_1j(H, D, RUNS):
    out = ["## 1J. Anatomy of 'block too old' (all phases)\n"]
    data = {r: block_too_old(H, D[r]) for r in RUNS}
    names = ["total", "directly preceded by CollectVote(from N) for the same block", "QC for that block already dispatched at this collector",
             "voter not listed in QC.IDs of the next block's attached QC"]
    rows = [[n] + [data[r][0][n] for r in RUNS] for n in names]
    for p in (4, 5, 6):
        rows.append([f"vote is the {p}th CollectVote line for that block at that collector"] + [data[r][1].get(p, 0) for r in RUNS])
    rows.append(["share of QCs formed that later get a 'block too old' (%)"] + [round(100 * data[r][0]["total"] / max(1, sum(1 for e in D[r]["events"] if e["ev"] == "QC_DISPATCH")), 1) for r in RUNS])
    out.append(mdutil.table(["metric"] + RUNS, rows))
    out.append("")
    out.append("late voter (sender id) hs1/hs2/hs3/hs4: " + "; ".join(f"{r}: " + "/".join(str(data[r][2].get(k, 0)) for k in H.REPLICAS) for r in RUNS) + "\n")
    return "\n".join(out), data


# ---------------------------------------------------------------------------------------------------------------
# 1K  commit / decide / execute chain
# ---------------------------------------------------------------------------------------------------------------
def commit_chain(H, run_data):
    evs = run_data["events"]
    reg = _registry(run_data)
    shapes = collections.Counter(); r1 = collections.Counter(); r2 = collections.Counter(); gaps_tab = collections.defaultdict(collections.Counter)
    for k in H.REPLICAS:
        st = [e for e in evs if e["r"] == k and e["ev"] in ("TRY_COMMIT", "PRE_COMMIT", "COMMIT", "DECIDE")]
        groups, cur = [], None
        for e in st:
            if e["ev"] == "TRY_COMMIT":
                if cur is not None:
                    groups.append(cur)
                cur = (e, [])
            elif cur is not None:
                cur[1].append(e)
        if cur is not None:
            groups.append(cur)
        lock = 0
        for tc, lines in groups:
            b = reg[tc["blk"]["hash"]]
            b1 = reg.get(b["qc_hash"]); b2 = reg.get(b1["qc_hash"]) if b1 else None; b3 = reg.get(b2["qc_hash"]) if b2 else None
            has = {l["ev"] for l in lines}
            shapes["+".join(l["ev"] for l in lines) or "(none)"] += 1
            if b2 is not None:
                r2[((b2["view"] > lock), ("COMMIT" in has))] += 1
                if "COMMIT" in has:
                    lock = max(lock, [l for l in lines if l["ev"] == "COMMIT"][0]["blk"]["view"])
            if b3 is not None:
                exp = (b1["view"] == b2["view"] + 1) and (b2["view"] == b3["view"] + 1)
                r1[(exp, "DECIDE" in has)] += 1
            g = tuple((x["view"] - y["view"]) if (x and y) else None for x, y in ((b, b1), (b1, b2), (b2, b3)))
            gaps_tab[g]["+".join(l["ev"] for l in lines) or "(none)"] += 1
    per = {}
    for k in H.REPLICAS:
        dec = [e for e in evs if e["r"] == k and e["ev"] == "DECIDE"]
        exe = [e for e in evs if e["r"] == k and e["ev"] == "EXEC"]
        dh = [e["blk"]["hash"] for e in dec]; eh = [e["blk"]["hash"] for e in exe]
        per[k] = dict(try_commit=sum(1 for e in evs if e["r"] == k and e["ev"] == "TRY_COMMIT"),
                      pre=sum(1 for e in evs if e["r"] == k and e["ev"] == "PRE_COMMIT"),
                      commit=sum(1 for e in evs if e["r"] == k and e["ev"] == "COMMIT"),
                      decide=len(dh), decide_distinct=len(set(dh)), exec=len(eh), exec_distinct=len(set(eh)),
                      decide_genesis=sum(1 for e in dec if e["blk"]["view"] == 0),
                      exec_without_decide=len(set(eh) - set(dh)),
                      exec_views_increasing=all(a["blk"]["view"] < b["blk"]["view"] for a, b in zip(exe, exe[1:])),
                      exec_hashes=eh)
    ks = list(H.REPLICAS)
    m = min(len(per[k]["exec_hashes"]) for k in ks)
    same_prefix = all(per[k]["exec_hashes"][:m] == per[ks[0]]["exec_hashes"][:m] for k in ks)
    same_len = len({len(per[k]["exec_hashes"]) for k in ks}) == 1
    brk = collections.Counter()
    for b in run_data["blocks"].values():
        p = reg.get(b["parent"])
        if p is not None and b["view"] >= 1:
            brk[b["view"] - p["view"]] += 1
    return dict(shapes=shapes, r1=r1, r2=r2, per=per, same_prefix=same_prefix, same_len=same_len, prefix_len=m, parent_gap=brk, gaps_tab=gaps_tab)


def section_1k(H, D, RUNS):
    out = ["## 1K. Commit / DECIDE / EXEC chain\n"]
    data = {r: commit_chain(H, D[r]) for r in RUNS}
    hdr = ["per replica (hs1/hs2/hs3/hs4)"] + RUNS
    rows = []
    for key, name in [("try_commit", "TryCommit (validated proposal processed)"), ("pre", "CommitRule - PRE_COMMIT"), ("commit", "CommitRule - COMMIT"),
                      ("decide", "CommitRule - DECIDE (incl. genesis once)"), ("decide_distinct", "... distinct blocks decided"), ("exec", "EXEC"),
                      ("exec_without_decide", "EXEC of a block that never had its own DECIDE line (ancestor executed with a descendant)")]:
        rows.append([name] + ["/".join(str(data[r]["per"][k][key]) for k in H.REPLICAS) for r in RUNS])
    out.append(mdutil.table(hdr, rows, align="lrrrr"))
    out.append("")
    hdr = ["rule tested against the log (zero violations expected)"] + RUNS
    rows = []
    def pairs(c, what):
        names = {(True, True): f"{what} expected and logged", (False, False): f"{what} not expected and not logged",
                 (True, False): f"{what} expected but NOT logged", (False, True): f"{what} logged but NOT expected"}
        return "; ".join(f"{names[k]}: {v}" for k, v in sorted(c.items(), reverse=True))
    rows.append(["R2: a COMMIT line is logged  <=>  view(block2) > largest view of any earlier COMMIT line at that replica"] + [pairs(data[r]["r2"], "COMMIT") for r in RUNS])
    rows.append(["R1: a DECIDE line is logged  <=>  view(block1) = view(block2)+1 and view(block2) = view(block3)+1"] + [pairs(data[r]["r1"], "DECIDE") for r in RUNS])
    rows.append(["R1/R2 violations"] + [sum(v for (a, b), v in data[r]["r1"].items() if a != b) + sum(v for (a, b), v in data[r]["r2"].items() if a != b) for r in RUNS])
    rows.append(["all replicas execute the same hash sequence (same length, identical)"] + [f"{'yes' if (data[r]['same_len'] and data[r]['same_prefix']) else 'NO'} (n={data[r]['prefix_len']})" for r in RUNS])
    rows.append(["EXEC view numbers strictly increasing at every replica"] + ["yes" if all(data[r]["per"][k]["exec_views_increasing"] for k in H.REPLICAS) else "NO" for r in RUNS])
    rows.append(["parent-link gaps (view - parent view) over all proposals"] + [", ".join(f"gap{g}:{v}" for g, v in sorted(data[r]["parent_gap"].items())) for r in RUNS])
    out.append(mdutil.table(hdr, rows, align="lrrrr"))
    out.append("")
    return "\n".join(out), data
