#!/usr/bin/env bash
# verify_views.sh - independent grep/awk/sort/comm check of the Part-3 view sets (no Python).
#   usage: ./verify_views.sh [LOGDIR] [WORKDIR]       (WORKDIR receives the per-run view lists, default ./views_work)
#   Output: key=value lines that compare_views.py checks against part3.json.
set -u
LOGDIR=${1:-.}
W=${2:-./views_work}
mkdir -p "$W"
RUNS="main main_2 main_3 main_4"

for r in $RUNS; do
  f="$LOGDIR/$r.log"
  STOP=$(grep -n 'Stopping clients\.\.\.' "$f" | head -1 | cut -d: -f1)
  # (a) views that carry a proposal: 'proposer: P, view: V' printed by 'Received proposal' or 'TryCommit' lines (view >= 1)
  grep -E 'Received proposal|TryCommit:' "$f" | grep -oE 'proposer: [0-9]+, view: [0-9]+' | sed -E 's/proposer: ([0-9]+), view: ([0-9]+)/\2 \1/' | sort -u -k1,1n -k2,2n | awk '$1>=1' > "$W/$r.view_proposer"
  cut -d' ' -f1 "$W/$r.view_proposer" | sort -u > "$W/$r.views"     # plain (lexicographic) order: required by comm
  # first line where each view's block is seen -> active/drain
  grep -nE 'Received proposal|TryCommit:' "$f" | awk -F'\t' -v stop="$STOP" '
      { split($1, a, ":"); n = a[1]; if (match($5, /proposer: [0-9]+, view: [0-9]+/)) { t = substr($5, RSTART, RLENGTH); sub(/.*view: /, "", t); v = t + 0; if (v >= 1 && !(v in first)) first[v] = n } }
      END { for (v in first) if (first[v] < stop) print v }' | sort > "$W/$r.active_views"
  # (b) timeout-type events with an explicit view number in the message, active phase only (line < STOP)
  head -n $((STOP-1)) "$f" | grep -E 'OnLocalTimeout: [0-9]+$' | sed -E 's/.*OnLocalTimeout: ([0-9]+)$/\1/' | sort -u > "$W/$r.local_to_views_active"
  head -n $((STOP-1)) "$f" | grep -E 'OnRemoteTimeout \(advancing view\): ID: [0-9]+, View: [0-9]+|not enough timeouts for view [0-9]+|Stopped voting for timed out view [0-9]+|OnLocalTimeout: [0-9]+$' |
     sed -E 's/.*OnRemoteTimeout \(advancing view\): ID: [0-9]+, View: ([0-9]+).*/\1/; s/.*not enough timeouts for view ([0-9]+).*/\1/; s/.*Stopped voting for timed out view ([0-9]+).*/\1/; s/.*OnLocalTimeout: ([0-9]+)$/\1/' | sort -u > "$W/$r.timeout_views_active"
done

echo "== (a) views with a proposal"
for r in $RUNS; do echo "views_with_proposal.$r=$(wc -l < "$W/$r.views")"; echo "active_views.$r=$(wc -l < "$W/$r.active_views")"; done
cp "$W/main.views" "$W/_i"
for r in main_2 main_3 main_4; do comm -12 "$W/_i" "$W/$r.views" > "$W/_j"; mv "$W/_j" "$W/_i"; done
echo "views_in_all_four=$(wc -l < "$W/_i")"
cp "$W/main.active_views" "$W/_i"
for r in main_2 main_3 main_4; do comm -12 "$W/_i" "$W/$r.active_views" > "$W/_j"; mv "$W/_j" "$W/_i"; done
echo "active_views_in_all_four=$(wc -l < "$W/_i")"
for a in $RUNS; do for b in $RUNS; do printf 'pair.%s.%s=%s\n' "$a" "$b" "$(comm -12 "$W/$a.views" "$W/$b.views" | wc -l)"; done; done
echo "views_in_union=$(cat $W/*.views | sort -u | wc -l)"

echo "== (b) timeout views (explicit view number in the message), active phase"
for r in $RUNS; do echo "local_timeout_views_active.$r=$(wc -l < "$W/$r.local_to_views_active")"; echo "timeout_views_active_explicit.$r=$(wc -l < "$W/$r.timeout_views_active")"; done
cp "$W/main.local_to_views_active" "$W/_i"
for r in main_2 main_3 main_4; do comm -12 "$W/_i" "$W/$r.local_to_views_active" > "$W/_j"; mv "$W/_j" "$W/_i"; done
echo "local_timeout_views_in_all_four=$(sort -n "$W/_i" | tr '\n' ',' | sed 's/,$//')"
cp "$W/main.timeout_views_active" "$W/_i"
for r in main_2 main_3 main_4; do comm -12 "$W/_i" "$W/$r.timeout_views_active" > "$W/_j"; mv "$W/_j" "$W/_i"; done
echo "timeout_views_in_all_four=$(sort -n "$W/_i" | tr '\n' ',' | sed 's/,$//')"
for a in main main_2 main_3 main_4; do for b in main main_2 main_3 main_4; do if [ "$a" \< "$b" ]; then
   echo "timeout_overlap.$a.$b=$(comm -12 "$W/$a.timeout_views_active" "$W/$b.timeout_views_active" | sort -n | tr '\n' ',' | sed 's/,$//')"; fi; done; done

echo "== (c) proposer vs view number"
cat $W/*.view_proposer | sort -u > "$W/_vp"
echo "distinct_view_numbers=$(cut -d' ' -f1 "$W/_vp" | sort -u | wc -l)"
echo "distinct_view_proposer_pairs=$(wc -l < "$W/_vp")"
echo "proposer_not_leader_view=$(awk '{ if ($2 != ($1 % 4) + 1) bad++ } END { print bad+0 }' "$W/_vp")   # leader(view) = (view mod 4)+1"
rm -f "$W/_i" "$W/_j" "$W/_vp"
