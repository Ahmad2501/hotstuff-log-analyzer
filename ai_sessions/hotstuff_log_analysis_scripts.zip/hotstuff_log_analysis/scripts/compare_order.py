#!/usr/bin/env python3
"""compare_order.py - compares the awk re-computation (verify_order.tsv) with the Python analysis (part4.json).
   usage: python3 compare_order.py [verify_order.tsv] [part4.json]      -> prints every mismatch and 'N values compared, M mismatches'"""
import json
import os
import sys
import collections

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("HS_OUT", os.path.join(os.path.dirname(HERE), "out"))
tsv = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT, "verify_order.tsv")
js = sys.argv[2] if len(sys.argv) > 2 else os.path.join(OUT, "part4.json")
A = collections.defaultdict(dict)
for line in open(tsv):
    run, name, val = line.rstrip("\n").split("\t")
    A[run][name] = float(val)
J = json.load(open(js))
nc = nm = 0


def chk(run, name, py):
    global nc, nm
    a = A[run].get(name)
    nc += 1
    if a is None or abs(a - float(py)) > 1e-9:
        nm += 1
        print(f"MISMATCH {run:7s} {name:34s} awk={a} python={py}")


for run, R in J["runs"].items():
    F = J["flat"][run]
    S = R["steps"]

    def tot(k):
        return sum(S.get(k, {}).values())

    def lab(k, text):
        return S.get(k, {}).get(text, 0)

    def pre(k, prefix):
        return sum(n for t, n in S.get(k, {}).items() if t.startswith(prefix))
    chk(run, "blocks", F["blocks"])
    chk(run, "blocks_parent_eq_qc", F["blocks_parent_eq_qc"])
    for g, n in R["blocks"]["gap"].items():
        chk(run, "gap%s" % g, n)
    chk(run, "views_tested", F["views_tested"])
    for k, nm_ in (("O1", "o1"), ("O2", "o2"), ("O3", "o3"), ("O6", "o6"), ("O6b", "o6b")):
        chk(run, nm_ + "_pass", lab(k, "pass"))
        chk(run, nm_ + "_tested", tot(k))
    chk(run, "o4_pass", lab("O4", "pass"))
    chk(run, "o4_tested", tot("O4"))
    chk(run, "o4_rejected", pre("O4", "rejected"))
    chk(run, "o4_rej_timeout_v", pre("O4", "rejected 'too old': replica had already timed out"))
    chk(run, "o4_rej_later_view", pre("O4", "rejected 'too old': replica had already voted"))
    chk(run, "o4_rej_other", pre("O4", "FAIL") + pre("O4", "rejected 'too old': other"))
    chk(run, "o5_updated_then_advanced", lab("O5", "HighQC updated, then 'Advanced to view v', then TryCommit"))
    chk(run, "o5_updated_already_in_v", pre("O5", "HighQC updated; replica was already"))
    chk(run, "o5_notupdated_then_advanced", lab("O5", "HighQC not updated (QC already known); then 'Advanced to view v'"))
    chk(run, "o5_notupdated_already_in_v", pre("O5", "HighQC not updated (QC already known); replica was already"))
    chk(run, "o5_other", pre("O5", "other"))
    chk(run, "o7_pass_3distinct", lab("O7", "pass (3 distinct vote lines before the dispatch)"))
    chk(run, "o7_pass_4distinct", lab("O7", "pass (4 distinct vote lines before the dispatch)"))
    chk(run, "o7_fail", pre("O7", "FAIL"))
    chk(run, "o7_nodispatch_1distinct", lab("O7", "no dispatch, 1 distinct vote line(s) (<3)"))
    chk(run, "o7_nodispatch_2distinct", lab("O7", "no dispatch, 2 distinct vote line(s) (<3)"))
    chk(run, "o7c_pass", lab("O7c", "pass"))
    chk(run, "o8_pass", lab("O8", "pass"))
    chk(run, "o8_fail", lab("O8", "FAIL"))
    chk(run, "o8_not_printed", pre("O8", "n/a"))
    chk(run, "o8b_no_late_vote", lab("O8b", "no vote line after the dispatch"))
    chk(run, "o8b_late_outside_ids", pre("O8b", "pass: late"))
    chk(run, "o8b_late_inside_ids", pre("O8b", "FAIL"))
    chk(run, "class_N", F["class_N"])
    chk(run, "class_L", F["class_L"])
    chk(run, "class_X", F["class_X"])
    chk(run, "class_N_interleaved", pre("O9", "pass, with"))
    chk(run, "dispatch_active", F["dispatch_active"])
    chk(run, "dispatch_unmatched", R["dispatch_chain"].get("dispatch line without a matching block (<3 distinct vote lines before it)", 0))
    chk(run, "dispatch_chain_complete", F["dispatch_chain_complete"])
    chk(run, "dispatch_chain_broken", F["dispatch_chain_broken"])
    chk(run, "gap_blocks_active", F["gap_blocks_active"])
    chk(run, "gap_blocks_equal_next_of_nonN", 1 if R["gap_equals_nonN_next"] else 0)
    for k in ("decide_consecutive_logged", "decide_consecutive_missing", "decide_nonconsecutive_logged", "decide_nonconsecutive_missing"):
        chk(run, k, F[k])
    for k in ("too_old_proposals", "too_old_proposals_lv_eq_v", "too_old_proposals_lv_gt_v", "delay_proposal_total", "delay_proposal_active"):
        chk(run, k, F[k])
    L = R["latency"]["cycle"]
    chk(run, "cycle_n", L["n"])
    chk(run, "cycle_median", L["median"])
    chk(run, "cycle_p90", L["p90"])
    chk(run, "cycle_max", L["max"])
print(f"{nc} values compared, {nm} mismatches")
