#!/usr/bin/env python3
"""compare_votes.py - compare the awk re-computation (verify_votes.tsv) with the Python analysis (part2.json['flat']).
   usage: compare_votes.py [verify_votes.tsv] [part2.json]"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.environ.get("HS_OUT", os.path.join(HERE, "..", "out"))
tsv = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT, "verify_votes.tsv")
p2 = sys.argv[2] if len(sys.argv) > 2 else os.path.join(OUT, "part2.json")
awk = {}
with open(tsv) as f:
    for ln in f:
        run, metric, c, j, n = ln.rstrip("\n").split("\t")
        if int(n) != 0:
            awk[f"{run}|{metric}|{c}|{j}"] = int(n)
py = {k: v for k, v in json.load(open(p2))["flat"].items() if v != 0}
bad = 0
for k in sorted(set(awk) | set(py)):
    if awk.get(k, 0) != py.get(k, 0):
        bad += 1
        print("MISMATCH", k, "awk:", awk.get(k, 0), "python:", py.get(k, 0))
print(f"compared {len(set(awk) | set(py))} non-zero metrics (awk vs python): {bad} mismatches")
