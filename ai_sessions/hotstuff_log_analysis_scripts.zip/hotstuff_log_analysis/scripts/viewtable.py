#!/usr/bin/env python3
"""viewtable.py - per-run, per-view event table (one row per view number)."""
import collections
import views

H = views.H

COUNT_EVENTS = [
    "RECV_PROPOSAL", "TRY_COMMIT", "PRE_COMMIT", "COMMIT", "DECIDE", "EXEC",
    "COLLECT_VOTE", "QC_DISPATCH", "BLOCK_TOO_OLD", "CACHE_MISS", "NO_BLOCK_FOR_VOTE",
    "ADVANCE_ENTER", "ON_NEW_VIEW", "HQC_UPDATED", "HQC_NOT_UPDATED", "ADVANCED", "FAIL_VERIFY_SYNCINFO",
    "LOCAL_TIMEOUT", "LOCAL_TIMEOUT_VIEW", "REMOTE_TIMEOUT", "NOT_ENOUGH_TIMEOUTS", "REMOTE_TIMEOUT_2ND",
    "STOP_VOTING", "FAIL_CREATE_SYNCINFO", "DELAY_PROPOSAL", "PROPOSAL_TOO_OLD", "FAIL_CREATE_PROPOSAL",
    "BLOCK_EXISTS", "PRUNE_FORK", "FETCH_ATTEMPT", "ON_REQUEST_BLOCK", "BATCH_HASH",
]
TIMEOUT_EVENTS = ["LOCAL_TIMEOUT", "LOCAL_TIMEOUT_VIEW", "REMOTE_TIMEOUT", "NOT_ENOUGH_TIMEOUTS", "REMOTE_TIMEOUT_2ND",
                  "STOP_VOTING", "FAIL_CREATE_SYNCINFO"]


def build(run_data):
    evs = run_data["events"]
    pv = views.proposers_by_view(run_data)
    hv = views.hashes_by_view(run_data)
    table = {}

    def row(v):
        if v not in table:
            table[v] = dict(view=v, cnt=collections.Counter(), by_r=collections.defaultdict(collections.Counter),
                            t_first=None, n_first=None, phases=set(),
                            local_to_replicas=set(), remote_from=set(), tc_replicas=set(), adv_via=collections.Counter())
        return table[v]

    for e in evs:
        v = e.get("v")
        if v is None or e["ev"] is None:
            continue
        # BATCH_HASH etc. do not carry v; skip events without a view
        rw = row(v)
        rw["cnt"][e["ev"]] += 1
        if e["r"]:
            rw["by_r"][e["ev"]][e["r"]] += 1
        rw["phases"].add(e["phase"])
        if rw["t_first"] is None:
            rw["t_first"], rw["n_first"] = e["t"], e["n"]
        if e["ev"] == "LOCAL_TIMEOUT_VIEW":
            rw["local_to_replicas"].add(e["r"])
        if e["ev"] == "REMOTE_TIMEOUT":
            rw["remote_from"].add(e["from_id"])
        if e["ev"] == "REMOTE_TIMEOUT_2ND":
            rw["tc_replicas"].add(e["r"])
        if e["ev"] == "ADVANCED":
            rw["adv_via"][e.get("trigger")] += 1
    for v, rw in table.items():
        rw["proposers"] = sorted(pv.get(v, []))
        rw["hashes"] = sorted(hv.get(v, []))
        rw["has_block"] = v in pv
    return table


def has_timeout(rw):
    return any(rw["cnt"][k] for k in TIMEOUT_EVENTS)
