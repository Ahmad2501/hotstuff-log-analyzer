"""Caveats, verification summary, and the two extra tabs (log excerpts, evidence tables)."""
import json
import os
import lib
from lib import RUNS, custom
import sec_p4

J3 = json.load(open(os.path.join(lib.OUT, "part3.json")))


def sec_caveats():
    return """## Caveats and inferences

What the logs show is separated here from what is inferred. Counts, orders and quotes are facts of the logs; the points below are interpretation, limits of the method or open questions.

**Limits of the method**

- **One recording per configuration.** Each run was recorded once, on different dates (main 2026-06-22, main_2 2026-07-31, main_3 and main_4 2026-09-13). Differences between runs cannot be separated from run-to-run variance or from changes of code or machine load between recordings; the logs carry no version information beyond the banner. main, main_3 and main_4 act as an informal replicate set, and main_2 stands apart in most measures.
- **p-values are indicative.** Chi-square, binomial, Fisher, hypergeometric and runs tests assume independent events, but timeouts and late votes are clustered (Part 3, bursts). Of the 32 tests on the order of the last two votes, 3 fall below 0.05, about 1.6 expected by chance.
- **Order means line order.** All ordering claims are about the physical order of log lines. Timestamps (1 ms resolution) show inversions of up to 3 ms between replicas and are used only for durations.
- **Active and drain phases.** The boundary is the controller's first `Stopping clients...` line. The drain phase (2.5 s) behaves differently because leaders cannot build proposals; every count in the report is shown for the phase it belongs to where that matters.

**Inferences, not log facts**

- **Timer length.** `OnLocalTimeout: V` fires a median 7 ms after the replica entered the view in main, main_3 and main_4 (57 ms in main_2), against the 500 ms printed in the banner. The log does not print the effective timer; an adaptive timeout would explain it.
- **Mixed-view timeout certificates.** All 41 `Failed to verify sync info` lines with an ecdsa TC come from TCs whose signers' timeout messages are for different views, and no TC with consistent views failed (132 / 94 / 150 / 128 consistent TCs). That a stale per-replica cache of timeout messages builds the mixed TCs is an inference from the message contents.
- **Extra `OnNewView` lines.** Each view has about three more `OnNewView (from network: false)` lines than QC dispatches (hs1 in excerpt E1). They re-process the QC the replica already has (`HighQC not updated`); that replicas send their HighQC to the next leader is an inference.
- **Rejected proposals and votes.** Of the 13 proposals that main_2 rejected with `last voted view was M`, 11 have M equal to the proposal's view and follow a local timeout of the same replica in that view (`OnLocalTimeout: V` and `Stopped voting for timed out view V` precede the line; verified for all 11); that `Stopped voting for timed out view` sets the 'last voted view' is read from the message text. The other 2 (hs3, views 955 and 988) have M = view + 2 and no timeout: hs3 had already accepted the later block (`TryCommit` of view 957 at line 54590, of view 990 at line 56367) before the older proposal arrived. In the 2 cases where a replica logged `TryCommit` but no `CollectVote` line for its vote reached the collector (main view 41, main_3 view 2666), the replica logged `OnLocalTimeout` in that view after its `TryCommit`; that the timeout suppressed the vote is an inference.
- **Timeout delivery model.** The count of `OnRemoteTimeout (advancing view)` lines equals 4 x the local timeouts plus 3 x the repeated expiries exactly in two of the runs and is off by 1-2 in the other two; the model (every replica broadcasts its timeout to the other three) is not a log fact.
- **Forks.** That B_v of a broken view stays as a fork and is later pruned is consistent with `PruneToHeight: found forked block` appearing only in the two runs with gap blocks (23 and 19 times); the log does not link each prune to its block.

**Open questions**

- **Proposal reception order.** The next leader logs `Received proposal` last in 38% of the blocks and first in 18%, in all four runs; the log does not show why.
- **Late votes in main_2.** 34.5% of its views have a late 4th vote against 24.0-26.5% in the others; no log line explains it.
- **Stall of main_2.** The 30-view stall (views 896-925) is described by its counts (timeouts, TCs, forks, fetches, client timeouts), but the log does not show what started it.
"""


def sec_summary():
    rows = [
        ["`verify_counts.sh`", "Part 1: 37 patterns x 4 runs x (total, active, drain), plus per-replica counts", "grep -c, awk", "1,036 values against the Python regex counts and 444 against `part1.json`: 1,480 compared, 0 mismatches"],
        ["`verify_votes.sh`", "Part 2: complete sequences, first / last, positions, processed order, proposal reception", "awk only", "581 non-zero metrics: 0 mismatches"],
        ["`verify_views.sh`", "Part 3: views per run, shared views, timeout views and their overlaps, proposer rule", "grep, sed, sort, comm", "33 values: 0 mismatches"],
        ["`verify_order.sh`", "Part 4: checks O1-O10, classes N / L / X, gap blocks, commit rule, cycle times", "awk only", "243 values: 0 mismatches"],
    ]
    t = custom(["Script", "Re-computes", "Tools", "Result against the Python analysis"], rows, [":---", ":---", ":---", ":---"])
    return f"""## Verification summary

Every count in this report was computed twice, once by the Python analysis and once by an independent shell script that reads the raw logs, and the two were compared value by value:

{t}

The class table, the view durations, the burst statistics, the per-second timeline and all chi-square, binomial, Fisher, hypergeometric and runs tests exist only in the Python analysis (`part3_views.py`, `part2_votes.py`); the shell scripts check the counts, orders and view sets underneath them. The tables of this report were written from the result files by a generator (`report/`), not typed, and the numbers quoted in the text were checked against the same files.

The scripts are in the zip file delivered with this report. `run_all.sh LOGDIR` rebuilds all result files and runs the four comparisons; the README lists the environment variables (`HS_LOGDIR`, `HS_OUT`), the run order and the expected `0 mismatches` lines.
"""


# ---------------------------------------------------------------------------------------------------- tab: log excerpts
def tab_excerpts():
    out = ["# Log excerpts", "", "Verbatim lines from the logs behind the findings of Part 4 and Part 2. E1 (a complete chain) and E2 (a TC wins the race) are in Part 4. Columns: physical line number, replica, message; lines of other event types and of other replicas are left out. The timestamps and source-file columns are in the logs.", ""]
    notes = {
        "E3": "hs2 collects votes from 2, 1 and 3 (162970-162972) while timeout messages arrive. An `OnNewView` that carries the TC for view 2968 moves hs2 to view 2969 (162977-162980). Only then is the QC dispatched (`current : 2969`, 162981), and hs2 proposes B_2969 with QC_2967, not QC_2968 (162982). QC_2968 (IDs [ 2 1 3 ]) is processed at 162995 and updates HighQC, but the view does not change.",
        "E4": "The collector hs3 receives one vote for B_897, from replica 2, logs `Local cache miss for block` for it (it does not know B_897) and sees the same vote line again at 49887. No second vote line reaches hs3, so no QC for view 897 exists (class X).",
        "E5": "hs4 receives B_1673 while it is still in view 1672 and logs `Delaying proposal until after next view change`. B_1672 arrives afterwards (91427), its attached QC_1671 is processed (91429, 91436), and hs4 accepts and votes for it (`TryCommit`, 91437). No vote is lost.",
        "E6": "hs1 receives B_398 first, processes QC_397, enters view 398 and votes (21948-21954). B_397 arrives later (21974); hs1 rejects it with `failed to verify incoming vote: block view 397 too old, last voted view was 398` (21980) and does not vote. This is the reason for the `DECIDE` difference at view 397 (Part 3).",
    }
    for tag in ("E3", "E4", "E5", "E6"):
        cap, code = sec_p4.excerpt(tag)
        out += [f"## {tag} · {cap}", "", notes[tag], "", "```", code, "```", ""]
    return "\n".join(out).rstrip() + "\n"


# ---------------------------------------------------------------------------------------------------- tab: evidence tables
def lists_table():
    per = J3["timeouts"]["per_run"]
    rows = []
    for run in RUNS:
        act = per[run]["active"]
        dr = per[run]["drain"]
        rows.append([run, f"{len(act)}", ", ".join(map(str, act)), f"{len(dr)}", f"{dr[0]}-{dr[-1]}"])
    return custom(["Run", "Views (active)", "View numbers with timeout-type events, active phase", "Views (drain)", "Drain-phase views"], rows, [":---", "---:", ":---", "---:", ":---"])


def tab_evidence():
    last2 = lib.tbl("part2.md", r"^### 2C-2\.", 0, cols=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                    rename={"collector": "Collector", "run": "Run", "tail candidates": "Candidates for last place", "n": "Sequences", "last = first cand / second cand": "Last = first / second candidate",
                            "share second cand last": "Second candidate last", "p (binomial)": "p (binomial)", "runs observed": "Runs observed", "runs z": "Runs z", "p (runs)": "p (runs)"})
    pos = lib.tbl("part2.md", r"^### 2D-2\.", 0, rename={"scope": "Scope", "sender": "Sender", "1st %": "1st %", "2nd %": "2nd %", "3rd %": "3rd %", "4th %": "4th %"})
    return f"""# Evidence tables

Supporting tables for Parts 2 and 3 that are too long for the main text.

## Part 2 · Which of the two open places is last, per collector and run

Every complete vote sequence reads collector, proposer, X, Y; X and Y are the two other replicas. Exact two-sided binomial test of 'which of the two is last' against 50 / 50, and Wald-Wolfowitz runs test over the consecutive turns of the same collector (every 4th view). The combined result is in the main text.

{last2}

## Part 2 · Position of each sender's vote, per run

Share of the complete vote sequences in which the sender's vote is 1st, 2nd, 3rd or 4th, pooled over all receivers:

{pos}

## Part 3 · Views with timeout-type events, per run

The views behind the counts of 'Views with timeout events': every view number with a timeout-type event, in the active phase, and the range of the drain-phase views. Drain-phase views are the views after the last client-driven proposal, where every view ends by timeout.

{lists_table()}

Reading the lists: view 3 is the only entry in all four; 896 and 897 (main, main_2) and 909 and 910 (main_3, main_2) lie in the stall window of main_2; 4, 5, 6 and 7 are start-up views; consecutive numbers (for example 2663-2667 and 2671-2674 in main_3) are bursts.
"""
