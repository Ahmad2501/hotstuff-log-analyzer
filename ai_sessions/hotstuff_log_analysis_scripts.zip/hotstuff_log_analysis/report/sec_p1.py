"""Part 1 sections: exact patterns and counts, comparison and verdicts, relation to view progression, verification commands."""
import json
import os
import re
import lib
from lib import RUNS, cell, tbl, custom, fmt

LOGDIR = os.environ.get("HS_LOGDIR", ".")
HERE = os.path.dirname(os.path.abspath(__file__))
EXTRA = json.load(open(os.path.join(HERE, "extra.json")))

MASTER = [
    ("block too old", "P1", "block too old"),
    ("... proposal rejected as too old (a different line)", "P1b", "too old, last voted view was"),
    ("Failed to verify sync info", "P2", "Failed to verify sync info"),
    ("... timeout certificate, ecdsa", "P2a", "Failed to verify sync info: failed to verify timeout certificate: ecdsa: failed to verify signature from replica"),
    ("... quorum certificate, block not found", "P2b", "Failed to verify sync info: failed to verify quorum certificate: block not found"),
    ("OnLocalTimeout (both line forms)", "P3", "OnLocalTimeout"),
    ("... line without a view (timer fired)", "P3a", "OnLocalTimeout$"),
    ("... line with the view (timeout of view V)", "P3b", "OnLocalTimeout: [0-9]+$"),
    ("... Stopped voting for timed out view", "P3c", "Stopped voting for timed out view"),
    ("OnRemoteTimeout (all forms)", "P4", "OnRemoteTimeout"),
    ("... advancing view (timeout message received)", "P4a", r"OnRemoteTimeout \(advancing view\)"),
    ("... second advance (TC formed)", "P4b", r"OnRemoteTimeout \(second advance\)"),
    ("not enough timeouts", "P5", "not enough timeouts"),
    ("Failed to create sync info (overlapping signatures)", "P5b", "Failed to create sync info"),
    ("HighQC updated", "P6", "advanceView: Successfully updated HighQC"),
    ("HighQC not updated", "P7", "advanceView: HighQC not updated"),
    ("View advancement", "P8", "advanceView: Advanced to view"),
    ("... advanceView calls", "P8a", r"advanceView: \{"),
    ("... OnNewView", "P8b", "OnNewView"),
    ("TryCommit", "P9a", "TryCommit:"),
    ("Commit rule PRE_COMMIT", "P9b", "CommitRule - PRE_COMMIT"),
    ("Commit rule COMMIT", "P9c", "CommitRule - COMMIT"),
    ("Commit rule DECIDE", "P9d", "CommitRule - DECIDE"),
    ("EXEC", "P9e", "EXEC:"),
    ("Received proposal", "X1", "Received proposal"),
    ("Vote received at the collector", "X2", r"CollectVote\(from"),
    ("QC formed (dispatch)", "X3", "CollectVote: dispatching event for new view"),
]

RAW = [
    ("main.log", r"votingmachine.go:80\s+block too old$"),
    ("main.log", r"too old, last voted view was"),
    ("main_2.log", r"Failed to verify sync info: failed to verify timeout"),
    ("main_2.log", r"Failed to verify sync info: failed to verify quorum"),
    ("main.log", r"synchronizer.go:183\s+OnLocalTimeout$"),
    ("main.log", r"OnLocalTimeout: [0-9]+$"),
    ("main.log", r"Stopped voting for timed out view"),
    ("main.log", r"OnRemoteTimeout \(advancing view\)"),
    ("main.log", r"not enough timeouts"),
    ("main.log", r"OnRemoteTimeout \(second advance\)"),
    ("main.log", r"Failed to create sync info"),
    ("main.log", r"advanceView: Successfully updated HighQC"),
    ("main.log", r"advanceView: HighQC not updated"),
    ("main.log", r"advanceView: Advanced to view 1000$"),
    ("main.log", r"TryCommit: Block\{ hash: qXCyTpwu"),
    ("main.log", r"CommitRule - PRE_COMMIT: Block\{ hash: qXCyTpwu"),
    ("main.log", r"CommitRule - COMMIT: Block\{ hash: qXCyTpwu"),
    ("main.log", r"CommitRule - DECIDE: Block\{ hash: qXCyTpwu"),
    ("main.log", r"EXEC: Block\{ hash: qXCyTpwu"),
]


def raw_lines():
    out = []
    cache = {}
    for fn, rx in RAW:
        if fn not in cache:
            with open(os.path.join(LOGDIR, fn), encoding="utf-8", errors="replace") as f:
                cache[fn] = f.read().split("\n")
        r = re.compile(rx)
        for n, line in enumerate(cache[fn], 1):
            p = line.split("\t", 4)
            if len(p) == 5 and r.search(line):
                msg = p[4]
                if len(msg) > 118:
                    msg = msg[:118] + " ..."
                src = p[3].split("/")[-1]
                out.append(f"{fn}:{n:<7} {p[2]}  {src:<20} {msg}")
                break
        else:
            raise RuntimeError(f"no match for {rx}")
    return "\n".join(out)


def master_table():
    rows = []
    for label, pid, ere in MASTER:
        rows.append([label, "`" + ere + "`"] + [cell(pid, r) for r in RUNS])
    return custom(["Event", "Exact pattern (grep -E)", "main", "main_2", "main_3", "main_4"], rows, [":---", ":---", "---:", "---:", "---:", "---:"])


def sec_counts():
    t = master_table()
    return f"""## Part 1 · Exact patterns and counts per run

Each pattern was counted with `grep -E` on the raw files; a cell shows the total, then (active phase / drain phase).

{t}

Raw lines behind the patterns (first hit in the named file; file:line, logger, source location, message):

```
{raw_lines()}
```

Exact arithmetic between the counts, which also shows what each line means:

- **Outcome of a timeout message.** Every `OnRemoteTimeout (advancing view)` line ends in exactly one of: not enough timeouts, TC formed (second advance), or Failed to create sync info. 766 = 621 + 137 + 8 (main), 602 = 491 + 110 + 1 (main_2), 816 = 648 + 160 + 8 (main_3), 782 = 643 + 138 + 1 (main_4). The substring total follows: 1,524 = 766 + 621 + 137 in main, and likewise in the other runs.
- **Delivery of a timeout.** Each `OnLocalTimeout: V` line is delivered as 4 `advancing view` lines (one per replica, the sender included) and each repeated timer expiry in the same view as 3 more: 4 x 190 + 3 x 2 = 766 (main, exact), 4 x 118 + 3 x 44 = 604 against 602 (main_2), 4 x 199 + 3 x 7 = 817 against 816 (main_3), 4 x 194 + 3 x 2 = 782 (main_4, exact). In main (active phase) the match holds per sender: 92 / 96 / 92 / 102 deliveries from hs1-hs4 against 23 / 24 / 23 / 24 timeouts and 0 / 0 / 0 / 2 repeats.
- **Two OnLocalTimeout lines.** The line without a view (synchronizer.go:183) is the timer firing; the line with the view (:191) is a new timeout of view V. Every bare line that is not followed by a `: V` line (2 / 44 / 7 / 2, all of them) occurs while the replica is still in a view it already timed out in: a repeated expiry.
- **Stopped voting.** `Stopped voting for timed out view V` appears exactly when a replica times out in V before it has voted in V: all 93 / 29 / 92 / 101 lines, and every timeout of a replica that had not voted has one. In the active phase this happens 0 / 14 / 2 / 0 times; the other active timeouts (94 / 89 / 104 / 90) come after the replica's vote.
"""


# ---------------------------------------------------------------------------------------------------------------------------
LABELS = {"'too old, last voted view was' (proposal path)": "'too old, last voted view was' (proposal rejected)",
          "OnLocalTimeout (bare, line end)": "OnLocalTimeout (line without a view)",
          "view advancement (Advanced to view)": "Advanced to view",
          "CommitRule PRE_COMMIT": "CommitRule PRE_COMMIT (= TryCommit)"}


def rates_table():
    t = lib.pick(lib.find_table("part1.md", r"^## 1C\."), cols=[0, 1, 2, 3, 4, 8, 6],
                 rows=r"^P1  |^P1b|^P2  |^P3b|^P3a|^P4a|^P4b|^P5  |^P6|^P7|^P8  |^P9b|^P9c|^P9d|^P9e|^X4",
                 rename={"pattern (active phase)": "Active phase, per 1,000 proposed views", "main /1k views": "main", "main_2 /1k views": "main_2",
                         "main_3 /1k views": "main_3", "main_4 /1k views": "main_4", "p 3 runs": "p, main / main_3 / main_4", "p 4 runs": "p, all four"})
    rows = []
    for r in t[2]:
        r = list(r)
        r[0] = LABELS.get(lib.clean(r[0]), lib.clean(r[0]))
        for k in (5, 6):                       # tiny p-values: show a bound instead of 1e-216
            try:
                if float(r[k]) < 1e-10:
                    r[k] = "< 1e-10"
            except ValueError:
                pass
        rows.append(r)
    return lib.render((t[0], t[1], rows))


def window_table():
    names = [("OnLocalTimeout: V", "LOCAL_TIMEOUT_VIEW"), ("OnRemoteTimeout (advancing view)", "REMOTE_TIMEOUT"),
             ("not enough timeouts", "NOT_ENOUGH_TIMEOUTS"), ("TC formed (second advance)", "REMOTE_TIMEOUT_2ND"),
             ("Failed to verify sync info", "FAIL_VERIFY_SYNCINFO"), ("Stopped voting for timed out view", "STOP_VOTING"),
             ("block too old", "BLOCK_TOO_OLD")]
    m2 = EXTRA["main_2"]
    wv, av = m2["window_views"], m2["active_views"]
    ov = av - wv
    rows = []
    for label, key in names:
        ins, out = m2["inside"].get(key, 0), m2["outside"].get(key, 0)
        row = [label, f"{ins}", f"{out / ov * 1000:.1f}"]
        for r in ("main", "main_3", "main_4"):
            e = EXTRA[r]
            tot = e["inside"].get(key, 0) + e["outside"].get(key, 0)
            row.append(f"{tot / e['active_views'] * 1000:.1f}")
        rows.append(row)
    rows.append(["views in the group", str(wv), f"{ov:,}", f"{EXTRA['main']['active_views']:,}", f"{EXTRA['main_3']['active_views']:,}", f"{EXTRA['main_4']['active_views']:,}"])
    return custom(["Active phase", "main_2: events in views 896-925", "main_2: per 1,000 other views", "main: per 1,000 views", "main_3: per 1,000 views", "main_4: per 1,000 views"], rows)


VERDICT = [
    ["block too old", "265 / 358 / 271 / 246",
     "A harmless race, not a fault: the 4th vote reaches the collector after the QC was dispatched. Every line directly follows that vote's CollectVote line (979 of 979, 977 of 977, 901 of 901; main_2: 400 of 402, the other 2 follow `Successfully fetched block`), and the voter is outside the QC in 979 / 398 / 975 / 900 cases. The late voter is spread over all replicas (main 258 / 237 / 263 / 221). Only main_2's higher share is a real difference (36.1% of QCs against 24.6-27.1%); it also exists outside its stall (358 per 1,000 views), and the log does not show why."],
    ["Failed to verify sync info", "1.4 / 15.2 / 2.8 / 2.7",
     "Meaningful for main_2 (6.7x per view; 11 of its 17 lines fall inside the stall). main, main_3 and main_4 share a low background rate (p = 0.35). Exact association: all 5 / 16 / 10 / 10 ecdsa failures are TCs assembled from timeout messages of mixed views; none of the 132 / 94 / 150 / 128 consistent TCs failed."],
    ["OnLocalTimeout: V", "25.5 / 92.3 / 29.4 / 24.6",
     "Meaningful for main_2 (3.5x): 80 of its 103 active timeouts lie in the 30-view stall, and outside it the rate is 21 per 1,000 views, like the others. main, main_3, main_4 agree (p = 0.41): about 1.7% of views have a timeout. Most timeouts fire after the replica has voted (94 / 89 / 104 / 90 of 94 / 103 / 106 / 90), so they do not prevent the QC."],
    ["OnRemoteTimeout", "advancing 103.6 / 483 / 122.5 / 99.3; second advance 7.1 / 80.6 / 14.7 / 7.4",
     "Derived from the local timeouts (4 deliveries per timeout), so it adds no independent signal, except the TC step: main_3 forms about twice as many TCs per view as main and main_4 (p = 0.0009; 35 of its 53 active TCs fall in seconds 7-8) and main_2 about 8x."],
    ["not enough timeouts", "94 / 401 / 106 / 92",
     "Derived: it is the outcome of every timeout message that does not complete a quorum (621 = 766 - 137 - 8 in main). It follows the local-timeout rate; p = 0.13 for main, main_3, main_4."],
    ["HighQC updated", "3,998 / 3,971 / 3,994 / 3,999",
     "No difference. 4 per view = 3 receivers (attached QC) + 1 collector (its own QC): 11,060 + 3,688 + 3 = 14,751 in main."],
    ["HighQC not updated", "3,109 / 3,566 / 3,138 / 3,105",
     "The baseline is identical (about 3.0 per view are OnNewView messages repeating a known QC: 3,022 / 3,012 / 3,021 / 3,022 per 1,000 views, all phases). main_2's excess is timeout traffic: 609 sync infos from remote timeouts per 1,000 views against 243 / 267 / 248."],
    ["Advanced to view", "3,998 / 3,996 / 3,998 / 3,999",
     "No difference in count: about four advances per view, always +1 (14,856 / 4,492 / 14,512 / 14,740 steps, no jump, no backward step). What differs is the cause: timeout certificates drive 13 / 67 / 36 / 8 active-phase advances (0.09% / 1.5% / 0.25% / 0.05%)."],
    ["TryCommit, COMMIT, DECIDE, EXEC", "TryCommit 3,999 / 3,986 / 3,999 / 4,000; DECIDE 3,997 / 3,939 / 3,985 / 3,998",
     "Equal in main and main_4. main_2 and main_3 are lower in COMMIT, DECIDE and EXEC only, exactly by the TryCommit lines whose three-chain spans non-consecutive views (44 and 40 lines, Part 4). All counts obey the commit rules (0 violations)."],
]


def verdict_table():
    return custom(["Event", "Per 1,000 views: main / main_2 / main_3 / main_4", "Is the difference meaningful, and why"],
                  VERDICT, [":---", ":---", ":---"])


def sec_compare():
    return f"""## Part 1 · Comparison and verdict per event

Per 1,000 proposed views (active phase) the progress counters agree across runs (within 1.6%), while the timeout-related counters separate main_2 from the rest.

{rates_table()}

The p-values are chi-square homogeneity tests on counts (they assume independent events; timeouts are clustered, so read them as a guide).

- **Similar in all four runs:** HighQC updates, view advances, TryCommit, COMMIT, DECIDE and EXEC per view (about 4.00 per view, within 1.6%); the structure of each view (3 receivers plus 1 collector update their HighQC; 4 timeout deliveries per timeout).
- **Similar in main, main_3 and main_4:** local timeouts (25-29 per 1,000 views, p = 0.41), not enough timeouts (p = 0.13), sync-info failures (p = 0.35) and late votes (p = 0.094).
- **Different:** main_2 has 3.5-8x the timeout events and 6.7x the sync-info failures per view, 36% more late votes and a third of the proposal rate; main_3 forms about twice as many timeout certificates as main and main_4.

Verdict per event (the first two columns are the comparison, the last one is the judgement):

{verdict_table()}

**main_2 inside and outside its stall.** main_2 needed 4.9 s for views 896-925 (view 896 was first entered 3,680 ms after the clients started, view 926 at 8,593 ms): about 164 ms per view against 3 ms normally. In the same period 60 client commands timed out (500 ms client timeout; first at 4,169 ms, last at 9,092 ms). Most of its excess timeout traffic sits in these 30 views:

{window_table()}

Outside the stall main_2's timeout rates are at or below those of the other runs; only the 6 remaining sync-info failures (4 of them in views 4-5) and the late votes stay above. Its baseline speed is lower too (222-255 proposals/s in seconds 0-2 against 309-382 in the other runs).
"""


# ---------------------------------------------------------------------------------------------------------------------------
def sec_views():
    d_tbl = tbl("part1.md", r"^## 1D\.", rename={"trigger": "Event before the 'Advanced to view' line (same replica)"})
    f_tbl = tbl("part1.md", r"^## 1F\.")
    h_tbl = tbl("part1.md", r"^## 1H\.")
    _i = lib.find_table("part1.md", r"^## 1I\.")
    _rows = []
    for r in _i[2]:
        if r[0].startswith("check:"):
            continue
        if r[0].startswith("sum = "):
            r = ["sum = all OnRemoteTimeout (advancing view) lines"] + r[1:]
        _rows.append(r)
    i_tbl = lib.render((_i[0], _i[1], _rows))
    j_tbl = tbl("part1.md", r"^## 1J\.")
    k_tbl = tbl("part1.md", r"^## 1K\.", n=0)
    return f"""## Part 1 · How the events relate to view progression

View advancement is QC-driven; timeouts add a second path that is rare in the active phase and dominant in the drain.

**What caused each 'Advanced to view N'** (the line that preceded the advanceView call at that replica; active / drain):

{d_tbl}

QC-driven advances (attached QC plus locally formed QC) make up 99.9% / 98.5% / 99.7% / 99.9% of the active-phase advances. In the drain, with no commands to propose, the timeout certificate is the normal way to advance (110 / 20 / 107 / 111).

**Views with an OnLocalTimeout (active phase) and what became of them:**

{f_tbl}

A local timeout almost never stops progress: the view still produced a QC in 63 of 63, 34 of 40, 58 of 60 and 61 of 61 cases. The 'TC advance, no QC' row counts views whose QC dispatch was logged only after the collector had left the view, or never; Part 4 splits these into classes L and X.

**The timeout-certificate path** (TCs are built from the timeout messages a replica has received) and **the fate of every timeout message**:

{h_tbl}

{i_tbl}

The association is exact: every ECDSA failure is a mixed-view TC and every mixed-view TC fails. The mechanism (a stale per-replica timeout cache) is an inference; the log shows only that the signers' latest messages belong to different views.

**Anatomy of 'block too old'** (all phases):

{j_tbl}

Late voter (sender id) hs1 / hs2 / hs3 / hs4: main 258 / 237 / 263 / 221; main_2 107 / 105 / 94 / 94; main_3 249 / 262 / 239 / 227; main_4 240 / 228 / 200 / 233. No replica is the habitual late voter.

**The commit / DECIDE / EXEC chain per replica (hs1 / hs2 / hs3 / hs4)**:

{k_tbl}

Rules tested against every TryCommit (0 violations in all four runs): PRE_COMMIT follows every TryCommit; COMMIT is logged exactly when the second block's view is higher than that of any earlier COMMIT at the replica; DECIDE is logged exactly when the three blocks are in consecutive views. The genesis block is decided once per replica and never executed; EXEC of a block without its own DECIDE (main: 1 at hs1; main_2: 8-10 per replica; main_3: 10 per replica; main_4: none) is an ancestor executed together with its descendant. All replicas execute the same hash sequence (3,685 / 1,108 / 3,595 / 3,656 blocks, strictly increasing views).
"""


def sec_verify():
    return r"""## Part 1 · Verification commands

Run these in the directory that holds the four logs. The first loop reproduces the totals and the active / drain split of the pattern table (the stop line is the first line of the drain phase; it matches none of the patterns).

```bash
for f in main main_2 main_3 main_4; do
  STOP=$(grep -n 'Stopping clients\.\.\.' $f.log | head -1 | cut -d: -f1)
  for p in 'block too old' 'Failed to verify sync info' 'OnLocalTimeout: [0-9]+$' 'OnRemoteTimeout \(advancing view\)' \
           'not enough timeouts' 'advanceView: Successfully updated HighQC' 'advanceView: HighQC not updated' \
           'advanceView: Advanced to view' 'CommitRule - DECIDE' 'EXEC:'; do
    tot=$(grep -cE -- "$p" $f.log)
    act=$(head -n $((STOP-1)) $f.log | grep -cE -- "$p")
    printf '%-7s %-40s total=%6s active=%6s drain=%5s\n' $f "$p" $tot $act $((tot-act))
  done
done
```

Per replica (tab-separated logger field), and the identities from the arithmetic list:

```bash
grep -cE $'\ths4\t.*block too old' main.log        # 266 in main
for f in main main_2 main_3 main_4; do
  a=$(grep -cE 'OnRemoteTimeout \(advancing view\)' $f.log)
  s=$(( $(grep -c 'not enough timeouts' $f.log) + $(grep -cE 'OnRemoteTimeout \(second advance\)' $f.log) + $(grep -c 'Failed to create sync info' $f.log) ))
  echo "$f advancing=$a outcomes=$s"                 # equal in every run
done
```

The shipped script `verify_counts.sh` does this for all 37 patterns, all phases and all replicas (grep and awk only). `compare_counts.py` compares it with the Python parser and the JSON results: 1,480 values compared, 0 mismatches.
"""
