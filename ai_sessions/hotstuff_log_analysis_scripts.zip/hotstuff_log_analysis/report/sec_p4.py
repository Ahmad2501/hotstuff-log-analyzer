"""Part 4 sections: the expected chain step by step, where it breaks, view entry / commit rule / block fields, verification commands."""
import re
import lib
from lib import RUNS, custom

OUTD = lib.OUT


def fnum(x):
    return f"{int(str(x).replace(',', '')):,}"


def rows4(anchor, n=0):
    """label -> [main, main_2, main_3, main_4] (ints as strings with commas) for the table after `anchor` in part4.md"""
    h, a, body = lib.find_table("part4.md", anchor, n)
    return {r[0].strip("*"): r[1:] for r in body}


def fc(s):
    return re.sub(r"\b\d{4,}\b", lambda m: f"{int(m.group()):,}", s)


def ints(vals):
    return [int(str(v).replace(",", "")) for v in vals]


def ratio(p, t, extra=None):
    out = []
    for i in range(4):
        s = f"{p[i]:,} / {t[i]:,}"
        if extra and extra[i]:
            s += f" ({extra[i]})"
        out.append(s)
    return out


def excerpt(tag):
    """verbatim text (without the caption line) of excerpt `tag` from out/part4_examples.md; returns (caption, code)"""
    txt = open(f"{OUTD}/part4_examples.md", encoding="utf-8").read()
    m = re.search(rf"^### {tag}  (.*?)\n\n```\n(.*?)\n```", txt, re.S | re.M)
    return m.group(1), m.group(2)


# ---------------------------------------------------------------------------------------------------- step table
def chain_table():
    o1 = rows4(r"^\*\*O1  ")
    o2 = rows4(r"^\*\*O2  ")
    o3 = rows4(r"^\*\*O3  ")
    o4 = rows4(r"^\*\*O4  ")
    o6 = rows4(r"^\*\*O6  ")
    o6b = rows4(r"^\*\*O6b ")
    o7 = rows4(r"^\*\*O7  ")
    o8 = rows4(r"^\*\*O8  ")
    o8b = rows4(r"^\*\*O8b ")
    o9 = rows4(r"^\*\*O9  ")
    o10 = rows4(r"^\*\*O10 ")
    e4 = rows4(r"^## 4E\.")
    k = lambda d, key: ints(d[key])
    # row 1: block parent link (4E)
    p1 = [int(x.split("/")[0]) for x in e4["blocks with known parent; QC view == parent view"]]
    t1 = [int(x.split("/")[1]) for x in e4["blocks with known parent; QC view == parent view"]]
    # row 4: rejected 'too old'
    rej4 = [a + b for a, b in zip(k(o4, "rejected 'too old': replica had already timed out in view v (last voted view = v), no vote"),
                                   k(o4, "rejected 'too old': replica had already voted/stopped in a later view (last voted view > v), no vote"))]
    # row 7: dispatch only after >= 3 distinct votes
    p7 = [a + b for a, b in zip(k(o7, "pass (3 distinct vote lines before the dispatch)"), k(o7, "pass (4 distinct vote lines before the dispatch)"))]
    t7 = k(o7, "tested")
    nodisp = [a + b for a, b in zip(k(o7, "no dispatch, 1 distinct vote line(s) (<3)"), k(o7, "no dispatch, 2 distinct vote line(s) (<3)"))]
    # row 8
    na8 = k(o8, "n/a: QC_v is never printed in a later block")
    # row 9: late votes
    late = k(o8b, "pass: late vote line(s) after the dispatch, sender outside QC.IDs")
    # row 10: chain O9
    p9 = [a + b for a, b in zip(k(o9, "pass"), k(o9, "pass, with timeout-handling lines of the same replica between dispatch and OnNewView"))]
    rows = [
        ["1", "Proposal B_v carries the QC of its parent", "`cert` QC of every proposal has the view of the block named as `parent` (table 'Block fields' in the section 'Part 4 · View entry, commit rule and block fields')", *ratio(p1, t1)],
        ["2", "The proposer builds B_v first", "proposer's `TryCommit(B_v)` and `Advanced to view v` precede the first `Received proposal` of B_v (O1, O2)", *ratio(k(o1, "pass"), k(o1, "tested"))],
        ["3", "A replica that receives the proposal processes the attached QC", "next `advanceView: { QC{...} }` after `Received proposal` carries exactly the QC attached to B_v (O3), per receiver and view", *ratio(k(o3, "pass"), k(o3, "tested"))],
        ["4", "...before it votes", "that `advanceView` precedes the receiver's `TryCommit(B_v)` (O4); the others were rejected by `failed to verify incoming vote: block view N too old`, no vote", *ratio(k(o4, "pass"), k(o4, "tested"), [f"{x} rejected" if x else "" for x in rej4])],
        ["5", "A vote is collected only after it was cast", "every `CollectVote(from s): H` follows the `TryCommit` of H by replica s (O6)", *ratio(k(o6, "pass"), k(o6, "tested"))],
        ["6", "A replica that voted is heard by the collector", "every `TryCommit(B_v)` has a `CollectVote(from s)` for B_v at the collector (O6b); the exceptions timed out right after voting", *ratio(k(o6b, "pass"), k(o6b, "tested"))],
        ["7", "A QC needs a quorum", "a dispatch `CollectVote: dispatching event for new view` exists only after 3 distinct `CollectVote` lines for B_v (O7); the others got fewer", *ratio(p7, t7, [f"{x} without QC" if x else "" for x in nodisp])],
        ["8", "QC_v is built from collected votes", "`QC_v.IDs` has 3 distinct replicas, each with a `CollectVote` line before the dispatch (O8); QC never printed in a later block: n/a", *ratio(k(o8, "pass"), k(o8, "tested"), [f"{x} n/a" if x else "" for x in na8])],
        ["9", "A late vote is not in the QC", "every `CollectVote` line after the dispatch is from a replica outside `QC_v.IDs` (O8b); inside: 0 in all runs", *ratio([a + b for a, b in zip(late, k(o8b, "no vote line after the dispatch"))], k(o8b, "tested"), [f"{x:,} views with late votes" for x in late])],
        ["10", "The QC reaches HighQC and moves the collector to v+1", "dispatch, `OnNewView`, `advanceView: { QC_v }`, `HighQC` updated, `Advanced to view v+1` in this order at the collector (O9)", *ratio(p9, k(o9, "tested"))],
        ["11", "The next leader proposes B_(v+1) with QC_v", "`TryCommit(B_(v+1))` right after that advance, proposer = collector, `cert` = QC_v (same hash and IDs) (O10)", *ratio(k(o10, "pass"), k(o10, "tested"))],
    ]
    return custom(["#", "Step of the expected ordering", "Check on the log lines", *RUNS], rows, [":---", ":---", ":---", "---:", "---:", "---:", "---:"])


def o5_table():
    t = lib.find_table("part4.md", r"^\*\*O5  ", 0)
    lab = {
        "HighQC updated, then 'Advanced to view v', then TryCommit": "HighQC updated, then `Advanced to view v`, then the vote (`TryCommit`)",
        "HighQC updated; replica was already in view v (entered v earlier via REMOTE_TIMEOUT_2ND)": "HighQC updated; the replica had entered v earlier through a timeout certificate",
        "HighQC not updated (QC already known); replica was already in view v (entered v earlier via REMOTE_TIMEOUT_2ND)": "HighQC not updated (QC already known); entered v earlier through a timeout certificate",
        "HighQC not updated (QC already known); replica was already in view v (entered v earlier via RECV_PROPOSAL)": "HighQC not updated (QC already known); entered v earlier through another proposal",
        "tested": "Receivers tested (proposal passed O4)",
    }
    order = ["HighQC updated, then 'Advanced to view v', then TryCommit",
             "HighQC updated; replica was already in view v (entered v earlier via REMOTE_TIMEOUT_2ND)",
             "HighQC not updated (QC already known); replica was already in view v (entered v earlier via REMOTE_TIMEOUT_2ND)",
             "HighQC not updated (QC already known); replica was already in view v (entered v earlier via RECV_PROPOSAL)",
             "tested"]
    body = {r[0].strip("*"): r[1:] for r in t[2]}
    rows = [[lab[k]] + body[k] for k in order]
    return custom(["Effect of the attached QC at the receiver (O5)", *RUNS], rows)


def sec_p4_chain():
    cap, code = excerpt("E1")
    return f"""## Part 4 · The expected chain, step by step

The expected chain holds in every tested view of main and main_4, in 99.9% of main_3 and in 99.1% of main_2; every exception is a timeout that wins the race against the QC (next section).

**How the events were matched.** Event order is the physical line order of the log: all four replicas write to one file, and the 1 ms timestamps are not used for ordering. A block is identified by its hash. The vote itself is not logged; the collector's `CollectVote(from s): H` line is its receipt, and the vote still has to be verified before it counts. Views 3 to last-1 of the active phase were tested (3,684 / 1,114 / 3,599 / 3,654 views); receiver and vote checks count one replica in one view. Each cell is passed / tested:

{chain_table()}

**What the attached QC does at the receiver.** For every proposal that passed check 4, the attached parent QC either raises HighQC (and the replica enters view v) or is already known:

{o5_table()}

A receiver that was already in view v when the proposal arrived had entered it earlier, in nearly all cases through a timeout certificate (`OnRemoteTimeout (second advance)`); this is rare (13 / 24 / 16 / 8 updates and 0 / 20 / 15 / 1 'not updated' cases). In all other cases, 11,038 / 3,282 / 10,764 / 10,953, the order is exactly QC, HighQC update, advance, vote.

**One complete chain from the log** (main.log, view 1000, lines 54858-54912; proposer hs1, receivers hs2 and hs3, collector hs2; the lines of hs4 and the lines of other event types are left out; columns: line number, replica, message):

```
{code}
```

Reading: hs1 proposes B_1000 with `cert` QC_999 (54858); hs2 and hs3 receive it (54865, 54873), process QC_999 (54866, 54876), update HighQC (54877, 54888), enter view 1000 (54878, 54889) and vote (`TryCommit` 54880, 54893). The collector hs2 receives the votes from 2, 1, 4 and 3 (54892, 54895, 54898, 54907); the QC dispatch (54906, `current : 1000`) follows the third distinct vote line, and the 4th vote line (from 3, 54907) comes after it. `OnNewView` carries QC_1000 (54908-54909), HighQC is updated (54910), hs2 advances to view 1001 (54911) and proposes B_1001 with `cert` QC_1000 (54912). QC_1000 lists its voters as [ 2 4 1 ] although the vote lines arrived as 2, 1, 4: the processing order differs from the arrival order (Part 2), and the late voter 3 is not in the QC. The three `OnNewView` lines of hs1 (54879, 54890, 54903) each process QC_999 again and leave HighQC unchanged (`HighQC not updated`); they are not part of the chain.
"""


# ---------------------------------------------------------------------------------------------------- where the chain breaks
def class_tables():
    t = lib.find_table("part4.md", r"^## 4B\.", 0)
    body = {r[0]: r[1:] for r in t[2]}
    keys = list(body.keys())
    lab = {
        keys[0]: "N · complete chain: dispatch, `OnNewView`, `advanceView(QC_v)`, HighQC updated, `Advanced to view v+1`, `TryCommit(B_(v+1))` with QC_v",
        keys[1]: "L · QC_v formed (dispatch logged) but a timeout or TC advance won the race",
        keys[2]: "X · fewer than 3 distinct `CollectVote` lines: no QC for B_v",
    }
    rows = [[lab[k]] + body[k] for k in keys[:3]]
    rows += [["Views tested"] + body["views tested"], ["Share of class N"] + body["share N"],
             ["Blocks whose parent is not the block of view v-1 (view gap)"] + body["blocks whose parent is NOT view-1 (view gap) in the tested range"],
             ["These blocks are exactly B_(v+1) of the views of class L or X"] + body["set of those blocks == {v+1 : v of class L or X}"]]
    return custom(["Class of view v (collector chain)", *RUNS], rows)


def lx_table():
    t = lib.find_table("part4.md", r"^Views of class L / X in detail", 0)
    rows = []
    for r in t[2]:
        rows.append([r[0], r[1].replace(",", ""), r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9].replace(",", "")])
    return custom(["Run", "View v", "Class", "Collector", "CollectVote senders in line order", "Local timeout at hs", "TC formed at hs", "Collector entered v+1 by",
                   "B_(v+1) proposer", "B_(v+1) carries QC of view"], rows, [":---", "---:", ":---", ":---", ":---", ":---", ":---", ":---", ":---", "---:"])


def disp_table():
    t = lib.find_table("part4.md", r"^## 4B\.", 1)
    body = {r[0]: r[1:] for r in t[2]}
    lab = {"complete": "Collector chain complete", "broken": "Collector chain broken", "dispatch line without a matching block (<3 distinct vote lines before it)": "Dispatch without 3 distinct vote lines before it",
           "QC_DISPATCH lines in the active phase": "QC dispatch lines in the active phase"}
    return custom(["Collector chain after a dispatch (all active-phase dispatch lines, views 1-2 and the last view included)", *RUNS], [[lab[k]] + v for k, v in body.items()])


def sec_p4_breaks():
    c2, code2 = excerpt("E2")
    return f"""## Part 4 · Where the chain breaks: a timeout wins the race

In 15 views (10 in main_2, 5 in main_3) the chain breaks, always because timeouts took over before the QC was used; main and main_4 have no broken view. The other exceptions in the checks above concern a single replica: 16 proposals rejected as too old (check 4) and 2 votes missing at the collector after a local timeout (check 6).

Every view of the tested range is put in one of three classes:

{class_tables()}

Counting every QC dispatch of the active phase, the collector chain is complete after 3,685 / 1,105 / 3,595 / 3,656 dispatches and broken after 0 / 5 / 4 / 0; no dispatch occurs without three distinct vote lines before it.

{disp_table()}

**The 15 broken views.** `CollectVote senders` lists the replica ids in the order of the `CollectVote` lines (2143 = votes from 2, 1, 4, 3). `Local timeout at` lists the replicas that logged `OnLocalTimeout: V`, `TC formed at` the replicas that logged `OnRemoteTimeout (second advance)` for the view (1234 = hs1 to hs4):

{lx_table()}

- **Timeouts at three or four replicas.** In all 15 views at least three replicas logged `OnLocalTimeout: V` and all four formed the timeout certificate; the collector entered v+1 through the TC (13 times `OnRemoteTimeout (second advance)`, twice an `OnNewView` that carried the TC, excerpt E3 in the 'Log excerpts' tab).
- **L: QC and TC at the same time.** The collector holds three votes and dispatches QC_v, but the TC advance is processed first, so the replica proposes B_(v+1) with the older QC. Excerpt E2 shows view 896 of main_2.
- **X: no QC.** Only 1 or 2 distinct votes arrived (view 897 of main_2: one vote, excerpt E4), so only the TC could move the view on.
- **Effect on the chain.** B_(v+1) extends the highest QC the collector knew (view v-1 or v-2 in the table), so its parent is not B_v. The set of blocks with a parent that is not the previous view is exactly the set of the blocks B_(v+1) above: 10 in main_2 and 5 in main_3 (table 'Block fields' in the section 'Part 4 · View entry, commit rule and block fields', below). B_v is left as a fork; `PruneToHeight: found forked block` is logged only in the two runs that have gap blocks (23 times in main_2, 19 in main_3, none in main and main_4), and some commit lines are missing (Section 'View entry, commit rule and block fields').

**Excerpt E2** (main_2.log, view 896, collector hs2; hs2 lines only): three votes arrive (49209-49222), hs2 times out (49232), the TC is formed (49279), hs2 advances to view 897 and proposes B_897 with QC_895 (49294, 49305), and QC_896 (IDs [ 2 1 4 ]) is processed only at line 49323, 29 lines after hs2 entered view 897.

```
{code2}
```
"""


# ---------------------------------------------------------------------------------------------------- view entry, commit rule, blocks
def entry_table():
    t = lib.find_table("part4.md", r"^## 4C\.", 0)
    lab = {"RECV_PROPOSAL": "`Received proposal` (receivers, next proposal)",
           "ON_NEW_VIEW_LOCAL": "`OnNewView` after the replica's own QC dispatch (collector)",
           "REMOTE_TIMEOUT_2ND": "`OnRemoteTimeout (second advance)`: timeout certificate",
           "REMOTE_TIMEOUT": "`OnRemoteTimeout (advancing view)`",
           "ON_NEW_VIEW_OTHER": "`OnNewView` carrying a TC (no dispatch of its own)",
           "total": "Total"}
    rows = []
    for r in t[2]:
        k = r[0]
        if k in lab:
            rows.append([lab[k]] + r[1:])
        elif k.startswith("view step"):
            rows.append(["View step +1 / +2 / +3 / more (all phases)"] + [fc(x) for x in r[1:]])
        elif k.startswith("advances that do not"):
            rows.append(["Advances that do not increase the view"] + r[1:])
    return custom(["Trigger of every `Advanced to view N` (after the replica's first); active / drain", *RUNS], rows)


def decide_table():
    t = lib.find_table("part4.md", r"^## 4D\.", 0)
    lab = {"b1,b2,b3 in consecutive views, DECIDE logged": "b1, b2, b3 in consecutive views, `DECIDE` logged",
           "b1,b2,b3 in consecutive views, DECIDE missing": "b1, b2, b3 in consecutive views, `DECIDE` missing",
           "NOT consecutive, DECIDE logged": "not consecutive, `DECIDE` logged",
           "NOT consecutive, DECIDE not logged": "not consecutive, `DECIDE` not logged"}
    return custom(["Every `TryCommit(B_v)` with a known three-chain (all phases)", *RUNS], [[lab[r[0]]] + r[1:] for r in t[2]])


def triple_table():
    t = lib.find_table("part4.md", r"^## 4D\.", 1)
    rows = []
    for run, gaps, lines in t[2]:
        if "None" in gaps or gaps == "(1, 1, 1)":
            continue
        rows.append([run, gaps, lines.replace("+", " + ")])
    return custom(["Run", "Gaps (B_v to b1, b1 to b2, b2 to b3)", "Commit-rule lines logged after `TryCommit(B_v)` (x = number of such TryCommits, replica by view)"], rows, [":---", ":---", ":---"])


def block_table():
    t = lib.find_table("part4.md", r"^## 4E\.", 0)
    lab = {"distinct blocks (hash) seen in the log": "Distinct blocks in the log (the genesis block included)",
           "blocks whose 'parent' hash == 'cert' QC hash": "Blocks whose `parent` hash equals the `cert` QC hash",
           "blocks whose cert lists 3 distinct signers": "Blocks whose `cert` lists 3 distinct signers (all but the genesis block and the view-1 block)",
           "blocks with known parent; QC view == parent view": "Proposals whose `cert` QC view equals the view of the parent block",
           "parent-link view gap (1 / 2 / 3 / more)": "View distance to the parent: 1 / 2 / 3 / more"}
    return custom(["Block fields", *RUNS], [[lab[r[0]]] + [fc(x) for x in r[1:]] for r in t[2]])


def stage_table():
    t = lib.find_table("part4.md", r"^## 4F\.", 0)
    lab = {"proposer TryCommit(B_v) -> first 'Received proposal'": "Proposer `TryCommit(B_v)` to first `Received proposal`",
           "'Received proposal' -> TryCommit(B_v) at the receiver": "`Received proposal` to `TryCommit(B_v)` at the receiver",
           "voter TryCommit(B_v) -> its CollectVote line at the collector (voter != collector)": "Voter's `TryCommit(B_v)` to its `CollectVote` line at the collector",
           "collector TryCommit(B_v) -> its own CollectVote line": "Collector's `TryCommit(B_v)` to its own `CollectVote` line",
           "3rd distinct CollectVote line -> QC dispatch": "3rd distinct `CollectVote` line to the QC dispatch",
           "QC dispatch -> 'Advanced to view v+1' at the collector": "QC dispatch to `Advanced to view v+1` at the collector",
           "'Advanced to view v+1' -> TryCommit(B_{v+1}) at the collector": "`Advanced to view v+1` to `TryCommit(B_(v+1))` at the collector",
           "TryCommit(B_v) at p -> TryCommit(B_{v+1}) at the collector": "Whole cycle: `TryCommit(B_v)` at the proposer to `TryCommit(B_(v+1))` at the collector"}
    return custom(["Stage (median / p90 / max, ms)", *RUNS], [[lab[r[0]]] + r[1:] for r in t[2]])


def sec_p4_commit():
    return f"""## Part 4 · View entry, commit rule and block fields

Views advance by exactly one, blocks name the QC of their parent, and a DECIDE is logged exactly when three certified blocks sit in consecutive views.

**How replicas enter views.** Every `advanceView: Advanced to view N` after a replica's first, by what led to it (active phase / drain):

{entry_table()}

In the active phase the collector enters v+1 through its own QC and the three other replicas through the next proposal, which is 4 entries per view (14,734 / 4,456 / 14,393 / 14,617 entries in the active phase). Entries through a timeout certificate are 13 / 67 / 36 / 8 in the active phase and 110 / 20 / 107 / 111 in the drain, where no proposals are made. All 14,856 / 4,492 / 14,512 / 14,740 entries are steps of exactly +1: there is no jump and no step backwards.

**Commit rule against consecutive views.** In the log, each `TryCommit(B_v)` is followed by `PRE_COMMIT` for the block b1 that B_v's QC certifies (its parent); `COMMIT` is logged for b2, the parent of b1, when its view is higher than that of the highest earlier COMMIT; `DECIDE` is logged for b3, the parent of b2, when b1, b2 and b3 are in consecutive views. For every TryCommit with a known three-chain:

{decide_table()}

The 44 (main_2) and 40 (main_3) TryCommits without `DECIDE` are exactly those whose chain is not consecutive; there is no DECIDE without a consecutive chain and no consecutive chain without DECIDE in any run (0 violations). The non-consecutive chains come from the gap blocks of the previous section:

{triple_table()}

The first TryCommits of every run (views 1-3) have an incomplete chain and log PRE_COMMIT only. With gaps (2, 1, 1) or (3, 1, 1) the gap sits between B_v and b1, so b1, b2, b3 are consecutive and DECIDE is logged; with a gap anywhere in b1, b2, b3 (for example (1, 2, 1)) DECIDE is missing. COMMIT needs the view of b2 to exceed the view of the highest block committed before; after a fork this does not always hold, which is why some rows have PRE_COMMIT only. Execution follows the decided blocks: all four replicas execute the same hash sequence in every run (3,685 / 1,108 / 3,595 / 3,656 `EXEC` lines per replica; the genesis block is decided once and never executed).

**Block fields.** A proposal carries the QC of its parent:

{block_table()}

**Stage latencies** inside the views of class N (log timestamps, resolution 1 ms):

{stage_table()}

A whole cycle takes a median 3 ms (4 ms in main_2) and 4 ms at the 90th percentile (7 ms in main_2); every single stage has a median of 0-1 ms. The longest cycles are 13 / 421 / 39 / 15 ms; main_2's 421 ms lies at the end of the stall window (the proposal of view 925).
"""


# ---------------------------------------------------------------------------------------------------- verification
def sec_p4_verify():
    return r"""## Part 4 · Verification commands

Every proposal carries the QC of its parent (`parent` hash = `cert` hash), and the view distance between a block and the QC it carries (run in the folder of the logs):

```bash
for f in main main_2 main_3 main_4; do
  grep -hE 'TryCommit: Block|Received proposal: Block' $f.log | grep -oE 'Block\{ hash: [^ ]+ parent: [^,]+, proposer: [0-9]+, view: [0-9]+ , cert: QC\{ hash: [^,]+' | sort -u |
    awk -v f=$f '{ p=$5; sub(/,$/,"",p); n++; if (p==$NF) ok++ } END { print f ": blocks=" n, "parent==cert=" ok+0 }'
  grep -hE 'TryCommit: Block|Received proposal: Block' $f.log | grep -oE 'view: [0-9]+ , cert: QC\{ hash: [^,]+, view: [0-9]+' | sort -u |
    awk '{ h[$2-$NF]++ } END { printf "  view distance to the QC:"; for (g in h) printf " %s:%d", g, h[g]; print "" }'
done
# main: blocks=3688 parent==cert=3688        distance 1:3688
# main_2: blocks=1119 parent==cert=1119      distance 3:5 2:5 1:1109
# main_3: blocks=3603 parent==cert=3603      distance 2:5 1:3598
# main_4: blocks=3659 parent==cert=3659      distance 1:3659
```

The blocks with a gap, which are the blocks B_(v+1) of the broken views:

```bash
grep -hE 'TryCommit: Block|Received proposal: Block' main_2.log | grep -oE 'view: [0-9]+ , cert: QC\{ hash: [^,]+, view: [0-9]+' | sort -u |
  awk '$2-$NF != 1 { print "block view " $2 " carries QC of view " $NF }' | sort -k3n
# block views 897 (QC 895), 898 (895), 899 (896), 901 (899), 902 (899), 904 (902), 905 (902), 906 (903), 908 (906), 914 (912)
# the same command on main_3.log: 2226 (2224), 2668 (2666), 2681 (2679), 2969 (2967), 2976 (2974)
```

Votes are collected only after the voter's own `TryCommit` of the same block (all `CollectVote` lines of a log, all phases):

```bash
for f in main main_2 main_3 main_4; do
  awk -F'\t' '
    $5 ~ /^TryCommit: Block\{/ { h=$5; sub(/^TryCommit: Block\{ hash: /,"",h); sub(/ .*/,"",h); r=$3; sub(/hs/,"",r); if (!((h,r) in t)) t[h,r]=NR }
    $5 ~ /^CollectVote\(from [0-9]+\): / { s=$5; sub(/^CollectVote\(from /,"",s); sub(/\).*/,"",s); h=$5; sub(/^.*: /,"",h); n++; if (((h,s) in t) && t[h,s] < NR) ok++ }
    END { printf "%s: %d CollectVote lines, %d after the sender'"'"'s own TryCommit of the same block\n", FILENAME, n, ok }' $f.log
done
# main.log: 14787 / 14787   main_2.log: 4502 / 4502   main_3.log: 14436 / 14436   main_4.log: 14659 / 14659
```

QC dispatches of the active phase and the commit-rule lines per run:

```bash
for f in main main_2 main_3 main_4; do
  STOP=$(grep -n 'Stopping clients\.\.\.' $f.log | head -1 | cut -d: -f1)
  printf '%s dispatch(active)=%s TryCommit=%s PRE_COMMIT=%s COMMIT=%s DECIDE=%s\n' $f "$(head -n $((STOP-1)) $f.log | grep -c 'CollectVote: dispatching event for new view')" \
    "$(grep -c 'TryCommit: Block' $f.log)" "$(grep -c 'CommitRule - PRE_COMMIT' $f.log)" "$(grep -c 'CommitRule - COMMIT' $f.log)" "$(grep -c 'CommitRule - DECIDE' $f.log)"
done
# main   dispatch(active)=3685 TryCommit=14751 PRE_COMMIT=14751 COMMIT=14743 DECIDE=14743
# main_2 dispatch(active)=1110 TryCommit=4460  PRE_COMMIT=4460  COMMIT=4434  DECIDE=4408
# main_3 dispatch(active)=3599 TryCommit=14410 PRE_COMMIT=14410 COMMIT=14384 DECIDE=14362
# main_4 dispatch(active)=3656 TryCommit=14636 PRE_COMMIT=14636 COMMIT=14628 DECIDE=14628
```

The shipped `verify_order.sh` (awk only, `verify_order.awk`) re-computes the whole ordering analysis from the raw logs: checks O1-O10, the classes N / L / X, the gap blocks, the commit-rule check and the cycle times. `compare_order.py` compares its 243 values with the Python results (`part4_ordering.py`): 243 compared, 0 mismatches. Its summary line per run is `N=3684 L=0 X=0 of 3684 views` (main), `N=1104 L=5 X=5 of 1114` (main_2), `N=3594 L=4 X=1 of 3599` (main_3), `N=3654 L=0 X=0 of 3654` (main_4).
"""
