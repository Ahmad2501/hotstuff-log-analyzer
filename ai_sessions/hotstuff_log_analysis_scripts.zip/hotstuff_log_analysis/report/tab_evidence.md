# Evidence tables

Supporting tables for Parts 2 and 3 that are too long for the main text.

## Part 2 · Which of the two open places is last, per collector and run

Every complete vote sequence reads collector, proposer, X, Y; X and Y are the two other replicas. Exact two-sided binomial test of 'which of the two is last' against 50 / 50, and Wald-Wolfowitz runs test over the consecutive turns of the same collector (every 4th view). The combined result is in the main text.

| Collector | Run | Candidates for last place | Sequences | Last = first / second candidate | Second candidate last | p (binomial) | Runs observed | Runs z | p (runs) |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| hs1 | main | hs2, hs3 | 915 | 451 / 464 | 50.7% | 0.692 | 479 (exp 458) | +1.36 | 0.173 |
| hs1 | main_2 | hs2, hs3 | 268 | 133 / 135 | 50.4% | 0.951 | 144 (exp 135) | +1.10 | 0.27 |
| hs1 | main_3 | hs2, hs3 | 893 | 458 / 435 | 48.7% | 0.462 | 456 (exp 447) | +0.59 | 0.556 |
| hs1 | main_4 | hs2, hs3 | 904 | 482 / 422 | 46.7% | 0.0497 | 452 (exp 451) | +0.07 | 0.947 |
| hs2 | main | hs3, hs4 | 901 | 469 / 432 | 47.9% | 0.23 | 417 (exp 451) | -2.25 | 0.0242 |
| hs2 | main_2 | hs3, hs4 | 266 | 139 / 127 | 47.7% | 0.5 | 142 (exp 134) | +1.02 | 0.309 |
| hs2 | main_3 | hs3, hs4 | 893 | 452 / 441 | 49.4% | 0.738 | 446 (exp 447) | -0.10 | 0.924 |
| hs2 | main_4 | hs3, hs4 | 904 | 450 / 454 | 50.2% | 0.921 | 451 (exp 453) | -0.13 | 0.895 |
| hs3 | main | hs1, hs4 | 902 | 476 / 426 | 47.2% | 0.103 | 469 (exp 451) | +1.23 | 0.219 |
| hs3 | main_2 | hs1, hs4 | 267 | 138 / 129 | 48.3% | 0.625 | 131 (exp 134) | -0.41 | 0.681 |
| hs3 | main_3 | hs1, hs4 | 892 | 450 / 442 | 49.6% | 0.815 | 454 (exp 447) | +0.47 | 0.637 |
| hs3 | main_4 | hs1, hs4 | 907 | 476 / 431 | 47.5% | 0.144 | 451 (exp 453) | -0.16 | 0.874 |
| hs4 | main | hs1, hs2 | 906 | 480 / 426 | 47.0% | 0.0782 | 478 (exp 452) | +1.71 | 0.0875 |
| hs4 | main_2 | hs1, hs2 | 265 | 139 / 126 | 47.5% | 0.461 | 117 (exp 133) | -2.00 | 0.0459 |
| hs4 | main_3 | hs1, hs2 | 885 | 448 / 437 | 49.4% | 0.737 | 455 (exp 443) | +0.78 | 0.436 |
| hs4 | main_4 | hs1, hs2 | 905 | 440 / 465 | 51.4% | 0.425 | 470 (exp 453) | +1.12 | 0.262 |

## Part 2 · Position of each sender's vote, per run

Share of the complete vote sequences in which the sender's vote is 1st, 2nd, 3rd or 4th, pooled over all receivers:

| Scope | Sender | 1st % | 2nd % | 3rd % | 4th % |
| :--- | :--- | ---: | ---: | ---: | ---: |
| main | hs1 | 25.1 | 24.9 | 23.6 | 26.4 |
| main | hs2 | 25.0 | 24.8 | 26.1 | 24.0 |
| main | hs3 | 24.9 | 25.0 | 24.2 | 25.8 |
| main | hs4 | 25.0 | 25.3 | 26.0 | 23.7 |
| main_2 | hs1 | 25.0 | 24.8 | 24.1 | 26.1 |
| main_2 | hs2 | 25.1 | 25.4 | 25.5 | 23.9 |
| main_2 | hs3 | 24.9 | 24.7 | 24.5 | 26.0 |
| main_2 | hs4 | 25.0 | 25.1 | 25.9 | 24.0 |
| main_3 | hs1 | 25.0 | 25.2 | 24.6 | 25.2 |
| main_3 | hs2 | 25.0 | 25.0 | 24.8 | 25.2 |
| main_3 | hs3 | 25.0 | 24.8 | 25.4 | 24.8 |
| main_3 | hs4 | 24.9 | 25.0 | 25.3 | 24.7 |
| main_4 | hs1 | 25.0 | 25.0 | 24.7 | 25.4 |
| main_4 | hs2 | 24.9 | 25.1 | 23.8 | 26.2 |
| main_4 | hs3 | 25.1 | 25.0 | 25.9 | 24.1 |
| main_4 | hs4 | 25.1 | 25.0 | 25.6 | 24.3 |
| combined | hs1 | 25.0 | 25.0 | 24.3 | 25.7 |
| combined | hs2 | 25.0 | 25.0 | 25.0 | 25.1 |
| combined | hs3 | 25.0 | 24.9 | 25.1 | 25.0 |
| combined | hs4 | 25.0 | 25.1 | 25.7 | 24.2 |

## Part 3 · Views with timeout-type events, per run

The views behind the counts of 'Views with timeout events': every view number with a timeout-type event, in the active phase, and the range of the drain-phase views. Drain-phase views are the views after the last client-driven proposal, where every view ends by timeout.

| Run | Views (active) | View numbers with timeout-type events, active phase | Views (drain) | Drain-phase views |
| :--- | ---: | :--- | ---: | :--- |
| main | 63 | 3, 20, 41, 115, 143, 174, 221, 241, 332, 407, 514, 563, 652, 787, 896, 897, 975, 1212, 1527, 1556, 1645, 1646, 1712, 1752, 1753, 1763, 2017, 2019, 2075, 2190, 2191, 2249, 2250, 2367, 2368, 2413, 2427, 2488, 2551, 2613, 2614, 2678, 2744, 2745, 2812, 2882, 2951, 3091, 3092, 3123, 3162, 3163, 3311, 3312, 3385, 3459, 3460, 3536, 3543, 3569, 3610, 3611, 3613 | 28 | 3688-3715 |
| main_2 | 40 | 3, 4, 5, 20, 61, 62, 85, 309, 396, 490, 542, 544, 545, 603, 870, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 917, 922, 923, 924, 925 | 5 | 1120-1124 |
| main_3 | 60 | 3, 5, 6, 7, 25, 26, 48, 126, 153, 154, 219, 254, 377, 419, 520, 680, 698, 909, 910, 1077, 1167, 1168, 1267, 1354, 1445, 1539, 1564, 1608, 1683, 1781, 1882, 1938, 1986, 1987, 2026, 2048, 2223, 2224, 2225, 2273, 2343, 2489, 2626, 2653, 2663, 2664, 2665, 2666, 2667, 2669, 2671, 2672, 2673, 2674, 2680, 2968, 2969, 2975, 2987, 2988 | 27 | 3603-3629 |
| main_4 | 61 | 3, 4, 7, 16, 83, 84, 110, 111, 176, 201, 202, 237, 275, 314, 356, 365, 545, 613, 614, 647, 648, 658, 667, 680, 682, 683, 1671, 1728, 2034, 2090, 2147, 2206, 2209, 2310, 2311, 2323, 2384, 2453, 2454, 2624, 2704, 2769, 2837, 2874, 2904, 2971, 2983, 3038, 3039, 3106, 3107, 3127, 3178, 3253, 3328, 3348, 3404, 3405, 3481, 3482, 3507 | 28 | 3659-3686 |

Reading the lists: view 3 is the only entry in all four; 896 and 897 (main, main_2) and 909 and 910 (main_3, main_2) lie in the stall window of main_2; 4, 5, 6 and 7 are start-up views; consecutive numbers (for example 2663-2667 and 2671-2674 in main_3) are bursts.
