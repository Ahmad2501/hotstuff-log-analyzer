#!/usr/bin/env python3
"""lib.py - helpers for the report builder: pull tables out of the verified result files (out/part*.md, out/*.tsv) so that
no table number in the report is typed by hand."""
import os
import re
import csv

SCR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.environ.get("HS_OUT", os.path.join(SCR, "out"))
RUNS = ["main", "main_2", "main_3", "main_4"]


def read_lines(name):
    with open(os.path.join(OUT, name), encoding="utf-8") as f:
        return f.read().split("\n")


def _cells(line):
    s = line.strip()
    assert s.startswith("|") and s.endswith("|"), line
    return [c.strip() for c in s[1:-1].split("|")]


def find_table(name, anchor, n=0):
    """Return (header, aligns, rows) of the n-th pipe table after the first line that matches regex `anchor`."""
    lines = read_lines(name)
    rx = re.compile(anchor)
    start = next((i for i, l in enumerate(lines) if rx.search(l)), None)
    if start is None:
        raise KeyError(f"{name}: anchor {anchor!r} not found")
    i, seen = start + 1, -1
    while i < len(lines):
        if lines[i].startswith("|") and i + 1 < len(lines) and re.match(r"^\|\s*:?-{3,}", lines[i + 1]):
            seen += 1
            j = i + 2
            rows = []
            while j < len(lines) and lines[j].startswith("|"):
                rows.append(_cells(lines[j]))
                j += 1
            if seen == n:
                return _cells(lines[i]), _cells(lines[i + 1]), rows
            i = j
        else:
            i += 1
    raise KeyError(f"{name}: table {n} after {anchor!r} not found")


def pick(table, cols=None, rows=None, rename=None, first_header=None):
    """cols: list of column indexes; rows: regex on the first cell (keep matching rows) or list of indexes."""
    header, aligns, body = table
    cols = list(range(len(header))) if cols is None else cols
    if rows is not None:
        if isinstance(rows, str):
            rx = re.compile(rows)
            body = [r for r in body if rx.search(r[0])]
        else:
            body = [body[i] for i in rows]
    h = [header[c] for c in cols]
    if first_header is not None:
        h[0] = first_header
    if rename:
        h = [rename.get(x, x) for x in h]
    a = [aligns[c] for c in cols]
    b = [[r[c] for c in cols] for r in body]
    return h, a, b


def clean(s):
    """Make a result-file cell safe for the document markdown (no angle-bracket pseudo tags, no pipes)."""
    s = s.replace("<view>", "V").replace("<=>", "iff").replace("<-", "from").replace("(<3)", "(under 3)").replace("<3 ", "under 3 ")
    s = re.sub(r"^P\d+[a-z]?\s+", "", s)          # drop the internal pattern id 'P1  ', 'P3b   ' ...
    s = re.sub(r"^X\d+\s+", "", s)
    return s


def render(table):
    h, a, b = table[0], table[1], table[2]
    h = [clean(x) for x in h]
    out = ["| " + " | ".join(h) + " |", "| " + " | ".join(a) + " |"]
    for r in b:
        out.append("| " + " | ".join(clean(c) for c in r) + " |")
    return "\n".join(out)


def tbl(name, anchor, n=0, cols=None, rows=None, rename=None, first_header=None, subst=None):
    t = pick(find_table(name, anchor, n), cols, rows, rename, first_header)
    if subst:
        t = (t[0], t[1], [[subst(c) for c in r] for r in t[2]])
    return render(t)


def custom(header, rows, aligns=None):
    if aligns is None:
        aligns = [":---"] + ["---:"] * (len(header) - 1)
    return render((header, aligns, [[str(c) for c in r] for r in rows]))


def fmt(n):
    return f"{n:,}"


# ---- verify_counts.tsv: id <TAB> run <TAB> scope <TAB> count (independent grep/awk numbers) --------------------------
_VC = None


def vc():
    global _VC
    if _VC is None:
        _VC = {}
        with open(os.path.join(OUT, "verify_counts.tsv"), encoding="utf-8") as f:
            for row in csv.reader(f, delimiter="\t"):
                if len(row) == 4:
                    _VC[(row[0], row[1], row[2])] = int(row[3])
    return _VC


def vcount(pid, run, scope="total"):
    return vc()[(pid, run, scope)]


def cell(pid, run):
    t, a, d = vcount(pid, run, "total"), vcount(pid, run, "active"), vcount(pid, run, "drain")
    return f"{fmt(t)} ({fmt(a)} / {fmt(d)})"


# ---- verify_order.tsv / verify_votes.tsv -----------------------------------------------------------------------------
_VO = None


def vo():
    global _VO
    if _VO is None:
        _VO = {}
        with open(os.path.join(OUT, "verify_order.tsv"), encoding="utf-8") as f:
            for row in csv.reader(f, delimiter="\t"):
                if len(row) >= 3:
                    _VO[(row[0], row[1])] = row[2]
    return _VO


def vo_int(run, key):
    return int(vo()[(run, key)])
