#!/usr/bin/env python3
"""extra.py - a few additional measurements that the report quotes (stall window split, timer length, voting state at timeout).
Writes report/extra.json.  Uses the same parsed/annotated events as the main analysis (scripts/views.py)."""
import os
import sys
import json
import collections
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "scripts"))
import views  # noqa: E402

RUNS = ["main", "main_2", "main_3", "main_4"]
WIN = (896, 925)          # main_2 stall window (see part3: inter-proposal gaps >= 100 ms for views 897..927)
EVS = ["LOCAL_TIMEOUT_VIEW", "REMOTE_TIMEOUT", "NOT_ENOUGH_TIMEOUTS", "REMOTE_TIMEOUT_2ND", "FAIL_VERIFY_SYNCINFO", "STOP_VOTING",
       "BLOCK_TOO_OLD", "PRUNE_FORK", "FETCH_ATTEMPT", "PROPOSAL_TOO_OLD"]


def q(a, p):
    a = sorted(a)
    k = (len(a) - 1) * p
    f = int(k)
    c = min(f + 1, len(a) - 1)
    return a[f] + (a[c] - a[f]) * (k - f)


def main():
    D = views.load_annotated()
    R = {}
    for run in RUNS:
        evs = D[run]["events"]
        t_log0 = evs[0]["t"]
        t_start = next(e["t"] for e in evs if e["ev"] == "CLIENT_START")
        res = {}
        # --- active views (first seen in the active phase) -------------------------------------------------------------
        act_views = sorted({e["blk"]["view"] for e in evs if e["ev"] in ("RECV_PROPOSAL", "TRY_COMMIT") and e["phase"] == "active" and e.get("blk")
                            and e["blk"]["view"] >= 1})
        # use the same definition as part1: views with a proposal first seen in the active phase
        first_seen = {}
        for e in evs:
            if e["ev"] in ("RECV_PROPOSAL", "TRY_COMMIT") and e.get("blk") and e["blk"]["view"] >= 1:
                first_seen.setdefault(e["blk"]["view"], e["phase"])
        n_act = sum(1 for v, ph in first_seen.items() if ph == "active")
        res["active_views"] = n_act
        # --- events inside / outside the window (active phase, attributed view) ------------------------------------------
        inside = collections.Counter()
        outside = collections.Counter()
        for e in evs:
            if e["phase"] != "active" or e["ev"] not in EVS or e.get("v") is None:
                continue
            (inside if WIN[0] <= e["v"] <= WIN[1] else outside)[e["ev"]] += 1
        res["inside"] = dict(inside)
        res["outside"] = dict(outside)
        win_views = sum(1 for v, ph in first_seen.items() if ph == "active" and WIN[0] <= v <= WIN[1])
        res["window_views"] = win_views
        # --- voting state at a local timeout -----------------------------------------------------------------------------
        voted = collections.defaultdict(set)
        had_voted = collections.Counter()
        stop = collections.Counter()
        last_adv = {}
        since = []
        lastto = {}
        gaps = []
        for e in evs:
            r = e["r"]
            if r is None or e["ev"] is None:
                continue
            if e["ev"] == "TRY_COMMIT" and e.get("blk"):
                voted[r].add(e["blk"]["view"])
            elif e["ev"] == "ADVANCED":
                last_adv[r] = e["t"]
            elif e["ev"] == "LOCAL_TIMEOUT_VIEW":
                hv = e["view"] in voted[r]
                had_voted[(e["phase"], hv)] += 1
                if e["phase"] == "active":
                    if r in last_adv:
                        since.append(e["t"] - last_adv[r])
            elif e["ev"] == "STOP_VOTING":
                stop[(e["phase"], e["view"] in voted[r])] += 1
        res["timeout_voted"] = {f"{k[0]}/{'voted' if k[1] else 'not_voted'}": v for k, v in had_voted.items()}
        res["stop_voting"] = {f"{k[0]}/{'voted' if k[1] else 'not_voted'}": v for k, v in stop.items()}
        res["since_view_entry_ms"] = dict(n=len(since), min=min(since), median=st.median(since), p90=q(since, .9), max=max(since))
        # --- view 3 start-up timeouts ----------------------------------------------------------------------------------------
        res["view3_timeout_replicas"] = sorted(e["r"] for e in evs if e["ev"] == "LOCAL_TIMEOUT_VIEW" and e["view"] == 3)
        res["view3_entered_ms"] = round(next(e["t"] for e in evs if e["ev"] == "ADVANCED" and e["view"] == 3) - t_log0)
        # --- repeats (bare lines w/o ':V' line) ---------------------------------------------------------------------------------
        R[run] = res
    # --- stall window timing in main_2 ---------------------------------------------------------------------------------------
    evs = D["main_2"]["events"]
    t_start = next(e["t"] for e in evs if e["ev"] == "CLIENT_START")
    first_enter = {}
    for e in evs:
        if e["ev"] == "ADVANCED":
            first_enter.setdefault(e["view"], e["t"])
    R["main_2"]["stall"] = dict(start_ms=round(first_enter[WIN[0]] - t_start), end_ms=round(first_enter[WIN[1] + 1] - t_start),
                                views=WIN[1] - WIN[0] + 1)
    cmds = [e for e in evs if e["ev"] == "CLIENT_CMD_TIMEOUT"]
    R["main_2"]["client_timeouts"] = dict(n=len(cmds), first_ms=round(cmds[0]["t"] - t_start), last_ms=round(cmds[-1]["t"] - t_start))
    with open(os.path.join(HERE, "extra.json"), "w") as f:
        json.dump(R, f, indent=1, default=str)
    print(json.dumps(R, indent=1, default=str))


if __name__ == "__main__":
    main()
