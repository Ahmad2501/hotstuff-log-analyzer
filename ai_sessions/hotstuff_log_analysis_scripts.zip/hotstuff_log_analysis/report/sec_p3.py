"""Part 3 sections: shared views, event-pattern classes, same view across runs, timeout views, timeouts vs view progression,
vote-collection patterns per view, view-only vs (view, proposer) matching, verification commands."""
import re
import json
import os
import lib
from lib import RUNS, custom, render

J3 = json.load(open(os.path.join(lib.OUT, "part3.json")))
EX = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "extra.json")))


def commas(c):
    """1065 (95.4%) -> 1,065 (95.4%); leaves view lists, decimals and small numbers alone."""
    return re.sub(r"(?<![\d,.\[ -])(\d{4,})(?![\d,]|\.\d)", lambda m: f"{int(m.group(1)):,}", c) if re.fullmatch(r"\d{4,}( \(.*\))?", c) else c


def num(x):
    return int(str(x).replace(",", "").split(" ")[0])


def T(name, anchor, n=0, **kw):
    return lib.tbl(name, anchor, n, subst=commas, **kw)


# ------------------------------------------------------------------------------------------------------------ 3A + 3B
def views_table():
    a = lib.find_table("part3.md", r"^## 3A\.", n=0)
    rows = []
    for r in a[2]:
        vn = r[2].replace("..", "-")
        vn = re.sub(r"-(\d{4,})", lambda m: f"-{int(m.group(1)):,}", vn)
        rows.append([r[0], r[1], vn, r[3], r[4], r[7], r[8]])
    return custom(["Run", "Views with a proposal", "View numbers", "First seen in the active phase", "First seen in the drain phase",
                   "View numbers without a proposal", "Views with two different proposals"], rows)


def class_table():
    t = lib.find_table("part3.md", r"^## 3B\.", n=0)
    by = {}
    for r in t[2]:
        by[r[0][0] if r[0][1:3] == "  " else "total"] = r
    lab = {"S": "S · standard core only",
           "L": "L · standard core plus a late 4th vote ('block too old')",
           "D": "D · standard core plus a duplicate vote line (local cache miss)",
           "N": "N · other core counts, no timeout event",
           "F": "F · fork, fetch, prune, missing-block or sync-info failure",
           "T": "T · timeout-type events"}
    rows = [[lab[k]] + by[k][1:] for k in ["S", "L", "D", "N", "F", "T"]] + [["Views (active phase)"] + by["total"][1:]]
    shares = {}
    for i, run in enumerate(RUNS):
        tot = num(by["total"][1 + i])
        shares[run] = {k: num(by[k][1 + i]) / tot for k in lab}
    return custom(["Class", *RUNS], rows), shares


def sec_p3_views():
    ct, sh = class_table()
    std = " / ".join(f"{100 * (sh[r]['S'] + sh[r]['L'] + sh[r]['D']):.1f}" for r in RUNS)
    fn = " / ".join(f"{100 * (sh[r]['F'] + sh[r]['N']):.1f}" for r in RUNS)
    pairs = T("part3.md", r"^## 3A\.", n=1, first_header="Run")
    return f"""## Part 3 · Shared views and event-pattern classes

Views 1-1,119 exist in all four runs, and 95-98% of the views of every run follow the standard event pattern. main_2 has the lowest share of standard views and the highest share of timeout views.

**Which views exist.** A view exists in a run when a block with that view number is proposed (a `TryCommit` line of the proposer):

{views_table()}

- **Four runs.** Views 1-1,119, the whole of main_2. 1,116 of them are first seen in the active phase in every run; the other 3 are drain-phase views of main_2.
- **Three runs.** Views 1,120-3,603 (2,484 views in main, main_3 and main_4). **Two runs:** 3,604-3,659 (56 views in main and main_4). **One run:** 3,660-3,688 (29 views in main). The union holds 3,688 views.
- **Structure.** View numbers are contiguous in every run, no view has two proposals, and the proposer of view v is always replica (v mod 4) + 1 (0 exceptions).

Number of views shared by each pair of runs:

{pairs}

**Event-pattern classes.** Every active-phase view gets one class from the events attributed to its view number. The standard core of a view is 3 `Received proposal`, 4 `TryCommit`, 4 `CollectVote`, 1 QC dispatch, 4 HighQC updates and 4 `Advanced to view` lines. Rule, first match wins: T = any timeout-type event; F = fork, fetch, prune, missing-block or sync-info failure; N = other core counts; D / L = standard core plus a duplicate vote line / a late 4th vote; S = standard core only.

{ct}

- **Standard views.** S, L and D together (standard core, only late or duplicate vote lines differ) are {std}% of the views of main / main_2 / main_3 / main_4.
- **Late 4th vote (L).** It is the most frequent deviation (24.0-26.5% of the views, 34.5% in main_2). The collector forms the QC from three votes and logs `block too old` when the fourth arrives; the voter of every late `CollectVote` line is outside `QC.IDs` (Part 4, check O8b).
- **Timeout views (T).** 1.7% in main, main_3 and main_4; 3.6% in main_2.
- **Fork, fetch, prune, missing block, other core counts (F + N).** {fn}% of the views; main_2 has 11 of these views, the others 2-7.
"""


# ------------------------------------------------------------------------------------------------------------ 3C
def sec_p3_same():
    c1 = T("part3.md", r"^## 3C\.", n=0, first_header="Measure over the views shared by all four runs")
    c2 = T("part3.md", r"^## 3C\.", n=1, rename={"event": "Event (per-view count)", "views where count differs in >=1 run": "Views where the count differs in at least one run", "share": "Share of the 1,116 shared views"}, first_header="Event (per-view count)")
    c3 = T("part3.md", r"^## 3C\.", n=2, rename={"views where count differs in >=1 of the 3 runs": "Views where the count differs in at least one of the 3 runs", "share": "Share of the 3,601 shared views"}, first_header="Event (per-view count)")
    return f"""## Part 3 · The same view in the four runs

For 95.4% of the 1,116 views that are shared and active in all four runs the core event counts are identical; the differences come from late votes and from timeout events.

{c1}

Events whose count in a view differs between the runs, over the same 1,116 views:

{c2}

The same measure for main, main_3 and main_4 only (main_2 left out), over their 3,601 shared active views:

{c3}

- **Similar views.** 1,065 views (95.4%) have identical core counts in all four runs, 1,009 (90.4%) have the standard core in all four. A view that is in the standard class in all four runs and has the same full event signature is rare (238-239 views, 21%), because late votes occur in a quarter to a third of the views of each run independently of the other runs (Section 'Vote collection in the same view').
- **Late vote line.** `BLOCK_TOO_OLD` is the most frequent difference (834 views, 74.7%; 57.6% among the three similar runs). It has no protocol effect: it is the line the collector writes for a vote that arrives after the QC was formed.
- **Advance and HighQC counts.** `ADVANCE_ENTER` (105 views) and `HQC_NOT_UPDATED` (99) differ in about as many views as the timeout events (90): in excerpts E2 and E3 every `OnRemoteTimeout` line is followed by an `advanceView` line and a 'HighQC not updated' line.
- **Commit events.** `DECIDE` differs in 19 of the shared views and `EXEC` in 25. All DECIDE differences but one are in main_2: 16 views of its stall window (897-916, where gap blocks break the three-chain, Part 4) and views 955 and 988, where hs3 logged `failed to verify incoming vote: block view 955 too old, last voted view was 957` (and the same for view 988, last voted view 990) and so had no `TryCommit` for the block. The exception is view 397 of main (hs1: `block view 397 too old, last voted view was 398`, excerpt E6).
"""


# ------------------------------------------------------------------------------------------------------------ 3D
def sec_p3_timeout():
    t0 = T("part3.md", r"^## 3D\.", n=0, rename={"views with timeout-type events: active-phase events": "Views, active phase", "drain-phase events": "Views, drain phase",
                                              "views in total": "Views, total", "views with 'OnLocalTimeout: V' (active)": "Views with 'OnLocalTimeout: V' (active)",
                                              "share of active views with timeout-type events": "Share of active views"}, first_header="Run")
    t1 = T("part3.md", r"^## 3D\.", n=1, rename={"shared active views": "Shared active views", "timeout views in A": "Timeout views in A", "in B": "in B",
                                              "in both (observed)": "In both", "expected by chance": "Expected by chance", "views in both": "Views in both"})
    per = J3["timeouts"]["per_run"]
    early = {r: [v for v in per[r]["active"] if v <= 10] for r in RUNS}
    n_early = sum(len(x) for x in early.values())
    win = [v for v in per["main_2"]["active"] if 896 <= v <= 925]
    v3 = {r: "hs" + " and hs".join(str(x) for x in EX[r]["view3_timeout_replicas"]) for r in RUNS}
    e3 = [EX[r]["view3_entered_ms"] for r in RUNS]
    return f"""## Part 3 · Views with timeout events

Timeout-type events occur in 1.7% of the active views of main, main_3 and main_4 and in 3.6% of main_2. Only view 3 has them in all four runs.

A timeout-type event is any of `OnLocalTimeout: V`, `OnRemoteTimeout`, `not enough timeouts`, the timeout-certificate advance (`OnRemoteTimeout (second advance)`), `Stopped voting for timed out view` and `Failed to create sync info`, attributed to the view named in the message (for the lines without a view number, the view of the replica's latest `OnRemoteTimeout` or its current view). Views with timeout-type events per run:

{t0}

- **All four runs.** Only view 3, in the active phase and in any phase; the same view is the only one with an `OnLocalTimeout: V` line in all four runs. The replicas that logged `OnLocalTimeout: 3` are {v3['main']} (main), {v3['main_2']} (main_2), {v3['main_3']} (main_3) and {v3['main_4']} (main_4). The view is entered {min(e3)}-{max(e3)} ms after the first log line of each run (start-up).
- **Start-up views.** In views 1-10, {n_early} of the 40 view slots (4 runs x 10 views) carry timeout-type events (main: {', '.join(map(str, early['main']))}; main_2: {', '.join(map(str, early['main_2']))}; main_3: {', '.join(map(str, early['main_3']))}; main_4: {', '.join(map(str, early['main_4']))}), {100 * n_early / 40:.1f}% against 1.7-3.6% over all views.
- **How many runs per view.** Counting every active view of every run: 200 views have timeout-type events in exactly one run, 10 in two runs, none in three, 1 (view 3) in four.
- **Stall window of main_2.** {len(win)} of the 30 views 896-925 of main_2 have timeout-type events (Section 'Timeouts and view progression').

Overlap of the timeout views of two runs, against the overlap expected if timeout views were scattered independently (hypergeometric upper tail, over the shared active views):

{t1}

Reading: main and main_2 share the views 3, 20, 896 and 897, main_2 and main_3 share 3, 5, 909 and 910. The low p-values (0.0024, 0.0045) come from views 896, 897, 909 and 910, which lie in the stall window of main_2, where {len(win)} of 30 views carry timeout events, so any timeout of another run that falls in the window overlaps. The other four pairs share 1-3 views (p = 0.063-0.66); all of them include view 3, and views 4, 5, 6 and 7 are start-up views as well. Only views 20, 545 and 680 are shared by two runs outside view 3, the start-up views and the stall window, as chance produces.
"""


# ------------------------------------------------------------------------------------------------------------ 3E
def dur_table():
    t = lib.find_table("part3.md", r"^## 3E\.", n=1)
    rows = [[r[0], r[1], r[2], r[3], r[4], r[5], r[6]] for r in t[2] if r[1] in ("S", "L", "T")]
    return custom(["Run", "Class", "Views", "Median ms", "Mean ms", "p90 ms", "Max ms"], [[c if i not in (2,) else f"{int(c.replace(',', '')):,}" for i, c in enumerate(r)] for r in rows],
                  [":---", ":---", "---:", "---:", "---:", "---:", "---:"])


def burst_table():
    t = lib.find_table("part3.md", r"^## 3E\.", n=2)
    rows = [[r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9]] for r in t[2]]
    return custom(["Run", "T views", "T then T", "T then not-T", "not-T then T", "not-T then not-T", "P(T at v+1, T at v)", "P(T at v+1, not T at v)", "Odds ratio", "Fisher p"],
                  [[commas(c) for c in r] for r in rows])


def timeline_table():
    t = lib.find_table("part3.md", r"^## 3E\.", n=3)
    return custom(["Second (0 = clients start)", "main", "main_2", "main_3", "main_4"], t[2],
                  [":---", "---:", "---:", "---:", "---:"])


def sec_p3_progress():
    out = T("part3.md", r"^## 3E\.", n=0, first_header="Outcome of the view that had an `OnLocalTimeout: V` (active phase)")
    st = EX["main_2"]["stall"]
    ct = EX["main_2"]["client_timeouts"]
    return f"""## Part 3 · Timeouts and view progression

A local timeout is mostly a short blip that the QC of the same view absorbs: in main, main_3 and main_4 the view still produced its QC in 96.7-100% of the timed-out views. In main_2 timeouts pile up into one 30-view stall.

**Did the timed-out view still make progress?** 'QC formed' means a `CollectVote: dispatching event for new view (current : v)` line exists for the view; 'advanced by TC' means at least one replica entered v+1 through `OnRemoteTimeout (second advance)`:

{out}

main_2 has 34 of 40 timed-out views with a QC (85%) and 6 without (5 views with fewer than 3 distinct votes and 1 whose QC was dispatched after the collector had left the view, Part 4).

**How long does a view take?** Time from the first replica entering view v to the first replica entering v+1, by class (ms; the log timestamps have 1 ms resolution):

{dur_table()}

A timed-out view takes about twice as long as a standard one in main, main_3 and main_4 (6-7 ms against 3 ms); in main_2 the median of a timeout view is 111.5 ms against 4 ms.

**Do timeout views come in bursts?** 2x2 table over consecutive active views (v, v+1):

{burst_table()}

After a timeout view, the next view is a timeout view in 20.6% (main), 65.0% (main_2), 30.0% (main_3) and 21.3% (main_4) of the cases, against 1.2-1.4% after a view without timeout. The odds ratios are 18.6, 140.7, 35.7 and 20.0 (Fisher p below 1e-10 in every run): timeouts cluster.

**Timeline.** Per second of the run (second 0 = client start; 'Stopping clients' is logged at second 10), each cell reads: proposals seen for the first time / `OnLocalTimeout: V` lines / TC formations (`second advance`):

{timeline_table()}

- **main, main_4.** 362-385 proposals per second in main (seconds 1-9) and 382-394 in main_4 from second 3 (309-315 in seconds 1-2), with 0-15 local timeouts per second, until the clients stop.
- **main_2.** 222-255 proposals per second in seconds 0-2, 179 in second 3, then 7 / 6 / 5 / 6 / 6 in seconds 4-8 with 27 and 21 local timeouts in seconds 4 and 5, and 187 in second 9. The stall covers views 896-925 (30 views) from {st['start_ms']:,} ms to {st['end_ms']:,} ms after the clients started, {st['end_ms'] - st['start_ms']:,} ms, i.e. 164 ms per view, against a mean of 2.7 ms (main, main_3, main_4) and 5.0 ms (main_2) for a standard view. The proposals of 29 of the 31 views 897-927 come at least 100 ms after the previous proposal (largest gap 421 ms, at view 925). The client reports {ct['n']} command timeouts between {ct['first_ms']:,} ms and {ct['last_ms']:,} ms.
- **main_3.** A shorter disturbance in seconds 7 and 8: 307 and 305 proposals per second with 33 and 13 local timeouts and 23 and 12 TCs (steady state: 0-12 and 0-4).
- **Drain (seconds 10-12).** The clients have stopped, so leaders cannot build proposals (`no command batch`) and every view ends by timeout: 71-81 local timeouts and 79-87 TCs in second 10 of main, main_3 and main_4, falling to 15-18 local timeouts in second 11 and 5-6 in second 12.
"""


# ------------------------------------------------------------------------------------------------------------ 3F
def sec_p3_votes():
    f1 = T("part3.md", r"^## 3F\.", n=0, rename={"views compared": "Views compared", "same last sender": "Same last sender", "agreement": "Agreement"})
    f2 = T("part3.md", r"^## 3F\.", n=1, rename={"views compared": "Views compared", "same excluded replica": "Same excluded replica", "agreement": "Agreement",
                                               "agreement expected if independent (per-collector marginals)": "Expected if independent"})
    f3 = T("part3.md", r"^## 3F\.", n=2, rename={"shared views": "Shared views", "late vote in A": "Late vote in A", "in B": "in B", "in both": "In both", "expected both": "Expected in both"})
    return f"""## Part 3 · Vote collection in the same view

The vote-collection pattern of a view repeats only where the leader rotation fixes it: the collector is first and the proposer second. Which replica is last, which one is left out of the QC and which views get a late vote do not recur across runs.

**Which replica is last in the same view** (complete sequences collector, proposer, X, Y; chance is 50%):

{f1}

All four runs agree on the last sender in 135 of 1,017 views (13.3%); independent fair coins give 12.5% (127 views), binomial p = 0.448. Only main_3 against main_4 (48.0%, p = 0.017) falls below 0.05; it is one of six comparisons.

**Collector first, proposer second.** Over the complete sequences of the shared views, 4,359 follow this order and 59 do not.

**Which replica is left out of the QC of the same view** (the 4th, late voter):

{f2}

**Views with a late 4th vote** ('block too old'), in run A, in run B and in both, against the overlap expected if independent:

{f3}

Reading: the recurring part is structural (collector and proposer are functions of the view number). Everything that depends on timing is independent between runs: the last sender agrees in 48.0-52.7% of the views, the excluded replica in 42.5-44.3% (expected 42.2-42.9%), and the late-vote overlaps (97-269 observed against 96.9-261.5 expected) are within 9% of the expectation in every pair.
"""


# ------------------------------------------------------------------------------------------------------------ 3G
def sec_p3_proposer():
    m = T("part3.md", r"^## 3G\.", n=0, first_header="Measure")
    by = T("part3.md", r"^### 3G-2\.", n=0, rename={"views led (active)": "Views led (active)", "class T %": "T %", "class L/D %": "L or D %", "class N/F %": "N or F %", "class S %": "S %"})
    hom = T("part3.md", r"^### 3G-2\.", n=1, rename={"event class": "Event", "views by proposer hs1/hs2/hs3/hs4": "Views by proposer hs1 / hs2 / hs3 / hs4",
                                                  "views led hs1/hs2/hs3/hs4": "Views led hs1 / hs2 / hs3 / hs4", "chi2": "chi2 (df 3)"})
    return f"""## Part 3 · View number alone or view number and proposer

Matching by view number and matching by (view number, proposer) give identical results in every row, because the proposer is a function of the view number: replica (view mod 4) + 1.

Both matchings were run on the same data. Shared views whose proposer differs between runs: 0; blocks whose proposer is not leader(view): 0; views with two different proposals in one run: 0.

{m}

What the proposer does explain is the vote order: the receiver of the votes of view v is the next leader (the collector, first in 100% of the sequences) and the second vote is the proposer's (99.12%). Grouping the active views by proposer adds one dimension; the shares of timeout, late-vote and standard views per proposer:

{by}

Homogeneity of the four proposers (chi-square, df = 3; indicative, events cluster):

{hom}

No proposer stands out: the smallest p-value is 0.13 (timeout views in main, 10-23 views per proposer). Using the proposer therefore changes neither the similarities (95.4% identical core counts), nor the differences (timeout views, late votes), nor the vote-order patterns (Section 'Vote collection in the same view'). The vote-order tables of Part 2 are already split by collector, which is the split by proposer (collector = proposer + 1): collector first in 100%, proposer second in 99.12%, last place divided 46.4-53.4% between the two other replicas.
"""


# ------------------------------------------------------------------------------------------------------------ verification
def sec_p3_verify():
    return r"""## Part 3 · Verification commands

Views per run, views shared by several runs (run in the folder of the logs; the output reproduces 'Which views exist'):

```bash
W=$(mktemp -d)
for r in main main_2 main_3 main_4; do
  grep -E 'Received proposal|TryCommit:' $r.log | grep -oE 'proposer: [0-9]+, view: [0-9]+' | sed -E 's/.*view: //' | sort -un | awk '$1>=1' > $W/$r.views
  echo "$r: $(wc -l < $W/$r.views) views, $(head -1 $W/$r.views)..$(tail -1 $W/$r.views)"
done
cat $W/*.views | sort -n | uniq -c | awk '{ n[$1]++ } END { for (k = 4; k >= 1; k--) print k " runs: " n[k] " views" }'
# main: 3688 views, 1..3688   main_2: 1119 views, 1..1119   main_3: 3603 views, 1..3603   main_4: 3659 views, 1..3659
# 4 runs: 1119 views   3 runs: 2484 views   2 runs: 56 views   1 runs: 29 views
```

Views with `OnLocalTimeout: V` in the active phase and the view that all four runs share:

```bash
W=$(mktemp -d)
for r in main main_2 main_3 main_4; do
  STOP=$(grep -n 'Stopping clients\.\.\.' $r.log | head -1 | cut -d: -f1)
  head -n $((STOP-1)) $r.log | grep -E 'OnLocalTimeout: [0-9]+$' | sed -E 's/.*OnLocalTimeout: //' | sort -un > $W/$r.lto
  echo "$r: $(wc -l < $W/$r.lto) views"
done
sort -n $W/*.lto | uniq -c | awk '$1==4 { print "view in all four runs:", $2 }'
# main: 63   main_2: 40   main_3: 60   main_4: 61   view in all four runs: 3
```

The proposer is a function of the view number (all four logs together):

```bash
cat main.log main_2.log main_3.log main_4.log | grep -E 'Received proposal|TryCommit:' | grep -oE 'proposer: [0-9]+, view: [0-9]+' | sort -u |
  awk '{ p=$2; sub(",","",p); v=$4; n++; if (p != (v % 4) + 1) bad++ } END { print n " distinct (proposer, view) pairs, " bad+0 " with proposer != (view mod 4)+1" }'
# 3688 distinct (proposer, view) pairs, 0 with proposer != (view mod 4)+1
```

The shipped `verify_views.sh` re-derives the view sets, the shared views, the timeout views, their pairwise overlaps and the proposer rule with grep, sed, sort and comm; `compare_views.py` compares its 33 values with the Python results: 33 compared, 0 mismatches. The class table, the view durations, the burst statistics and the per-second timeline come from `part3_views.py` only; they are not recomputed in shell.
"""
