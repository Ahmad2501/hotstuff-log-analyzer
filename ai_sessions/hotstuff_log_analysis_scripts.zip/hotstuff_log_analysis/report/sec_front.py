"""Front matter: lead paragraph, 'At a glance', 'Logs and conventions'."""
import lib
from lib import custom


LEAD = ("main, main_3 and main_4 share the same steady-state behaviour; main_2 is the outlier. The three run at about 365 proposals/s with the same "
        "progress counters per view and time out in 1.7% of views. main_2 runs at 112 proposals/s, stalls for 4.9 s around views 896-925 and logs "
        "3.5-8x more timeout and sync-info events per view. In all four runs the expected chain (proposal, QC, HighQC and view advance, next "
        "proposal) holds in 99.1-100% of views, and every exception is a timeout racing the QC.")


def glance():
    t = custom(
        ["", "main", "main_2", "main_3", "main_4"],
        [
            ["Recorded on", "2026-06-22", "2026-07-31", "2026-09-13", "2026-09-13"],
            ["Views with a proposal", "3,688", "1,119", "3,603", "3,659"],
            ["Proposals per second (10 s of client load)", "368.6", "111.6", "360.1", "365.6"],
            ["Client commands executed / timed out", "3,682 / 0", "1,045 / 60", "3,592 / 0", "3,653 / 0"],
            ["Views with at least one local timeout (active phase)", "63 (1.7%)", "40 (3.6%)", "60 (1.7%)", "61 (1.7%)"],
            ["View advances caused by a timeout certificate (active phase)", "13", "67", "36", "8"],
            ["'block too old' lines per 1,000 views", "265", "358", "271", "246"],
            ["'Failed to verify sync info' lines", "5", "17", "10", "10"],
            ["EXEC lines per replica", "3,685", "1,108", "3,595", "3,656"],
            ["Views with the complete ordered chain (class N, Part 4)", "100.00%", "99.10%", "99.86%", "100.00%"],
        ])
    return t


def sec_glance():
    return f"""## At a glance

Throughput and the timeout counters separate main_2 from the other runs, while the protocol counters per view do not.

{glance()}

- **Counts (Part 1).** Per proposed view, HighQC updates, view advances and TryCommit lines are within 1% of 4.00 in all four runs (p >= 0.99 across main, main_3 and main_4). Timeout counters are equal in main and main_4, about twice as high for timeout certificates in main_3 (14.7 against 7.1 and 7.4 per 1,000 views, p = 0.0009) and 3.5-8x higher in main_2.
- **Vote order (Part 2).** In 11,978 complete vote sequences the collector is first in 100% and the proposer second in 99.12%; the last two places are a coin flip (each replica is last 24.2-25.7%, p = 0.15). No replica is consistently first or last, and the order of the same view does not repeat across runs.
- **Views (Part 3).** 1,119 views occur in all four runs. Their core event counts are identical in 95.4%. Only view 3 has timeout events in all four runs. Matching by (view, proposer) gives exactly the same result as matching by view, because the proposer is a function of the view.
- **Ordering (Part 4).** The chain proposal, attached QC, HighQC and advance, vote, QC, next proposal holds in 3,684 of 3,684 / 1,104 of 1,114 / 3,594 of 3,599 / 3,654 of 3,654 tested views. Each of the 10 + 5 exceptions is a timeout that beat the QC, and each leaves one block whose parent is not the previous view.
- **Commit rule.** Of all TryCommit lines with a complete three-chain, the 44 (main_2) and 40 (main_3) without a DECIDE are exactly those whose chain spans non-consecutive views; no rule violation in any run.
- **Drain phase.** In main, main_3 and main_4 about half of the local-timeout lines (96 of 190, 93 of 199, 104 of 194) fall in the 2.5 s after the clients stop, when leaders cannot build proposals ('no command batch': 28 / 6 / 27 / 28 lines). main_2 has only 15 of 118 there.
"""


def sec_conventions():
    return """## Logs and conventions

The four logs use one configuration and one line format, so counts can be compared directly once they are normalised by view progression.

- **Files.** main.log (204,450 lines), main_2.log (63,935), main_3.log (200,004), main_4.log (202,887). The configuration banner is identical: 4 replicas, 1 client, chainedhotstuff, ecdsa, round-robin leaders, clique communication, batch size 1, 10 s of client load, ViewTimeout 500 ms.
- **Line format.** `timestamp<TAB>level<TAB>logger<TAB>source-file:line<TAB>message`. The loggers hs1-hs4 are the replicas, ctrl is the controller and cli1 the client; all four replicas write to the same file, interleaved.
- **Phases.** Active phase = lines before the first `Stopping clients...` line (ctrl, controller.go:109): line 201,864 / 63,334 / 197,476 / 200,122. Drain phase = the 2.5 s after it, while the replicas finish.
- **Protocol facts visible in the logs.** n = 4 and the quorum is 3. The leader of view v is replica (v mod 4) + 1 (0 exceptions in 3,688 views). A vote for block B_v goes to the leader of v+1, called the collector here. Only the three non-proposers log `Received proposal`. The vote itself is not logged; the collector's `CollectVote(from N): <hash>` line is its receipt. `TryCommit: Block{...}` is logged when a replica accepts a proposal, and the replica's vote follows.
- **Ordering.** Event order means physical line order within a file. Timestamps have 1 ms resolution and show inversions of up to 3 ms between loggers, so they are used only for durations.
- **Timer length.** The banner says ViewTimeout 500 ms, yet local timeouts fire a median 7 ms after the replica entered the view in main, main_3 and main_4 (57 ms in main_2). The log does not print the timer value, so the effective timer is not the configured 500 ms.
- **Statistics.** p-values come from chi-square, binomial, Fisher, hypergeometric and runs tests that assume independent events. Timeouts and late votes are clustered, so treat p-values as a rough guide, not as proof.
"""
