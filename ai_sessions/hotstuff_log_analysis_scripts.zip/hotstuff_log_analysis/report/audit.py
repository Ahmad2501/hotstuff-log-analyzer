#!/usr/bin/env python3
"""audit.py - flag numbers in the report text that do not occur in any result file (result files = verified analysis output).
Usage: python3 audit.py [section files...]   (default: sections/*.md)"""
import glob
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.dirname(HERE)
OUT = os.environ.get("HS_OUT", os.path.join(SCR, "out"))


def norm(s):
    return re.sub(r"(?<=\d),(?=\d)", "", s)


corpus = ""
for f in sorted(glob.glob(os.path.join(OUT, "*.md")) + glob.glob(os.path.join(OUT, "*.json")) + glob.glob(os.path.join(OUT, "*.tsv")) + glob.glob(os.path.join(OUT, "*.txt")) + [os.path.join(HERE, "extra.json")]):
    corpus += open(f, encoding="utf-8", errors="replace").read() + "\n"
for r in ("main", "main_2", "main_3", "main_4"):
    n = subprocess.run(["wc", "-l", os.path.join(os.environ.get("HS_LOGDIR", "."), f"{r}.log")], capture_output=True, text=True).stdout.split()[0]
    corpus += f"{n} lines\n"
corpus = norm(corpus)
NUM = re.compile(r"(?<![\w.])(\d[\d,]*(?:\.\d+)?)(?![\w])")


def check(path):
    txt = open(path, encoding="utf-8").read()
    txt = re.sub(r"```.*?```", "", txt, flags=re.S)          # code blocks are verified by running them
    flagged = {}
    for ln_no, line in enumerate(txt.split("\n"), 1):
        for m in NUM.finditer(line):
            tok = norm(m.group(1))
            if len(tok) <= 1:
                continue
            if re.search(r"(?<![\d.])" + re.escape(tok) + r"(?![\d])", corpus):
                continue
            flagged.setdefault(tok, []).append(ln_no)
    return flagged


def main():
    files = sys.argv[1:] or sorted(glob.glob(os.path.join(HERE, "sections", "*.md")))
    for p in files:
        fl = check(p)
        print(f"== {os.path.basename(p)}: {len(fl)} numbers not in any result file")
        for tok, lns in sorted(fl.items(), key=lambda kv: kv[1][0]):
            print(f"   {tok:<10} lines {lns[:6]}")


if __name__ == "__main__":
    main()
