#!/usr/bin/env python3
"""build.py - assemble the report from the verified result files.
Writes report/sections/NN_slug.md (one file per document section), report/report_full.md (the whole report) and the two tab files.
Usage: python3 build.py"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import sec_front, sec_p1, sec_p2, sec_p3, sec_p4, sec_end   # noqa: E402

SECTIONS = [
    ("glance", sec_front.sec_glance),
    ("conventions", sec_front.sec_conventions),
    ("p1_counts", sec_p1.sec_counts),
    ("p1_compare", sec_p1.sec_compare),
    ("p1_views", sec_p1.sec_views),
    ("p1_verify", sec_p1.sec_verify),
    ("p2_answers", sec_p2.sec_p2_answers),
    ("p2_order", sec_p2.sec_p2_order),
    ("p2_processed", sec_p2.sec_p2_processed),
    ("p2_verify", sec_p2.sec_p2_verify),
    ("p3_views", sec_p3.sec_p3_views),
    ("p3_same", sec_p3.sec_p3_same),
    ("p3_timeout", sec_p3.sec_p3_timeout),
    ("p3_progress", sec_p3.sec_p3_progress),
    ("p3_votes", sec_p3.sec_p3_votes),
    ("p3_proposer", sec_p3.sec_p3_proposer),
    ("p3_verify", sec_p3.sec_p3_verify),
    ("p4_chain", sec_p4.sec_p4_chain),
    ("p4_breaks", sec_p4.sec_p4_breaks),
    ("p4_commit", sec_p4.sec_p4_commit),
    ("p4_verify", sec_p4.sec_p4_verify),
    ("caveats", sec_end.sec_caveats),
    ("summary", sec_end.sec_summary),
]
TITLE = "HotStuff Four-Run Log Analysis"


def main():
    sd = os.path.join(HERE, "sections")
    os.makedirs(sd, exist_ok=True)
    parts = [f"# {TITLE}\n", sec_front.LEAD + "\n"]
    stats = []
    for i, (slug, fn) in enumerate(SECTIONS, 1):
        txt = fn().rstrip() + "\n"
        with open(os.path.join(sd, f"{i:02d}_{slug}.md"), "w", encoding="utf-8") as f:
            f.write(txt)
        parts.append(txt)
        stats.append((i, slug, len(txt), txt.splitlines()[0]))
    with open(os.path.join(HERE, "report_full.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(parts))
    for name, fn in (("tab_excerpts", sec_end.tab_excerpts), ("tab_evidence", sec_end.tab_evidence)):
        with open(os.path.join(HERE, f"{name}.md"), "w", encoding="utf-8") as f:
            f.write(fn())
    tot = 0
    for i, slug, n, head in stats:
        tot += n
        print(f"{i:02d} {slug:<13} {n:>7} chars  {head}")
    print("total", tot, "chars")


if __name__ == "__main__":
    main()
