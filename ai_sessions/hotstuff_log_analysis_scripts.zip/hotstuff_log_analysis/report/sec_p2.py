"""Part 2 sections: replica behaviour, vote order (first / last), processed order, proposal reception, unusual behaviour."""
import re
import lib
from lib import RUNS, tbl, custom, render


def participation_table():
    rows = []
    for run in RUNS:
        t = lib.pick(lib.find_table("part2.md", rf"^\*\*{run}\*\*  \(blocks"), cols=[0, 1, 2, 6, 8, 9, 10])
        for r in t[2]:
            rows.append([f"{run} · {r[0]}"] + r[1:])
    return custom(["Run · replica", "Proposals authored", "'Received proposal' lines", "Votes sent (seen at the collectors)", "Votes collected (as receiver)",
                   "QCs formed", "'block too old' logged"], rows)


def answers_table():
    rows = [
        ["1", "Do all replicas participate similarly in proposal reception and vote collection?",
         "Yes. Each replica authored a quarter of the proposals (922 / 922 / 922 / 922 in main), logged 100% of the proposals of the others (main_2: 99.88% for hs1, hs3, hs4), sent about one vote per block (1.00-1.01) and formed the QCs of its own collector turns. All 24 chi-square tests against equal shares give p >= 0.386."],
        ["2", "Is there a recurring order in which votes are received or processed?",
         "Yes. Received: the collector (the receiver of the votes) is first in 100% of 11,978 complete sequences and the proposer second in 99.12% (11,873). Processed: the QC lists the first three received votes in the same order in 6,683 of 11,969 QCs (55.8%), the same three in another order in 2,070 (17.3%), and contains the 4th received vote in 3,216 (26.9%)."],
        ["3", "Does any replica appear more frequently in the first or last position?",
         "First: no, 25.0% each; the first place belongs to the collector role, which rotates. Last: 25.7 / 25.1 / 25.0 / 24.2% for hs1-hs4, chi-square p = 0.15 (per run p = 0.048 / 0.62 / 0.97 / 0.23; only main touches 0.05)."],
        ["4", "Is any replica consistently first or last across complete vote sequences?",
         "No. The last place is shared by the two replicas that are neither collector nor proposer: per collector each candidate is last 46-54% of the time in a run and 48.1-51.9% pooled (p = 0.04-0.34; the single p = 0.04, hs3, is not significant after four comparisons)."],
        ["5", "Does the ordering differ between executions?",
         "The structure does not (same roles, same shares in every run; per-collector split homogeneous across runs, p = 0.29-0.76). The exact order of one view does not repeat: two runs agree on the last sender of the same view in 48.0-52.7% of views (chance 50%), all four in 13.3% (chance 12.5%, p = 0.45)."],
        ["6", "Differences that could indicate unusual replica behaviour?",
         "None at replica level. At event level: 105 complete sequences (0.88%) where the proposer is not second (main_2 2.20%), 7 incomplete sequences, 84 sequences with a duplicate vote line from the cache-miss path, and main_2's fork, fetch and prune events (below)."],
    ]
    return custom(["#", "Question", "Answer"], rows, [":---", ":---", ":---"])


def sec_p2_answers():
    return f"""## Part 2 · Replica behaviour: answers and participation

The four replicas behave alike. The vote order is fixed by roles: the collector is first, the proposer second, and the last two places are a coin flip.

{answers_table()}

**Participation** per run and replica (all phases). Votes sent are the `CollectVote(from k)` lines for sender k seen at all collectors; votes collected are the `CollectVote` lines logged by replica k as receiver:

{participation_table()}

Within each run the four replicas are statistically indistinguishable (chi-square against equal shares: authored, received, sent, collected, QCs formed and 'block too old' logged, 24 tests, smallest p = 0.386).

**How many vote sequences are complete.** A complete sequence is exactly four `CollectVote` lines from four distinct senders for one block at one collector. These 11,978 sequences carry the first / last statistics below.

{tbl("part2.md", r"^## 2B\.")}

The missing sender of the 7 incomplete sequences is hs1 in main (2 times) and main_3 (1), and hs1 / hs3 / hs4 in main_2 (1 / 2 / 1). A 'duplicate' sequence has a second line from one sender: after `Local cache miss for block`, the collector fetches the block and processes the vote again.
"""


def d_table():
    rows = []
    scopes = [("main", r"^\*\*main\*\*  \(3660"), ("main_2", r"^\*\*main_2\*\*  \(1090"), ("main_3", r"^\*\*main_3\*\*  \(3585"),
              ("main_4", r"^\*\*main_4\*\*  \(3643"), ("combined", r"^\*\*combined\*\*  \(11978")]
    for name, anchor in scopes:
        t = find = lib.find_table("part2.md", anchor)
        for r in t[2]:
            label = r[0]
            m = re.match(r"all receivers \((\d+)\)", label)
            if m:
                label = f"all receivers ({int(m.group(1)):,})"
            rows.append([f"{name} · {label}", r[1], r[2]])
    return custom(["Run · receiver (complete sequences)", "FIRST, % of sequences, sender hs1 / hs2 / hs3 / hs4", "LAST, % of sequences, sender hs1 / hs2 / hs3 / hs4"], rows)


def sec_p2_order():
    structure = tbl("part2.md", r"^## 2C\.", n=0)
    tail_comb = tbl("part2.md", r"^Combined over the four runs", n=0, cols=[0, 1, 2, 3, 4, 5],
                    rename={"collector": "Collector (receiver)", "last = lower-ID cand / higher-ID cand": "Last place: lower-ID / higher-ID candidate",
                            "share higher-ID cand last": "Higher-ID candidate last", "p (binomial vs 50%)": "p (binomial vs 50%)",
                            "chi2 across runs": "chi2 across runs (df 3)", "p (across runs)": "p (across runs)"})
    pos = tbl("part2.md", r"^### 2D-2\.", n=0, rows=[16, 17, 18, 19])
    pooled = tbl("part2.md", r"^Pooled over all receivers", n=0)
    return f"""## Part 2 · Vote order: who is first and who is last

The collector is always first and the proposer almost always second, so only the last two places are open, and they split evenly.

**Structure of the received order** in complete sequences (each sequence reads collector, proposer, X, Y):

{structure}

The proposer is second in 99.12% of the sequences; in the 105 others it is third (57) or fourth (48), never first.

**The open places.** X and Y are the two replicas that are neither collector nor proposer. For each collector, the share of sequences in which the higher-ID candidate is last (combined over the four runs):

{tail_comb}

Per run (16 collector-run cells) each candidate is last in 46.7-53.3% of the sequences. Three of the 32 tests (16 binomial tests, 16 runs tests for alternation) fall below 0.05: hs1 in main_4 (binomial, p = 0.0497), hs2 in main (runs, p = 0.024) and hs4 in main_2 (runs, p = 0.046); about 1.6 are expected by chance. The per-run table is in the 'Evidence tables' tab.

**First and last place per replica, receiver against sender** (all complete sequences). Rows are the receiving replica (the collector); the columns give how often each sending replica is first or last in that receiver's sequences:

{d_table()}

Reading the table: in the receiver's own row the receiver is first in 100% of its sequences, so the 'all receivers' row of the FIRST column is 25% each by construction of the rotation. In the LAST column the receiver itself is never last (0.0%), the proposer is last in 0.3-0.5% pooled (up to 1.8% in one run), and the two remaining senders share the place at 46.4-53.4% each.

**Position of each sender's vote pooled over all receivers** (combined, % of complete sequences):

{pos}

**Is a replica last more often than 25%?** Chi-square test of the pooled last place against 25% each (df = 3):

{pooled}

Only main reaches p = 0.048. hs1 is the most frequent last voter in main (26.4%), main_2 (26.1%) and pooled (25.7%), but the effect is under one percentage point and the combined test gives p = 0.15.
"""


def sec_p2_processed():
    e1 = tbl("part2.md", r"^## 2E\.", n=0, cols=[0, 1, 2, 3, 4, 5],
             rename={"scope": "Scope", "complete sequences whose QC is printed in a later block": "QCs analysed",
                     "QC.IDs == first three received (same order)": "QC.IDs = first three received, same order",
                     "same three replicas, different order": "same three, other order",
                     "4th received vote is inside QC.IDs": "4th received vote is in the QC",
                     "excluded replica was received 1st/2nd/3rd/4th": "replica left out was received 1st / 2nd / 3rd / 4th"})
    e2 = tbl("part2.md", r"^## 2E\.", n=1, rows=[16, 17, 18, 19])
    f = lib.find_table("part2.md", r"^Role summary", n=0)
    roles = {}
    for sc, role, first, last in f[2]:
        roles.setdefault(sc, {})[role] = (first, last)
    rows = []
    for sc in ["main", "main_2", "main_3", "main_4", "combined"]:
        d = roles[sc]
        rows.append([sc] + [f"{d[k][0]} / {d[k][1]}" for k in ("next leader (collector)", "previous leader", "other")])
    f_tbl = custom(["Run", "Next leader (collector): first / last", "Previous leader: first / last", "Other replica: first / last"], rows)
    g = tbl("part2.md", r"^## 2G\.", n=0)
    g2 = tbl("part2.md", r"^Complete sequences in which the proposer is NOT", n=0)
    return f"""## Part 2 · Processed order, proposal reception and unusual behaviour

A vote that is received earlier is not always processed earlier: in 27% of the QCs one of the first three received votes was left out.

**Received order against processed order.** `QC.IDs` lists the voters in the order their verified votes entered the QC; a `CollectVote` line only shows that the vote arrived, and the vote still has to be verified. For each complete sequence whose QC is printed in a later block:

{e1}

The collector's own vote is the first entry of QC.IDs in 11,394 of 11,969 QCs (95.2%). The replica left out of the QC was received 4th in 73% of the cases (8,753) and 1st, 2nd or 3rd in 27% (3,216). Which replica is left out, by collector (combined, % of that collector's QCs):

{e2}

The proposer (the replica before the collector in the rotation) is left out only 8% of the time because its vote is second in the received order; the two other replicas share the exclusion (44-47% each).

**Proposal reception order.** Three replicas receive each proposal. Share of blocks in which the receiver of that role logged `Received proposal` first / last (one third would be neutral):

{f_tbl}

The roles are not neutral: the next leader logs a proposal last in about 38% of the blocks and first in about 18%, the previous leader the reverse. The pattern is the same in all four runs (next leader first 17.3-24.3%), so it is structural; the log does not show its cause.

**Replica-level counters** that could point to an unusual replica (all phases, hs1 / hs2 / hs3 / hs4):

{g}

main_2 stands out through fork handling: forked blocks pruned 5 / 7 / 7 / 4, block fetches 3 / 3 / 4 / 2 and block requests served 6 / 8 / 5 / 4, plus 13 proposals rejected as too old; main_3 has forked blocks too (19) but almost no fetches. No single replica is responsible: every counter is spread over hs1-hs4.

**Complete sequences where the proposer is not second:**

{g2}
"""


def sec_p2_verify():
    return r"""## Part 2 · Verification commands

The first one-liner reproduces the complete-sequence count, the collector-first count and the last-place counts per sender of the tables above from the raw logs (awk only):

```bash
for f in main main_2 main_3 main_4; do
  awk -F'\t' '$3 ~ /^hs[1-4]$/ && $5 ~ /^CollectVote\(from [0-9]+\): / {
    s=$5; sub(/^CollectVote\(from /,"",s); sub(/\).*/,"",s); h=$5; sub(/^.*: /,"",h)
    k=$3 SUBSEP h; n[k]++; seq[k]=seq[k] " " s }
  END { for (k in n) if (n[k]==4) { split(seq[k],a," "); d=0
          for (i=2;i<=4;i++) for (j=1;j<i;j++) if (a[i]==a[j]) d=1
          if (!d) { split(k,kk,SUBSEP); tot++; if ("hs" a[1]==kk[1]) cf++; last[a[4]]++ } }
        printf "%s: complete=%d collector-first=%d last hs1/hs2/hs3/hs4=%d/%d/%d/%d\n", FILENAME, tot, cf, last[1], last[2], last[3], last[4] }' $f.log
done
# main.log:   complete=3660 collector-first=3660 last=968/880/945/867
# main_2.log: complete=1090 collector-first=1090 last=284/261/283/262
# main_3.log: complete=3585 collector-first=3585 last=904/904/890/887
# main_4.log: complete=3643 collector-first=3643 last=924/956/877/886
```

One block by hand (view 1000 of main, shown with all its chain lines in Part 4): the four votes in log order, collector hs2 first, proposer hs1 second:

```bash
awk -F'\t' -v h=qXCyTpwu '$5 ~ ("^CollectVote\\(from [0-9]+\\): " h "$") { print NR, $3, $5 }' main.log
# 54892 hs2 CollectVote(from 2): qXCyTpwu
# 54895 hs2 CollectVote(from 1): qXCyTpwu
# 54898 hs2 CollectVote(from 4): qXCyTpwu
# 54907 hs2 CollectVote(from 3): qXCyTpwu
```

The shipped `verify_votes.sh` (awk only) recomputes all of Part 2 (first / last, positions, processed order, proposal reception); `compare_votes.py` compares it with the Python results: 581 metrics compared, 0 mismatches.
"""
