# HotStuff Four-Run Log Analysis

main, main_3 and main_4 share the same steady-state behaviour; main_2 is the outlier. The three run at about 365 proposals/s with the same progress counters per view and time out in 1.7% of views. main_2 runs at 112 proposals/s, stalls for 4.9 s around views 896-925 and logs 3.5-8x more timeout and sync-info events per view. In all four runs the expected chain (proposal, QC, HighQC and view advance, next proposal) holds in 99.1-100% of views, and every exception is a timeout racing the QC.

## At a glance

Throughput and the timeout counters separate main_2 from the other runs, while the protocol counters per view do not.

|  | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| Recorded on | 2026-06-22 | 2026-07-31 | 2026-09-13 | 2026-09-13 |
| Views with a proposal | 3,688 | 1,119 | 3,603 | 3,659 |
| Proposals per second (10 s of client load) | 368.6 | 111.6 | 360.1 | 365.6 |
| Client commands executed / timed out | 3,682 / 0 | 1,045 / 60 | 3,592 / 0 | 3,653 / 0 |
| Views with at least one local timeout (active phase) | 63 (1.7%) | 40 (3.6%) | 60 (1.7%) | 61 (1.7%) |
| View advances caused by a timeout certificate (active phase) | 13 | 67 | 36 | 8 |
| 'block too old' lines per 1,000 views | 265 | 358 | 271 | 246 |
| 'Failed to verify sync info' lines | 5 | 17 | 10 | 10 |
| EXEC lines per replica | 3,685 | 1,108 | 3,595 | 3,656 |
| Views with the complete ordered chain (class N, Part 4) | 100.00% | 99.10% | 99.86% | 100.00% |

- **Counts (Part 1).** Per proposed view, HighQC updates, view advances and TryCommit lines are within 1% of 4.00 in all four runs (p >= 0.99 across main, main_3 and main_4). Timeout counters are equal in main and main_4, about twice as high for timeout certificates in main_3 (14.7 against 7.1 and 7.4 per 1,000 views, p = 0.0009) and 3.5-8x higher in main_2.
- **Vote order (Part 2).** In 11,978 complete vote sequences the collector is first in 100% and the proposer second in 99.12%; the last two places are a coin flip (each replica is last 24.2-25.7%, p = 0.15). No replica is consistently first or last, and the order of the same view does not repeat across runs.
- **Views (Part 3).** 1,119 views occur in all four runs. Their core event counts are identical in 95.4%. Only view 3 has timeout events in all four runs. Matching by (view, proposer) gives exactly the same result as matching by view, because the proposer is a function of the view.
- **Ordering (Part 4).** The chain proposal, attached QC, HighQC and advance, vote, QC, next proposal holds in 3,684 of 3,684 / 1,104 of 1,114 / 3,594 of 3,599 / 3,654 of 3,654 tested views. Each of the 10 + 5 exceptions is a timeout that beat the QC, and each leaves one block whose parent is not the previous view.
- **Commit rule.** Of all TryCommit lines with a complete three-chain, the 44 (main_2) and 40 (main_3) without a DECIDE are exactly those whose chain spans non-consecutive views; no rule violation in any run.
- **Drain phase.** In main, main_3 and main_4 about half of the local-timeout lines (96 of 190, 93 of 199, 104 of 194) fall in the 2.5 s after the clients stop, when leaders cannot build proposals ('no command batch': 28 / 6 / 27 / 28 lines). main_2 has only 15 of 118 there.

## Logs and conventions

The four logs use one configuration and one line format, so counts can be compared directly once they are normalised by view progression.

- **Files.** main.log (204,450 lines), main_2.log (63,935), main_3.log (200,004), main_4.log (202,887). The configuration banner is identical: 4 replicas, 1 client, chainedhotstuff, ecdsa, round-robin leaders, clique communication, batch size 1, 10 s of client load, ViewTimeout 500 ms.
- **Line format.** `timestamp<TAB>level<TAB>logger<TAB>source-file:line<TAB>message`. The loggers hs1-hs4 are the replicas, ctrl is the controller and cli1 the client; all four replicas write to the same file, interleaved.
- **Phases.** Active phase = lines before the first `Stopping clients...` line (ctrl, controller.go:109): line 201,864 / 63,334 / 197,476 / 200,122. Drain phase = the 2.5 s after it, while the replicas finish.
- **Protocol facts visible in the logs.** n = 4 and the quorum is 3. The leader of view v is replica (v mod 4) + 1 (0 exceptions in 3,688 views). A vote for block B_v goes to the leader of v+1, called the collector here. Only the three non-proposers log `Received proposal`. The vote itself is not logged; the collector's `CollectVote(from N): <hash>` line is its receipt. `TryCommit: Block{...}` is logged when a replica accepts a proposal, and the replica's vote follows.
- **Ordering.** Event order means physical line order within a file. Timestamps have 1 ms resolution and show inversions of up to 3 ms between loggers, so they are used only for durations.
- **Timer length.** The banner says ViewTimeout 500 ms, yet local timeouts fire a median 7 ms after the replica entered the view in main, main_3 and main_4 (57 ms in main_2). The log does not print the timer value, so the effective timer is not the configured 500 ms.
- **Statistics.** p-values come from chi-square, binomial, Fisher, hypergeometric and runs tests that assume independent events. Timeouts and late votes are clustered, so treat p-values as a rough guide, not as proof.

## Part 1 · Exact patterns and counts per run

Each pattern was counted with `grep -E` on the raw files; a cell shows the total, then (active phase / drain phase).

| Event | Exact pattern (grep -E) | main | main_2 | main_3 | main_4 |
| :--- | :--- | ---: | ---: | ---: | ---: |
| block too old | `block too old` | 979 (978 / 1) | 402 (400 / 2) | 977 (976 / 1) | 901 (900 / 1) |
| ... proposal rejected as too old (a different line) | `too old, last voted view was` | 1 (1 / 0) | 13 (13 / 0) | 2 (2 / 0) | 0 (0 / 0) |
| Failed to verify sync info | `Failed to verify sync info` | 5 (5 / 0) | 17 (17 / 0) | 10 (10 / 0) | 10 (10 / 0) |
| ... timeout certificate, ecdsa | `Failed to verify sync info: failed to verify timeout certificate: ecdsa: failed to verify signature from replica` | 5 (5 / 0) | 16 (16 / 0) | 10 (10 / 0) | 10 (10 / 0) |
| ... quorum certificate, block not found | `Failed to verify sync info: failed to verify quorum certificate: block not found` | 0 (0 / 0) | 1 (1 / 0) | 0 (0 / 0) | 0 (0 / 0) |
| OnLocalTimeout (both line forms) | `OnLocalTimeout` | 382 (190 / 192) | 280 (249 / 31) | 405 (218 / 187) | 390 (181 / 209) |
| ... line without a view (timer fired) | `OnLocalTimeout$` | 192 (96 / 96) | 162 (146 / 16) | 206 (112 / 94) | 196 (91 / 105) |
| ... line with the view (timeout of view V) | `OnLocalTimeout: [0-9]+$` | 190 (94 / 96) | 118 (103 / 15) | 199 (106 / 93) | 194 (90 / 104) |
| ... Stopped voting for timed out view | `Stopped voting for timed out view` | 93 (0 / 93) | 29 (14 / 15) | 92 (2 / 90) | 101 (0 / 101) |
| OnRemoteTimeout (all forms) | `OnRemoteTimeout` | 1,524 (756 / 768) | 1,203 (1,077 / 126) | 1,624 (874 / 750) | 1,563 (725 / 838) |
| ... advancing view (timeout message received) | `OnRemoteTimeout \(advancing view\)` | 766 (382 / 384) | 602 (539 / 63) | 816 (441 / 375) | 782 (363 / 419) |
| ... second advance (TC formed) | `OnRemoteTimeout \(second advance\)` | 137 (26 / 111) | 110 (90 / 20) | 160 (53 / 107) | 138 (27 / 111) |
| not enough timeouts | `not enough timeouts` | 621 (348 / 273) | 491 (448 / 43) | 648 (380 / 268) | 643 (335 / 308) |
| Failed to create sync info (overlapping signatures) | `Failed to create sync info` | 8 (8 / 0) | 1 (1 / 0) | 8 (8 / 0) | 1 (1 / 0) |
| HighQC updated | `advanceView: Successfully updated HighQC` | 14,751 (14,737 / 14) | 4,448 (4,432 / 16) | 14,396 (14,381 / 15) | 14,635 (14,620 / 15) |
| HighQC not updated | `advanceView: HighQC not updated` | 12,045 (11,460 / 585) | 4,089 (3,980 / 109) | 11,868 (11,299 / 569) | 11,970 (11,350 / 620) |
| View advancement | `advanceView: Advanced to view` | 14,860 (14,738 / 122) | 4,496 (4,460 / 36) | 14,516 (14,397 / 119) | 14,744 (14,621 / 123) |
| ... advanceView calls | `advanceView: \{` | 26,801 (26,204 / 597) | 8,554 (8,429 / 125) | 26,274 (25,690 / 584) | 26,615 (25,980 / 635) |
| ... OnNewView | `OnNewView` | 14,833 (14,737 / 96) | 4,485 (4,452 / 33) | 14,489 (14,396 / 93) | 14,717 (14,621 / 96) |
| TryCommit | `TryCommit:` | 14,751 (14,740 / 11) | 4,460 (4,448 / 12) | 14,410 (14,399 / 11) | 14,636 (14,624 / 12) |
| Commit rule PRE_COMMIT | `CommitRule - PRE_COMMIT` | 14,751 (14,740 / 11) | 4,460 (4,448 / 12) | 14,410 (14,399 / 11) | 14,636 (14,624 / 12) |
| Commit rule COMMIT | `CommitRule - COMMIT` | 14,743 (14,732 / 11) | 4,434 (4,422 / 12) | 14,384 (14,373 / 11) | 14,628 (14,616 / 12) |
| Commit rule DECIDE | `CommitRule - DECIDE` | 14,743 (14,732 / 11) | 4,408 (4,396 / 12) | 14,362 (14,351 / 11) | 14,628 (14,616 / 12) |
| EXEC | `EXEC:` | 14,740 (14,729 / 11) | 4,432 (4,420 / 12) | 14,380 (14,369 / 11) | 14,624 (14,612 / 12) |
| Received proposal | `Received proposal` | 11,065 (11,059 / 6) | 3,357 (3,348 / 9) | 10,809 (10,800 / 9) | 10,978 (10,969 / 9) |
| Vote received at the collector | `CollectVote\(from` | 14,787 (14,775 / 12) | 4,502 (4,489 / 13) | 14,436 (14,424 / 12) | 14,659 (14,647 / 12) |
| QC formed (dispatch) | `CollectVote: dispatching event for new view` | 3,688 (3,685 / 3) | 1,114 (1,110 / 4) | 3,602 (3,599 / 3) | 3,659 (3,656 / 3) |

Raw lines behind the patterns (first hit in the named file; file:line, logger, source location, message):

```
main.log:138     hs4  votingmachine.go:80  block too old
main.log:21980   hs1  synchronizer.go:119  failed to verify incoming vote: block view 397 too old, last voted view was 398
main_2.log:358     hs2  synchronizer.go:255  advanceView: Failed to verify sync info: failed to verify timeout certificate: ecdsa: failed to verify signature from  ...
main_2.log:52003   hs1  synchronizer.go:255  advanceView: Failed to verify sync info: failed to verify quorum certificate: block not found: DegHnHMmfTLDmP0cNBx8rOA ...
main.log:139     hs4  synchronizer.go:183  OnLocalTimeout
main.log:140     hs4  synchronizer.go:191  OnLocalTimeout: 3
main.log:202091  hs2  synchronizer.go:201  Stopped voting for timed out view 3689
main.log:147     hs4  synchronizer.go:217  OnRemoteTimeout (advancing view): ID: 4, View: 3, SyncInfo: { TC{ view: 0, IDs: [ ] } QC{ hash: QczDi94T, view: 2, IDs ...
main.log:150     hs4  synchronizer.go:222  OnRemoteTimeout: not enough timeouts for view 3, waiting for more
main.log:2362    hs4  synchronizer.go:235  OnRemoteTimeout (second advance)
main.log:2354    hs3  synchronizer.go:230  Failed to create sync info: failed to create timeout certificate: overlapping signatures
main.log:94      hs3  synchronizer.go:263  advanceView: Successfully updated HighQC
main.log:68      hs4  synchronizer.go:265  advanceView: HighQC not updated, current view: 1, new view: 0
main.log:54857   hs1  synchronizer.go:290  advanceView: Advanced to view 1000
main.log:54858   hs1  committer.go:45      TryCommit: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: ...
main.log:54913   hs2  chainedhotstuff.go:56 CommitRule - PRE_COMMIT: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, v ...
main.log:54968   hs3  chainedhotstuff.go:64 CommitRule - COMMIT: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: ...
main.log:55017   hs4  chainedhotstuff.go:79 CommitRule - DECIDE: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: ...
main.log:55018   hs4  committer.go:89      EXEC: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1  ...
```

Exact arithmetic between the counts, which also shows what each line means:

- **Outcome of a timeout message.** Every `OnRemoteTimeout (advancing view)` line ends in exactly one of: not enough timeouts, TC formed (second advance), or Failed to create sync info. 766 = 621 + 137 + 8 (main), 602 = 491 + 110 + 1 (main_2), 816 = 648 + 160 + 8 (main_3), 782 = 643 + 138 + 1 (main_4). The substring total follows: 1,524 = 766 + 621 + 137 in main, and likewise in the other runs.
- **Delivery of a timeout.** Each `OnLocalTimeout: V` line is delivered as 4 `advancing view` lines (one per replica, the sender included) and each repeated timer expiry in the same view as 3 more: 4 x 190 + 3 x 2 = 766 (main, exact), 4 x 118 + 3 x 44 = 604 against 602 (main_2), 4 x 199 + 3 x 7 = 817 against 816 (main_3), 4 x 194 + 3 x 2 = 782 (main_4, exact). In main (active phase) the match holds per sender: 92 / 96 / 92 / 102 deliveries from hs1-hs4 against 23 / 24 / 23 / 24 timeouts and 0 / 0 / 0 / 2 repeats.
- **Two OnLocalTimeout lines.** The line without a view (synchronizer.go:183) is the timer firing; the line with the view (:191) is a new timeout of view V. Every bare line that is not followed by a `: V` line (2 / 44 / 7 / 2, all of them) occurs while the replica is still in a view it already timed out in: a repeated expiry.
- **Stopped voting.** `Stopped voting for timed out view V` appears exactly when a replica times out in V before it has voted in V: all 93 / 29 / 92 / 101 lines, and every timeout of a replica that had not voted has one. In the active phase this happens 0 / 14 / 2 / 0 times; the other active timeouts (94 / 89 / 104 / 90) come after the replica's vote.

## Part 1 · Comparison and verdict per event

Per 1,000 proposed views (active phase) the progress counters agree across runs (within 1.6%), while the timeout-related counters separate main_2 from the rest.

| Active phase, per 1,000 proposed views | main | main_2 | main_3 | main_4 | p, main / main_3 / main_4 | p, all four |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| block too old | 265.3 | 358.4 | 271.0 | 246.2 | 0.094 | 9e-09 |
| 'too old, last voted view was' (proposal rejected) | 0.3 | 11.6 | 0.6 | 0.0 | 0.36 | < 1e-10 |
| Failed to verify sync info | 1.4 | 15.2 | 2.8 | 2.7 | 0.35 | < 1e-10 |
| OnLocalTimeout: V | 25.5 | 92.3 | 29.4 | 24.6 | 0.41 | < 1e-10 |
| OnLocalTimeout (line without a view) | 26.0 | 130.8 | 31.1 | 24.9 | 0.24 | < 1e-10 |
| OnRemoteTimeout (advancing view) | 103.6 | 483.0 | 122.5 | 99.3 | 0.0063 | < 1e-10 |
| OnRemoteTimeout (second advance) | 7.1 | 80.6 | 14.7 | 7.4 | 0.00089 | < 1e-10 |
| not enough timeouts | 94.4 | 401.4 | 105.5 | 91.6 | 0.13 | < 1e-10 |
| HighQC updated | 3,998.1 | 3,971.3 | 3,993.6 | 3,998.9 | 0.99 | 0.98 |
| HighQC not updated | 3,109.1 | 3,566.3 | 3,137.7 | 3,104.5 | 0.69 | < 1e-10 |
| Advanced to view | 3,998.4 | 3,996.4 | 3,998.1 | 3,999.2 | 1 | 1 |
| CommitRule PRE_COMMIT (= TryCommit) | 3,998.9 | 3,985.7 | 3,998.6 | 4,000.0 | 1 | 1 |
| CommitRule COMMIT | 3,996.7 | 3,962.4 | 3,991.4 | 3,997.8 | 0.99 | 0.96 |
| CommitRule DECIDE | 3,996.7 | 3,939.1 | 3,985.3 | 3,997.8 | 0.96 | 0.84 |
| EXEC | 3,995.9 | 3,960.6 | 3,990.3 | 3,996.7 | 0.99 | 0.96 |
| Local cache miss for block | 10.0 | 37.6 | 7.5 | 6.3 | 0.18 | < 1e-10 |

The p-values are chi-square homogeneity tests on counts (they assume independent events; timeouts are clustered, so read them as a guide).

- **Similar in all four runs:** HighQC updates, view advances, TryCommit, COMMIT, DECIDE and EXEC per view (about 4.00 per view, within 1.6%); the structure of each view (3 receivers plus 1 collector update their HighQC; 4 timeout deliveries per timeout).
- **Similar in main, main_3 and main_4:** local timeouts (25-29 per 1,000 views, p = 0.41), not enough timeouts (p = 0.13), sync-info failures (p = 0.35) and late votes (p = 0.094).
- **Different:** main_2 has 3.5-8x the timeout events and 6.7x the sync-info failures per view, 36% more late votes and a third of the proposal rate; main_3 forms about twice as many timeout certificates as main and main_4.

Verdict per event (the first two columns are the comparison, the last one is the judgement):

| Event | Per 1,000 views: main / main_2 / main_3 / main_4 | Is the difference meaningful, and why |
| :--- | :--- | :--- |
| block too old | 265 / 358 / 271 / 246 | A harmless race, not a fault: the 4th vote reaches the collector after the QC was dispatched. Every line directly follows that vote's CollectVote line (979 of 979, 977 of 977, 901 of 901; main_2: 400 of 402, the other 2 follow `Successfully fetched block`), and the voter is outside the QC in 979 / 398 / 975 / 900 cases. The late voter is spread over all replicas (main 258 / 237 / 263 / 221). Only main_2's higher share is a real difference (36.1% of QCs against 24.6-27.1%); it also exists outside its stall (358 per 1,000 views), and the log does not show why. |
| Failed to verify sync info | 1.4 / 15.2 / 2.8 / 2.7 | Meaningful for main_2 (6.7x per view; 11 of its 17 lines fall inside the stall). main, main_3 and main_4 share a low background rate (p = 0.35). Exact association: all 5 / 16 / 10 / 10 ecdsa failures are TCs assembled from timeout messages of mixed views; none of the 132 / 94 / 150 / 128 consistent TCs failed. |
| OnLocalTimeout: V | 25.5 / 92.3 / 29.4 / 24.6 | Meaningful for main_2 (3.5x): 80 of its 103 active timeouts lie in the 30-view stall, and outside it the rate is 21 per 1,000 views, like the others. main, main_3, main_4 agree (p = 0.41): about 1.7% of views have a timeout. Most timeouts fire after the replica has voted (94 / 89 / 104 / 90 of 94 / 103 / 106 / 90), so they do not prevent the QC. |
| OnRemoteTimeout | advancing 103.6 / 483 / 122.5 / 99.3; second advance 7.1 / 80.6 / 14.7 / 7.4 | Derived from the local timeouts (4 deliveries per timeout), so it adds no independent signal, except the TC step: main_3 forms about twice as many TCs per view as main and main_4 (p = 0.0009; 35 of its 53 active TCs fall in seconds 7-8) and main_2 about 8x. |
| not enough timeouts | 94 / 401 / 106 / 92 | Derived: it is the outcome of every timeout message that does not complete a quorum (621 = 766 - 137 - 8 in main). It follows the local-timeout rate; p = 0.13 for main, main_3, main_4. |
| HighQC updated | 3,998 / 3,971 / 3,994 / 3,999 | No difference. 4 per view = 3 receivers (attached QC) + 1 collector (its own QC): 11,060 + 3,688 + 3 = 14,751 in main. |
| HighQC not updated | 3,109 / 3,566 / 3,138 / 3,105 | The baseline is identical (about 3.0 per view are OnNewView messages repeating a known QC: 3,022 / 3,012 / 3,021 / 3,022 per 1,000 views, all phases). main_2's excess is timeout traffic: 609 sync infos from remote timeouts per 1,000 views against 243 / 267 / 248. |
| Advanced to view | 3,998 / 3,996 / 3,998 / 3,999 | No difference in count: about four advances per view, always +1 (14,856 / 4,492 / 14,512 / 14,740 steps, no jump, no backward step). What differs is the cause: timeout certificates drive 13 / 67 / 36 / 8 active-phase advances (0.09% / 1.5% / 0.25% / 0.05%). |
| TryCommit, COMMIT, DECIDE, EXEC | TryCommit 3,999 / 3,986 / 3,999 / 4,000; DECIDE 3,997 / 3,939 / 3,985 / 3,998 | Equal in main and main_4. main_2 and main_3 are lower in COMMIT, DECIDE and EXEC only, exactly by the TryCommit lines whose three-chain spans non-consecutive views (44 and 40 lines, Part 4). All counts obey the commit rules (0 violations). |

**main_2 inside and outside its stall.** main_2 needed 4.9 s for views 896-925 (view 896 was first entered 3,680 ms after the clients started, view 926 at 8,593 ms): about 164 ms per view against 3 ms normally. In the same period 60 client commands timed out (500 ms client timeout; first at 4,169 ms, last at 9,092 ms). Most of its excess timeout traffic sits in these 30 views:

| Active phase | main_2: events in views 896-925 | main_2: per 1,000 other views | main: per 1,000 views | main_3: per 1,000 views | main_4: per 1,000 views |
| :--- | ---: | ---: | ---: | ---: | ---: |
| OnLocalTimeout: V | 80 | 21.2 | 25.5 | 29.4 | 24.6 |
| OnRemoteTimeout (advancing view) | 441 | 90.2 | 103.6 | 122.5 | 99.3 |
| not enough timeouts | 361 | 80.1 | 94.4 | 105.5 | 91.6 |
| TC formed (second advance) | 79 | 10.1 | 7.1 | 14.7 | 7.4 |
| Failed to verify sync info | 11 | 5.5 | 1.4 | 2.8 | 2.7 |
| Stopped voting for timed out view | 14 | 0.0 | 0.0 | 0.6 | 0.0 |
| block too old | 11 | 358.2 | 265.3 | 271.0 | 246.2 |
| views in the group | 30 | 1,086 | 3,686 | 3,601 | 3,656 |

Outside the stall main_2's timeout rates are at or below those of the other runs; only the 6 remaining sync-info failures (4 of them in views 4-5) and the late votes stay above. Its baseline speed is lower too (222-255 proposals/s in seconds 0-2 against 309-382 in the other runs).

## Part 1 · How the events relate to view progression

View advancement is QC-driven; timeouts add a second path that is rare in the active phase and dominant in the drain.

**What caused each 'Advanced to view N'** (the line that preceded the advanceView call at that replica; active / drain):

| Event before the 'Advanced to view' line (same replica) | main act / drain | main_2 act / drain | main_3 act / drain | main_4 act / drain |
| :--- | ---: | ---: | ---: | ---: |
| attached QC of a received proposal | 11,040 / 8 | 3,288 / 9 | 10,764 / 9 | 10,957 / 9 |
| QC formed locally from votes (collector) | 3,685 / 3 | 1,105 / 4 | 3,595 / 3 | 3,656 / 3 |
| timeout certificate (TC) formed from timeout messages | 13 / 110 | 67 / 20 | 36 / 107 | 8 / 111 |
| QC inside a remote timeout message | 0 / 0 | 0 / 3 | 0 / 0 | 0 / 0 |
| other OnNewView (QC already known) | 0 / 1 | 0 / 0 | 2 / 0 | 0 / 0 |
| total ADVANCED | 14,738 / 122 | 4,460 / 36 | 14,397 / 119 | 14,621 / 123 |

QC-driven advances (attached QC plus locally formed QC) make up 99.9% / 98.5% / 99.7% / 99.9% of the active-phase advances. In the drain, with no commands to propose, the timeout certificate is the normal way to advance (110 / 20 / 107 / 111).

**Views with an OnLocalTimeout (active phase) and what became of them:**

| metric | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| views with >=1 local timeout (active) | 63 | 40 | 60 | 61 |
| ... as share of active views (%) | 1.7 | 3.6 | 1.7 | 1.7 |
| local-timeout events (replica x view) | 94 | 103 | 106 | 90 |
| views where exactly 1 replica(s) timed out | 43 | 12 | 34 | 41 |
| views where exactly 2 replica(s) timed out | 9 | 6 | 11 | 11 |
| views where exactly 3 replica(s) timed out | 11 | 9 | 10 | 9 |
| views where exactly 4 replica(s) timed out | 0 | 13 | 5 | 0 |
| outcome: QC formed, no TC advance | 56 | 19 | 47 | 57 |
| outcome: QC formed AND TC advance | 7 | 15 | 11 | 4 |
| outcome: TC advance, no QC | 0 | 6 | 2 | 0 |
| outcome: neither QC nor TC advance | 0 | 0 | 0 | 0 |

A local timeout almost never stops progress: the view still produced a QC in 63 of 63, 34 of 40, 58 of 60 and 61 of 61 cases. The 'TC advance, no QC' row counts views whose QC dispatch was logged only after the collector had left the view, or never; Part 4 splits these into classes L and X.

**The timeout-certificate path** (TCs are built from the timeout messages a replica has received) and **the fate of every timeout message**:

| metric | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| total lines 'Failed to verify sync info' | 5 | 17 | 10 | 10 |
| ... of which 'timeout certificate: ecdsa: failed to verify signature' | 5 | 16 | 10 | 10 |
| ... of which 'quorum certificate: block not found' | 0 | 1 | 0 | 0 |
| TCs built by replicas from timeout messages (all phases) | 137 | 110 | 160 | 138 |
| ... TC whose signers' latest timeout message is for the TC view ('consistent'), accepted | 132 | 94 | 150 | 128 |
| ... consistent but verification failed | 0 | 0 | 0 | 0 |
| ... TC with >=1 signer whose latest message is for another view ('mixed-view'), verification failed | 5 | 16 | 10 | 10 |
| ... mixed-view but accepted | 0 | 0 | 0 | 0 |

| outcome | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| not enough timeouts (quorum not reached) | 621 | 491 | 648 | 643 |
| TC formed (second advance), verification ok | 132 | 94 | 150 | 128 |
| TC formed (second advance), verification FAILED | 5 | 16 | 10 | 10 |
| Failed to create sync info (overlapping signatures) | 8 | 1 | 8 | 1 |
| other | 0 | 0 | 0 | 0 |
| sum = all OnRemoteTimeout (advancing view) lines | 766 | 602 | 816 | 782 |

The association is exact: every ECDSA failure is a mixed-view TC and every mixed-view TC fails. The mechanism (a stale per-replica timeout cache) is an inference; the log shows only that the signers' latest messages belong to different views.

**Anatomy of 'block too old'** (all phases):

| metric | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| total | 979 | 402 | 977 | 901 |
| directly preceded by CollectVote(from N) for the same block | 979 | 400 | 977 | 901 |
| QC for that block already dispatched at this collector | 979 | 398 | 976 | 901 |
| voter not listed in QC.IDs of the next block's attached QC | 979 | 398 | 975 | 900 |
| vote is the 4th CollectVote line for that block at that collector | 977 | 398 | 975 | 901 |
| vote is the 5th CollectVote line for that block at that collector | 2 | 1 | 2 | 0 |
| vote is the 6th CollectVote line for that block at that collector | 0 | 1 | 0 | 0 |
| share of QCs formed that later get a 'block too old' (%) | 26.5 | 36.1 | 27.1 | 24.6 |

Late voter (sender id) hs1 / hs2 / hs3 / hs4: main 258 / 237 / 263 / 221; main_2 107 / 105 / 94 / 94; main_3 249 / 262 / 239 / 227; main_4 240 / 228 / 200 / 233. No replica is the habitual late voter.

**The commit / DECIDE / EXEC chain per replica (hs1 / hs2 / hs3 / hs4)**:

| per replica (hs1/hs2/hs3/hs4) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| TryCommit (validated proposal processed) | 3687/3688/3688/3688 | 1116/1117/1114/1113 | 3602/3603/3602/3603 | 3659/3659/3659/3659 |
| CommitRule - PRE_COMMIT | 3687/3688/3688/3688 | 1116/1117/1114/1113 | 3602/3603/3602/3603 | 3659/3659/3659/3659 |
| CommitRule - COMMIT | 3685/3686/3686/3686 | 1109/1109/1107/1109 | 3596/3596/3596/3596 | 3657/3657/3657/3657 |
| CommitRule - DECIDE (incl. genesis once) | 3685/3686/3686/3686 | 1101/1104/1101/1102 | 3590/3591/3590/3591 | 3657/3657/3657/3657 |
| ... distinct blocks decided | 3685/3686/3686/3686 | 1101/1101/1099/1101 | 3586/3586/3586/3586 | 3657/3657/3657/3657 |
| EXEC | 3685/3685/3685/3685 | 1108/1108/1108/1108 | 3595/3595/3595/3595 | 3656/3656/3656/3656 |
| EXEC of a block that never had its own DECIDE line (ancestor executed with a descendant) | 1/0/0/0 | 8/8/10/8 | 10/10/10/10 | 0/0/0/0 |

Rules tested against every TryCommit (0 violations in all four runs): PRE_COMMIT follows every TryCommit; COMMIT is logged exactly when the second block's view is higher than that of any earlier COMMIT at the replica; DECIDE is logged exactly when the three blocks are in consecutive views. The genesis block is decided once per replica and never executed; EXEC of a block without its own DECIDE (main: 1 at hs1; main_2: 8-10 per replica; main_3: 10 per replica; main_4: none) is an ancestor executed together with its descendant. All replicas execute the same hash sequence (3,685 / 1,108 / 3,595 / 3,656 blocks, strictly increasing views).

## Part 1 · Verification commands

Run these in the directory that holds the four logs. The first loop reproduces the totals and the active / drain split of the pattern table (the stop line is the first line of the drain phase; it matches none of the patterns).

```bash
for f in main main_2 main_3 main_4; do
  STOP=$(grep -n 'Stopping clients\.\.\.' $f.log | head -1 | cut -d: -f1)
  for p in 'block too old' 'Failed to verify sync info' 'OnLocalTimeout: [0-9]+$' 'OnRemoteTimeout \(advancing view\)' \
           'not enough timeouts' 'advanceView: Successfully updated HighQC' 'advanceView: HighQC not updated' \
           'advanceView: Advanced to view' 'CommitRule - DECIDE' 'EXEC:'; do
    tot=$(grep -cE -- "$p" $f.log)
    act=$(head -n $((STOP-1)) $f.log | grep -cE -- "$p")
    printf '%-7s %-40s total=%6s active=%6s drain=%5s\n' $f "$p" $tot $act $((tot-act))
  done
done
```

Per replica (tab-separated logger field), and the identities from the arithmetic list:

```bash
grep -cE $'\ths4\t.*block too old' main.log        # 266 in main
for f in main main_2 main_3 main_4; do
  a=$(grep -cE 'OnRemoteTimeout \(advancing view\)' $f.log)
  s=$(( $(grep -c 'not enough timeouts' $f.log) + $(grep -cE 'OnRemoteTimeout \(second advance\)' $f.log) + $(grep -c 'Failed to create sync info' $f.log) ))
  echo "$f advancing=$a outcomes=$s"                 # equal in every run
done
```

The shipped script `verify_counts.sh` does this for all 37 patterns, all phases and all replicas (grep and awk only). `compare_counts.py` compares it with the Python parser and the JSON results: 1,480 values compared, 0 mismatches.

## Part 2 · Replica behaviour: answers and participation

The four replicas behave alike. The vote order is fixed by roles: the collector is first, the proposer second, and the last two places are a coin flip.

| # | Question | Answer |
| :--- | :--- | :--- |
| 1 | Do all replicas participate similarly in proposal reception and vote collection? | Yes. Each replica authored a quarter of the proposals (922 / 922 / 922 / 922 in main), logged 100% of the proposals of the others (main_2: 99.88% for hs1, hs3, hs4), sent about one vote per block (1.00-1.01) and formed the QCs of its own collector turns. All 24 chi-square tests against equal shares give p >= 0.386. |
| 2 | Is there a recurring order in which votes are received or processed? | Yes. Received: the collector (the receiver of the votes) is first in 100% of 11,978 complete sequences and the proposer second in 99.12% (11,873). Processed: the QC lists the first three received votes in the same order in 6,683 of 11,969 QCs (55.8%), the same three in another order in 2,070 (17.3%), and contains the 4th received vote in 3,216 (26.9%). |
| 3 | Does any replica appear more frequently in the first or last position? | First: no, 25.0% each; the first place belongs to the collector role, which rotates. Last: 25.7 / 25.1 / 25.0 / 24.2% for hs1-hs4, chi-square p = 0.15 (per run p = 0.048 / 0.62 / 0.97 / 0.23; only main touches 0.05). |
| 4 | Is any replica consistently first or last across complete vote sequences? | No. The last place is shared by the two replicas that are neither collector nor proposer: per collector each candidate is last 46-54% of the time in a run and 48.1-51.9% pooled (p = 0.04-0.34; the single p = 0.04, hs3, is not significant after four comparisons). |
| 5 | Does the ordering differ between executions? | The structure does not (same roles, same shares in every run; per-collector split homogeneous across runs, p = 0.29-0.76). The exact order of one view does not repeat: two runs agree on the last sender of the same view in 48.0-52.7% of views (chance 50%), all four in 13.3% (chance 12.5%, p = 0.45). |
| 6 | Differences that could indicate unusual replica behaviour? | None at replica level. At event level: 105 complete sequences (0.88%) where the proposer is not second (main_2 2.20%), 7 incomplete sequences, 84 sequences with a duplicate vote line from the cache-miss path, and main_2's fork, fetch and prune events (below). |

**Participation** per run and replica (all phases). Votes sent are the `CollectVote(from k)` lines for sender k seen at all collectors; votes collected are the `CollectVote` lines logged by replica k as receiver:

| Run · replica | Proposals authored | 'Received proposal' lines | Votes sent (seen at the collectors) | Votes collected (as receiver) | QCs formed | 'block too old' logged |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| main · hs1 | 922 | 2,767 | 3,696 | 3,695 | 922 | 237 |
| main · hs2 | 922 | 2,766 | 3,697 | 3,699 | 922 | 238 |
| main · hs3 | 922 | 2,766 | 3,697 | 3,695 | 922 | 238 |
| main · hs4 | 922 | 2,766 | 3,697 | 3,698 | 922 | 266 |
| main_2 · hs1 | 279 | 840 | 1,128 | 1,128 | 280 | 105 |
| main_2 · hs2 | 280 | 839 | 1,130 | 1,116 | 277 | 86 |
| main_2 · hs3 | 280 | 840 | 1,124 | 1,126 | 278 | 102 |
| main_2 · hs4 | 280 | 838 | 1,120 | 1,132 | 279 | 109 |
| main_3 · hs1 | 900 | 2,703 | 3,607 | 3,610 | 900 | 244 |
| main_3 · hs2 | 901 | 2,702 | 3,612 | 3,605 | 900 | 232 |
| main_3 · hs3 | 901 | 2,702 | 3,608 | 3,608 | 901 | 253 |
| main_3 · hs4 | 901 | 2,702 | 3,609 | 3,613 | 901 | 248 |
| main_4 · hs1 | 914 | 2,745 | 3,661 | 3,670 | 915 | 208 |
| main_4 · hs2 | 915 | 2,744 | 3,665 | 3,664 | 914 | 226 |
| main_4 · hs3 | 915 | 2,744 | 3,668 | 3,663 | 915 | 242 |
| main_4 · hs4 | 915 | 2,745 | 3,665 | 3,662 | 915 | 225 |

Within each run the four replicas are statistically indistinguishable (chi-square against equal shares: authored, received, sent, collected, QCs formed and 'block too old' logged, 24 tests, smallest p = 0.386).

**How many vote sequences are complete.** A complete sequence is exactly four `CollectVote` lines from four distinct senders for one block at one collector. These 11,978 sequences carry the first / last statistics below.

| class | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| complete | 3,660 | 1,090 | 3,585 | 3,643 |
| with duplicate sender line (local cache miss path) | 26 | 25 | 17 | 16 |
| incomplete (3 distinct senders) | 2 | 4 | 1 | 0 |
| incomplete (2 distinct senders) | 0 | 0 | 0 | 0 |
| incomplete (1 distinct senders) | 0 | 0 | 0 | 0 |
| all (collector, block) sequences | 3,688 | 1,119 | 3,603 | 3,659 |
| collector logger == leader(view+1) | 3,688 | 1,119 | 3,603 | 3,659 |
| collector logger != leader(view+1) | 0 | 0 | 0 | 0 |

The missing sender of the 7 incomplete sequences is hs1 in main (2 times) and main_3 (1), and hs1 / hs3 / hs4 in main_2 (1 / 2 / 1). A 'duplicate' sequence has a second line from one sender: after `Local cache miss for block`, the collector fetches the block and processes the vote again.

## Part 2 · Vote order: who is first and who is last

The collector is always first and the proposer almost always second, so only the last two places are open, and they split evenly.

**Structure of the received order** in complete sequences (each sequence reads collector, proposer, X, Y):

| run | complete sequences | collector (receiver of the votes) is 1st | proposer of the block is 2nd | both | proposer position 1st/2nd/3rd/4th |
| :--- | ---: | ---: | ---: | ---: | ---: |
| main | 3,660 | 3660 (100.00%) | 3624 (99.02%) | 3624 (99.02%) | 0/3624/18/18 |
| main_2 | 1,090 | 1090 (100.00%) | 1066 (97.80%) | 1066 (97.80%) | 0/1066/11/13 |
| main_3 | 3,585 | 3585 (100.00%) | 3563 (99.39%) | 3563 (99.39%) | 0/3563/13/9 |
| main_4 | 3,643 | 3643 (100.00%) | 3620 (99.37%) | 3620 (99.37%) | 0/3620/15/8 |
| combined | 11,978 | 11978 (100.00%) | 11873 (99.12%) | 11873 (99.12%) | 0/11873/57/48 |

The proposer is second in 99.12% of the sequences; in the 105 others it is third (57) or fourth (48), never first.

**The open places.** X and Y are the two replicas that are neither collector nor proposer. For each collector, the share of sequences in which the higher-ID candidate is last (combined over the four runs):

| Collector (receiver) | Last place: lower-ID / higher-ID candidate | Higher-ID candidate last | p (binomial vs 50%) | chi2 across runs (df 3) | p (across runs) |
| :--- | ---: | ---: | ---: | ---: | ---: |
| hs1 | 1524 / 1456 | 48.9% | 0.22 | 3.22 | 0.358 |
| hs2 | 1510 / 1454 | 49.1% | 0.312 | 1.16 | 0.763 |
| hs3 | 1540 / 1428 | 48.1% | 0.0416 | 1.15 | 0.764 |
| hs4 | 1507 / 1454 | 49.1% | 0.339 | 3.74 | 0.291 |

Per run (16 collector-run cells) each candidate is last in 46.7-53.3% of the sequences. Three of the 32 tests (16 binomial tests, 16 runs tests for alternation) fall below 0.05: hs1 in main_4 (binomial, p = 0.0497), hs2 in main (runs, p = 0.024) and hs4 in main_2 (runs, p = 0.046); about 1.6 are expected by chance. The per-run table is in the 'Evidence tables' tab.

**First and last place per replica, receiver against sender** (all complete sequences). Rows are the receiving replica (the collector); the columns give how often each sending replica is first or last in that receiver's sequences:

| Run · receiver (complete sequences) | FIRST, % of sequences, sender hs1 / hs2 / hs3 / hs4 | LAST, % of sequences, sender hs1 / hs2 / hs3 / hs4 |
| :--- | ---: | ---: |
| main · hs1 (918) | 100.0 / 0.0 / 0.0 / 0.0 | 0.0 / 49.1 / 50.7 / 0.2 |
| main · hs2 (914) | 0.0 / 100.0 / 0.0 / 0.0 | 0.7 / 0.0 / 51.8 / 47.6 |
| main · hs3 (913) | 0.0 / 0.0 / 100.0 / 0.0 | 52.6 / 0.3 / 0.0 / 47.1 |
| main · hs4 (915) | 0.0 / 0.0 / 0.0 / 100.0 | 52.7 / 46.6 / 0.8 / 0.0 |
| main · all receivers (3,660) | 25.1 / 25.0 / 24.9 / 25.0 | 26.4 / 24.0 / 25.8 / 23.7 |
| main_2 · hs1 (273) | 100.0 / 0.0 / 0.0 / 0.0 | 0.0 / 48.7 / 50.2 / 1.1 |
| main_2 · hs2 (274) | 0.0 / 100.0 / 0.0 / 0.0 | 1.8 / 0.0 / 51.8 / 46.4 |
| main_2 · hs3 (271) | 0.0 / 0.0 / 100.0 / 0.0 | 50.9 / 0.4 / 0.0 / 48.7 |
| main_2 · hs4 (272) | 0.0 / 0.0 / 0.0 / 100.0 | 51.8 / 46.7 / 1.5 / 0.0 |
| main_2 · all receivers (1,090) | 25.0 / 25.1 / 24.9 / 25.0 | 26.1 / 23.9 / 26.0 / 24.0 |
| main_3 · hs1 (897) | 100.0 / 0.0 / 0.0 / 0.0 | 0.0 / 51.2 / 48.5 / 0.3 |
| main_3 · hs2 (896) | 0.0 / 100.0 / 0.0 / 0.0 | 0.1 / 0.0 / 50.7 / 49.2 |
| main_3 · hs3 (898) | 0.0 / 0.0 / 100.0 / 0.0 | 50.2 / 0.4 / 0.0 / 49.3 |
| main_3 · hs4 (894) | 0.0 / 0.0 / 0.0 / 100.0 | 50.6 / 49.3 / 0.1 / 0.0 |
| main_3 · all receivers (3,585) | 25.0 / 25.0 / 25.0 / 24.9 | 25.2 / 25.2 / 24.8 / 24.7 |
| main_4 · hs1 (909) | 100.0 / 0.0 / 0.0 / 0.0 | 0.0 / 53.4 / 46.6 / 0.0 |
| main_4 · hs2 (908) | 0.0 / 100.0 / 0.0 / 0.0 | 0.3 / 0.0 / 49.7 / 50.0 |
| main_4 · hs3 (913) | 0.0 / 0.0 / 100.0 / 0.0 | 52.4 / 0.3 / 0.0 / 47.3 |
| main_4 · hs4 (913) | 0.0 / 0.0 / 0.0 / 100.0 | 48.5 / 51.3 / 0.2 / 0.0 |
| main_4 · all receivers (3,643) | 25.0 / 24.9 / 25.1 / 25.1 | 25.4 / 26.2 / 24.1 / 24.3 |
| combined · hs1 (2997) | 100.0 / 0.0 / 0.0 / 0.0 | 0.0 / 51.0 / 48.7 / 0.3 |
| combined · hs2 (2992) | 0.0 / 100.0 / 0.0 / 0.0 | 0.5 / 0.0 / 50.8 / 48.7 |
| combined · hs3 (2995) | 0.0 / 0.0 / 100.0 / 0.0 | 51.7 / 0.4 / 0.0 / 48.0 |
| combined · hs4 (2994) | 0.0 / 0.0 / 0.0 / 100.0 | 50.7 / 48.8 / 0.5 / 0.0 |
| combined · all receivers (11,978) | 25.0 / 25.0 / 25.0 / 25.0 | 25.7 / 25.1 / 25.0 / 24.2 |

Reading the table: in the receiver's own row the receiver is first in 100% of its sequences, so the 'all receivers' row of the FIRST column is 25% each by construction of the rotation. In the LAST column the receiver itself is never last (0.0%), the proposer is last in 0.3-0.5% pooled (up to 1.8% in one run), and the two remaining senders share the place at 46.4-53.4% each.

**Position of each sender's vote pooled over all receivers** (combined, % of complete sequences):

| scope | sender | 1st % | 2nd % | 3rd % | 4th % |
| :--- | :--- | ---: | ---: | ---: | ---: |
| combined | hs1 | 25.0 | 25.0 | 24.3 | 25.7 |
| combined | hs2 | 25.0 | 25.0 | 25.0 | 25.1 |
| combined | hs3 | 25.0 | 24.9 | 25.1 | 25.0 |
| combined | hs4 | 25.0 | 25.1 | 25.7 | 24.2 |

**Is a replica last more often than 25%?** Chi-square test of the pooled last place against 25% each (df = 3):

| scope | complete sequences | last = hs1/hs2/hs3/hs4 (count) | last (%) | chi2 | p |
| :--- | ---: | ---: | ---: | ---: | ---: |
| main | 3,660 | 968/880/945/867 | 26.4/24.0/25.8/23.7 | 7.91 | 0.0479 |
| main_2 | 1,090 | 284/261/283/262 | 26.1/23.9/26.0/24.0 | 1.78 | 0.619 |
| main_3 | 3,585 | 904/904/890/887 | 25.2/25.2/24.8/24.7 | 0.27 | 0.965 |
| main_4 | 3,643 | 924/956/877/886 | 25.4/26.2/24.1/24.3 | 4.36 | 0.225 |
| combined | 11,978 | 3080/3001/2995/2902 | 25.7/25.1/25.0/24.2 | 5.31 | 0.15 |

Only main reaches p = 0.048. hs1 is the most frequent last voter in main (26.4%), main_2 (26.1%) and pooled (25.7%), but the effect is under one percentage point and the combined test gives p = 0.15.

## Part 2 · Processed order, proposal reception and unusual behaviour

A vote that is received earlier is not always processed earlier: in 27% of the QCs one of the first three received votes was left out.

**Received order against processed order.** `QC.IDs` lists the voters in the order their verified votes entered the QC; a `CollectVote` line only shows that the vote arrived, and the vote still has to be verified. For each complete sequence whose QC is printed in a later block:

| Scope | QCs analysed | QC.IDs = first three received, same order | same three, other order | 4th received vote is in the QC | replica left out was received 1st / 2nd / 3rd / 4th |
| :--- | ---: | ---: | ---: | ---: | ---: |
| main | 3,659 | 2,015 | 649 | 995 | 6/278/711/2664 |
| main_2 | 1,088 | 643 | 168 | 277 | 3/84/190/811 |
| main_3 | 3,580 | 2,001 | 622 | 957 | 7/277/673/2623 |
| main_4 | 3,642 | 2,024 | 631 | 987 | 3/307/677/2655 |
| combined | 11,969 | 6,683 | 2,070 | 3,216 | 19/946/2251/8753 |

The collector's own vote is the first entry of QC.IDs in 11,394 of 11,969 QCs (95.2%). The replica left out of the QC was received 4th in 73% of the cases (8,753) and 1st, 2nd or 3rd in 27% (3,216). Which replica is left out, by collector (combined, % of that collector's QCs):

| scope | receiver | QCs | excluded hs1 % | excluded hs2 % | excluded hs3 % | excluded hs4 % |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: |
| combined | hs1 | 2,992 | 0.1 | 46.9 | 44.6 | 8.3 |
| combined | hs2 | 2,989 | 8.1 | 0.1 | 46.3 | 45.5 |
| combined | hs3 | 2,994 | 47.3 | 8.2 | 0.2 | 44.3 |
| combined | hs4 | 2,994 | 45.8 | 46.0 | 8.1 | 0.2 |

The proposer (the replica before the collector in the rotation) is left out only 8% of the time because its vote is second in the received order; the two other replicas share the exclusion (44-47% each).

**Proposal reception order.** Three replicas receive each proposal. Share of blocks in which the receiver of that role logged `Received proposal` first / last (one third would be neutral):

| Run | Next leader (collector): first / last | Previous leader: first / last | Other replica: first / last |
| :--- | ---: | ---: | ---: |
| main | 18.7 / 37.6 | 43.0 / 29.2 | 38.3 / 33.2 |
| main_2 | 24.3 / 34.7 | 38.1 / 32.6 | 37.6 / 32.7 |
| main_3 | 17.6 / 39.1 | 43.3 / 29.9 | 39.1 / 31.0 |
| main_4 | 17.3 / 39.2 | 42.0 / 29.5 | 40.7 / 31.3 |
| combined | 18.5 / 38.3 | 42.3 / 29.8 | 39.2 / 31.9 |

The roles are not neutral: the next leader logs a proposal last in about 38% of the blocks and first in about 18%, the previous leader the reverse. The pattern is the same in all four runs (next leader first 17.3-24.3%), so it is structural; the log does not show its cause.

**Replica-level counters** that could point to an unusual replica (all phases, hs1 / hs2 / hs3 / hs4):

| counter (hs1/hs2/hs3/hs4) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| Local cache miss (vote for unknown block) | 7/11/9/10 | 9/6/13/14 | 8/5/4/10 | 10/8/3/2 |
| Could not find block for vote | 0/0/0/0 | 0/2/0/0 | 0/0/0/0 | 0/0/0/0 |
| Attempting to fetch block | 1/0/0/0 | 3/3/4/2 | 1/0/0/0 | 0/0/0/1 |
| On RequestBlock (served a fetch) | 0/1/1/1 | 6/8/5/4 | 0/1/0/1 | 1/1/1/0 |
| PruneToHeight found forked block | 0/0/0/0 | 5/7/7/4 | 5/5/4/5 | 0/0/0/0 |
| block already exists | 0/0/0/0 | 2/0/0/0 | 0/0/0/0 | 0/0/0/1 |
| failed to verify incoming vote: block view N too old | 1/0/0/0 | 2/2/4/5 | 1/0/1/0 | 0/0/0/0 |
| OnLocalTimeout: V | 47/47/48/48 | 30/31/28/29 | 48/51/49/51 | 49/46/48/51 |
| Stopped voting for timed out view | 23/23/24/23 | 8/6/5/10 | 24/22/23/23 | 26/25/25/25 |
| Failed to verify sync info | 1/0/4/0 | 4/5/2/6 | 2/4/0/4 | 2/4/2/2 |
| block too old (as collector) | 237/238/238/266 | 105/86/102/109 | 244/232/253/248 | 208/226/242/225 |
| Failed to create proposal | 7/7/7/7 | 2/2/1/1 | 7/7/7/6 | 7/7/7/7 |

main_2 stands out through fork handling: forked blocks pruned 5 / 7 / 7 / 4, block fetches 3 / 3 / 4 / 2 and block requests served 6 / 8 / 5 / 4, plus 13 proposals rejected as too old; main_3 has forked blocks too (19) but almost no fetches. No single replica is responsible: every counter is spread over hs1-hs4.

**Complete sequences where the proposer is not second:**

| run | complete sequences | proposer not 2nd | share | by proposer hs1/hs2/hs3/hs4 |
| :--- | ---: | ---: | ---: | ---: |
| main | 3,660 | 36 | 0.98% | 13/11/9/3 |
| main_2 | 1,090 | 24 | 2.20% | 8/4/7/5 |
| main_3 | 3,585 | 22 | 0.61% | 3/6/9/4 |
| main_4 | 3,643 | 23 | 0.63% | 4/6/8/5 |

## Part 2 · Verification commands

The first one-liner reproduces the complete-sequence count, the collector-first count and the last-place counts per sender of the tables above from the raw logs (awk only):

```bash
for f in main main_2 main_3 main_4; do
  awk -F'\t' '$3 ~ /^hs[1-4]$/ && $5 ~ /^CollectVote\(from [0-9]+\): / {
    s=$5; sub(/^CollectVote\(from /,"",s); sub(/\).*/,"",s); h=$5; sub(/^.*: /,"",h)
    k=$3 SUBSEP h; n[k]++; seq[k]=seq[k] " " s }
  END { for (k in n) if (n[k]==4) { split(seq[k],a," "); d=0
          for (i=2;i<=4;i++) for (j=1;j<i;j++) if (a[i]==a[j]) d=1
          if (!d) { split(k,kk,SUBSEP); tot++; if ("hs" a[1]==kk[1]) cf++; last[a[4]]++ } }
        printf "%s: complete=%d collector-first=%d last hs1/hs2/hs3/hs4=%d/%d/%d/%d\n", FILENAME, tot, cf, last[1], last[2], last[3], last[4] }' $f.log
done
# main.log:   complete=3660 collector-first=3660 last=968/880/945/867
# main_2.log: complete=1090 collector-first=1090 last=284/261/283/262
# main_3.log: complete=3585 collector-first=3585 last=904/904/890/887
# main_4.log: complete=3643 collector-first=3643 last=924/956/877/886
```

One block by hand (view 1000 of main, shown with all its chain lines in Part 4): the four votes in log order, collector hs2 first, proposer hs1 second:

```bash
awk -F'\t' -v h=qXCyTpwu '$5 ~ ("^CollectVote\\(from [0-9]+\\): " h "$") { print NR, $3, $5 }' main.log
# 54892 hs2 CollectVote(from 2): qXCyTpwu
# 54895 hs2 CollectVote(from 1): qXCyTpwu
# 54898 hs2 CollectVote(from 4): qXCyTpwu
# 54907 hs2 CollectVote(from 3): qXCyTpwu
```

The shipped `verify_votes.sh` (awk only) recomputes all of Part 2 (first / last, positions, processed order, proposal reception); `compare_votes.py` compares it with the Python results: 581 metrics compared, 0 mismatches.

## Part 3 · Shared views and event-pattern classes

Views 1-1,119 exist in all four runs, and 95-98% of the views of every run follow the standard event pattern. main_2 has the lowest share of standard views and the highest share of timeout views.

**Which views exist.** A view exists in a run when a block with that view number is proposed (a `TryCommit` line of the proposer):

| Run | Views with a proposal | View numbers | First seen in the active phase | First seen in the drain phase | View numbers without a proposal | Views with two different proposals |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: |
| main | 3,688 | 1-3,688 | 3,686 | 2 | 0 | 0 |
| main_2 | 1,119 | 1-1,119 | 1,116 | 3 | 0 | 0 |
| main_3 | 3,603 | 1-3,603 | 3,601 | 2 | 0 | 0 |
| main_4 | 3,659 | 1-3,659 | 3,656 | 3 | 0 | 0 |

- **Four runs.** Views 1-1,119, the whole of main_2. 1,116 of them are first seen in the active phase in every run; the other 3 are drain-phase views of main_2.
- **Three runs.** Views 1,120-3,603 (2,484 views in main, main_3 and main_4). **Two runs:** 3,604-3,659 (56 views in main and main_4). **One run:** 3,660-3,688 (29 views in main). The union holds 3,688 views.
- **Structure.** View numbers are contiguous in every run, no view has two proposals, and the proposer of view v is always replica (v mod 4) + 1 (0 exceptions).

Number of views shared by each pair of runs:

| Run | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| main | 3,688 | 1,119 | 3,603 | 3,659 |
| main_2 | 1,119 | 1,119 | 1,119 | 1,119 |
| main_3 | 3,603 | 1,119 | 3,603 | 3,603 |
| main_4 | 3,659 | 1,119 | 3,603 | 3,659 |

**Event-pattern classes.** Every active-phase view gets one class from the events attributed to its view number. The standard core of a view is 3 `Received proposal`, 4 `TryCommit`, 4 `CollectVote`, 1 QC dispatch, 4 HighQC updates and 4 `Advanced to view` lines. Rule, first match wins: T = any timeout-type event; F = fork, fetch, prune, missing-block or sync-info failure; N = other core counts; D / L = standard core plus a duplicate vote line / a late 4th vote; S = standard core only.

| Class | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| S · standard core only | 2,632 (71.4%) | 662 (59.3%) | 2,572 (71.4%) | 2,694 (73.7%) |
| L · standard core plus a late 4th vote ('block too old') | 960 (26.0%) | 385 (34.5%) | 953 (26.5%) | 879 (24.0%) |
| D · standard core plus a duplicate vote line (local cache miss) | 25 (0.7%) | 18 (1.6%) | 14 (0.4%) | 15 (0.4%) |
| N · other core counts, no timeout event | 2 (0.1%) | 4 (0.4%) | 1 (0.0%) | 1 (0.0%) |
| F · fork, fetch, prune, missing-block or sync-info failure | 4 (0.1%) | 7 (0.6%) | 1 (0.0%) | 6 (0.2%) |
| T · timeout-type events | 63 (1.7%) | 40 (3.6%) | 60 (1.7%) | 61 (1.7%) |
| Views (active phase) | 3,686 | 1,116 | 3,601 | 3,656 |

- **Standard views.** S, L and D together (standard core, only late or duplicate vote lines differ) are 98.1 / 95.4 / 98.3 / 98.1% of the views of main / main_2 / main_3 / main_4.
- **Late 4th vote (L).** It is the most frequent deviation (24.0-26.5% of the views, 34.5% in main_2). The collector forms the QC from three votes and logs `block too old` when the fourth arrives; the voter of every late `CollectVote` line is outside `QC.IDs` (Part 4, check O8b).
- **Timeout views (T).** 1.7% in main, main_3 and main_4; 3.6% in main_2.
- **Fork, fetch, prune, missing block, other core counts (F + N).** 0.2 / 1.0 / 0.1 / 0.2% of the views; main_2 has 11 of these views, the others 2-7.

## Part 3 · The same view in the four runs

For 95.4% of the 1,116 views that are shared and active in all four runs the core event counts are identical; the differences come from late votes and from timeout events.

| Measure over the views shared by all four runs | value |
| :--- | ---: |
| views shared by all four runs (active in each) | 1,116 |
| core counts identical in all four runs | 1,065 (95.4%) |
| all four runs in the standard core (class S, L or D - only late/duplicate vote lines differ) | 1,009 (90.4%) |
| all four runs class S (nothing but the standard events) | 238 (21.3%) |
| full event-count signature identical in all four runs | 239 (21.4%) |
| at least one run has a timeout-type event (class T) | 90 (8.1%) |
| class T in all four runs | 1 |
| at least one run in class T, F or N | 107 (9.6%) |

Events whose count in a view differs between the runs, over the same 1,116 views:

| Event (per-view count) | Views where the count differs in at least one run | Share of the 1,116 shared views |
| :--- | ---: | ---: |
| BLOCK_TOO_OLD | 834 | 74.7% |
| ADVANCE_ENTER | 105 | 9.4% |
| HQC_NOT_UPDATED | 99 | 8.9% |
| LOCAL_TIMEOUT | 90 | 8.1% |
| LOCAL_TIMEOUT_VIEW | 90 | 8.1% |
| REMOTE_TIMEOUT | 90 | 8.1% |
| NOT_ENOUGH_TIMEOUTS | 90 | 8.1% |
| REMOTE_TIMEOUT_2ND | 44 | 3.9% |
| ON_NEW_VIEW | 43 | 3.9% |
| COLLECT_VOTE | 41 | 3.7% |
| CACHE_MISS | 38 | 3.4% |
| EXEC | 25 | 2.2% |
| FAIL_VERIFY_SYNCINFO | 20 | 1.8% |
| DECIDE | 19 | 1.7% |

The same measure for main, main_3 and main_4 only (main_2 left out), over their 3,601 shared active views:

| Event (per-view count) | Views where the count differs in at least one of the 3 runs | Share of the 3,601 shared views |
| :--- | ---: | ---: |
| BLOCK_TOO_OLD | 2,074 | 57.6% |
| ADVANCE_ENTER | 201 | 5.6% |
| HQC_NOT_UPDATED | 194 | 5.4% |
| LOCAL_TIMEOUT | 177 | 4.9% |
| LOCAL_TIMEOUT_VIEW | 177 | 4.9% |
| REMOTE_TIMEOUT | 177 | 4.9% |
| NOT_ENOUGH_TIMEOUTS | 177 | 4.9% |
| COLLECT_VOTE | 60 | 1.7% |
| CACHE_MISS | 58 | 1.6% |
| REMOTE_TIMEOUT_2ND | 47 | 1.3% |

- **Similar views.** 1,065 views (95.4%) have identical core counts in all four runs, 1,009 (90.4%) have the standard core in all four. A view that is in the standard class in all four runs and has the same full event signature is rare (238-239 views, 21%), because late votes occur in a quarter to a third of the views of each run independently of the other runs (Section 'Vote collection in the same view').
- **Late vote line.** `BLOCK_TOO_OLD` is the most frequent difference (834 views, 74.7%; 57.6% among the three similar runs). It has no protocol effect: it is the line the collector writes for a vote that arrives after the QC was formed.
- **Advance and HighQC counts.** `ADVANCE_ENTER` (105 views) and `HQC_NOT_UPDATED` (99) differ in about as many views as the timeout events (90): in excerpts E2 and E3 every `OnRemoteTimeout` line is followed by an `advanceView` line and a 'HighQC not updated' line.
- **Commit events.** `DECIDE` differs in 19 of the shared views and `EXEC` in 25. All DECIDE differences but one are in main_2: 16 views of its stall window (897-916, where gap blocks break the three-chain, Part 4) and views 955 and 988, where hs3 logged `failed to verify incoming vote: block view 955 too old, last voted view was 957` (and the same for view 988, last voted view 990) and so had no `TryCommit` for the block. The exception is view 397 of main (hs1: `block view 397 too old, last voted view was 398`, excerpt E6).

## Part 3 · Views with timeout events

Timeout-type events occur in 1.7% of the active views of main, main_3 and main_4 and in 3.6% of main_2. Only view 3 has them in all four runs.

A timeout-type event is any of `OnLocalTimeout: V`, `OnRemoteTimeout`, `not enough timeouts`, the timeout-certificate advance (`OnRemoteTimeout (second advance)`), `Stopped voting for timed out view` and `Failed to create sync info`, attributed to the view named in the message (for the lines without a view number, the view of the replica's latest `OnRemoteTimeout` or its current view). Views with timeout-type events per run:

| Run | Views, active phase | Views, drain phase | Views, total | Views with 'OnLocalTimeout: V' (active) | Share of active views |
| :--- | ---: | ---: | ---: | ---: | ---: |
| main | 63 | 28 | 91 | 63 | 1.7% |
| main_2 | 40 | 5 | 45 | 40 | 3.6% |
| main_3 | 60 | 27 | 87 | 60 | 1.7% |
| main_4 | 61 | 28 | 89 | 61 | 1.7% |

- **All four runs.** Only view 3, in the active phase and in any phase; the same view is the only one with an `OnLocalTimeout: V` line in all four runs. The replicas that logged `OnLocalTimeout: 3` are hs4 (main), hs2 and hs4 (main_2), hs2 and hs4 (main_3) and hs4 (main_4). The view is entered 164-225 ms after the first log line of each run (start-up).
- **Start-up views.** In views 1-10, 11 of the 40 view slots (4 runs x 10 views) carry timeout-type events (main: 3; main_2: 3, 4, 5; main_3: 3, 5, 6, 7; main_4: 3, 4, 7), 27.5% against 1.7-3.6% over all views.
- **How many runs per view.** Counting every active view of every run: 200 views have timeout-type events in exactly one run, 10 in two runs, none in three, 1 (view 3) in four.
- **Stall window of main_2.** 25 of the 30 views 896-925 of main_2 have timeout-type events (Section 'Timeouts and view progression').

Overlap of the timeout views of two runs, against the overlap expected if timeout views were scattered independently (hypergeometric upper tail, over the shared active views):

| run A | run B | Shared active views | Timeout views in A | in B | In both | Expected by chance | p | Views in both |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| main | main_2 | 1,116 | 17 | 40 | 4 | 0.61 | 0.00241 | [3, 20, 896, 897] |
| main | main_3 | 3,601 | 60 | 60 | 1 | 1.00 | 0.638 | [3] |
| main | main_4 | 3,656 | 63 | 61 | 1 | 1.05 | 0.657 | [3] |
| main_2 | main_3 | 1,116 | 40 | 20 | 4 | 0.72 | 0.00453 | [3, 5, 909, 910] |
| main_2 | main_4 | 1,116 | 40 | 26 | 3 | 0.93 | 0.0627 | [3, 4, 545] |
| main_3 | main_4 | 3,601 | 60 | 61 | 3 | 1.02 | 0.0802 | [3, 7, 680] |

Reading: main and main_2 share the views 3, 20, 896 and 897, main_2 and main_3 share 3, 5, 909 and 910. The low p-values (0.0024, 0.0045) come from views 896, 897, 909 and 910, which lie in the stall window of main_2, where 25 of 30 views carry timeout events, so any timeout of another run that falls in the window overlaps. The other four pairs share 1-3 views (p = 0.063-0.66); all of them include view 3, and views 4, 5, 6 and 7 are start-up views as well. Only views 20, 545 and 680 are shared by two runs outside view 3, the start-up views and the stall window, as chance produces.

## Part 3 · Timeouts and view progression

A local timeout is mostly a short blip that the QC of the same view absorbs: in main, main_3 and main_4 the view still produced its QC in 96.7-100% of the timed-out views. In main_2 timeouts pile up into one 30-view stall.

**Did the timed-out view still make progress?** 'QC formed' means a `CollectVote: dispatching event for new view (current : v)` line exists for the view; 'advanced by TC' means at least one replica entered v+1 through `OnRemoteTimeout (second advance)`:

| Outcome of the view that had an `OnLocalTimeout: V` (active phase) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| QC formed, nobody advanced by TC | 56 | 19 | 47 | 57 |
| QC formed, some replicas advanced by TC | 7 | 15 | 11 | 4 |
| no QC, advanced by TC | 0 | 6 | 2 | 0 |
| neither | 0 | 0 | 0 | 0 |
| views with OnLocalTimeout (active) | 63 | 40 | 60 | 61 |

main_2 has 34 of 40 timed-out views with a QC (85%) and 6 without (5 views with fewer than 3 distinct votes and 1 whose QC was dispatched after the collector had left the view, Part 4).

**How long does a view take?** Time from the first replica entering view v to the first replica entering v+1, by class (ms; the log timestamps have 1 ms resolution):

| Run | Class | Views | Median ms | Mean ms | p90 ms | Max ms |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: |
| main | S | 2,632 | 3.0 | 2.7 | 3.9 | 7 |
| main | L | 960 | 2.0 | 2.6 | 3.0 | 7 |
| main | T | 63 | 6.0 | 6.1 | 7.8 | 13 |
| main_2 | S | 662 | 4.0 | 5.0 | 6.0 | 123 |
| main_2 | L | 385 | 4.0 | 5.1 | 6.0 | 176 |
| main_2 | T | 40 | 111.5 | 111.2 | 234.6 | 407 |
| main_3 | S | 2,572 | 3.0 | 2.7 | 4.0 | 10 |
| main_3 | L | 953 | 2.0 | 2.6 | 4.0 | 15 |
| main_3 | T | 60 | 6.0 | 8.9 | 17.1 | 32 |
| main_4 | S | 2,694 | 3.0 | 2.7 | 4.0 | 11 |
| main_4 | L | 879 | 2.0 | 2.6 | 3.0 | 9 |
| main_4 | T | 61 | 7.0 | 6.5 | 10.0 | 15 |

A timed-out view takes about twice as long as a standard one in main, main_3 and main_4 (6-7 ms against 3 ms); in main_2 the median of a timeout view is 111.5 ms against 4 ms.

**Do timeout views come in bursts?** 2x2 table over consecutive active views (v, v+1):

| Run | T views | T then T | T then not-T | not-T then T | not-T then not-T | P(T at v+1, T at v) | P(T at v+1, not T at v) | Odds ratio | Fisher p |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| main | 63 | 13 | 50 | 50 | 3,572 | 20.6% | 1.4% | 18.6 | 1.59e-11 |
| main_2 | 40 | 26 | 14 | 14 | 1,061 | 65.0% | 1.3% | 140.7 | 1.44e-32 |
| main_3 | 60 | 18 | 42 | 42 | 3,498 | 30.0% | 1.2% | 35.7 | 3.46e-19 |
| main_4 | 61 | 13 | 48 | 48 | 3,546 | 21.3% | 1.3% | 20.0 | 7.29e-12 |

After a timeout view, the next view is a timeout view in 20.6% (main), 65.0% (main_2), 30.0% (main_3) and 21.3% (main_4) of the cases, against 1.2-1.4% after a view without timeout. The odds ratios are 18.6, 140.7, 35.7 and 20.0 (Fisher p below 1e-10 in every run): timeouts cluster.

**Timeline.** Per second of the run (second 0 = client start; 'Stopping clients' is logged at second 10), each cell reads: proposals seen for the first time / `OnLocalTimeout: V` lines / TC formations (`second advance`):

| Second (0 = clients start) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| 0 | 335 / 17 / 8 | 222 / 11 / 7 | 327 / 21 / 11 | 318 / 17 / 4 |
| 1 | 365 / 5 / 0 | 255 / 3 / 0 | 372 / 5 / 0 | 309 / 10 / 4 |
| 2 | 369 / 8 / 6 | 243 / 7 / 4 | 382 / 5 / 0 | 315 / 9 / 3 |
| 3 | 370 / 1 / 0 | 179 / 14 / 11 | 381 / 8 / 2 | 394 / 0 / 0 |
| 4 | 367 / 9 / 1 | 7 / 27 / 33 | 390 / 5 / 1 | 387 / 1 / 0 |
| 5 | 383 / 5 / 2 | 6 / 21 / 19 | 377 / 12 / 4 | 393 / 8 / 4 |
| 6 | 371 / 15 / 4 | 5 / 10 / 10 | 381 / 4 / 0 | 383 / 13 / 4 |
| 7 | 385 / 8 / 0 | 6 / 5 / 3 | 307 / 33 / 23 | 389 / 9 / 4 |
| 8 | 379 / 13 / 2 | 6 / 5 / 3 | 305 / 13 / 12 | 387 / 13 / 1 |
| 9 | 362 / 13 / 3 | 187 / 0 / 0 | 378 / 0 / 0 | 382 / 10 / 3 |
| 10 | 2 / 75 / 83 | 3 / 4 / 4 | 3 / 71 / 79 | 2 / 81 / 87 |
| 11 | 0 / 15 / 20 | 0 / 8 / 12 | 0 / 17 / 20 | 0 / 18 / 16 |
| 12 | 0 / 6 / 8 | 0 / 3 / 4 | 0 / 5 / 8 | 0 / 5 / 8 |

- **main, main_4.** 362-385 proposals per second in main (seconds 1-9) and 382-394 in main_4 from second 3 (309-315 in seconds 1-2), with 0-15 local timeouts per second, until the clients stop.
- **main_2.** 222-255 proposals per second in seconds 0-2, 179 in second 3, then 7 / 6 / 5 / 6 / 6 in seconds 4-8 with 27 and 21 local timeouts in seconds 4 and 5, and 187 in second 9. The stall covers views 896-925 (30 views) from 3,680 ms to 8,593 ms after the clients started, 4,913 ms, i.e. 164 ms per view, against a mean of 2.7 ms (main, main_3, main_4) and 5.0 ms (main_2) for a standard view. The proposals of 29 of the 31 views 897-927 come at least 100 ms after the previous proposal (largest gap 421 ms, at view 925). The client reports 60 command timeouts between 4,169 ms and 9,092 ms.
- **main_3.** A shorter disturbance in seconds 7 and 8: 307 and 305 proposals per second with 33 and 13 local timeouts and 23 and 12 TCs (steady state: 0-12 and 0-4).
- **Drain (seconds 10-12).** The clients have stopped, so leaders cannot build proposals (`no command batch`) and every view ends by timeout: 71-81 local timeouts and 79-87 TCs in second 10 of main, main_3 and main_4, falling to 15-18 local timeouts in second 11 and 5-6 in second 12.

## Part 3 · Vote collection in the same view

The vote-collection pattern of a view repeats only where the leader rotation fixes it: the collector is first and the proposer second. Which replica is last, which one is left out of the QC and which views get a late vote do not recur across runs.

**Which replica is last in the same view** (complete sequences collector, proposer, X, Y; chance is 50%):

| run A | run B | Views compared | Same last sender | Agreement | p (binomial vs 50%) |
| :--- | :--- | ---: | ---: | ---: | ---: |
| main | main_2 | 1,045 | 551 | 52.7% | 0.0832 |
| main | main_3 | 3,500 | 1,745 | 49.9% | 0.879 |
| main | main_4 | 3,555 | 1,791 | 50.4% | 0.663 |
| main_2 | main_3 | 1,050 | 536 | 51.0% | 0.517 |
| main_2 | main_4 | 1,045 | 515 | 49.3% | 0.665 |
| main_3 | main_4 | 3,523 | 1,690 | 48.0% | 0.0167 |

All four runs agree on the last sender in 135 of 1,017 views (13.3%); independent fair coins give 12.5% (127 views), binomial p = 0.448. Only main_3 against main_4 (48.0%, p = 0.017) falls below 0.05; it is one of six comparisons.

**Collector first, proposer second.** Over the complete sequences of the shared views, 4,359 follow this order and 59 do not.

**Which replica is left out of the QC of the same view** (the 4th, late voter):

| run A | run B | Views compared | Same excluded replica | Agreement | Expected if independent |
| :--- | :--- | ---: | ---: | ---: | ---: |
| main | main_2 | 1,108 | 480 | 43.3% | 42.2% |
| main | main_3 | 3,596 | 1,594 | 44.3% | 42.8% |
| main | main_4 | 3,656 | 1,554 | 42.5% | 42.5% |
| main_2 | main_3 | 1,108 | 471 | 42.5% | 42.9% |
| main_2 | main_4 | 1,108 | 478 | 43.1% | 42.4% |
| main_3 | main_4 | 3,596 | 1,533 | 42.6% | 42.6% |

**Views with a late 4th vote** ('block too old'), in run A, in run B and in both, against the overlap expected if independent:

| run A | run B | Shared views | Late vote in A | in B | In both | Expected in both |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: |
| main | main_2 | 1,116 | 315 | 399 | 107 | 112.6 |
| main | main_3 | 3,601 | 965 | 976 | 269 | 261.5 |
| main | main_4 | 3,656 | 972 | 900 | 250 | 239.3 |
| main_2 | main_3 | 1,116 | 399 | 311 | 102 | 111.2 |
| main_2 | main_4 | 1,116 | 399 | 271 | 97 | 96.9 |
| main_3 | main_4 | 3,601 | 976 | 885 | 237 | 239.9 |

Reading: the recurring part is structural (collector and proposer are functions of the view number). Everything that depends on timing is independent between runs: the last sender agrees in 48.0-52.7% of the views, the excluded replica in 42.5-44.3% (expected 42.2-42.9%), and the late-vote overlaps (97-269 observed against 96.9-261.5 expected) are within 9% of the expectation in every pair.

## Part 3 · View number alone or view number and proposer

Matching by view number and matching by (view number, proposer) give identical results in every row, because the proposer is a function of the view number: replica (view mod 4) + 1.

Both matchings were run on the same data. Shared views whose proposer differs between runs: 0; blocks whose proposer is not leader(view): 0; views with two different proposals in one run: 0.

| Measure | match by view number | match by (view number, proposer) |
| :--- | ---: | ---: |
| views / keys present in all four runs | 1,119 | 1,119 |
| ... first seen in the active phase in all four | 1,116 | 1,116 |
| core counts identical in all four runs | 1,065 | 1,065 |
| class S/L/D (standard core) in all four runs | 1,009 | 1,009 |
| class T (timeout-type events) in >=1 run | 90 | 90 |
| class T in all four runs | 1 | 1 |
| views / keys with timeout-type events in all four runs (active) | 1 | 1 |
| pairwise comparisons of the last vote sender (pairs of runs x views) | 13,718 | 13,718 |
| ... pairs with the same last sender | 6,828 | 6,828 |

What the proposer does explain is the vote order: the receiver of the votes of view v is the next leader (the collector, first in 100% of the sequences) and the second vote is the proposer's (99.12%). Grouping the active views by proposer adds one dimension; the shares of timeout, late-vote and standard views per proposer:

| run | proposer | Views led (active) | T % | L or D % | N or F % | S % |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: |
| main | hs1 | 921 | 1.7% | 25.8% | 0.1% | 72.3% |
| main | hs2 | 922 | 1.5% | 26.0% | 0.2% | 72.2% |
| main | hs3 | 922 | 1.1% | 29.4% | 0.3% | 69.2% |
| main | hs4 | 921 | 2.5% | 25.6% | 0.0% | 71.9% |
| main_2 | hs1 | 279 | 3.6% | 31.2% | 0.7% | 64.5% |
| main_2 | hs2 | 279 | 4.3% | 36.9% | 1.4% | 57.3% |
| main_2 | hs3 | 279 | 3.6% | 37.6% | 0.7% | 58.1% |
| main_2 | hs4 | 279 | 2.9% | 38.7% | 1.1% | 57.3% |
| main_3 | hs1 | 900 | 1.4% | 25.7% | 0.0% | 72.9% |
| main_3 | hs2 | 901 | 1.8% | 27.7% | 0.1% | 70.4% |
| main_3 | hs3 | 900 | 1.7% | 27.7% | 0.1% | 70.6% |
| main_3 | hs4 | 900 | 1.8% | 26.3% | 0.0% | 71.9% |
| main_4 | hs1 | 914 | 1.6% | 24.7% | 0.2% | 73.4% |
| main_4 | hs2 | 914 | 1.3% | 26.3% | 0.3% | 72.1% |
| main_4 | hs3 | 914 | 1.8% | 24.1% | 0.2% | 74.0% |
| main_4 | hs4 | 914 | 2.0% | 22.8% | 0.0% | 75.3% |

Homogeneity of the four proposers (chi-square, df = 3; indicative, events cluster):

| run | Event | Views by proposer hs1 / hs2 / hs3 / hs4 | Views led hs1 / hs2 / hs3 / hs4 | chi2 (df 3) | p |
| :--- | :--- | ---: | ---: | ---: | ---: |
| main | timeout-type events | 16/14/10/23 | 921/922/922/921 | 5.65 | 0.13 |
| main | late 4th vote | 238/240/271/236 | 921/922/922/921 | 3.31 | 0.346 |
| main_2 | timeout-type events | 10/12/10/8 | 279/279/279/279 | 0.80 | 0.849 |
| main_2 | late 4th vote | 87/103/105/108 | 279/279/279/279 | 2.63 | 0.453 |
| main_3 | timeout-type events | 13/16/15/16 | 900/901/900/900 | 0.40 | 0.941 |
| main_3 | late 4th vote | 231/250/249/237 | 900/901/900/900 | 1.05 | 0.789 |
| main_4 | timeout-type events | 15/12/16/18 | 914/914/914/914 | 1.23 | 0.746 |
| main_4 | late 4th vote | 226/240/220/208 | 914/914/914/914 | 2.38 | 0.498 |

No proposer stands out: the smallest p-value is 0.13 (timeout views in main, 10-23 views per proposer). Using the proposer therefore changes neither the similarities (95.4% identical core counts), nor the differences (timeout views, late votes), nor the vote-order patterns (Section 'Vote collection in the same view'). The vote-order tables of Part 2 are already split by collector, which is the split by proposer (collector = proposer + 1): collector first in 100%, proposer second in 99.12%, last place divided 46.4-53.4% between the two other replicas.

## Part 3 · Verification commands

Views per run, views shared by several runs (run in the folder of the logs; the output reproduces 'Which views exist'):

```bash
W=$(mktemp -d)
for r in main main_2 main_3 main_4; do
  grep -E 'Received proposal|TryCommit:' $r.log | grep -oE 'proposer: [0-9]+, view: [0-9]+' | sed -E 's/.*view: //' | sort -un | awk '$1>=1' > $W/$r.views
  echo "$r: $(wc -l < $W/$r.views) views, $(head -1 $W/$r.views)..$(tail -1 $W/$r.views)"
done
cat $W/*.views | sort -n | uniq -c | awk '{ n[$1]++ } END { for (k = 4; k >= 1; k--) print k " runs: " n[k] " views" }'
# main: 3688 views, 1..3688   main_2: 1119 views, 1..1119   main_3: 3603 views, 1..3603   main_4: 3659 views, 1..3659
# 4 runs: 1119 views   3 runs: 2484 views   2 runs: 56 views   1 runs: 29 views
```

Views with `OnLocalTimeout: V` in the active phase and the view that all four runs share:

```bash
W=$(mktemp -d)
for r in main main_2 main_3 main_4; do
  STOP=$(grep -n 'Stopping clients\.\.\.' $r.log | head -1 | cut -d: -f1)
  head -n $((STOP-1)) $r.log | grep -E 'OnLocalTimeout: [0-9]+$' | sed -E 's/.*OnLocalTimeout: //' | sort -un > $W/$r.lto
  echo "$r: $(wc -l < $W/$r.lto) views"
done
sort -n $W/*.lto | uniq -c | awk '$1==4 { print "view in all four runs:", $2 }'
# main: 63   main_2: 40   main_3: 60   main_4: 61   view in all four runs: 3
```

The proposer is a function of the view number (all four logs together):

```bash
cat main.log main_2.log main_3.log main_4.log | grep -E 'Received proposal|TryCommit:' | grep -oE 'proposer: [0-9]+, view: [0-9]+' | sort -u |
  awk '{ p=$2; sub(",","",p); v=$4; n++; if (p != (v % 4) + 1) bad++ } END { print n " distinct (proposer, view) pairs, " bad+0 " with proposer != (view mod 4)+1" }'
# 3688 distinct (proposer, view) pairs, 0 with proposer != (view mod 4)+1
```

The shipped `verify_views.sh` re-derives the view sets, the shared views, the timeout views, their pairwise overlaps and the proposer rule with grep, sed, sort and comm; `compare_views.py` compares its 33 values with the Python results: 33 compared, 0 mismatches. The class table, the view durations, the burst statistics and the per-second timeline come from `part3_views.py` only; they are not recomputed in shell.

## Part 4 · The expected chain, step by step

The expected chain holds in every tested view of main and main_4, in 99.9% of main_3 and in 99.1% of main_2; every exception is a timeout that wins the race against the QC (next section).

**How the events were matched.** Event order is the physical line order of the log: all four replicas write to one file, and the 1 ms timestamps are not used for ordering. A block is identified by its hash. The vote itself is not logged; the collector's `CollectVote(from s): H` line is its receipt, and the vote still has to be verified before it counts. Views 3 to last-1 of the active phase were tested (3,684 / 1,114 / 3,599 / 3,654 views); receiver and vote checks count one replica in one view. Each cell is passed / tested:

| # | Step of the expected ordering | Check on the log lines | main | main_2 | main_3 | main_4 |
| :--- | :--- | :--- | ---: | ---: | ---: | ---: |
| 1 | Proposal B_v carries the QC of its parent | `cert` QC of every proposal has the view of the block named as `parent` (table 'Block fields' in the section 'Part 4 · View entry, commit rule and block fields') | 3,688 / 3,688 | 1,119 / 1,119 | 3,603 / 3,603 | 3,659 / 3,659 |
| 2 | The proposer builds B_v first | proposer's `TryCommit(B_v)` and `Advanced to view v` precede the first `Received proposal` of B_v (O1, O2) | 3,684 / 3,684 | 1,113 / 1,113 | 3,599 / 3,599 | 3,654 / 3,654 |
| 3 | A replica that receives the proposal processes the attached QC | next `advanceView: { QC{...} }` after `Received proposal` carries exactly the QC attached to B_v (O3), per receiver and view | 11,052 / 11,052 | 3,339 / 3,339 | 10,797 / 10,797 | 10,962 / 10,962 |
| 4 | ...before it votes | that `advanceView` precedes the receiver's `TryCommit(B_v)` (O4); the others were rejected by `failed to verify incoming vote: block view N too old`, no vote | 11,051 / 11,052 (1 rejected) | 3,326 / 3,339 (13 rejected) | 10,795 / 10,797 (2 rejected) | 10,962 / 10,962 |
| 5 | A vote is collected only after it was cast | every `CollectVote(from s): H` follows the `TryCommit` of H by replica s (O6) | 14,771 / 14,771 | 4,482 / 4,482 | 14,420 / 14,420 | 14,639 / 14,639 |
| 6 | A replica that voted is heard by the collector | every `TryCommit(B_v)` has a `CollectVote(from s)` for B_v at the collector (O6b); the exceptions timed out right after voting | 14,734 / 14,735 | 4,440 / 4,440 | 14,393 / 14,394 | 14,616 / 14,616 |
| 7 | A QC needs a quorum | a dispatch `CollectVote: dispatching event for new view` exists only after 3 distinct `CollectVote` lines for B_v (O7); the others got fewer | 3,684 / 3,684 | 1,109 / 1,114 (5 without QC) | 3,598 / 3,599 (1 without QC) | 3,654 / 3,654 |
| 8 | QC_v is built from collected votes | `QC_v.IDs` has 3 distinct replicas, each with a `CollectVote` line before the dispatch (O8); QC never printed in a later block: n/a | 3,684 / 3,684 | 1,106 / 1,109 (3 n/a) | 3,594 / 3,598 (4 n/a) | 3,654 / 3,654 |
| 9 | A late vote is not in the QC | every `CollectVote` line after the dispatch is from a replica outside `QC_v.IDs` (O8b); inside: 0 in all runs | 3,684 / 3,684 (1,143 views with late votes) | 1,106 / 1,106 (445 views with late votes) | 3,594 / 3,594 (1,118 views with late votes) | 3,654 / 3,654 (1,033 views with late votes) |
| 10 | The QC reaches HighQC and moves the collector to v+1 | dispatch, `OnNewView`, `advanceView: { QC_v }`, `HighQC` updated, `Advanced to view v+1` in this order at the collector (O9) | 3,684 / 3,684 | 1,104 / 1,109 | 3,594 / 3,598 | 3,654 / 3,654 |
| 11 | The next leader proposes B_(v+1) with QC_v | `TryCommit(B_(v+1))` right after that advance, proposer = collector, `cert` = QC_v (same hash and IDs) (O10) | 3,684 / 3,684 | 1,104 / 1,109 | 3,594 / 3,598 | 3,654 / 3,654 |

**What the attached QC does at the receiver.** For every proposal that passed check 4, the attached parent QC either raises HighQC (and the replica enters view v) or is already known:

| Effect of the attached QC at the receiver (O5) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| HighQC updated, then `Advanced to view v`, then the vote (`TryCommit`) | 11,038 | 3,282 | 10,764 | 10,953 |
| HighQC updated; the replica had entered v earlier through a timeout certificate | 13 | 24 | 16 | 8 |
| HighQC not updated (QC already known); entered v earlier through a timeout certificate | 0 | 19 | 15 | 0 |
| HighQC not updated (QC already known); entered v earlier through another proposal | 0 | 1 | 0 | 1 |
| Receivers tested (proposal passed O4) | 11,051 | 3,326 | 10,795 | 10,962 |

A receiver that was already in view v when the proposal arrived had entered it earlier, in nearly all cases through a timeout certificate (`OnRemoteTimeout (second advance)`); this is rare (13 / 24 / 16 / 8 updates and 0 / 20 / 15 / 1 'not updated' cases). In all other cases, 11,038 / 3,282 / 10,764 / 10,953, the order is exactly QC, HighQC update, advance, vote.

**One complete chain from the log** (main.log, view 1000, lines 54858-54912; proposer hs1, receivers hs2 and hs3, collector hs2; the lines of hs4 and the lines of other event types are left out; columns: line number, replica, message):

```
  54858  hs1  TryCommit: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54865  hs2  Received proposal: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54866  hs2  advanceView: { QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54873  hs3  Received proposal: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54876  hs3  advanceView: { QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54877  hs2  advanceView: Successfully updated HighQC
  54878  hs2  advanceView: Advanced to view 1000
  54879  hs1  OnNewView (from network: false)
  54880  hs2  TryCommit: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54881  hs1  advanceView: { QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54883  hs1  advanceView: HighQC not updated, current view: 1000, new view: 999
  54888  hs3  advanceView: Successfully updated HighQC
  54889  hs3  advanceView: Advanced to view 1000
  54890  hs1  OnNewView (from network: false)
  54891  hs1  advanceView: { QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54892  hs2  CollectVote(from 2): qXCyTpwu
  54893  hs3  TryCommit: Block{ hash: qXCyTpwu parent: 6qBgPYcc, proposer: 1, view: 1000 , cert: QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54894  hs1  advanceView: HighQC not updated, current view: 1000, new view: 999
  54895  hs2  CollectVote(from 1): qXCyTpwu
  54898  hs2  CollectVote(from 4): qXCyTpwu
  54903  hs1  OnNewView (from network: false)
  54904  hs1  advanceView: { QC{ hash: 6qBgPYcc, view: 999, IDs: [ 1 4 3 ] } }
  54905  hs1  advanceView: HighQC not updated, current view: 1000, new view: 999
  54906  hs2  CollectVote: dispatching event for new view (current : 1000)
  54907  hs2  CollectVote(from 3): qXCyTpwu
  54908  hs2  OnNewView (from network: false)
  54909  hs2  advanceView: { QC{ hash: qXCyTpwu, view: 1000, IDs: [ 2 4 1 ] } }
  54910  hs2  advanceView: Successfully updated HighQC
  54911  hs2  advanceView: Advanced to view 1001
  54912  hs2  TryCommit: Block{ hash: q3IX1Jg5 parent: qXCyTpwu, proposer: 2, view: 1001 , cert: QC{ hash: qXCyTpwu, view: 1000, IDs: [ 2 4 1 ] } }
```

Reading: hs1 proposes B_1000 with `cert` QC_999 (54858); hs2 and hs3 receive it (54865, 54873), process QC_999 (54866, 54876), update HighQC (54877, 54888), enter view 1000 (54878, 54889) and vote (`TryCommit` 54880, 54893). The collector hs2 receives the votes from 2, 1, 4 and 3 (54892, 54895, 54898, 54907); the QC dispatch (54906, `current : 1000`) follows the third distinct vote line, and the 4th vote line (from 3, 54907) comes after it. `OnNewView` carries QC_1000 (54908-54909), HighQC is updated (54910), hs2 advances to view 1001 (54911) and proposes B_1001 with `cert` QC_1000 (54912). QC_1000 lists its voters as [ 2 4 1 ] although the vote lines arrived as 2, 1, 4: the processing order differs from the arrival order (Part 2), and the late voter 3 is not in the QC. The three `OnNewView` lines of hs1 (54879, 54890, 54903) each process QC_999 again and leave HighQC unchanged (`HighQC not updated`); they are not part of the chain.

## Part 4 · Where the chain breaks: a timeout wins the race

In 15 views (10 in main_2, 5 in main_3) the chain breaks, always because timeouts took over before the QC was used; main and main_4 have no broken view. The other exceptions in the checks above concern a single replica: 16 proposals rejected as too old (check 4) and 2 votes missing at the collector after a local timeout (check 6).

Every view of the tested range is put in one of three classes:

| Class of view v (collector chain) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| N · complete chain: dispatch, `OnNewView`, `advanceView(QC_v)`, HighQC updated, `Advanced to view v+1`, `TryCommit(B_(v+1))` with QC_v | 3,684 | 1,104 | 3,594 | 3,654 |
| L · QC_v formed (dispatch logged) but a timeout or TC advance won the race | 0 | 5 | 4 | 0 |
| X · fewer than 3 distinct `CollectVote` lines: no QC for B_v | 0 | 5 | 1 | 0 |
| Views tested | 3,684 | 1,114 | 3,599 | 3,654 |
| Share of class N | 100.00% | 99.10% | 99.86% | 100.00% |
| Blocks whose parent is not the block of view v-1 (view gap) | 0 | 10 | 5 | 0 |
| These blocks are exactly B_(v+1) of the views of class L or X | yes | yes | yes | yes |

Counting every QC dispatch of the active phase, the collector chain is complete after 3,685 / 1,105 / 3,595 / 3,656 dispatches and broken after 0 / 5 / 4 / 0; no dispatch occurs without three distinct vote lines before it.

| Collector chain after a dispatch (all active-phase dispatch lines, views 1-2 and the last view included) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| Collector chain complete | 3,685 | 1,105 | 3,595 | 3,656 |
| Collector chain broken | 0 | 5 | 4 | 0 |
| Dispatch without 3 distinct vote lines before it | 0 | 0 | 0 | 0 |
| QC dispatch lines in the active phase | 3,685 | 1,110 | 3,599 | 3,656 |

**The 15 broken views.** `CollectVote senders` lists the replica ids in the order of the `CollectVote` lines (2143 = votes from 2, 1, 4, 3). `Local timeout at` lists the replicas that logged `OnLocalTimeout: V`, `TC formed at` the replicas that logged `OnRemoteTimeout (second advance)` for the view (1234 = hs1 to hs4):

| Run | View v | Class | Collector | CollectVote senders in line order | Local timeout at hs | TC formed at hs | Collector entered v+1 by | B_(v+1) proposer | B_(v+1) carries QC of view |
| :--- | ---: | :--- | :--- | :--- | :--- | :--- | :--- | :--- | ---: |
| main_2 | 896 | L | hs2 | 2143 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs2 | 895 |
| main_2 | 897 | X | hs3 | 2 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs3 | 895 |
| main_2 | 898 | X | hs4 | 32 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs4 | 896 |
| main_2 | 900 | X | hs2 | 13 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs2 | 899 |
| main_2 | 901 | X | hs3 | 21 | 234 | 1234 | REMOTE_TIMEOUT_2ND | hs3 | 899 |
| main_2 | 903 | L | hs1 | 1432 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs1 | 902 |
| main_2 | 904 | X | hs2 | 1 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs2 | 902 |
| main_2 | 905 | L | hs3 | 321 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs3 | 903 |
| main_2 | 907 | L | hs1 | 1423 | 124 | 1234 | REMOTE_TIMEOUT_2ND | hs1 | 906 |
| main_2 | 913 | L | hs3 | 324 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs3 | 912 |
| main_3 | 2225 | L | hs3 | 3214 | 123 | 1234 | REMOTE_TIMEOUT_2ND | hs3 | 2224 |
| main_3 | 2667 | X | hs1 | 24 | 1234 | 1234 | ON_NEW_VIEW_OTHER | hs1 | 2666 |
| main_3 | 2680 | L | hs2 | 2143 | 1234 | 1234 | REMOTE_TIMEOUT_2ND | hs2 | 2679 |
| main_3 | 2968 | L | hs2 | 2134 | 134 | 1234 | ON_NEW_VIEW_OTHER | hs2 | 2967 |
| main_3 | 2975 | L | hs1 | 1423 | 124 | 1234 | REMOTE_TIMEOUT_2ND | hs1 | 2974 |

- **Timeouts at three or four replicas.** In all 15 views at least three replicas logged `OnLocalTimeout: V` and all four formed the timeout certificate; the collector entered v+1 through the TC (13 times `OnRemoteTimeout (second advance)`, twice an `OnNewView` that carried the TC, excerpt E3 in the 'Log excerpts' tab).
- **L: QC and TC at the same time.** The collector holds three votes and dispatches QC_v, but the TC advance is processed first, so the replica proposes B_(v+1) with the older QC. Excerpt E2 shows view 896 of main_2.
- **X: no QC.** Only 1 or 2 distinct votes arrived (view 897 of main_2: one vote, excerpt E4), so only the TC could move the view on.
- **Effect on the chain.** B_(v+1) extends the highest QC the collector knew (view v-1 or v-2 in the table), so its parent is not B_v. The set of blocks with a parent that is not the previous view is exactly the set of the blocks B_(v+1) above: 10 in main_2 and 5 in main_3 (table 'Block fields' in the section 'Part 4 · View entry, commit rule and block fields', below). B_v is left as a fork; `PruneToHeight: found forked block` is logged only in the two runs that have gap blocks (23 times in main_2, 19 in main_3, none in main and main_4), and some commit lines are missing (Section 'View entry, commit rule and block fields').

**Excerpt E2** (main_2.log, view 896, collector hs2; hs2 lines only): three votes arrive (49209-49222), hs2 times out (49232), the TC is formed (49279), hs2 advances to view 897 and proposes B_897 with QC_895 (49294, 49305), and QC_896 (IDs [ 2 1 4 ]) is processed only at line 49323, 29 lines after hs2 entered view 897.

```
  49209  hs2  CollectVote(from 2): fDl8NbsB
  49211  hs2  CollectVote(from 1): fDl8NbsB
  49222  hs2  CollectVote(from 4): fDl8NbsB
  49232  hs2  OnLocalTimeout: 896
  49238  hs2  OnRemoteTimeout (advancing view): ID: 2, View: 896, SyncInfo: { TC{ view: 0, IDs: [ ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49241  hs2  advanceView: { TC{ view: 0, IDs: [ ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49243  hs2  advanceView: HighQC not updated, current view: 896, new view: 895
  49244  hs2  OnRemoteTimeout: not enough timeouts for view 896, waiting for more
  49245  hs2  CollectVote(from 3): fDl8NbsB
  49254  hs2  CollectVote: dispatching event for new view (current : 896)
  49255  hs2  OnRemoteTimeout (advancing view): ID: 4, View: 896, SyncInfo: { TC{ view: 0, IDs: [ ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49257  hs2  advanceView: { TC{ view: 0, IDs: [ ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49258  hs2  advanceView: HighQC not updated, current view: 896, new view: 895
  49259  hs2  OnRemoteTimeout: not enough timeouts for view 896, waiting for more
  49270  hs2  OnRemoteTimeout (advancing view): ID: 1, View: 896, SyncInfo: { TC{ view: 0, IDs: [ ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49272  hs2  advanceView: { TC{ view: 0, IDs: [ ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49278  hs2  advanceView: HighQC not updated, current view: 896, new view: 895
  49279  hs2  OnRemoteTimeout (second advance)
  49280  hs2  advanceView: { TC{ view: 896, IDs: [ 2 4 1 ] } QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49293  hs2  advanceView: HighQC not updated, current view: 896, new view: 895
  49294  hs2  advanceView: Advanced to view 897
  49305  hs2  TryCommit: Block{ hash: nV+NRgFy parent: pNKe9YmS, proposer: 2, view: 897 , cert: QC{ hash: pNKe9YmS, view: 895, IDs: [ 1 3 4 ] } }
  49314  hs2  OnNewView (from network: false)
  49323  hs2  advanceView: { QC{ hash: fDl8NbsB, view: 896, IDs: [ 2 1 4 ] } }
```

## Part 4 · View entry, commit rule and block fields

Views advance by exactly one, blocks name the QC of their parent, and a DECIDE is logged exactly when three certified blocks sit in consecutive views.

**How replicas enter views.** Every `advanceView: Advanced to view N` after a replica's first, by what led to it (active phase / drain):

| Trigger of every `Advanced to view N` (after the replica's first); active / drain | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| `Received proposal` (receivers, next proposal) | 11,037 / 8 | 3,285 / 9 | 10,761 / 9 | 10,954 / 9 |
| `OnNewView` after the replica's own QC dispatch (collector) | 3,684 / 3 | 1,104 / 4 | 3,594 / 3 | 3,655 / 3 |
| `OnRemoteTimeout (second advance)`: timeout certificate | 13 / 110 | 67 / 20 | 36 / 107 | 8 / 111 |
| `OnRemoteTimeout (advancing view)` | 0 / 0 | 0 / 3 | 0 / 0 | 0 / 0 |
| `OnNewView` carrying a TC (no dispatch of its own) | 0 / 1 | 0 / 0 | 2 / 0 | 0 / 0 |
| Total | 14,734 / 122 | 4,456 / 36 | 14,393 / 119 | 14,617 / 123 |
| View step +1 / +2 / +3 / more (all phases) | 14,856 / 0 / 0 / 0 | 4,492 / 0 / 0 / 0 | 14,512 / 0 / 0 / 0 | 14,740 / 0 / 0 / 0 |
| Advances that do not increase the view | 0 | 0 | 0 | 0 |

In the active phase the collector enters v+1 through its own QC and the three other replicas through the next proposal, which is 4 entries per view (14,734 / 4,456 / 14,393 / 14,617 entries in the active phase). Entries through a timeout certificate are 13 / 67 / 36 / 8 in the active phase and 110 / 20 / 107 / 111 in the drain, where no proposals are made. All 14,856 / 4,492 / 14,512 / 14,740 entries are steps of exactly +1: there is no jump and no step backwards.

**Commit rule against consecutive views.** In the log, each `TryCommit(B_v)` is followed by `PRE_COMMIT` for the block b1 that B_v's QC certifies (its parent); `COMMIT` is logged for b2, the parent of b1, when its view is higher than that of the highest earlier COMMIT; `DECIDE` is logged for b3, the parent of b2, when b1, b2 and b3 are in consecutive views. For every TryCommit with a known three-chain:

| Every `TryCommit(B_v)` with a known three-chain (all phases) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| b1, b2, b3 in consecutive views, `DECIDE` logged | 14,743 | 4,408 | 14,362 | 14,628 |
| b1, b2, b3 in consecutive views, `DECIDE` missing | 0 | 0 | 0 | 0 |
| not consecutive, `DECIDE` logged | 0 | 0 | 0 | 0 |
| not consecutive, `DECIDE` not logged | 0 | 44 | 40 | 0 |

The 44 (main_2) and 40 (main_3) TryCommits without `DECIDE` are exactly those whose chain is not consecutive; there is no DECIDE without a consecutive chain and no consecutive chain without DECIDE in any run (0 violations). The non-consecutive chains come from the gap blocks of the previous section:

| Run | Gaps (B_v to b1, b1 to b2, b2 to b3) | Commit-rule lines logged after `TryCommit(B_v)` (x = number of such TryCommits, replica by view) |
| :--- | :--- | :--- |
| main_2 | (1, 1, 2) | PRE_COMMIT + COMMIT x8 |
| main_2 | (3, 1, 1) | PRE_COMMIT + COMMIT + DECIDE x4; PRE_COMMIT + DECIDE x2 |
| main_2 | (1, 3, 1) | PRE_COMMIT + COMMIT x6 |
| main_2 | (2, 3, 1) | PRE_COMMIT x5; PRE_COMMIT + COMMIT x1 |
| main_2 | (2, 1, 1) | PRE_COMMIT + DECIDE x4; PRE_COMMIT + COMMIT + DECIDE x1 |
| main_2 | (3, 3, 1) | PRE_COMMIT x3; PRE_COMMIT + COMMIT x1 |
| main_2 | (1, 3, 3) | PRE_COMMIT + COMMIT x4 |
| main_2 | (3, 1, 3) | PRE_COMMIT + COMMIT x4 |
| main_2 | (1, 2, 3) | PRE_COMMIT + COMMIT x4 |
| main_2 | (1, 2, 1) | PRE_COMMIT + COMMIT x4 |
| main_2 | (3, 3, 3) | PRE_COMMIT x3 |
| main_2 | (2, 3, 3) | PRE_COMMIT x1 |
| main_3 | (2, 1, 1) | PRE_COMMIT + DECIDE x18; PRE_COMMIT + COMMIT + DECIDE x2 |
| main_3 | (1, 2, 1) | PRE_COMMIT + COMMIT x20 |
| main_3 | (1, 1, 2) | PRE_COMMIT + COMMIT x20 |

The first TryCommits of every run (views 1-3) have an incomplete chain and log PRE_COMMIT only. With gaps (2, 1, 1) or (3, 1, 1) the gap sits between B_v and b1, so b1, b2, b3 are consecutive and DECIDE is logged; with a gap anywhere in b1, b2, b3 (for example (1, 2, 1)) DECIDE is missing. COMMIT needs the view of b2 to exceed the view of the highest block committed before; after a fork this does not always hold, which is why some rows have PRE_COMMIT only. Execution follows the decided blocks: all four replicas execute the same hash sequence in every run (3,685 / 1,108 / 3,595 / 3,656 `EXEC` lines per replica; the genesis block is decided once and never executed).

**Block fields.** A proposal carries the QC of its parent:

| Block fields | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| Distinct blocks in the log (the genesis block included) | 3,689 | 1,120 | 3,604 | 3,660 |
| Blocks whose `parent` hash equals the `cert` QC hash | 3,689 | 1,120 | 3,604 | 3,660 |
| Blocks whose `cert` lists 3 distinct signers (all but the genesis block and the view-1 block) | 3,687 | 1,118 | 3,602 | 3,658 |
| Proposals whose `cert` QC view equals the view of the parent block | 3,688 / 3,688 | 1,119 / 1,119 | 3,603 / 3,603 | 3,659 / 3,659 |
| View distance to the parent: 1 / 2 / 3 / more | 3,688 / 0 / 0 / 0 | 1,109 / 5 / 5 / 0 | 3,598 / 5 / 0 / 0 | 3,659 / 0 / 0 / 0 |

**Stage latencies** inside the views of class N (log timestamps, resolution 1 ms):

| Stage (median / p90 / max, ms) | main | main_2 | main_3 | main_4 |
| :--- | ---: | ---: | ---: | ---: |
| Proposer `TryCommit(B_v)` to first `Received proposal` | 1.0 / 1 / 5 | 1.0 / 2 / 273 | 1.0 / 1 / 15 | 1.0 / 1 / 7 |
| `Received proposal` to `TryCommit(B_v)` at the receiver | 1.0 / 1 / 10 | 1.0 / 2 / 46 | 1.0 / 1 / 14 | 1.0 / 1 / 7 |
| Voter's `TryCommit(B_v)` to its `CollectVote` line at the collector | 1.0 / 2 / 11 | 1.0 / 4 / 333 | 1.0 / 2 / 31 | 1.0 / 2 / 13 |
| Collector's `TryCommit(B_v)` to its own `CollectVote` line | 0.0 / 1 / 9 | 0.0 / 1 / 36 | 0.0 / 1 / 8 | 0.0 / 1 / 5 |
| 3rd distinct `CollectVote` line to the QC dispatch | 0.0 / 1 / 3 | 0.0 / 1 / 44 | 0.0 / 1 / 5 | 0.0 / 1 / 5 |
| QC dispatch to `Advanced to view v+1` at the collector | 0.0 / 1 / 9 | 1.0 / 1 / 70 | 0.0 / 1 / 13 | 0.0 / 1 / 8 |
| `Advanced to view v+1` to `TryCommit(B_(v+1))` at the collector | 0.0 / 1 / 4 | 0.0 / 1 / 86 | 0.0 / 1 / 14 | 0.0 / 1 / 6 |
| Whole cycle: `TryCommit(B_v)` at the proposer to `TryCommit(B_(v+1))` at the collector | 3.0 / 4 / 13 | 4.0 / 7 / 421 | 3.0 / 4 / 39 | 3.0 / 4 / 15 |

A whole cycle takes a median 3 ms (4 ms in main_2) and 4 ms at the 90th percentile (7 ms in main_2); every single stage has a median of 0-1 ms. The longest cycles are 13 / 421 / 39 / 15 ms; main_2's 421 ms lies at the end of the stall window (the proposal of view 925).

## Part 4 · Verification commands

Every proposal carries the QC of its parent (`parent` hash = `cert` hash), and the view distance between a block and the QC it carries (run in the folder of the logs):

```bash
for f in main main_2 main_3 main_4; do
  grep -hE 'TryCommit: Block|Received proposal: Block' $f.log | grep -oE 'Block\{ hash: [^ ]+ parent: [^,]+, proposer: [0-9]+, view: [0-9]+ , cert: QC\{ hash: [^,]+' | sort -u |
    awk -v f=$f '{ p=$5; sub(/,$/,"",p); n++; if (p==$NF) ok++ } END { print f ": blocks=" n, "parent==cert=" ok+0 }'
  grep -hE 'TryCommit: Block|Received proposal: Block' $f.log | grep -oE 'view: [0-9]+ , cert: QC\{ hash: [^,]+, view: [0-9]+' | sort -u |
    awk '{ h[$2-$NF]++ } END { printf "  view distance to the QC:"; for (g in h) printf " %s:%d", g, h[g]; print "" }'
done
# main: blocks=3688 parent==cert=3688        distance 1:3688
# main_2: blocks=1119 parent==cert=1119      distance 3:5 2:5 1:1109
# main_3: blocks=3603 parent==cert=3603      distance 2:5 1:3598
# main_4: blocks=3659 parent==cert=3659      distance 1:3659
```

The blocks with a gap, which are the blocks B_(v+1) of the broken views:

```bash
grep -hE 'TryCommit: Block|Received proposal: Block' main_2.log | grep -oE 'view: [0-9]+ , cert: QC\{ hash: [^,]+, view: [0-9]+' | sort -u |
  awk '$2-$NF != 1 { print "block view " $2 " carries QC of view " $NF }' | sort -k3n
# block views 897 (QC 895), 898 (895), 899 (896), 901 (899), 902 (899), 904 (902), 905 (902), 906 (903), 908 (906), 914 (912)
# the same command on main_3.log: 2226 (2224), 2668 (2666), 2681 (2679), 2969 (2967), 2976 (2974)
```

Votes are collected only after the voter's own `TryCommit` of the same block (all `CollectVote` lines of a log, all phases):

```bash
for f in main main_2 main_3 main_4; do
  awk -F'\t' '
    $5 ~ /^TryCommit: Block\{/ { h=$5; sub(/^TryCommit: Block\{ hash: /,"",h); sub(/ .*/,"",h); r=$3; sub(/hs/,"",r); if (!((h,r) in t)) t[h,r]=NR }
    $5 ~ /^CollectVote\(from [0-9]+\): / { s=$5; sub(/^CollectVote\(from /,"",s); sub(/\).*/,"",s); h=$5; sub(/^.*: /,"",h); n++; if (((h,s) in t) && t[h,s] < NR) ok++ }
    END { printf "%s: %d CollectVote lines, %d after the sender'"'"'s own TryCommit of the same block\n", FILENAME, n, ok }' $f.log
done
# main.log: 14787 / 14787   main_2.log: 4502 / 4502   main_3.log: 14436 / 14436   main_4.log: 14659 / 14659
```

QC dispatches of the active phase and the commit-rule lines per run:

```bash
for f in main main_2 main_3 main_4; do
  STOP=$(grep -n 'Stopping clients\.\.\.' $f.log | head -1 | cut -d: -f1)
  printf '%s dispatch(active)=%s TryCommit=%s PRE_COMMIT=%s COMMIT=%s DECIDE=%s\n' $f "$(head -n $((STOP-1)) $f.log | grep -c 'CollectVote: dispatching event for new view')" \
    "$(grep -c 'TryCommit: Block' $f.log)" "$(grep -c 'CommitRule - PRE_COMMIT' $f.log)" "$(grep -c 'CommitRule - COMMIT' $f.log)" "$(grep -c 'CommitRule - DECIDE' $f.log)"
done
# main   dispatch(active)=3685 TryCommit=14751 PRE_COMMIT=14751 COMMIT=14743 DECIDE=14743
# main_2 dispatch(active)=1110 TryCommit=4460  PRE_COMMIT=4460  COMMIT=4434  DECIDE=4408
# main_3 dispatch(active)=3599 TryCommit=14410 PRE_COMMIT=14410 COMMIT=14384 DECIDE=14362
# main_4 dispatch(active)=3656 TryCommit=14636 PRE_COMMIT=14636 COMMIT=14628 DECIDE=14628
```

The shipped `verify_order.sh` (awk only, `verify_order.awk`) re-computes the whole ordering analysis from the raw logs: checks O1-O10, the classes N / L / X, the gap blocks, the commit-rule check and the cycle times. `compare_order.py` compares its 243 values with the Python results (`part4_ordering.py`): 243 compared, 0 mismatches. Its summary line per run is `N=3684 L=0 X=0 of 3684 views` (main), `N=1104 L=5 X=5 of 1114` (main_2), `N=3594 L=4 X=1 of 3599` (main_3), `N=3654 L=0 X=0 of 3654` (main_4).

## Caveats and inferences

What the logs show is separated here from what is inferred. Counts, orders and quotes are facts of the logs; the points below are interpretation, limits of the method or open questions.

**Limits of the method**

- **One recording per configuration.** Each run was recorded once, on different dates (main 2026-06-22, main_2 2026-07-31, main_3 and main_4 2026-09-13). Differences between runs cannot be separated from run-to-run variance or from changes of code or machine load between recordings; the logs carry no version information beyond the banner. main, main_3 and main_4 act as an informal replicate set, and main_2 stands apart in most measures.
- **p-values are indicative.** Chi-square, binomial, Fisher, hypergeometric and runs tests assume independent events, but timeouts and late votes are clustered (Part 3, bursts). Of the 32 tests on the order of the last two votes, 3 fall below 0.05, about 1.6 expected by chance.
- **Order means line order.** All ordering claims are about the physical order of log lines. Timestamps (1 ms resolution) show inversions of up to 3 ms between replicas and are used only for durations.
- **Active and drain phases.** The boundary is the controller's first `Stopping clients...` line. The drain phase (2.5 s) behaves differently because leaders cannot build proposals; every count in the report is shown for the phase it belongs to where that matters.

**Inferences, not log facts**

- **Timer length.** `OnLocalTimeout: V` fires a median 7 ms after the replica entered the view in main, main_3 and main_4 (57 ms in main_2), against the 500 ms printed in the banner. The log does not print the effective timer; an adaptive timeout would explain it.
- **Mixed-view timeout certificates.** All 41 `Failed to verify sync info` lines with an ecdsa TC come from TCs whose signers' timeout messages are for different views, and no TC with consistent views failed (132 / 94 / 150 / 128 consistent TCs). That a stale per-replica cache of timeout messages builds the mixed TCs is an inference from the message contents.
- **Extra `OnNewView` lines.** Each view has about three more `OnNewView (from network: false)` lines than QC dispatches (hs1 in excerpt E1). They re-process the QC the replica already has (`HighQC not updated`); that replicas send their HighQC to the next leader is an inference.
- **Rejected proposals and votes.** Of the 13 proposals that main_2 rejected with `last voted view was M`, 11 have M equal to the proposal's view and follow a local timeout of the same replica in that view (`OnLocalTimeout: V` and `Stopped voting for timed out view V` precede the line; verified for all 11); that `Stopped voting for timed out view` sets the 'last voted view' is read from the message text. The other 2 (hs3, views 955 and 988) have M = view + 2 and no timeout: hs3 had already accepted the later block (`TryCommit` of view 957 at line 54590, of view 990 at line 56367) before the older proposal arrived. In the 2 cases where a replica logged `TryCommit` but no `CollectVote` line for its vote reached the collector (main view 41, main_3 view 2666), the replica logged `OnLocalTimeout` in that view after its `TryCommit`; that the timeout suppressed the vote is an inference.
- **Timeout delivery model.** The count of `OnRemoteTimeout (advancing view)` lines equals 4 x the local timeouts plus 3 x the repeated expiries exactly in two of the runs and is off by 1-2 in the other two; the model (every replica broadcasts its timeout to the other three) is not a log fact.
- **Forks.** That B_v of a broken view stays as a fork and is later pruned is consistent with `PruneToHeight: found forked block` appearing only in the two runs with gap blocks (23 and 19 times); the log does not link each prune to its block.

**Open questions**

- **Proposal reception order.** The next leader logs `Received proposal` last in 38% of the blocks and first in 18%, in all four runs; the log does not show why.
- **Late votes in main_2.** 34.5% of its views have a late 4th vote against 24.0-26.5% in the others; no log line explains it.
- **Stall of main_2.** The 30-view stall (views 896-925) is described by its counts (timeouts, TCs, forks, fetches, client timeouts), but the log does not show what started it.

## Verification summary

Every count in this report was computed twice, once by the Python analysis and once by an independent shell script that reads the raw logs, and the two were compared value by value:

| Script | Re-computes | Tools | Result against the Python analysis |
| :--- | :--- | :--- | :--- |
| `verify_counts.sh` | Part 1: 37 patterns x 4 runs x (total, active, drain), plus per-replica counts | grep -c, awk | 1,036 values against the Python regex counts and 444 against `part1.json`: 1,480 compared, 0 mismatches |
| `verify_votes.sh` | Part 2: complete sequences, first / last, positions, processed order, proposal reception | awk only | 581 non-zero metrics: 0 mismatches |
| `verify_views.sh` | Part 3: views per run, shared views, timeout views and their overlaps, proposer rule | grep, sed, sort, comm | 33 values: 0 mismatches |
| `verify_order.sh` | Part 4: checks O1-O10, classes N / L / X, gap blocks, commit rule, cycle times | awk only | 243 values: 0 mismatches |

The class table, the view durations, the burst statistics, the per-second timeline and all chi-square, binomial, Fisher, hypergeometric and runs tests exist only in the Python analysis (`part3_views.py`, `part2_votes.py`); the shell scripts check the counts, orders and view sets underneath them. The tables of this report were written from the result files by a generator (`report/`), not typed, and the numbers quoted in the text were checked against the same files.

The scripts are in the zip file delivered with this report. `run_all.sh LOGDIR` rebuilds all result files and runs the four comparisons; the README lists the environment variables (`HS_LOGDIR`, `HS_OUT`), the run order and the expected `0 mismatches` lines.
