# Log excerpts

Verbatim lines from the logs behind the findings of Part 4 and Part 2. E1 (a complete chain) and E2 (a TC wins the race) are in Part 4. Columns: physical line number, replica, message; lines of other event types and of other replicas are left out. The timestamps and source-file columns are in the logs.

## E3 · main_3.log, view 2968 (collector hs2): TC-driven advance to 2969 first, QC_2968 dispatched afterwards (dispatch prints current : 2969) - lines 162970-162998, hs2 only

hs2 collects votes from 2, 1 and 3 (162970-162972) while timeout messages arrive. An `OnNewView` that carries the TC for view 2968 moves hs2 to view 2969 (162977-162980). Only then is the QC dispatched (`current : 2969`, 162981), and hs2 proposes B_2969 with QC_2967, not QC_2968 (162982). QC_2968 (IDs [ 2 1 3 ]) is processed at 162995 and updates HighQC, but the view does not change.

```
 162970  hs2  CollectVote(from 2): 20K2ZNLO
 162971  hs2  CollectVote(from 1): 20K2ZNLO
 162972  hs2  CollectVote(from 3): 20K2ZNLO
 162973  hs2  OnRemoteTimeout (advancing view): ID: 3, View: 2968, SyncInfo: { TC{ view: 0, IDs: [ ] } QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162974  hs2  advanceView: { TC{ view: 0, IDs: [ ] } QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162975  hs2  advanceView: HighQC not updated, current view: 2968, new view: 2967
 162976  hs2  OnRemoteTimeout: not enough timeouts for view 2968, waiting for more
 162977  hs2  OnNewView (from network: false)
 162978  hs2  advanceView: { TC{ view: 2968, IDs: [ 1 4 3 ] } QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162979  hs2  advanceView: HighQC not updated, current view: 2968, new view: 2967
 162980  hs2  advanceView: Advanced to view 2969
 162981  hs2  CollectVote: dispatching event for new view (current : 2969)
 162982  hs2  TryCommit: Block{ hash: Ug59RLs5 parent: I4nQWOAp, proposer: 2, view: 2969 , cert: QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162985  hs2  CollectVote(from 4): 20K2ZNLO
 162986  hs2  OnRemoteTimeout (advancing view): ID: 4, View: 2968, SyncInfo: { TC{ view: 0, IDs: [ ] } QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162987  hs2  advanceView: { TC{ view: 0, IDs: [ ] } QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162988  hs2  advanceView: HighQC not updated, current view: 2969, new view: 2967
 162989  hs2  OnRemoteTimeout: not enough timeouts for view 2968, waiting for more
 162990  hs2  OnNewView (from network: false)
 162991  hs2  advanceView: { TC{ view: 2968, IDs: [ 1 4 3 ] } QC{ hash: I4nQWOAp, view: 2967, IDs: [ 1 4 3 ] } }
 162992  hs2  advanceView: HighQC not updated, current view: 2969, new view: 2967
 162994  hs2  OnNewView (from network: false)
 162995  hs2  advanceView: { QC{ hash: 20K2ZNLO, view: 2968, IDs: [ 2 1 3 ] } }
 162996  hs2  advanceView: Successfully updated HighQC
```

## E4 · main_2.log, view 897 (collector hs3): votes for B_897 that reach the collector (all lines of this hash) - lines 49321-49888

The collector hs3 receives one vote for B_897, from replica 2, logs `Local cache miss for block` for it (it does not know B_897) and sees the same vote line again at 49887. No second vote line reaches hs3, so no QC for view 897 exists (class X).

```
  49321  hs3  CollectVote(from 2): nV+NRgFy
  49322  hs3  Local cache miss for block: nV+NRgFy
  49887  hs3  CollectVote(from 2): nV+NRgFy
```

## E5 · main_4.log, hs4: B_1673 arrives before B_1672 ('Delaying proposal until after next view change') - lines 91414-91444, hs4 only

hs4 receives B_1673 while it is still in view 1672 and logs `Delaying proposal until after next view change`. B_1672 arrives afterwards (91427), its attached QC_1671 is processed (91429, 91436), and hs4 accepts and votes for it (`TryCommit`, 91437). No vote is lost.

```
  91419  hs4  advanceView: Successfully updated HighQC
  91421  hs4  advanceView: Advanced to view 1672
  91422  hs4  Delaying proposal until after next view change (proposal view 1673 > local view 1672)
  91423  hs4  OnNewView (from network: false)
  91424  hs4  advanceView: { QC{ hash: I+WYIMx4, view: 1670, IDs: [ 4 3 2 ] } }
  91425  hs4  advanceView: HighQC not updated, current view: 1672, new view: 1670
  91427  hs4  Received proposal: Block{ hash: 65UePSSX parent: LJlyJ3vs, proposer: 1, view: 1672 , cert: QC{ hash: LJlyJ3vs, view: 1671, IDs: [ 1 3 4 ] } }
  91429  hs4  advanceView: { QC{ hash: LJlyJ3vs, view: 1671, IDs: [ 1 3 4 ] } }
  91436  hs4  advanceView: HighQC not updated, current view: 1672, new view: 1671
  91437  hs4  TryCommit: Block{ hash: 65UePSSX parent: LJlyJ3vs, proposer: 1, view: 1672 , cert: QC{ hash: LJlyJ3vs, view: 1671, IDs: [ 1 3 4 ] } }
```

## E6 · main.log, hs1: B_397 reaches hs1 after hs1 has already voted in view 398 - lines 21940-21982, hs1 only

hs1 receives B_398 first, processes QC_397, enters view 398 and votes (21948-21954). B_397 arrives later (21974); hs1 rejects it with `failed to verify incoming vote: block view 397 too old, last voted view was 398` (21980) and does not vote. This is the reason for the `DECIDE` difference at view 397 (Part 3).

```
  21944  hs1  advanceView: Successfully updated HighQC
  21945  hs1  advanceView: Advanced to view 397
  21946  hs1  Delaying proposal until after next view change (proposal view 398 > local view 397)
  21948  hs1  Received proposal: Block{ hash: YsJHfcSL parent: S1XFIJk9, proposer: 3, view: 398 , cert: QC{ hash: S1XFIJk9, view: 397, IDs: [ 3 2 4 ] } }
  21950  hs1  advanceView: { QC{ hash: S1XFIJk9, view: 397, IDs: [ 3 2 4 ] } }
  21951  hs1  advanceView: HighQC not updated, current view: 397, new view: 397
  21953  hs1  advanceView: Advanced to view 398
  21954  hs1  TryCommit: Block{ hash: YsJHfcSL parent: S1XFIJk9, proposer: 3, view: 398 , cert: QC{ hash: S1XFIJk9, view: 397, IDs: [ 3 2 4 ] } }
  21970  hs1  OnNewView (from network: false)
  21971  hs1  advanceView: { QC{ hash: WbM5l6fd, view: 395, IDs: [ 2 1 4 ] } }
  21972  hs1  advanceView: HighQC not updated, current view: 398, new view: 395
  21974  hs1  Received proposal: Block{ hash: S1XFIJk9 parent: dYdWp41c, proposer: 2, view: 397 , cert: QC{ hash: dYdWp41c, view: 396, IDs: [ 2 1 3 ] } }
  21975  hs1  advanceView: { QC{ hash: dYdWp41c, view: 396, IDs: [ 2 1 3 ] } }
  21979  hs1  advanceView: HighQC not updated, current view: 398, new view: 396
  21980  hs1  failed to verify incoming vote: block view 397 too old, last voted view was 398
```
