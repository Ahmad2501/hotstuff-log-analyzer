#!/usr/bin/env python3
"""Evidence-based HotStuff comparison. Run: python analyze_hotstuff.py"""
import re,csv,json,collections,statistics
from pathlib import Path
FILES=[Path('/mnt/data/main(8).log'),Path('/mnt/data/main_2(4).log'),Path('/mnt/data/main_3(4).log'),Path('/mnt/data/main_4(4).log')]
OUT=Path('/mnt/data/hotstuff_analysis');OUT.mkdir(exist_ok=True)
EVENTS={
 'block_too_old':r'block too old', 'failed_sync':r'Failed to verify sync info',
 'local_timeout':r'\bOnLocalTimeout$', 'remote_timeout':r'OnRemoteTimeout \(advancing view\)',
 'not_enough_timeouts':r'OnRemoteTimeout: not enough timeouts',
 'liveness_failed':r'VoteRule: liveness condition failed',
 'highqc_updated':r'advanceView: Successfully updated HighQC',
 'highqc_not_updated':r'advanceView: HighQC not updated',
 'advanced':r'advanceView: Advanced to view \d+',
 'proposal_received':r'Received proposal: Block\{',
 'propose':r'\bPropose$', 'collect_vote':r'CollectVote\(from \d+\):',
 'newview':r'OnNewView \(', 'qc_dispatch':r'CollectVote: dispatching event for new view',
 'precommit':r'CommitRule - PRE_COMMIT:', 'commit':r'CommitRule - COMMIT:',
 'decide':r'CommitRule - DECIDE:', 'exec':r'\bEXEC: Block',
 'remote_second':r'OnRemoteTimeout \(second advance\)',
 'stopped_vote':r'Stopped voting for timed out view',
 'verify_vote_failure':r'failed to verify incoming vote',
 'tc_failure':r'Failed to create sync info: failed to create timeout certificate',
}
PATS={k:re.compile(p,re.I if k=='block_too_old' else 0) for k,p in EVENTS.items()}
BR=re.compile(r'Block\{ hash: (\S+) parent: (\S+), proposer: (\d+), view: (\d+)\s*, cert: QC\{ hash: (\S+), view: (\d+), IDs: \[([^\]]*)\]')
VOTE=re.compile(r'CollectVote\(from (\d+)\): (\S+)')
HOST=re.compile(r'\ths([1-4])\t')
ADV=re.compile(r'Advanced to view (\d+)')
REM=re.compile(r'OnRemoteTimeout \(advancing view\): ID: (\d+), View: (\d+)')
LOCALVIEW=re.compile(r'OnLocalTimeout: (\d+)')
QCVIEW=re.compile(r'QC\{ hash: (\S+), view: (\d+)')
VIEWFAIL=re.compile(r'block view (\d+)')

def csvout(name,rows,fields):
 with open(OUT/name,'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

runs=[]; allcounts=[]; allvote=[]; allview=[]; allrep=[]; allorder=[]; alltimeouts=[]; blocks_all=[]
for run,path in enumerate(FILES,1):
 counts=collections.Counter(); byrep=collections.defaultdict(collections.Counter)
 blocks={}; events_by_view=collections.defaultdict(collections.Counter)
 raw_votes=collections.defaultdict(list); raw_recv=collections.defaultdict(list)
 raw_events=[]; byrep_adv=collections.defaultdict(list)
 timeout_records=[]; views_proposers=collections.defaultdict(set)
 total=0
 with path.open(errors='replace') as f:
  for ln,line in enumerate(f,1):
   total=ln
   host=HOST.search(line);host=int(host.group(1)) if host else None
   msg=line.rsplit('\t',1)[-1].strip()
   event=None
   for k,p in PATS.items():
    if p.search(msg):
     counts[k]+=1
     if host:byrep[host][k]+=1
     event=k; break
   bm=BR.search(msg)
   if bm:
    bh,parent,proposer,view,qch,qcv,qcids=bm.groups();view=int(view);proposer=int(proposer);qcv=int(qcv)
    blocks.setdefault(bh,{'hash':bh,'parent':parent,'proposer':proposer,'view':view,'qc_hash':qch,'qc_view':qcv,'qc_ids':qcids.strip(),'first_line':ln})
    views_proposers[view].add(proposer)
    if event:events_by_view[view][event]+=1
    if event=='proposal_received':raw_recv[(host,bh)].append(ln)
   if event=='collect_vote':
    vm=VOTE.search(msg)
    if vm:raw_votes[(host,vm.group(2))].append((ln,int(vm.group(1))))
   if event=='advanced':
    a=ADV.search(msg)
    if a:
     v=int(a.group(1));byrep_adv[host].append((ln,v));events_by_view[v]['advanced_into']+=1
     raw_events.append((ln,host,'advanced',v,None))
   if event=='local_timeout':
    raw_events.append((ln,host,'local_timeout',None,None))
   if event=='remote_timeout':
    rm=REM.search(msg)
    if rm:
     sender,v=map(int,rm.groups());timeout_records.append({'run':run,'line':ln,'host':host,'kind':'remote','view':v,'sender':sender})
     events_by_view[v]['remote_timeout']+=1
   if event=='not_enough_timeouts':
    # map to most recent remote timeout by this host, within 12 lines
    recent=next((r for r in reversed(timeout_records) if r['host']==host and ln-r['line']<=15),None)
    if recent:events_by_view[recent['view']]['not_enough_timeouts']+=1
   if event=='stopped_vote':
    m=re.search(r'view (\d+)',msg)
    if m:events_by_view[int(m.group(1))]['stopped_vote']+=1
   if event=='verify_vote_failure':
    m=VIEWFAIL.search(msg)
    if m:events_by_view[int(m.group(1))]['verify_vote_failure']+=1
   if event=='qc_dispatch':
    m=re.search(r'current\s*:\s*(\d+)',msg)
    if m:events_by_view[int(m.group(1))]['qc_dispatch']+=1
   if event=='highqc_not_updated':
    m=re.search(r'current view: (\d+), new view: (\d+)',msg)
    if m:events_by_view[int(m.group(1))]['highqc_not_updated']+=1
   if event=='block_too_old':
    m=re.search(r'view (\d+)',msg)
    if m:events_by_view[int(m.group(1))]['block_too_old']+=1
 # infer local timeout view: explicit following `OnLocalTimeout: v` for same replica within 10 lines, else latest advanced
 for line,host,kind,_,_ in raw_events:
  if kind!='local_timeout':continue
  # nearest available advanced earlier than timeout (binary search)
  import bisect
  ar=byrep_adv[host];ix=bisect.bisect_right(ar,(line,10**9))-1
  v=ar[ix][1] if ix>=0 else 1
  timeout_records.append({'run':run,'line':line,'host':host,'kind':'local_inferred','view':v,'sender':host})
  events_by_view[v]['local_timeout_inferred']+=1
 # assign hashed votes to views
 seqs=[];vote_by_rep=collections.defaultdict(collections.Counter)
 for (host,bh), seq in raw_votes.items():
  block=blocks.get(bh)
  if not block:continue
  v,p=block['view'],block['proposer'];events_by_view[v]['collect_vote']+=len(seq)
  for ln,from_id in seq:vote_by_rep[from_id]['sent_vote_seen']+=1
  first_unique=[];seen=set()
  for line,from_id in seq:
   if from_id not in seen: first_unique.append((line,from_id));seen.add(from_id)
  complete=len(seen)==4
  entry={'run':run,'receiver':host,'hash':bh,'view':v,'proposer':p,'count':len(seq),'unique_count':len(seen),'complete':int(complete),'order':'-'.join(str(s) for _,s in first_unique),'first':first_unique[0][1] if first_unique else None,'last':first_unique[-1][1] if first_unique else None,'first_line':first_unique[0][0] if first_unique else None,'last_line':first_unique[-1][0] if first_unique else None,'duplicate_count':len(seq)-len(seen)}
  seqs.append(entry)
  if complete:
   events_by_view[v]['complete_vote_sequences']+=1
   for pos,(_,sender) in enumerate(first_unique):
    vote_by_rep[sender]['complete_position_'+str(pos+1)]+=1
   vote_by_rep[entry['first']]['first']+=1;vote_by_rep[entry['last']]['last']+=1
 for v,ps in views_proposers.items():
  events_by_view[v]['distinct_proposers']=len(ps)
  events_by_view[v]['distinct_blocks']=len(set(b for b,x in blocks.items() if x['view']==v))
  events_by_view[v]['proposals_receipts']=sum(len(lines) for (host,bh),lines in raw_recv.items() if blocks[bh]['view']==v)
  if len(ps)==1:events_by_view[v]['proposer']=next(iter(ps))
 for x in blocks.values():
  x['run']=run; blocks_all.append(x)
 for s in seqs:allvote.append(s)
 for v,c in events_by_view.items():
  allview.append({'run':run,'view':v,**c})
 for r in range(1,5):
  allrep.append({'run':run,'replica':r,**byrep[r],**vote_by_rep[r]})
 for t in timeout_records:alltimeouts.append(t)
 allcounts.append({'run':run,'file':path.name,'lines':total,'views_with_blocks':len(views_proposers),'max_block_view':max(views_proposers),'blocks':len(blocks),'vote_sequences':len(seqs),'complete_sequences':sum(s['complete'] for s in seqs),'timeout_views':len({t['view'] for t in timeout_records}),**counts})
 runs.append({'run':run,'file':path.name,'blocks':blocks,'seqs':seqs,'views':events_by_view,'byrep':byrep,'votes':vote_by_rep,'timeouts':timeout_records,'receipts':raw_recv})
 print('parsed run',run,total,'lines',len(blocks),'blocks',len(seqs),'sequences',flush=True)
fields=['run','file','lines','views_with_blocks','max_block_view','blocks','vote_sequences','complete_sequences','timeout_views',*EVENTS.keys()]
csvout('event_counts.csv',allcounts,fields)
csvout('vote_sequences.csv',allvote,['run','receiver','hash','view','proposer','count','unique_count','complete','order','first','last','first_line','last_line','duplicate_count'])
csvout('per_view.csv',allview,['run','view','proposer','distinct_proposers','distinct_blocks','proposals_receipts',*EVENTS.keys(),'advanced_into','local_timeout_inferred','complete_vote_sequences'])
csvout('per_replica.csv',allrep,['run','replica',*EVENTS.keys(),'sent_vote_seen','first','last',*['complete_position_'+str(i) for i in range(1,5)]])
csvout('timeouts.csv',alltimeouts,['run','line','host','kind','view','sender'])
csvout('blocks.csv',blocks_all,['run','hash','parent','proposer','view','qc_hash','qc_view','qc_ids','first_line'])
# first & last per-run and combined
orderrows=[]
for run in [1,2,3,4,0]:
 seq=[s for s in allvote if s['complete'] and (run==0 or s['run']==run)]
 for receiver in [0,1,2,3,4]:
  sub=[s for s in seq if receiver==0 or s['receiver']==receiver]
  for sender in range(1,5):
   orderrows.append({'run':'combined' if run==0 else run,'receiver':'all' if receiver==0 else receiver,'sender':sender,'complete_sequences':len(sub),'first':sum(s['first']==sender for s in sub),'last':sum(s['last']==sender for s in sub),'first_pct':round(100*sum(s['first']==sender for s in sub)/len(sub),2) if sub else 0,'last_pct':round(100*sum(s['last']==sender for s in sub)/len(sub),2) if sub else 0})
csvout('vote_positions.csv',orderrows,['run','receiver','sender','complete_sequences','first','last','first_pct','last_pct'])
# paired view aggregation for matched only
common=set.intersection(*[set(r['views']) for r in runs]);both=set.intersection(*[set(r['blocks'][b]['view'] for b in r['blocks']) for r in runs]);
for view in sorted(common):
 for r in runs:
  pass
# order pattern frequency / same view and proposer
pattern_rows=[]
for group_name,group in [('view',lambda s:(s['view'],)),('view_proposer',lambda s:(s['view'],s['proposer']))]:
 keyed=collections.defaultdict(lambda:collections.defaultdict(list))
 for s in allvote:
  if s['complete']:keyed[group(s)][s['run']].append(s)
 for key,perrun in keyed.items():
  if len(perrun)!=4:continue
  patterns=[collections.Counter(s['order'] for s in perrun[i]) for i in range(1,5)]
  shared=set.intersection(*(set(x) for x in patterns))
  pattern_rows.append({'matching':group_name,'view':key[0],'proposer':key[1] if len(key)>1 else '', 'common_orders':len(shared),'same_order_all_runs':int(bool(shared)),'run1_orders':'/'.join(sorted(patterns[0])),'run2_orders':'/'.join(sorted(patterns[1])),'run3_orders':'/'.join(sorted(patterns[2])),'run4_orders':'/'.join(sorted(patterns[3]))})
csvout('matched_vote_orders.csv',pattern_rows,['matching','view','proposer','common_orders','same_order_all_runs','run1_orders','run2_orders','run3_orders','run4_orders'])
# view and qc link validation for every distinct block
validation=collections.Counter();examples=collections.defaultdict(list)
for b in blocks_all:
 if b['view']>1:
  k='parent_hash_matches_qc_hash' if b['parent']==b['qc_hash'] else 'parent_hash_differs_from_qc_hash'
  validation[k]+=1
  if len(examples[k])<5:examples[k].append((b['run'],b['view'],b['hash'],b['first_line']))
  k='parent_qc_previous_view' if b['qc_view']==b['view']-1 else 'parent_qc_nonconsecutive_view'
  validation[k]+=1
  if len(examples[k])<10:examples[k].append((b['run'],b['view'],b['hash'],b['qc_view'],b['first_line']))
# output summary
summary={'runs':allcounts,'common_views_all_events':len(common),'common_views_with_proposal':len(both),'common_proposal_view_min':min(both),'common_proposal_view_max':max(both),'total_complete_sequences':sum(s['complete'] for s in allvote),'complete_sequences_by_receiver':dict(collections.Counter(s['receiver'] for s in allvote if s['complete'])),'matched_orders':{k:{'matched':sum(r['matching']==k for r in pattern_rows),'shared':sum(r['matching']==k and r['same_order_all_runs'] for r in pattern_rows)} for k in ['view','view_proposer']},'validation':dict(validation),'validation_examples':dict(examples)}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2)[:10000]);print('outputs',OUT)
